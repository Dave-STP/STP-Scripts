#--------------------------------------------------------------------
#------------ PR05 - Audit QA File.py -------------------------------
#--------------------------------------------------------------------

import sys
import os
import time
from collections import OrderedDict
from pyrevit import script

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


##---Constants brought from main script
Lib_Path = revit_library_path
local_mode = local_version
##-------------------------------------

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

tab_function_path = os.path.join(functions_path,"Project Admin Tab")
sys.path.append(tab_function_path)
import STP_PR_Functions
from STP_PR_Functions import *

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")

 


#Debug bypass
#================================================================
#if user_name != "Rafael":
#    forms.alert("This tool is under revision. Will be back soon")
#    sys.exit()
#================================================================
revit_version = __revit__.Application.VersionNumber[2:]
current_date = datetime.fromtimestamp(time.time()).date()

#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
rvt_Data = get_project_info(doc)
if rvt_Data:
    p_Numb = rvt_Data["Project Number"]
    p_Address = rvt_Data["Project Address"]
    if not p_Numb:
        sys.exit()
    
    if not re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE):
        forms.alert(
            "Project Number for this file doesn't match 'STPYY-0000' standard code",
            exitscript = True
        )
    
    p_Suburb = rvt_Data["Suburb"]
    
    if p_Suburb == "N/F":
        split_addres = p_Address.split(", ")
        rvt_Data["Project Address"] = split_addres[0]
        p_Suburb = rvt_Data["Suburb"] = split_addres[1]
        p_Pcode = rvt_Data["Postcode"] = split_addres[3]

projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
p_numb_found = False
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)


p_Numb, code_name, p_Path = selected_project
p_Name = code_name.replace(" - Documents", "").upper().replace("MCDON","McDON")

#--------------------------------------------------------------------
#----------- READ QA FILE -------------------------------------------
#--------------------------------------------------------------------
qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb)

if qa_info_exists:
    while confirm_file_is_not_opened(qa_path):
        file_name = os.path.basename(qa_path)

        action = forms.alert(
            "The QA Excel file '{}' is currently open or being used by another process.\n\n"
            "Please close the file and select 'Try Again'.\n\n"
            "If the file is not visibly open, Microsoft Excel may still be running in the background. "
            "Open Task Manager, check for any Microsoft Excel processes, and close them before trying again."
            .format(file_name),
            title="QA File In Use",
            options=[
                "Try Again",
                "Cancel"
            ]
        )

        if action != "Try Again":
            sys.exit()
        
    qa_Data = read_qa_excel_file_V2(qa_path)
    qa_Data["Project Number"] = p_Numb
    
    if qa_Data:
        p_Name = qa_Data["Project Name"]
        p_Client = qa_Data["Client Name"]
        p_Address = qa_Data["Project Address"]
        p_Suburb = qa_Data["Suburb"]
        p_Pcode = qa_Data["Postcode"]
        tb_Name = qa_Data["tb_Name"]
        tb_Type = qa_Data["tb_Type"]
        tb_Side = qa_Data["tb_Side"]
        tb_Size = qa_Data["tb_Size"]
        last_user = qa_Data["last_user"]
        first_user = qa_Data["first_user"]
        qa_type = qa_Data["pr_type"]
        qa_version = qa_Data["revit_version"]
        tb_target_path = os.path.join(p_Path,"Drawings","xref",tb_Name)
    
    if qa_Data["pr_type"] == "[PG]" and p_Suburb == "N/A":
        mssg = "The QA Check List for this project is not compatible with new STP Tools QA Format.\n\n" + \
               "Please execute edit Project parameters to update a compatible Project Address Format"
        forms.alert(mssg)
        sys.exit()
    
else:
    forms.alert(
        "No QA Checklist file is currently associated with this project number.\n\n"
        "Please use the 'New File' tool to create or assign the QA Checklist file before continuing.",
        title="QA Checklist Not Found",
        exitscript = True
    )

#--------------------------------------------------------------------
#----------- COMPARE INFORMATION ------------------------------------
#--------------------------------------------------------------------
result = compare_data_maps(qa_Data, rvt_Data)
Lines = []
incorrect_list = []

Lines.append("PROJECT NUMBER: > > > {} - Audit Report.".format(p_Numb))
Lines.append(title_for_drawings("- - - REPORT  SUMMARY - - -"))

#print(qa_Data)
#print("-----------")
#print(rvt_Data)
#sys.exit()


qa_full_address = qa_Data["Project Address"] + ", " + qa_Data["Suburb"] + ", QLD, " + qa_Data["Postcode"]
pr_full_address = rvt_Data["Project Address"] + ", " + rvt_Data["Suburb"] + ", QLD, " + rvt_Data["Postcode"]

compare_data = OrderedDict([
    ("Project_Name:", [qa_Data["Project Name"], rvt_Data["Project Name"]]),
    ("Pr.__Address:", [qa_full_address, pr_full_address]),
    ("Client_Name_:", [qa_Data["Client Name"], rvt_Data["Client Name"]]),
    ("Client Ref._:", [qa_Data["Client Reference Number"], rvt_Data["Client Reference Number"]]),
    ("Qbuild Ref._:", [qa_Data["Qbuild Project Number"], rvt_Data["Qbuild Project Number"]])
])

#print(compare_data)
#sys.exit()


#1 Check project information
for key, item in compare_data.items():
    if item[0] == item[1]:
        if key == "Client Ref.:" or key == "Qbuild Ref._:":
            if item[0] == "":
                Lines.append(key + " __N/A___ >> ")
                continue
        Lines.append(key + " __PASS__ >> " + item[1])
    else:
        Lines.append("{} __FAIL__ >> See Details Below.".format(key))
        incorrect_list.append(
            "\n" + key.replace("_","") + "\n"
            + "--Current File : " + item[1] + "\n"
            + "--QA Data File : " + item[0] + "\n"
        )


#2 Check title block
qa_tb_name = qa_Data["tb_Name"]
if not "signatures" in qa_tb_name:
    qa_tblock_path = os.path.join(p_Path, "Drawings", "xref", qa_tb_name)

    tb_ok = True
    if os.path.exists(qa_tblock_path):
        Lines.append("Title Block_: __PASS__ >> Saved Correctly in the Xref folder.")
        
    else:
        Lines.append("Title Block_: __FAIL__ >> Title block file was not found in the Xref folder.")
        incorrect_list.append("Title Block " + qa_tb_name + " not found in xrev folder.\n")


#3 Check if the tblock is in project and if all drawings have that title block
not_matching_tblocks, missing_initials = check_title_blocks(doc, qa_tb_name)

if not_matching_tblocks:
    Lines.append("Title Block_: __FAIL__ >> One or more drawing sheets use an incorrect title block.")

    for item in not_matching_tblocks:
        incorrect_list.append(
                "\nSheet Number: " + item[0] + "\n"
                + "--QA Title Block Name : " + qa_tb_name + "\n"
                + "--Current Title Block : " + item[1] + "\n\n"
            )
else:
    Lines.append("Title Block_: __PASS__ >> All drawing sheets use the correct title block.")


#4 Check for missing parameters in drawings
if missing_initials:
    Lines.append("Parameters__: __FAIL__ >> One or more required parameters are missing")
    incorrect_list.append("\nThe following drawings have missing parameters:\n")
    incorrect_list.extend(missing_initials)
else:
    Lines.append("Parameters__: __PASS__ >> All required parameters are present.")

#--------------------------------------------------------------------
#----------- CREATE OUTPUT REPORT -----------------------------------
#--------------------------------------------------------------------
output = script.get_output()
output.set_height(1000)
first_line = True

for line in Lines:
    if first_line:
        output.print_html(
            '<span style="font-weight:bold; font-size:20px; color:green;">'
            '{}</span>'.format(line)
        )
        first_line = False
    
    elif "=" in line:
        output.print_html(
            '<span style="font-weight:bold; font-size:16px;">'
            '{} <br></span>'.format(line)
        )
        
    elif "FAIL" in line:
        output.print_html(
            '<span style="font-weight:bold; font-size:18px; color:red;">'
            '{} <br></span>'.format(line)
        )
    
    else:
        output.print_html(
            '<span style="font-size:18px;">'
            '{} <br></span>'.format(line)
        )

if incorrect_list:
    output.print_html(
        '<span style="font-weight:bold; font-size:16px;">'
        '{}</span>'.format(title_for_drawings("- - - ERROR DETAILS - - -")
        )
    )


    for line in incorrect_list:
        output.print_html('<span style="font-size:18px;">'
            '{} <br></span>'.format(line)
        )
    

else:
    output.print_html(
        '<span style="font-weight:bold; font-size:18px; color:green;">'
        '{}</span>'.format("\n\nALL CORRECT")
    )
    
output.inject_script("window.scrollTo(0, 0);")



#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

#data = {
#    "time": start_time,
#    "p_numb": p_Numb,
#    "user": user_name,
##    "file": "Audit QA",
#    "items": "1"
#}
#track_data(Lib_Path, data, "PR05")