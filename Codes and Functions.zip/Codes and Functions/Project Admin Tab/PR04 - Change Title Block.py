#--------------------------------------------------------------------
#------------ PR04 - Change Title Block.py --------------------------
#--------------------------------------------------------------------

import sys
import os
import time
from pyrevit.forms import SelectFromList
from Autodesk.Revit.DB import ViewSheet, BuiltInCategory

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
local_mode = local_version
xaml_forms
##-------------------------------------

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import EditTitleBlock

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
revit_version = __revit__.Application.VersionNumber[2:]
current_date = datetime.fromtimestamp(time.time()).date()

#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
rvt_Data = get_project_info(doc)
if rvt_Data:
    p_Numb = rvt_Data["Project Number"]
    
    if not p_Numb:
        sys.exit()
    
    if not re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE):
        forms.alert(
            "Project Number for this file doesn't match 'STPYY-0000' standard code",
            exitscript = True
        )

    p_Suburb = rvt_Data["Suburb"]
    
projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
p_numb_found = False
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)


p_Numb, code_name, p_Path = selected_project
p_Name = code_name.replace(" - Documents", "").upper().replace("MCDON","McDON")

#--------------------------------------------------------------------
#----------- READ QA FILE -------------------------------------------
#--------------------------------------------------------------------
qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb)

if qa_info_exists:
    while confirm_file_is_not_opened(qa_path):
        file_name = os.path.basename(qa_path)

        action = forms.alert(
            "The QA Excel file '{}' is currently open or being used by another process.\n\n"
            "Please close the file and select 'Try Again'.\n\n"
            "If the file is not visibly open, Microsoft Excel may still be running in the background. "
            "Open Task Manager, check for any Microsoft Excel processes, and close them before trying again."
            .format(file_name),
            title="QA File In Use",
            options=[
                "Try Again",
                "Cancel"
            ]
        )

        if action != "Try Again":
            sys.exit()
        
    qa_Data = read_qa_excel_file_V2(qa_path)
    qa_Data["Project Number"] = p_Numb
    tb_Name = qa_Data["tb_Name"]
    tb_target_path = os.path.join(p_Path,"Drawings","xref",tb_Name)
    
    if qa_Data["pr_type"] == "[PG]" and p_Suburb == "N/A":
        mssg = "The QA Check List for this project is not compatible with new STP Tools QA Format.\n\n" + \
               "Please execute edit Project parameters to update a compatible Project Address Format"
        forms.alert(mssg)
        sys.exit()

else:
    forms.alert("QA file has not been created for this job yet.", exitscript = True)
    
#--------------------------------------------------------------------
#----------- PRE-FORM CHECK -----------------------------------------
#--------------------------------------------------------------------
p_Type = qa_Data["pr_type"]
T_Block_paths = {
    "[PG]": ["List_General Title block types.txt", 4],
    "[PR]": ["List_Residential Title block types.txt", 1],
    "[PM]": ["List_McDonalds Title block types.txt", 1]
    }
title_block_path = T_Block_paths[p_Type][0]
with open(os.path.join(Lib_Path, "Data Base", "List_no_replace_tblocks.txt"), 'r') as file:
    default_tblocks = [line.strip() for line in file]


# Get Title Block List
tbs_path = os.path.join(Lib_Path, "Data Base", title_block_path)
if os.path.exists(tbs_path):
    title_block_info = fill_titleblock_list(tbs_path)
    if title_block_info:
        tb_list = title_block_info[0]

if not os.path.exists(tbs_path) or not tb_list:
    mssg = "Error while reading title block lists from Data Base:\n\n" + \
           "Please contact STP Tool developer"
    forms.alert(mssg)
    sys.exit()

# Get sheets and title blocks to replace
sheets_collector = FilteredElementCollector(doc).OfClass(ViewSheet)
titleblocks_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_TitleBlocks).WhereElementIsNotElementType()

list_of_sheets_and_tblocks = []

for sheet in sheets_collector:
    sheet_number = sheet.SheetNumber
    # Get title blocks in the sheet
    titleblocks = [tb for tb in titleblocks_collector if tb.OwnerViewId == sheet.Id]
    for tb in titleblocks:
        # Get the name of the title block type
        tb_name = doc.GetElement(tb.GetTypeId()).Family.Name
        if not tb_name in default_tblocks:
            list_of_sheets_and_tblocks.append(sheet_number + " - " + tb_name)

supersd_path = os.path.join(p_Path, "Drawings", "xref", "superseded")

if not os.path.exists(supersd_path):
    try:
        os.makedirs(supersd_path)
    except:
        pass


#--------------------------------------------------------------------
#----------- EDIT GENERAL PROJECT FORM ------------------------------
#--------------------------------------------------------------------
qa_Data["tb_list"] = tb_list
qa_Data["tb_paths"] = T_Block_paths

# Activate the Form
form = EditTitleBlock(
    xaml_forms["main_form"], 
    Lib_Path, qa_Data
)

form.show_dialog()

if not form.process_go:
    sys.exit()


#--------------------------------------------------------------------
#----------- LOAD TITLE BLOCK IN PROJECT ----------------------------
#--------------------------------------------------------------------

stage = "Load Title Block"
tb_source_path = ""
tb_types_list = ["McDONALDS DM2", "McDONALDS I2C", "McDONALDS MPA", "McDONALDS MGT","QBUILD", "PAYNTERS"]
tb_code, tb_index = form.tblock_info
put_files_back = []

if "OTHER" in tb_code:
    tb_source_path = tb_index
    tb_Name = os.path.basename(tb_source_path)
    tb_Type = "CUSTOM TYPE"
    if "HORIZ" in tb_Name.upper():
        tb_Side = "HORIZONTAL"
    elif "VERT" in tb_Name.upper():
        tb_Side = "VERTICAL"
    else:
        tb_Side = "UNKNOWN"
    if "A1" in tb_Name.upper():
        tb_Size = "A1"
    elif "A0" in tb_Name.upper():
        tb_Size = "A0"
    elif "A3" in tb_Name.upper():
        tb_Size = "A3"
    else:
        tb_Size = "UNKNOWN"
    tb_target_path = os.path.join(p_Path, "Drawings","xref",tb_Name)
elif 'default' in tb_code:
    tb_Name = "STP_A3_HORIZONTAL (signatures added)"
    tb_Type = "STP SANDARD"
    tb_Side = "HORIZONTAL"
    tb_Size = "A3"
    tb_source_path = tb_target_path = ""
else:
    tb_source_path = os.path.join(Lib_Path.replace("STP Tools",""),title_block_info[1][tb_index])
    tb_Type = title_block_info[2][tb_index].replace(" = ","")
    tb_Side = "HORIZONTAL" if title_block_info[3][tb_index] == "H" else "VERTICAL"
    tb_Size = title_block_info[4][tb_index]
    
    if tb_Type == "STP STANDARD":
        if p_Type == "R":
            tb_Name = p_Numb + tb_code.replace("#","").replace("STP","") + " (signatures added).rfa"
        else:
            tb_Name = p_Numb + tb_code.replace("#","").replace("STP","") + ".rfa"
    elif tb_Type in tb_types_list:
        tb_Name = p_Numb + "_" + tb_code.replace("#","") + ".rfa"

    tb_target_path = os.path.join(p_Path, "Drawings","xref",tb_Name)

if tb_source_path and tb_target_path:
    action = load_title_block(doc, tb_source_path, tb_target_path)

if action:
    next_line = int(qa_Data["No"]) + 1
    next_line = str(next_line).replace(".0","")
    add_line = [next_line, qa_Data["Project Name"], qa_Data["Client Name"],
                qa_Data["Project Address"], qa_Data["Suburb"], qa_Data["Postcode"],
                tb_Name, tb_Type, tb_Side, tb_Size,
                user_name, revit_version, current_date]
                
else:
    mssg = "Error when getting new line. \n\nPlease contact STP Tools developer"
    forms.alert(mssg)
    sys.exit()

if "tb_history" in qa_Data:
    for fam_name in qa_Data["tb_history"]:
        if fam_name:
            current_path = os.path.join(p_Path, "Drawings", "xref", fam_name)
            supersd_path = os.path.join(p_Path, "Drawings", "xref", "superseded", fam_name.replace(".rfa","_SS.rfa"))
            if os.path.exists(current_path):
                try:
                    os.rename(current_path, supersd_path)
                except:
                    pass
else:
    mssg = "Error when getting title block History. \n\nPlease contact STP Tools developer"
    forms.alert(mssg)
    sys.exit()  

# endregion

#--------------------------------------------------------------------
#----------- REPLACE TITLE BLOCKS WITH NEW TB -----------------------
#--------------------------------------------------------------------

next_step = False
if any([form.optKeep.IsChecked, form.optDelete.IsChecked]):
    selected = SelectFromList.show(
        sorted(list_of_sheets_and_tblocks),
        title="Select Sheets to replace Title Block",
        multiselect=True,
        button_name='Replace these Title Blocks with: ' + tb_Name.replace('_', '__'),
        group_by_value=False
    )

    replace_items = []
    sheet_list = []
    tblock_list = []
    
    if selected:
        for select in selected:
            line = select.split(" - ")
            if line[0] not in sheet_list:
                sheet_list.append(line[0])
                if line[1] not in tblock_list:
                    tblock_list.append(line[1])

        
        if sheet_list:
            for tb in tblock_list:
                next_step = replace_title_block(doc, sheet_list, tb, tb_Name.replace(".rfa",""), 0, 0)


        delete_or_supersede_titleblock(
            doc,
            form.optDelete.IsChecked,
            tb_Name.replace(".rfa",""),
            qa_Data["tb_history"]
            )
    else:
        sys.exit()
else:
    if "tb_history" in qa_Data:
        supersed_tblock_family(qa_Data["tb_history"])


#--------------------------------------------------------------------
#----------- ADD LINE TO QA EXCEL FILE ------------------------------
#--------------------------------------------------------------------

extra_data = {
    "p_type": qa_Data["pr_type"],
    "ini_type": qa_Data["pr_type"]
}

result = write_qa_excel_file_V2(qa_path, "Modify", [add_line], extra_data)
if result:
    try:
        if doc.PathName: #Save to avoid problems
            doc.Save()
    except:
        pass

else:
    if os.path.exists(current_path) and os.path.exists(supersd_path):
        try:
            os.rename(current_path, supersd_path)
        except:
            pass


#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "change_tblock",
    "items": "1"
}
track_data(Lib_Path, data, "PR04")





    