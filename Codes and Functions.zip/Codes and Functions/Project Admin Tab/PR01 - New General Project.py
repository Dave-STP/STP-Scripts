#--------------------------------------------------------------------
#------------ PR01 - New General Project.py -------------------------
#--------------------------------------------------------------------

import sys
import os
import shutil
import time
import datetime
from datetime import datetime
from pyrevit import forms
from Autodesk.Revit.UI import UIDocument
from Autodesk.Revit.DB import FilteredElementCollector, Viewport, SaveAsOptions
from System.Windows.Forms import Application
from System.Threading import Thread

##---Constants brought from main script
Lib_Path = revit_library_path
discipline
local_mode = local_version
bin_folder
p_Type = proj_type
title_block_list_path = tblock_list_file
xaml_forms
##-------------------------------------

temp_folder = os.path.join(bin_folder, "Temp_drawings")
if not os.path.exists(temp_folder):
    os.makedirs(temp_folder)
else:
    try:
        clean_up_folder(temp_folder)
    except:
        pass


functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

tab_function_path = os.path.join(functions_path,"Project Admin Tab")
sys.path.append(tab_function_path)
import STP_PR_Functions
from STP_PR_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import *

tab_function_path = os.path.join(functions_path,"ACC Admin tab")
sys.path.append(tab_function_path)
import STP_ACC_Functions
from STP_ACC_Functions import *

tab_function_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(tab_function_path)
import STP_DOC_Functions
from STP_DOC_Functions import clean_up_folder, delete_files_when_fail

uidoc = __revit__.ActiveUIDocument
revit_version = __revit__.Application.VersionNumber[2:]
if uidoc:
    doc = uidoc.Document
    from_template = False
else:
    doc = None
    from_template = True

user_name = os.environ.get("USERNAME")
#if user_name != "Rafael":
#    forms.alert("This tool is under repair. Ii will be back soon")
#    sys.exit()

failed_list = []
moving_list = [] # List of files to move from temp folder in bin to project folder
    
save_info = {}
new_created_file_path = None # To storage revit file from template saved in bin folder temporal

#=============**********DELETE ME*************=======================
local_debug = False
if local_debug:
    local_mode = local_debug
    Lib_Path = r"C:\Users\Rafael.STPTSV\AppData\Roaming\pyRevit-Master\extensions\STP Tools.extension\bin"
    if not os.path.exists(Lib_Path):
        Lib_Path = r"C:\Users\Rafael.STPTSV\AppData\Roaming\pyRevit-Master\extensions\STP Tools.extension\bin"
#=============**********DELETE ME*************=======================

allow_current_job = uidoc is not None
if not uidoc and local_mode:
    forms.alert("Please open a new file from an SPT Template to continue")
    sys.exit()


form = NewFileOptionsForm(
    xaml_forms["new_file_form"],
    local_mode,
    discipline,
    allow_current_job
)

form.show_dialog()
if not form.process_go:
    sys.exit()

save_info = form.key_map # Contains info of the selected disciplines like folder 'Struct
if form.comb_models and len(save_info) > 1:
    combined_letters = ""
    for key, value in save_info.items():
        combined_letters += key[0]
    
    first_key = save_info.keys()[0]
    save_info = {"COMB_" + combined_letters: save_info[first_key]}

#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
projects = []
selected_folder = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
    
# Show Project Select Form
project_numbers = [project[0] + " - " + project[1] for project in projects]
selected_project = forms.SelectFromList.show(project_numbers, multiselect=False, title="Select a Project")


#--------------------------------------------------------------------
#----------- CREATE DISCIPLINE AND FOLDER KEY MAP -------------------
#--------------------------------------------------------------------
# Get basic information from folder name
if selected_project:
    selected_index = project_numbers.index(selected_project)  # Get the index of the selected project
    p_Numb = projects[selected_index][0]
    p_Code = projects[selected_index][1].replace(" - Documents", "").upper().replace("MCDON","McDON")
    p_Path = projects[selected_index][2]
    
    # Check if the folder has the standard folder structure or need to locate 'Drawings' folder manually.
    check_path = os.path.join(p_Path, "Drawings", "Issued Drawings")
    
    # Add values to dictionary
    file_names = []
    for key in save_info:
        aux_letters = key[5:] if key[:5] == "COMB_" else key[0].upper()
        name = p_Numb + "_" + aux_letters + "_RVT" + revit_version
        f_path = os.path.join(
            p_Path, "Drawings", "Current Drawings",
            save_info[key]["folder_name"], 
            name + ".rvt"
        )
        
        save_info[key]["file_name"] = name
        save_info[key]["file_path"] = f_path
        save_info[key]["std_folders"] = os.path.exists(check_path)
        save_info[key]["pr_number"] = p_Numb
        

    
else:
    sys.exit()


#--------------------------------------------------------------------
#----------- SET TEMPORARY FILE IF FROM TEMPLATE --------------------
#--------------------------------------------------------------------
if save_info:
    from_template = form.from_template
else:
    forms.alert("Error while choosing discipline and file source. Please contact STP Tool developer")
    sys.exit()

if from_template:
    template_path = find_stp_templates(Lib_Path, user_name)
    if template_path == None:
        sys.exit()
    
temp_path = os.path.join(temp_folder, p_Numb + "_TEMP.rvt")    


#--------------------------------------------------------------------
#----------- READ QA FILE -------------------------------------------
#--------------------------------------------------------------------
qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb)

if qa_info_exists:
    while confirm_file_is_not_opened(qa_path):
        file_name = os.path.basename(qa_path)

        action = forms.alert(
            "The QA Excel file '{}' is currently open or being used by another process.\n\n"
            "Please close the file and select 'Try Again'.\n\n"
            "If the file is not visibly open, Microsoft Excel may still be running in the background. "
            "Open Task Manager, check for any Microsoft Excel processes, and close them before trying again."
            .format(file_name),
            title="QA File In Use",
            options=[
                "Try Again",
                "Cancel"
            ]
        )

        if action != "Try Again":
            sys.exit()
        
    qa_Data = read_qa_excel_file_V2(qa_path)
    qa_Data["Project Number"] = p_Numb
    
    if qa_Data:
        p_Name = qa_Data["Project Name"]
        p_Client = qa_Data["Client Name"]
        p_Address = qa_Data["Project Address"]
        p_Suburb = qa_Data["Suburb"]
        p_Pcode = qa_Data["Postcode"]
        tb_Name = qa_Data["tb_Name"]
        tb_Type = qa_Data["tb_Type"]
        tb_Side = qa_Data["tb_Side"]
        tb_Size = qa_Data["tb_Size"]
        last_user = qa_Data["last_user"]
        first_user = qa_Data["first_user"]
        qa_type = qa_Data["pr_type"]
        qa_version = qa_Data["revit_version"]
        tb_target_path = os.path.join(p_Path,"Drawings","xref",tb_Name)
    
    if qa_Data["pr_type"] == "[PG]" and p_Suburb == "N/A":
        mssg = "The QA Check List for this project is not compatible with new STP Tools QA Format.\n\n" + \
               "Please execute edit Project parameters to update a compatible Project Address Format"
        forms.alert(mssg)
        sys.exit()

else:
    form_title = "Please fill in the blanks."
    result = split_address(Lib_Path, p_Code) #Check if the address is in the folder name
    empty_map = {
        "map_name": "Empty",
        "Project Number": p_Numb,
        "Project Name": p_Code,
        "Client Name": "",
        "Project Address": "FILL THIS BLANK",
        "Suburb": "FILL THIS BLANK",
        "Postcode": "0000",
        "Region": "",
        "Client Reference Number": "",
        "Qbuild Project Number": ""
    }
    
    if result[0] != "N/F":
        empty_map["Project Address"] = result[0]
        empty_map["Suburb"] = result[1]
        empty_map["Postcode"] = result[2]
        empty_map["Region"] = result[3]

    if p_Type == "[PR]":
        empty_map["Project Name"] = "NEW RESIDENCE AT"

#--------------------------------------------------------------------
#----------- PRE-FORM CHECK -----------------------------------------
#--------------------------------------------------------------------

# Stops the user from use a wrong project type for new projects.
if qa_info_exists:
    aux_text_old = p_Type.replace("P","")
    if p_Type != qa_type:
        if qa_type == "[PM]":
            aux_text = "McDonal's"
        elif qa_type == "[PR]":
            aux_text = "Residential"
        elif qa_type == "[PG]":
            aux_text = "General"
        
        mssg = (
            "This project was initially created as a " + aux_text + " type by " + first_user + ".\n\n" +
            "Please use: 'New " + aux_text + " Type' button to continue."
            )
        forms.alert(mssg)
        sys.exit()

# Stops the user from duplicate residential project.
if qa_info_exists and p_Type == "[PR]":
    mssg = (
        "This Residential Job has been already started by " + last_user + ":\n\n" +
        p_Name.capitalize() + "\n " + p_Address.title()  + "\n" +
        p_Suburb.title() + "\n" + str(p_Pcode).replace(".0","")  + ":\n\n" +
        "No New Projects are allowed for Residential Projects"
        )
    forms.alert(mssg)
    sys.exit()

# Check revit version against the qa revit version in qa_data
if qa_info_exists:
    if all([qa_version != revit_version, qa_version != "DWG"]):
        mssg = ("This project was started in Revit Version: 20" + qa_version + " by: " + first_user +
                ".\nCurrent Revit Version is 20" + revit_version + "\n\n" +
                "Do you want to Continue?")
        title = "Revit Version Confirmation"
        response = forms.alert(mssg, title="Confirmation", options=["Yes", "No"])
        if response == "No":
            sys.exit()

# Get Title Block List
tbs_path = os.path.join(Lib_Path, "Data Base", title_block_list_path)
if not os.path.exists(tbs_path):
    mssg = "Title block txt file not found in: \n\n" + tbs_path
    forms.alert(mssg)
    sys.exit()

title_block_info = fill_titleblock_list(tbs_path)
if not title_block_info:
    mssg = "Title block info not found"
    forms.alert(mssg)
    sys.exit()

tb_list = title_block_info[0]
if not tb_list:
    mssg = "Title block list not found"
    forms.alert(mssg)
    sys.exit()


#--------------------------------------------------------------------
#----------- OPEN SELECTED NEW PROJECT FORM -------------------------
#--------------------------------------------------------------------

if qa_info_exists:
    input_keymap = qa_Data
else:
    input_keymap = empty_map

input_keymap["tb_list"] = tb_list
input_keymap["user_name"] = user_name



# Activate the Form
if p_Type == "[PG]":
    form = GeneralProjectForm(xaml_forms["main_form"], Lib_Path, input_keymap)
elif p_Type == "[PR]":
    form = ResidentialProjectForm(xaml_forms["main_form"], Lib_Path, input_keymap)
elif p_Type == "[PM]":
    form = McDonaldsProjectForm(xaml_forms["main_form"], Lib_Path, input_keymap)
else:
    sys.exit()

form.show_dialog()

if not form.process_go:
    sys.exit()

#--------------------------------------------------------------------
#----------- OPEN SAVE OPTION FORMS ---------------------------------
#--------------------------------------------------------------------
acc_name = None
if doc:
    cloud_restrictions = [doc.IsModelInCloud, doc.IsWorkshared]
    save_action = get_save_action(save_info, from_template, cloud_restrictions)
else:
    save_action = get_save_action(save_info, from_template)

if not save_action:
    sys.exit()

if not "Allow" in save_action:
    for discipline, info in save_info.items():
        save_form = NewFileNameForm(
            xaml_forms["select_name"],
            discipline,
            info,
            save_action
        )
        
        acc_name = info["file_name"]
        
        save_form.show_dialog()
        if not save_form.process_go:
            break
                
    if not save_form.process_go:
        sys.exit()    
    
acc_file = acc_name if "ACC" in save_action else None

#--------------------------------------------------------------------
#----------- OPEN A NEW FILE FROM TEMPLATE IF REQUIRED --------------
#--------------------------------------------------------------------
if from_template:

    # Revit DB document
    doc = __revit__.Application.NewProjectDocument(
        template_path
    )
    
    save_options = SaveAsOptions()
    save_options.OverwriteExistingFile = True

    if not "Allow" in save_action:
        try:
            doc.SaveAs(temp_path, save_options)
            doc.Close(False)
            uidoc = __revit__.OpenAndActivateDocument(temp_path)
            doc = uidoc.Document
        except Exception as e:
            print(str(e))
            forms.alert("File couldn't save to temporal path", exitscript = True)
    
    else:
        uidoc = UIDocument(doc)
        viewport = (
            FilteredElementCollector(doc)
            .OfClass(Viewport)
            .WhereElementIsNotElementType()
            .FirstElement()
        )

        if viewport:
            uidoc.ShowElements(viewport.Id)       
    
#--------------------------------------------------------------------
#----------- FILL PROJECT PARAMETER IN REVIT ------------------------
# region ------------------------------------------------------------
if not doc:
    forms.alert("Error while finding an opened document, please contact STP Tools developer")
    sys.exit()

params = ["Project Number","Project Name","Project Address","Suburb", "Postcode",
          "Client Name", "Local Government Area", "Client Reference Number", "Qbuild Project Number"]

# Fill project information parameters
p_Name, p_Client, p_Address, p_Suburb, p_Pcode, p_State, p_Region, client_ref, qbuild_ref = form.project_info[0:9]

p_Name = p_Name.replace(",", "¸"[-1])
p_Client = p_Client.replace(",", "¸"[-1])
p_Address = p_Address.replace(",", "¸"[-1])
p_Suburb = p_Suburb.replace(",", "¸"[-1])


if p_Type == "[PR]":
    p_Name += (" AT" if p_Name[-3:] != " AT" else "")
    
# Check if proyect name has a non ascii *'*
p_Name = remove_non_ascii(p_Name)
    
values = [p_Numb, p_Name, p_Address, p_Suburb, str(p_Pcode).replace(".0",""), 
          p_Client, p_Region, client_ref, qbuild_ref]
list_to_change = zip(params, values)
fill_project_info(doc, list_to_change)

# Fill design parameters for Residential
initials = ""
if not qa_info_exists and p_Type == "[PR]":
    initials = fill_design_info(doc, form.design_info)

#--------------------------------------------------------------------
#----------- LOAD TITLE BLOCK IN PROJECT ----------------------------
#--------------------------------------------------------------------
tb_source_path = ""
action = False
change_resid_tblock = False
no_std_tb_type_list = ["McDONALDS DM2", "McDONALDS I2C", "McDONALDS MPA", 
                 "McDONALDS MGT","QBUILD", "PAYNTERS"]

if form.tblock_info:
    if not qa_info_exists:
        tb_code, tb_index = form.tblock_info
        if "OTHER" in tb_code:
            tb_source_path = tb_index
            tb_Name = os.path.basename(tb_source_path)
            tb_Type = "CUSTOM TYPE"
            if "HORIZ" in tb_Name.upper():
                tb_Side = "HORIZONTAL"
            elif "VERT" in tb_Name.upper():
                tb_Side = "VERTICAL"
            else:
                tb_Side = "UNKNOWN"
            if "A1" in tb_Name.upper():
                tb_Size = "A1"
            elif "A0" in tb_Name.upper():
                tb_Size = "A0"
            elif "A3" in tb_Name.upper():
                tb_Size = "A3"
            else:
                tb_Size = "UNKNOWN"

            tb_Name = p_Numb + "_" + tb_Name
            tb_target_path = os.path.join(p_Path, "Drawings","xref",tb_Name)

        elif not "Default" in tb_code:
            aux_path = title_block_info[1][tb_index]
            if local_mode:
                tb_source_path = os.path.join(Lib_Path, "STP Titleblocks", os.path.basename(aux_path))
            else:
                tb_source_path = os.path.join(Lib_Path.replace("STP Tools",""), title_block_info[1][tb_index]) 


            tb_Type = title_block_info[2][tb_index].replace(" = ","")
            tb_Side = "HORIZONTAL" if title_block_info[3][tb_index] == "H" else "VERTICAL"
            tb_Size = title_block_info[4][tb_index]

            if tb_Type == "STP STANDARD":
                if p_Type == "[PR]":
                    tb_Name = p_Numb + tb_code.replace("#","").replace("STP","") + " (signatures added).rfa"
                else:
                    tb_Name = p_Numb + tb_code.replace("#","").replace("STP","") + ".rfa"
            elif tb_Type in no_std_tb_type_list:
                tb_Name = p_Numb + "_" + tb_code.replace("#","") + ".rfa"

            tb_target_path = os.path.join(p_Path, "Drawings","xref",tb_Name)
            change_resid_tblock = True
            
        elif 'Default' in tb_code:
            tb_Name = "STP_A3_HORIZONTAL (signatures added)"
            tb_Type = "STP STANDARD"
            tb_Side = "HORIZONTAL"
            tb_Size = "A3"
            tb_source_path = tb_target_path = ""
        else:
            tb_source_path = tb_target_path = ""

    else:
        tb_source_path = "QA_data"
        change_resid_tblock = True
        if revit_version == "DWG":
            tb_create_item = tb_Type.replace("STP STANDARD","STP_").replace("QBUILD","BAS_").replace("PAYNTERS","PYT_").replace("McDONLDS IC2","IC2_").replace("McDONLDS DM2","Dm2_")
            tb_create_item += tb_Size + "_" + tb_Side
            tb_create_index = indexOf(title_block_info[0],tb_create_item)
            tb_source_path = os.path.join(Lib_Path.replace("STP Tools",""),title_block_info[1][tb_create_index])
            tb_Name = p_Numb + "_" + tb_create_item + ".rfa"
            tb_target_path = os.path.join(p_Path, "Drawings","xref",tb_Name)

    if change_resid_tblock and not p_Type == "[PR]":
        
        result = load_title_block(doc, tb_source_path, tb_target_path)
        if result:
            failed_list.append(result[1])

    if p_Type == "[PM]":
        dx = 0
        dy = 0
        data = replace_title_block(
            doc, "ALL",
            "A3 Empty Titleblock",
            tb_Name.replace(".rfa",""), dx, dy)
        if not data:
            forms.alert("Error while replacing title block.\n\nNot all title block were automatically replaced. You might need to replace manually", "Error While replacing titleblocks", options=["OK"])


#--------------------------------------------------------------------
#----------- CREATE AND/OR OPEN FINAL EXCEL -------------------------
#--------------------------------------------------------------------
add_line = []
mssg = ""

if not qa_info_exists:
    qa_folder = os.path.join(p_Path, "Drawings")
    if not os.path.exists(qa_folder):
        os.path.makedirs(qa_folder)
    qa_path = os.path.join(qa_folder, p_Numb + "_QA_Checklist.xlsx")
    qa_source_path = os.path.join(Lib_Path,"Data Base","QA_Check List - V2.xlsx")

    try:
        shutil.copyfile(qa_source_path, qa_path)
    except Exception as e:
        failed_list.append(qa_path)
        delete_files_when_fail(failed_list)
        print(aborting_message("MN0001", "ERROR WHILE COPYING QA CHECK LIST FILE FROM REVIT LIBRARY."))
        
    first_time = time.time()
    current_date = datetime.fromtimestamp(first_time).date()
    add_line = [1, p_Name, p_Client, p_Address, p_Suburb, p_Pcode, tb_Name, 
               tb_Type, tb_Side, tb_Size, user_name, revit_version, current_date]
    
    extra_data = {
        "p_type": p_Type,
        "initials": initials,
        "ref_client": client_ref,
        "ref_qbuild": qbuild_ref,
        "acc_file": acc_file
    }
    
    result = write_qa_excel_file_V2(qa_path, "Create", [add_line], extra_data)

    if not result:
        forms.alert(
            "Error while creating or saving excel QA file. "
            "Please contact STP Tools developer for further assistance"
        )
        failed_list.append(qa_path)
        delete_files_when_fail(failed_list)
        print(aborting_message("MN0002", "ERROR WHILE WRITTING QA CHECK LIST FILE."))
    
    # Create a print preference file for residential.
    if p_Type == "[PR]":
        source_path = os.path.join(Lib_Path, "Data Base", "issue_print_preferences - Residential.txt")
        target_folder = os.path.join(os.path.dirname(qa_path), "xref")
        target_path = os.path.join(target_folder, "issue_print_preferences.txt")
        if os.path.exists(source_path) and os.path.exists(target_folder):
            shutil.copy2(source_path, target_path)

        
#--------------------------------------------------------------------
#----------- SAVE FILE IN CURRENT OR CLOUD --------------------------
#--------------------------------------------------------------------
no_saved_files = [] 
with forms.ProgressBar(title="Creating and Saving Revit Files.") as pb:
    pb.update_progress(0.75, 1)

    #----------- CONTINUE WITHOUT SAVING ---------------
    if "manually" in save_action:
        forms.alert(
            "All done, {}. Please save the file manually."
            "".format(user_name)
        )

    #----------- SAVE IN Autodesk Construction Cloud --------------------
    elif "Forma" in save_action:
        token_data = get_token()
        access_token = token_data["access_token"]
        existing_project = find_project_by_job_number_api(access_token, p_Numb)
        if not existing_project:
            forms.alert(
                "Project Number {} not found in ACC.\n\nPlease create the ACC project first.".format(p_Numb),
                exitscript=True
            )
        else:
            existing_project_id = get_project_id(existing_project)
            project_name = get_project_name(existing_project)

        try:
            ACCOUNT_ID = get_hub_id()
            account_guid = Guid(ACCOUNT_ID)
            project_guid = Guid(to_guid_string(existing_project_id))
        except:
            forms.alert("Neccesary Ids for this project were not found. Please contact STP developer for furhter support", exitscript=True)
            
        confirm = forms.alert(
            "This model will be saved to the cloud under the following "
            "project:\n\n{}".format(project_name.replace(" - ","\n")),
            title="Saving File Confirmation",
            options=["Continue to Save", "Cancel"]
        )
        
        if not confirm == "Continue to Save":
            sys.exit()   

        for discipline, info in save_info.items():
            file_name = info["file_name"]
            sub_folder_name = "STP-Structural" if "S" in discipline else "STP-Services"
            top_folder_name = "Project Files"
            
            # Prepare IDs for ACC API
            hub_id = ACCOUNT_ID
            if not hub_id.startswith("b."):
                hub_id = "b." + hub_id

            project_id_dm = existing_project_id
            if not project_id_dm.startswith("b."):
                project_id_dm = "b." + project_id_dm
            
            # Prepare IDs for Revit SaveAsCloudModel
            account_guid = Guid(to_guid_string(hub_id))
            project_guid = Guid(to_guid_string(project_id_dm))
            
            # Find target folder id in Docs
            top_folder_id = get_top_folder_id_by_name(
                access_token,
                hub_id,
                project_id_dm,
                top_folder_name
            )
            
            if not top_folder_id:
                forms.alert("Top folder '{}' not found.".format(top_folder_name), exitscript=True)

            target_folder_id = get_child_folder_id(
                access_token,
                project_id_dm,
                top_folder_id,
                sub_folder_name
            )

            if not target_folder_id:
                forms.alert("Folder '{}' not found.".format(sub_folder_name), exitscript=True)

            file_exists = acc_file_exists(
                access_token,
                project_id_dm,
                target_folder_id,
                file_name
            )
            
            if file_exists:
                forms.alert(
                    "A file with this name already exists in this Autodesk Forma project and "
                    "will not be saved.",
                    title="File Already Exists"
                )
                no_saved_files.append(file_name)
                continue
            
            Application.DoEvents()
            Thread.CurrentThread.Join(2000)

            try:
                doc.SaveAsCloudModel(
                    account_guid,
                    project_guid,
                    target_folder_id,
                    file_name
                )
                
                forms.alert(
                    "All done, {}. Cloud model created successfully under {} folder.\n\n"
                    "If multiple users will work on this model, please enable worksharing "
                    "(worksets) manually.".format(user_name, sub_folder_name),
                    exitscript=False
                )
                
            except Exception as e:
                #print(str(e))
                #print(traceback.format_exc())
                msg = (
                    "The model could not be saved to Autodesk Forma Cloud.\n\n"
                    "Please confirm the following before trying again:\n\n"
                    "1. --------------------------------------------------------------------\n"
                    "A Revit file with the same name already exists in the selected discipline folder of this ACC project.\n"
                    "2. --------------------------------------------------------------------\n"
                    "A member was added recently, or the Autodesk Forma project was created recently.\n\n"
                    "Solution:\n"
                    "Please wait 10 to 20 minutes for project permissions and services to synchronise before trying again.\n\n"
                    "3. --------------------------------------------------------------------\n"
                    "A Revit cloud model may already exist in this Forma project using a different Revit version.\n\n"
                    "Forma projects can become associated with a specific Revit version. "
                    "If the current file is opened in a different version, Revit may prevent it from being saved to that project.\n\n"
                    "Solution:\n"
                    "Use the 'ACC Project Inspection' tool to check the Revit version of the existing cloud models and compare it with "
                    "the version of Revit you are currently using.\n\n"
                    "You can also test this manually using Revit's 'Save as Cloud Model' option. "
                    "If the project/job number is not visible in the project list, the current Revit "
                    "version cannot save a cloud model to that Forma project.\n\n"
                    "If the problem persists after completing these checks, or if you have "
                    "problems to find ACC allowable revit file versions, "
                    "please contact the STP Tools Developer for further assistance."
                )

                forms.alert(msg, title="Unable to Save to Autodesk Forma Cloud")
            

    #----- SAVE TO CURRENT DRAWINGS IN SHARE POINT FOLDER---------------
    elif "Current" in save_action or "Location" in save_action:
        open_files = []
        for discipline, info in save_info.items():
            folder_path = os.path.dirname(info["file_path"])
            action = info["save_action"]
            file_name = info["file_name"]
            current_file = info["file_path"]
            
            if action == "Skip":
                continue
            
            # Check if the file is opened in this session.
            open_doc = get_open_document(current_file)
            if open_doc:
                no_saved_files.append(file_name)
                continue

            
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
                    
            if action == "Supersede":
                counter = 1
                ss_path = os.path.join(folder_path, "SS")
                if not os.path.exists(ss_path):
                    os.makedirs(ss_path)
                    
                ss_name = file_name + "_ss01"
                ss_file_path = os.path.join(ss_path, ss_name + ".rvt")
                
                while os.path.exists(ss_file_path):
                    counter += 1
                    ss_name = file_name + "_ss" + str(counter).zfill(2)
                    ss_file_path = os.path.join(ss_path, ss_name + ".rvt")
                    
                if os.path.exists(current_file):
                    shutil.move(current_file, ss_file_path)
                        
            try:
                save_options = SaveAsOptions()
                save_options.OverwriteExistingFile = True
                doc.SaveAs(current_file, save_options)
                open_files.append(current_file)
            except:
                no_saved_files.append(file_name)
                
        if not no_saved_files:
            uidoc = UIDocument(doc)
            forms.alert(
                "All done, {}.\n\n Local Model saved succesfully".format(user_name),
                exitscript=False
            )

        for revit_path in open_files[:-1]:
            __revit__.OpenAndActivateDocument(revit_path)


    else:
        if not from_template and doc.PathName:
            try:
                doc.Save()
            except:
                pass


if no_saved_files:
    forms.alert(
        "The following Revit file(s) could not be saved:\n\n" +
        "\n".join(no_saved_files ) + "\n\n"
        "The specified project information will still be filled in. "
        "However, you will need to use the STP "
        "'Save this Revit File' tool to complete the saving process.",
        title="Revit Files Not Saved"
    )

#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "New Project",
    "items": len(save_info)
}
track_data(Lib_Path, data, "PR01")










