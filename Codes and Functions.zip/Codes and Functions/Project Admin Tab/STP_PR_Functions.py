import os
import sys
from pyrevit import forms
from Autodesk.Revit.DB import FilteredElementCollector, ViewSheet, BuiltInCategory, BuiltInParameter

def test():
    print("testing project functions")
    
def fill_titleblock_list(path):
    tb_names = []
    tb_pahts = []
    tb_version = []
    tb_side = []
    tb_size = []
    tb_Info = []
    
    # Open the file and read it line by line
    try:
        with open(path, 'r') as file:
            for line in file:
                # Look for lines starting with 'tb_path ='
                if line.strip().startswith('tb_path'):
                    tb_pahts.append(line.strip()[10:])
                if line.strip().startswith('name'):
                    tb_names.append(line.strip()[7:])
                if line.strip().startswith('version'):
                    tb_version.append(line.strip()[7:])
                if line.strip().startswith('side'):
                    tb_side.append(line.strip()[7:])
                if line.strip().startswith('size'):
                    tb_size.append(line.strip()[7:])
            
            tb_Info = ((tb_names, tb_pahts, tb_version, tb_side, tb_size))
            return tb_Info

            
    except Exception as e:
        return None

def check_title_blocks(doc, qa_tb_name):
    sheets = (
    FilteredElementCollector(doc)
        .OfClass(ViewSheet)
    )
    
    
    print_base = {"E": "Electrical", "F": "Fire", "M": "Mechanical", "H": "Hydraulic", "S": "Structural"}
    pdf_forms = ["RVT", "SID", "SPEC", "F15"]
    not_matching = []
    missing_initials = []
    excluded_tblocks = ["STP Site Class Info"]
    
    for sheet in sheets:
        sheet_numb = sheet.SheetNumber
        if not sheet_numb or not sheet.SheetNumber[0] in print_base:
            continue
            
        # Exclude PDF-only forms
        if any(pdf_form in sheet_numb for pdf_form in pdf_forms):
            continue        
        
        titleblocks = (
            FilteredElementCollector(doc, sheet.Id)
            .OfCategory(BuiltInCategory.OST_TitleBlocks)
            .WhereElementIsNotElementType()
            .ToElements()
        )
        
        if titleblocks:
            for tb in titleblocks:
                family_name = tb.Symbol.Family.Name
                if not "Service" in family_name and not "Foundation" in family_name and family_name not in excluded_tblocks:
                    if family_name != qa_tb_name.replace(".rfa",""):
                        not_matching.append((sheet.SheetNumber, family_name))
                    
        fail = []
        drawn_by = sheet.get_Parameter(BuiltInParameter.SHEET_DRAWN_BY).AsString()
        if not drawn_by or drawn_by == "Author":
            fail.append("Author")

        designed_by = sheet.get_Parameter(BuiltInParameter.SHEET_DESIGNED_BY).AsString()
        if not designed_by or designed_by == "Designer":
            fail.append("Designer")

        approved_by = sheet.get_Parameter(BuiltInParameter.SHEET_APPROVED_BY).AsString()
        if not approved_by or approved_by == "Approver":
            fail.append("Approver")
        
        if fail:
            missing_initials.append(sheet.SheetNumber + " - Missing Parameters: " + ", ".join(fail))
            

    return not_matching, missing_initials

def find_stp_templates(path, user = None):
    lib_path = path.replace("STP Tools","STP Templates")
    folder_list = [
        "",
        "Structural Templates",
        "Mackay Structural Template",
        "Electrical",
        "Hydraulic"
    ]
    
    template_list = []
    template_maps = {}
    for folder in folder_list:
        if folder == "":
            search_folder = lib_path
            folder_name = "STP TEMPLATES"
        else:
            search_folder = os.path.join(lib_path, folder)
            folder_name = folder
        
        template_list.append("----------- [ Folder: " + folder_name.upper() + " ] ----------------")
        if os.path.exists(search_folder):
            for f in os.listdir(search_folder):
                if f.lower().endswith(".rte") and not f.lower()[-9] == "." and not "TEST" in f.upper():
                    template_list.append(f)
                    template_maps[f] = (os.path.join(search_folder, f))
                    
            
    if user and user == "Rafael":
        template_list.append("Local Resid")
        template_maps["Local Resid"] = (
            r"C:\Users\Rafael\OneDrive - STP Consultants"
            r"\Documents\Local Rafa Backup\Temp and Export Revit"
            r"\Design_Template R26.rte"
        )
    
    
    if template_list:
        selected_template = forms.SelectFromList.show(
            template_list,
            title="Select Revit Template",
            button_name="Select",
            multiselect=False
        )
    else:
        forms.alert(
            "No STP Revit template files were found in the standard folders.\n\n"
            "Please contact the STP Tools developer to add the required Revit templates.",
            title="Templates Not Found"
        )
        sys.exit()
    
    if selected_template:
        if "--" in selected_template:
            forms.alert("Please choose a valid template from the list")
            sys.exit()
            
        if not os.path.exists(template_maps[selected_template]):
            forms.alert("The selected template doesn't exists. Please contact STP developer")
            sys.exit()
        
        return template_maps[selected_template]

def select_file_name_options(doc, from_temp, save_options):
    save_action = None
    selected_discipline = None

    save_action = forms.alert(
        "Where do you want to save the Revit file?",
        title="Save Revit File",
        options = save_options,
        warn_icon=False
    )
    
    if save_action:        
        if "Forma" in save_action and not from_temp:
            # 1. Make sure current document is not already a cloud model
            if doc.IsModelInCloud:
                forms.alert(
                    "This script is intended for non-cloud saved files only.\n\n"
                    "Current document is already in the cloud.",
                    exitscript=True
                )

            # 2. Make sure document is not workshared
            if doc.IsWorkshared:
                forms.alert(
                    "This script is intended for non-workshared files only.\n\n"
                    "Current document is already workshared.",
                    exitscript=True
                )    
    
        return save_action

    sys.exit()





