#--------------------------------------------------------------------
#------------ PR03 - Edit Project Info.py ---------------------------
#--------------------------------------------------------------------

import sys
import os
import time
import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
local_mode = local_version
xaml_forms
##-------------------------------------

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import EditProjInfo

forms_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(forms_path)
import STP_DOC_Functions
from STP_DOC_Functions import *

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
revit_version = __revit__.Application.VersionNumber[2:]
current_date = datetime.fromtimestamp(time.time()).date()

#Debug bypass
#================================================================
#if user_name != "Rafael":
#    forms.alert("This tool is under revision. Will be back soon")
#    sys.exit()
#================================================================

#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
rvt_Data = get_project_info(doc)
if rvt_Data:
    p_Numb = rvt_Data["Project Number"]
    p_Address = rvt_Data["Project Address"]
    if not p_Numb:
        sys.exit()
    
    if not re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE):
        forms.alert(
            "Project Number for this file doesn't match 'STPYY-0000' standard code",
            exitscript = True
        )
    
    p_Suburb = rvt_Data["Suburb"]
    
    if p_Suburb == "N/F":
        split_addres = p_Address.split(", ")
        rvt_Data["Project Address"] = split_addres[0]
        p_Suburb = rvt_Data["Suburb"] = split_addres[1]
        p_Pcode = rvt_Data["Postcode"] = split_addres[3]

projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
p_numb_found = False
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)

p_Path = selected_project[2]

#--------------------------------------------------------------------
#----------- READ QA FILE -------------------------------------------
#--------------------------------------------------------------------
qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb)

if qa_info_exists:
    while confirm_file_is_not_opened(qa_path):
        file_name = os.path.basename(qa_path)

        action = forms.alert(
            "The QA Excel file '{}' is currently open or being used by another process.\n\n"
            "Please close the file and select 'Try Again'.\n\n"
            "If the file is not visibly open, Microsoft Excel may still be running in the background. "
            "Open Task Manager, check for any Microsoft Excel processes, and close them before trying again."
            .format(file_name),
            title="QA File In Use",
            options=[
                "Try Again",
                "Cancel"
            ]
        )

        if action != "Try Again":
            sys.exit()
        
    qa_Data = read_qa_excel_file_V2(qa_path)
    
    if qa_Data["pr_type"] == "[PG]" and p_Suburb == "N/A":
        mssg = "The QA Check List for this project is not compatible with new STP Tools QA Format.\n\n" + \
               "Please execute edit Project parameters to update a compatible Project Address Format"
        forms.alert(mssg)
        sys.exit()

else:
    forms.alert("QA file has not been created for this job yet.", exitscript = True)


#--------------------------------------------------------------------
#----------- EDIT GENERAL PROJECT FORM ------------------------------
#--------------------------------------------------------------------
# Activate the Form
form = EditProjInfo(
    xaml_forms["main_form"], 
    Lib_Path, rvt_Data, qa_Data
)
form.show_dialog()
change_list = form.change_pars

#--------------------------------------------------------------------
# ------ ADD LINE TO QA EXCEL FILE AND UPDATE PR INFO ---------------
#--------------------------------------------------------------------
if not change_list:
    sys.exit()

result = fill_project_info(doc, change_list)

if result and form.go_for_qa == True:
    for item in change_list:
        qa_Data[item[0]] = item[1]
        

    next_line = int(qa_Data["No"]) + 1
    next_line = str(next_line).replace(".0","")
    add_line = [next_line, qa_Data["Project Name"], qa_Data["Client Name"],
                qa_Data["Project Address"], qa_Data["Suburb"], qa_Data["Postcode"],
                qa_Data["tb_Name"], qa_Data["tb_Type"], qa_Data["tb_Side"],
                qa_Data["tb_Size"], user_name, revit_version, current_date]

    extra_data = {
        "p_type": qa_Data["pr_type"],
        "ini_type": qa_Data["pr_type"],
        "ref_client": change_list[5][1],
        "ref_qbuild": change_list[6][1]
    }

    result = write_qa_excel_file_V2(qa_path, "Modify", [add_line], extra_data)
    if result:
        try:
            if doc.PathName: #Save to avoid problems
                doc.Save()
        except:
            pass


#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "Edit Project",
    "items": "1"
}
track_data(Lib_Path, data, "PR03")








