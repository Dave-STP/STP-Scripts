#--------------------------------------------------------------------
#------------ PR02 - Save File.py -----------------------------------
#--------------------------------------------------------------------

import sys
import os
import re
import time
from Autodesk.Revit.DB import SaveAsOptions
from System.Windows.Forms import Application

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
discipline
local_mode = local_version
xaml_forms
##-------------------------------------

#=============**********DELETE ME*************=======================
local_debug = False
#if local_debug:
#    local_mode = local_debug
#    Lib_Path = r"C:\Users\Rafael.STPTSV\AppData\Roaming\pyRevit-Master\extensions\STPV3.extension\bin"
#=============**********DELETE ME*************=======================

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

tab_function_path = os.path.join(functions_path,"Project Admin Tab")
sys.path.append(tab_function_path)
import STP_PR_Functions
from STP_PR_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import NewFileNameForm

tab_function_path = os.path.join(functions_path,"ACC Admin tab")
sys.path.append(tab_function_path)
import STP_ACC_Functions
from STP_ACC_Functions import *

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
revit_version = __revit__.Application.VersionNumber[2:]

rvt_Data = get_project_info(doc)
if rvt_Data:
    p_Numb = rvt_Data["Project Number"]
    match = re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE)
    
if not p_Numb:
    sys.exit()
if not match:
    forms.alert(
        "Project Number for this file doesn't match 'STPYY-0000' standard code",
        exitscript = True
    )

#--------------------------------------------------------------------
#---- SELECT SAVE OPTIONS, DISCIPLINE AND LOCATION FOLDER -----------
#--------------------------------------------------------------------
save_options = [
    "Save to Autodesk Forma (Former ACC)",
    "Save to SharePoint Current Drawings Folder",
    "Select a Specific Location"
]

save_action = select_file_name_options(doc, False, save_options)
selected_discipline, folder_short = select_discipline(discipline)

if not save_action or not selected_discipline:
    sys.exit()
    
if "Select" in save_action:
    p_Path = forms.pick_folder(
        title="Select Folder to Save Revit File"
    )
    
    if not p_Path:
        sys.exit()
 
if "Current Drawings" in save_action:
    projects = []
    selected_folder = None
    p_Path = None
    projects = get_project_folders_from_onedrive(user_name, Lib_Path)

    if not projects:
        mssg = "No Project Folders Found. \n\n"
        if local_mode:
            mssg += "Please make sure project folder is inside the designided local folder.\n\n"
        else:
            mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
        mssg += "If the problem persists, contact the STP Tools Admin for further support."
        forms.alert(mssg)
        sys.exit()
            
    # Get current project number folder and location
    p_numb_found = False
    for project in projects:
        if project[0] == p_Numb:
            p_Path = os.path.join(
                project[2],
                "Drawings", "Current Drawings",
                folder_short
            )
            break
    
    if not p_Path:
        mssg = "The Project Number from this file was not found. \n\n" + \
               "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
               "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
               "If the problem persists, contact the STP Tools Admin for further support."
        forms.alert(mssg, exitscript=True)
    

elif "Forma" in save_action:
    p_Path = None


if p_Numb:
    file_name = p_Numb + "_" + selected_discipline[0].upper() + "_RVT" + revit_version
    file_path = ""
    if p_Path:
        file_path = os.path.join(p_Path, file_name + ".rvt")


info = {
    "folder_name": folder_short,
    "file_name": file_name,
    "file_path": file_path,
    "save_action": ""
}



form = NewFileNameForm(
    xaml_forms["save_file"],
    selected_discipline,
    info,
    save_action
)

form.show_dialog()

if not form.process_go:
    sys.exit()



with forms.ProgressBar(title="Creating and Saving Revit Files.") as pb:
    pb.update_progress(0.75, 1)
    
    #--------------------------------------------------------------------
    #----------- SAVE IN Autodesk Construction Cloud --------------------
    #--------------------------------------------------------------------
    if "Forma" in save_action:
        token_data = get_token()
        access_token = token_data["access_token"]
        existing_project = find_project_by_job_number_api(access_token, p_Numb)
        if not existing_project:
            forms.alert(
                "Project Number {} not found in ACC.\n\nPlease create the ACC project first.".format(acc_numb),
                exitscript=True
            )
        else:
            existing_project_id = get_project_id(existing_project)
            project_name = get_project_name(existing_project)

        try:
            ACCOUNT_ID = get_hub_id()
            account_guid = Guid(ACCOUNT_ID)
            project_guid = Guid(to_guid_string(existing_project_id))
        except:
            forms.alert("Neccesary Ids for this project were not found. Please contact STP developer for furhter support", exitscript=True)
            
        confirm = forms.alert(
            "This model will be saved to the cloud under the following project:\n\n{}".format(project_name),
            title="Saving File Confirmation",
            options=["Continue to Save", "Cancel"]
        )
        
        if not confirm == "Continue to Save":
            sys.exit()   
        
        file_name = info["file_name"]
        sub_folder_name = "STP-Structural" if "S" in selected_discipline else "STP-Services"
        top_folder_name = "Project Files"
        
       
        # Prepare IDs for ACC API
        hub_id = ACCOUNT_ID
        if not hub_id.startswith("b."):
            hub_id = "b." + hub_id

        project_id_dm = existing_project_id
        if not project_id_dm.startswith("b."):
            project_id_dm = "b." + project_id_dm
        
        # Prepare IDs for Revit SaveAsCloudModel
        account_guid = Guid(to_guid_string(hub_id))
        project_guid = Guid(to_guid_string(project_id_dm))
        
        # Find target folder id in Docs
        top_folder_id = get_top_folder_id_by_name(
            access_token,
            hub_id,
            project_id_dm,
            top_folder_name
        )
        
        if not top_folder_id:
            forms.alert("Top folder '{}' not found.".format(top_folder_name), exitscript=True)

        target_folder_id = get_child_folder_id(
            access_token,
            project_id_dm,
            top_folder_id,
            sub_folder_name
        )

        if not target_folder_id:
            forms.alert("Folder '{}' not found.".format(sub_folder_name), exitscript=True)

        file_exists = acc_file_exists(
            access_token,
            project_id_dm,
            target_folder_id,
            file_name
        )
        
        if file_exists:
            forms.alert(
                "A file with this name already exists in this Autodesk Forma project and "
                "will not be saved.",
                title="File Already Exists", exitscript = True
            )

        with forms.ProgressBar(title="Saving model to ACC... Please wait as this process can take a few minutes.") as pb:
            pb.update_progress(1, 1)
            Application.DoEvents()
            time.sleep(2)

            try:
                doc.SaveAsCloudModel(
                    account_guid,
                    project_guid,
                    target_folder_id,
                    file_name
                )
                
                forms.alert(
                    "All done, {}. Cloud model created successfully under {} folder.\n\nIf multiple users will work on this model, please enable worksharing (worksets) manually.".format(user_name, sub_folder_name),
                    exitscript=False
                )
                
            except Exception as e:
                #print(str(e))
                #print(traceback.format_exc())
                msg = (
                    "The model could not be saved to Autodesk Forma Cloud.\n\n"
                    "Please confirm the following before trying again:\n\n"
                    "1. --------------------------------------------------------------------\n"
                    "A member was added recently, or the Autodesk Forma project was created recently.\n\n"
                    "Solution:\n"
                    "Please wait 10 to 20 minutes for project permissions and services to synchronise before trying again.\n\n"
                    "2. --------------------------------------------------------------------\n"
                    "A Revit cloud model may already exist in this Forma project using a different Revit version.\n\n"
                    "Forma projects can become associated with a specific Revit version. If the current file is opened in a different version, Revit may prevent it from being saved to that project.\n\n"
                    "Solution:\n"
                    "Use the 'ACC Project Inspection' tool to check the Revit version of the existing cloud models and compare it with the version of Revit you are currently using.\n\n"
                    "You can also test this manually using Revit's 'Save as Cloud Model' option. If the project/job number is not visible in the project list, the current Revit version cannot save a cloud model to that Forma project.\n\n"
                    "If the problem persists after completing these checks, or if you have problems to find ACC allowable revit file versions, please contact the STP Tools Developer for further assistance."
                )

                forms.alert(msg, title="Unable to Save to Autodesk Forma Cloud")
        

    #--------------------------------------------------------------------
    #----------- SAVE IN SHARE POINT CURRENT DRAWINGS -------------------
    #--------------------------------------------------------------------
    elif "Current" in save_action or "Location" in save_action:
        folder_path = os.path.dirname(info["file_path"])
        action = info["save_action"]
        file_name = info["file_name"]
        current_file = info["file_path"]
        
        if action == "Skip":
            sys.exit()
        
        # Check if the file is opened in this session.
        open_doc = get_open_document(current_file)
        if open_doc:
            forms.alert("The selected file is already open in this session. "
                "Please close the file and try again", exitscript = True)

        
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
                
        if action == "Supersede":
            counter = 1
            ss_path = os.path.join(folder_path, "SS")
            if not os.path.exists(ss_path):
                os.makedirs(ss_path)
                
            ss_name = file_name + "_ss01"
            ss_file_path = os.path.join(ss_path, ss_name + ".rvt")
            
            while os.path.exists(ss_file_path):
                counter += 1
                ss_name = file_name + "_ss" + str(counter).zfill(2)
                ss_file_path = os.path.join(ss_path, ss_name + ".rvt")
                
            if os.path.exists(current_file):
                shutil.move(current_file, ss_file_path)
                    
        #if doc: #for debugging
        try:
            save_options = SaveAsOptions()
            save_options.OverwriteExistingFile = True
            doc.SaveAs(current_file, save_options)
            forms.alert(
                    "All done, {}. "
                    "Revit model saved successfully to:\n\n'Drawings / Current Drawings / {}' folder.\n\n"
                    .format(user_name, folder_short)
                )
        except:
            forms.alert("There was an error while saving the file. "
                "Please try again or contact STP Tools developer for assistance", 
                exitscript = True
            )
            
#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "Save File",
    "items": "1"
}
track_data(Lib_Path, data, "PR02")