#--------------------------------------------------------------------
#------------ PR02 - Save File.py -----------------------------------
#--------------------------------------------------------------------

import sys
import os
import re
import time
from Autodesk.Revit.DB import SaveAsOptions
from System.Windows.Forms import Application
import System.Threading as Threading

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
discipline
local_mode = local_version
xaml_forms
##-------------------------------------
bin_folder = globals().get("bin_folder")  # Eliminate this in future main update
##-------------------------------------

if bin_folder:
    temp_folder = os.path.join(bin_folder, "Temp_drawings")
else:
    temp_folder = r"C:\XREV\temp"

if not os.path.exists(temp_folder):
    os.makedirs(temp_folder)
else:
    try:
        clean_up_folder(temp_folder)
    except:
        pass


#=============**********DELETE ME*************=======================
#if local_debug:
#    local_mode = local_debug
#    Lib_Path = r"C:\Users\Rafael.STPTSV\AppData\Roaming\pyRevit-Master\extensions\STPV3.extension\bin"
#=============**********DELETE ME*************=======================

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

tab_function_path = os.path.join(functions_path,"Project Admin Tab")
sys.path.append(tab_function_path)
import STP_PR_Functions
from STP_PR_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import NewFileNameForm

tab_function_path = os.path.join(functions_path,"ACC Admin tab")
sys.path.append(tab_function_path)
import STP_ACC_Functions
from STP_ACC_Functions import *
set_lib_path(Lib_Path)

tab_function_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(tab_function_path)
import STP_DOC_Functions
from STP_DOC_Functions import clean_up_folder, move_files_from_temp

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
revit_version = __revit__.Application.VersionNumber[2:]


#================ REVISION BY PASS ==============
#if user_name != "Rafael":
#    forms.alert("This tool is under revision, will be back soon", exitscript = True)
#================ REVISION BY PASS ==============

if "select_name" not in xaml_forms:
    xaml_forms["select_name"] = os.path.join(
        Lib_Path, "Codes and Functions", "Xaml Forms", "select_name_form.xaml")



#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
preset_number = "STP"
rvt_Data = get_project_info(doc)
if rvt_Data:
    rvt_pr_number = rvt_Data["Project Number"]
    if rvt_pr_number and re.search(r"(STP\d{2}-\d{4})", rvt_pr_number, re.IGNORECASE):
        preset_number = rvt_pr_number


#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER AND SAVE OPTIONS --------------------
#--------------------------------------------------------------------
p_Numb = forms.ask_for_string(
    default = preset_number, 
    prompt="Enter Job Number (STPYY-XXXX):", 
    title="Save Revit File"
)

if not p_Numb:
    sys.exit()

if not re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE):
    forms.alert(
        "Project Number for this file doesn't match 'STPYY-0000' standard code",
        exitscript = True
    )
    
projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
p_numb_found = False
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)

p_Numb, code_name, p_Path = selected_project
selected_discipline = select_discipline(discipline)

new_proj_Data = {
    "discipline": selected_discipline[0],
    "folder_name": selected_discipline[1],
    "local_mode": local_mode,
    "pr_numb": p_Numb,
    "disc_code": selected_discipline[0][0].upper(),
    "pr_path": p_Path,
    "rvt_version": revit_version,
}


saving_type = get_revit_file_save_action(doc, new_proj_Data, False)
if not saving_type:
    sys.exit()

acc_file = True if "ACC" in saving_type else False
if not "Allow" in saving_type:
    save_form = NewFileNameForm(
        xaml_forms["select_name"],
        new_proj_Data,
        saving_type
    )

    save_form.show_dialog()
    if not save_form.process_go:
        sys.exit()

else:
    new_proj_Data["save_action"] = None


#--------------------------------------------------------------------
#----------- SAVING REVIT FILE --------------------------------------
#--------------------------------------------------------------------
relocate_paths = []
file_name = new_proj_Data["file_name"]
discipline = new_proj_Data["discipline"]
folder_path = os.path.dirname(new_proj_Data["file_path"])
action = new_proj_Data["save_action"]
current_file = new_proj_Data["file_path"]
final_alert = ""

with forms.ProgressBar(title="Creating and Saving Revit Files.") as pb:
    pb.update_progress(0.75, 1)

    #----------- CONTINUE WITHOUT SAVING ---------------
    if "manually" in saving_type:
        final_alert = "All done, {}. Please save the file manually.".format(user_name)
                       
    #----------- SAVE IN Autodesk Construction Cloud --------------------
    elif "Forma" in saving_type:
        token_data = get_token()
        access_token = token_data["access_token"]
        existing_project = find_project_by_job_number_api(access_token, p_Numb)
        
        if existing_project: 
            next_step = True
            try:
                existing_project_id = get_project_id(existing_project)
                project_name = get_project_name(existing_project)
                ACCOUNT_ID = get_hub_id()
                account_guid = Guid(ACCOUNT_ID)
                project_guid = Guid(to_guid_string(existing_project_id))
            
            except:
                next_step = False
                final_alert = (
                    "The required project IDs could not be found, so the Revit file could not be saved automatically.\n\n"
                    "Please contact the STP Tools developer for further support."
                )

            if next_step:
                confirm = forms.alert(
                    "This model will be saved to the cloud under the following "
                    "project:\n\n{}".format(project_name.replace(" - ","\n")),
                    title="Saving File Confirmation",
                    options=["Continue to Save", "Cancel"]
                )
                
                if not confirm == "Continue to Save":
                    sys.exit()   

                sub_folder_name = "STP-Structural" if "S" in discipline else "STP-Services"
                top_folder_name = "Project Files"
                
                # Prepare IDs for ACC API
                hub_id = ACCOUNT_ID
                if not hub_id.startswith("b."):
                    hub_id = "b." + hub_id

                project_id_dm = existing_project_id
                if not project_id_dm.startswith("b."):
                    project_id_dm = "b." + project_id_dm
                
                # Prepare IDs for Revit SaveAsCloudModel
                account_guid = Guid(to_guid_string(hub_id))
                project_guid = Guid(to_guid_string(project_id_dm))
                
                # Find target folder id in Docs
                top_folder_id = get_top_folder_id_by_name(
                    access_token,
                    hub_id,
                    project_id_dm,
                    top_folder_name
                )
                
                if top_folder_id:
                    target_folder_id = get_child_folder_id(
                        access_token,
                        project_id_dm,
                        top_folder_id,
                        sub_folder_name
                    )
                    
                    if target_folder_id:
                        Application.DoEvents()
                        Threading.Thread.CurrentThread.Join(2000)

                        try:
                            doc.SaveAsCloudModel(
                                account_guid,
                                project_guid,
                                target_folder_id,
                                file_name
                            )
                            
                            final_alert = (
                                "All done, {}. Cloud model created successfully under {} folder.\n\n"
                                "If multiple users will work on this model, please enable worksharing "
                                "(worksets) manually.".format(user_name, sub_folder_name)
                            )
                            
                        except Exception as e:
                            fallback_path = get_temp_revit_path(file_name)
                            save_options = SaveAsOptions()
                            save_options.OverwriteExistingFile = False
                            doc.SaveAs(fallback_path, save_options)
                            
                            final_alert = (
                                "The model could not be saved to Autodesk Forma Cloud.\n\n"
                                "Please confirm the following before trying again:\n\n"
                                "1. --------------------------------------------------------------------\n"
                                "A Revit file with the same name already exists in the selected discipline folder of this ACC project.\n\n"
                                "2. --------------------------------------------------------------------\n"
                                "A member was added recently, or the Autodesk Forma project was created recently.\n\n"
                                "Solution:\n"
                                "Please wait 10 to 20 minutes for project permissions and services to synchronise before trying again.\n\n"
                                "3. --------------------------------------------------------------------\n"
                                "A Revit cloud model may already exist in this Forma project using a different Revit version.\n\n"
                                "Forma projects can become associated with a specific Revit version. "
                                "If the current file is opened in a different version, Revit may prevent it from being saved to that project.\n\n"
                                "Solution:\n"
                                "Use the 'ACC Project Inspection' tool to check the Revit version of the existing cloud models and compare it with "
                                "the version of Revit you are currently using.\n\n"
                                "You can also test this manually using Revit's 'Save as Cloud Model' option. "
                                "If the project/job number is not visible in the project list, the current Revit "
                                "version cannot save a cloud model to that Forma project.\n\n"
                                "If the problem persists after completing these checks, or if you have "
                                "problems to find ACC allowable revit file versions, "
                                "please contact the STP Tools Developer for further assistance."
                            )

                    else:
                        final_alert = (
                            "The folder '{}' could not be found, so the Revit file could not be saved automatically.\n\n"
                            "Please check the project folder structure and try again. If the problem persists, "
                            "contact STP tools developer.".format(sub_folder_name)
                        )
                    
                else:
                    final_alert = (
                        "The Top folder '{}' could not be found, so the Revit file could not be saved automatically.\n\n"
                        "Please check the project folder structure and try again. If the problem persists, "
                        "contact STP tools developer.".format(top_folder_name)
                    )
       
        else:
            final_alert = (
                "Project Number {} was not found in Autodesk ACC.\n\n"
                "Please create the project folder in ACC first and then try again"
                .format(p_Numb)
            )
            



    #----- SAVE TO CURRENT DRAWINGS IN SHARE POINT FOLDER---------------
    elif "Current" in saving_type or "Location" in saving_type:
        if action == "Skip":
            final_alert = "All done, {}. Please save the file manually.".format(user_name)
        
        else:
            # Check if the file is opened in this session.
            open_doc = get_open_document(current_file)
                
            if action == "Supersede":
                file_name = file_name.replace(".rvt","")
                counter = 1
                ss_path = os.path.join(folder_path, "SS")
                ss_name = file_name + "_ss01"
                ss_file_path = os.path.join(
                    ss_path,
                    ss_name + ".rvt"
                )
                
                # Find next available superseded name
                while os.path.exists(ss_file_path):
                    counter += 1
                    ss_name = (file_name + "_ss" + str(counter).zfill(2))
                    ss_file_path = os.path.join(ss_path, ss_name + ".rvt")
                
                # Temporary superseded file
                temp_path = os.path.join(temp_folder, ss_name + ".rvt")

                # Copy the CURRENT saved version before overwriting/saving
                if os.path.exists(current_file):
                    shutil.copy2(current_file, temp_path)
                    relocate_paths.append([temp_path, ss_file_path]) # Store it so you can move it to SS later            

            if open_doc:
                try:
                    open_doc.Save()
                    final_alert = "All done, {}.\n\n Revit Model saved succesfully".format(user_name)

                except Exception as e:
                    final_alert = (
                        "{} Project is currently open, but STP Tools could not save the file.\n\n"
                        "The process will continue. Once it is finished, please save the Revit file manually."
                        .format(p_Numb)
                    )

                    if action == "Supersede" and relocate_paths:
                        relocate_paths.pop()
                
            else:
                try:
                    save_options = SaveAsOptions()
                    save_options.OverwriteExistingFile = True
                    doc.SaveAs(current_file, save_options)
                    final_alert = "All done, {}.\n\n Revit Model saved succesfully".format(user_name)

                except:
                    final_alert = (
                        "An error occurred while saving the new Revit file.\n\n"
                        .format(p_Numb)
                    )                
                
if relocate_paths:
    result = move_files_from_temp(relocate_paths)
    
if temp_folder == r"C:\XREV\temp" and os.path.exists(temp_folder):
    try:
        shutil.rmtree(temp_folder)
    except:
        pass
        
if final_alert:
    forms.alert(final_alert)


#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "Save File",
    "items": "1"
}
track_data(Lib_Path, data, "PR02")