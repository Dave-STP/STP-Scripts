#--------------------------------------------------------------------
#------------ ACC03 - Add ACC Member.py -----------------------------
#--------------------------------------------------------------------

import os
import sys
import re
from pyrevit import forms, script

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
##-------------------------------------

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import get_project_info, track_data

tab_function_path = os.path.join(functions_path,"ACC Admin tab")
sys.path.append(tab_function_path)
import STP_ACC_Functions
from STP_ACC_Functions import *


user_name = os.environ.get("USERNAME")
uidoc = __revit__.ActiveUIDocument

if uidoc:
    doc = uidoc.Document
    rvt_Data = get_project_info(doc)
    pr_Numb = rvt_Data["Project Number"]

else:
    doc = None
    pr_Numb = "STP"


pattern = r"^STP\d{2}-\d{4}$"
acc_numb = None
while True:
    project_number = forms.ask_for_string(
        default = pr_Numb,
        prompt="Enter project number (format: STPXX-0000)",
        title="Project Number"
    )
    
    # user pressed Cancel
    if project_number is None:
        script.exit()
    
    project_number = project_number.strip().upper()
    
    # check format
    if re.match(pattern, project_number):
        acc_numb = project_number
        break
    
    # invalid format
    action = forms.alert(
        "Invalid project number format.\n\nExpected format: STPXX-0000\nExample: STP26-1234",
        options=["Try Again", "Cancel"],
        title="Invalid Format"
    )
    
    if action == "Cancel" or not action:
        script.exit()

#---Dictionaries ---
COMPANY_ID = '918d87da-2dca-4d56-972f-ac57de55dff6'
MEMBER_PRODUCTS = [
    {
        "key": "projectAdministration",
        "access": "member"
    },
    {
        "key": "docs",
        "access": "member"
    }
]
acc_roles = {
    "Project Manager": 'ff4b4050-6530-4ead-9ad9-c0ca6c5bda68',
    "Document Manager": '7268a583-4ddc-4c64-a11a-02eb2941ecb7',
    "BIM Manager": 'e96feb87-5c2d-44da-a431-e8cf380d1398',
    "Drafter": 'ddd506d4-7cc1-4390-8755-c5b140577cdb'
}

#---Activate Token and ACC access.---
token_data = get_token()
access_token = token_data["access_token"]
existing_project = find_project_by_job_number_api(access_token, acc_numb)
if existing_project:
    existing_project_id = get_project_id(existing_project)
else:
    forms.alert("Project Number {} not found in ACC data base. \n\nPlease use the ACC new project.".format(acc_numb))
    sys.exit()

#---Collect Members---
user_list = []
email_list = get_email_list(Lib_Path)   ### activate when ready. Don't delete
if email_list:
    for line in email_list:
        user_list.append(line[0])

selected_members = forms.SelectFromList.show(user_list, multiselect=True, title="Select the STP Members to add into {} ACC project.".format(acc_numb))
role_Ids = []
msg = ""

#---Collect Roles and Add Members to project
if selected_members:
    for member in selected_members:
        index = user_list.index(member)
        user_email = email_list[index][1]
        user_name = email_list[index][0]
        msg += "{} - [{}]\n".format(user_name, user_email)
        
        selected_roles = forms.SelectFromList.show(
            acc_roles.keys(),
            multiselect=True,
            title="SELECT ROLE FOR {}".format(user_name)
        )
        if selected_roles:
            for role in selected_roles:
                role_Ids.append(acc_roles[role])
            
        
        else:
            action = forms.alert("No role selected for {}. Do you want to continue without role?".format(user_name), "ALERT", options=["Continue", "Cancel Process"])
            if not action or action == "Cancel Process":
                sys.exit()
            else:
                ROLE_ID = None

        try:
            member_result = import_project_member(
                access_token,
                existing_project_id,
                user_email,
                MEMBER_PRODUCTS,
                role_Ids,
                COMPANY_ID
            )
            
        except Exception as e:
            forms.alert("There was an error during adding members. Please contact STP developer for further information")
            print(e)
            sys.exit()
        
    
    added_members = "\n".join(selected_members)
    forms.alert("The following members have been added to ACC {} project.\n\n{}".format(acc_numb, added_members) + msg)