import os
import urllib
import urllib2
import json
import base64
import netrequests as requests
import clr
import math
from System import Guid
from pyrevit import forms
clr.AddReference("System")

from System import Type, Activator, Array, Object
from System.Reflection import BindingFlags

lib_path = None

def set_lib_path(path):
    global lib_path
    lib_path = path

def access(req_data = []):
    token_folder = "Data Base\ACC_access_data.txt"
    #print(lib_path)
    token_path = os.path.join(lib_path, token_folder)

    access_data = []
    with open(token_path, "r") as f:
        for line in f:
            split_lines = line.split(" = ")
            if split_lines[0].strip() in req_data:
                access_data.append(split_lines[1].strip())
    
    return access_data


# TOKEN
def get_token():
    url = "https://developer.api.autodesk.com/authentication/v2/token"
    CLIENT_ID, CLIENT_SECRET = access(["CLIENT_ID", "CLIENT_SECRET"])

    raw_auth = "{}:{}".format(CLIENT_ID, CLIENT_SECRET)
    basic_b64 = base64.b64encode(raw_auth)

    body = urllib.urlencode({
        "grant_type": "client_credentials",
        "scope": "data:read data:write account:read account:write"
    })

    req = urllib2.Request(url, body)
    req.add_header("Authorization", "Basic " + basic_b64)
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    req.add_header("Accept", "application/json")

    try:
        res = urllib2.urlopen(req)
        return json.loads(res.read())
    except urllib2.HTTPError as ex:
        raise Exception("Token request failed ({})\n{}".format(ex.code, ex.read()))

# HTTP HELPERS

def http_get(url, access_token):
    req = urllib2.Request(url)
    req.add_header("Authorization", "Bearer " + access_token)
    req.add_header("Accept", "application/json")

    try:
        res = urllib2.urlopen(req)
        return json.loads(res.read())
    except urllib2.HTTPError as ex:
        raise Exception("GET failed ({})\n{}".format(ex.code, ex.read()))

def http_post_json(url, payload, access_token):
    #print(payload)
    data = json.dumps(payload)
    req = urllib2.Request(url, data)
    req.add_header("Authorization", "Bearer " + access_token)
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")

    X_USER_ID = access(["X_USER_ID"])[0]
    if X_USER_ID:
        req.add_header("x-user-id", X_USER_ID)

    try:
        res = urllib2.urlopen(req)
        return json.loads(res.read())
    except urllib2.HTTPError as ex:
        raise Exception("POST failed ({})\n{}".format(ex.code, ex.read()))

# PROJECT HELPERS

def normalize_projects_response(projects_response):
    if isinstance(projects_response, list):
        return projects_response

    if isinstance(projects_response, dict):
        if "results" in projects_response and isinstance(projects_response["results"], list):
            return projects_response["results"]
        if "data" in projects_response and isinstance(projects_response["data"], list):
            return projects_response["data"]
        if "items" in projects_response and isinstance(projects_response["items"], list):
            return projects_response["items"]

    return []

def get_projects_page(access_token, limit=200, offset=0):
    ACCOUNT_ID = access(["ACCOUNT_ID"])[0]
    url = (
        "https://developer.api.autodesk.com/construction/admin/v1/accounts/{}/projects"
        "?limit={}&offset={}"
    ).format(ACCOUNT_ID, limit, offset)

    return http_get(url, access_token)

def get_all_projects(access_token, limit=200):
    all_projects = []
    offset = 0

    while True:
        response = get_projects_page(access_token, limit, offset)
        page_projects = normalize_projects_response(response)

        if not page_projects:
            break

        all_projects.extend(page_projects)

        if len(page_projects) < limit:
            break

        offset += limit

    return all_projects

def get_project_id(project_obj):
    if not isinstance(project_obj, dict):
        return ""

    if "id" in project_obj:
        return str(project_obj["id"])

    if "projectId" in project_obj:
        return str(project_obj["projectId"])

    attrs = project_obj.get("attributes", {})
    if isinstance(attrs, dict):
        if "id" in attrs:
            return str(attrs["id"])
        if "projectId" in attrs:
            return str(attrs["projectId"])

    return ""

def get_project_name(project_obj):
    if not isinstance(project_obj, dict):
        return ""

    if "name" in project_obj:
        return str(project_obj["name"])

    if "projectName" in project_obj:
        return str(project_obj["projectName"])

    attrs = project_obj.get("attributes", {})
    if isinstance(attrs, dict):
        if "name" in attrs:
            return str(attrs["name"])
        if "projectName" in attrs:
            return str(attrs["projectName"])

    return ""

def get_project_job_number(project_obj):
    if not isinstance(project_obj, dict):
        return ""

    if "jobNumber" in project_obj:
        return str(project_obj["jobNumber"])

    if "projectNumber" in project_obj:
        return str(project_obj["projectNumber"])

    attrs = project_obj.get("attributes", {})
    if isinstance(attrs, dict):
        if "jobNumber" in attrs:
            return str(attrs["jobNumber"])
        if "projectNumber" in attrs:
            return str(attrs["projectNumber"])

    return ""

def fill_tracking_data(path, p_numb, user, file, version, start_time, end_time, items, stage):
    testing = False #Make true when testing the function only
    
    if ("XXXX" in p_numb or "TEST" in p_numb) and not testing:
        return ""
    else:
        local_report = ""
        new_line = "Project Number:, " + p_numb
        new_line += ", User:, " + user
        new_line += ", File:, " + file
        new_line += ", Version:, " + version
        new_line += ", Start Time:, " + start_time
        new_line += ", End Time:, " + end_time
        new_line += ", Loaded Items:, " + items

        try:
            with open(path, "a") as f:
                f.write(new_line + "\n")
            local_report += u"\u2705 Stage: " + stage + ": [Update Tracking data] Success. \n"
        except Exception as e:
            local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
            
        return local_report

def find_project_by_job_number_api(access_token, job_number, limit=200):

    target = job_number.strip().lower()

    # First call just to get total number of projects
    first_response = get_projects_page(access_token, limit, 0)
    total = first_response["pagination"]["totalResults"]
    n_pages = math.ceil(total / float(limit))

    # Calculate last page offset
    offset = (total // limit) * limit
    page_numb = 1

    with forms.ProgressBar() as pb:

        while offset >= 0:

            pb.title = "Searching for existing job on ACC PAGE {}/{}".format(page_numb, int(n_pages))
            pb.update_progress(page_numb, n_pages)

            response = get_projects_page(access_token, limit, offset)
            page_projects = normalize_projects_response(response)

            if not page_projects:
                return None

            for p in page_projects:
                aux = get_project_job_number(p)

                if aux.strip().lower() == target:
                    return p

            offset -= limit
            page_numb += 1
        
        pb.update_progress(10, 10)
    return None

def find_project_by_job_number(projects, job_number):
    target = job_number.strip().lower()

    for p in projects:
        aux = get_project_job_number(p)
        if aux.strip().lower() == target:
            return p

    return None

def get_project_users(access_token, project_id):

    url = "https://developer.api.autodesk.com/construction/admin/v1/projects/{}/users".format(project_id)

    return http_get(url, access_token)

def to_guid_string(id_text):
    """Remove b. prefix if present and return raw GUID text."""
    if not id_text:
        return None
    if id_text.startswith("b."):
        return id_text[2:]
    return id_text

def get_top_folder_id_by_name(access_token, hub_id, project_id_dm, top_folder_name):
    data = get_top_folders(access_token, hub_id, project_id_dm)
    folders = data.get("data", [])

    for folder in folders:
        attrs = folder.get("attributes", {})
        name = attrs.get("displayName") or attrs.get("name") or ""
        if name.strip().lower() == top_folder_name.strip().lower():
            return folder["id"]

    return None

def get_child_folder_id(access_token, project_id_dm, parent_folder_id, child_folder_name):
    data = get_folder_contents(access_token, project_id_dm, parent_folder_id)
    items = data.get("data", [])

    for item in items:
        if item.get("type") != "folders":
            continue

        attrs = item.get("attributes", {})
        name = attrs.get("displayName") or attrs.get("name") or ""
        if name.strip().lower() == child_folder_name.strip().lower():
            return item["id"]

    return None

def get_hub_id():
    ACCOUNT_ID = access(["ACCOUNT_ID"])[0]
    return ACCOUNT_ID

def get_top_folders(access_token, hub_id, project_id_dm):

    url = "https://developer.api.autodesk.com/project/v1/hubs/{}/projects/{}/topFolders".format(
        hub_id,
        project_id_dm
    )

    req = urllib2.Request(url)
    req.add_header("Authorization", "Bearer " + access_token)
    req.add_header("Accept", "application/json")

    try:
        res = urllib2.urlopen(req)
        return json.loads(res.read())

    except urllib2.HTTPError as ex:
        raise Exception("GET topFolders failed ({})\n{}".format(ex.code, ex.read()))

def get_folder_contents(access_token, project_id_dm, folder_id):

    url = "https://developer.api.autodesk.com/data/v1/projects/{}/folders/{}/contents".format(
        project_id_dm,
        urllib.quote(folder_id, safe="")
    )

    req = urllib2.Request(url)
    req.add_header("Authorization", "Bearer " + access_token)
    req.add_header("Accept", "application/json")

    try:
        res = urllib2.urlopen(req)
        return json.loads(res.read())

    except urllib2.HTTPError as ex:
        raise Exception("GET folder contents failed ({})\n{}".format(ex.code, ex.read()))

def get_folder_guid_from_urn(folder_id):
    return folder_id.split(".")[-1]

# SEARCH OR INSPECT PROJECTS
def api_get_json(access_token, url):
    req = urllib2.Request(url)
    req.add_header("Authorization", "Bearer " + access_token)
    req.add_header("Accept", "application/json")

    try:
        res = urllib2.urlopen(req)
        return json.loads(res.read())

    except urllib2.HTTPError as ex:
        raise Exception(
            "ACC request failed ({})\n{}\n\n{}".format(
                ex.code,
                url,
                ex.read()
            )
        )

def to_data_management_id(value):
    if value.startswith("b."):
        return value

    return "b." + value

def get_acc_top_folders(access_token, account_id, project_id):
    try:
        hub_id = to_data_management_id(account_id)
        project_id = to_data_management_id(project_id)

        url = (
            "https://developer.api.autodesk.com"
            "/project/v1/hubs/{}/projects/{}/topFolders"
        ).format(
            hub_id,
            project_id
        )

        response = api_get_json(access_token, url)

        return response.get("data", [])

    except Exception as e:
        error = str(e)
        if "Project is not active" in error:
            forms.alert(
                "This Autodesk Forma project is inactive or archived and cannot be accessed by STP Tools.\n\n"
                "Please check the project status in ACC. If the project is archived, restore it before continuing.\n\n"
                "If the problem persists contact STP Tools developer for further assistance.",
                title="Archived Project"
            )
            
            return None
        
        else:
            raise
            return None



def get_acc_folder_contents(access_token, project_id, folder_id):

    project_id = to_data_management_id(project_id)

    # Folder IDs contain characters such as :
    # so they need to be URL encoded.
    encoded_folder_id = urllib.quote(folder_id, safe="")

    url = (
        "https://developer.api.autodesk.com"
        "/data/v1/projects/{}/folders/{}/contents"
    ).format(
        project_id,
        encoded_folder_id
    )

    contents = []

    while url:

        response = api_get_json(access_token, url)

        contents.extend(
            response.get("data", [])
        )

        # Handle pagination if the folder contains many items
        next_link = response.get("links", {}).get("next")

        if isinstance(next_link, dict):
            url = next_link.get("href")
        else:
            url = next_link

    return contents

def find_stp_revit_files(access_token, project_id, root_folder):

    revit_files = []
    autocad_files = []
    other_files = []
    
    visited_folders = set()

    def search_folder(folder_id, folder_path):

        if folder_id in visited_folders:
            return

        visited_folders.add(folder_id)

        contents = get_acc_folder_contents(
            access_token,
            project_id,
            folder_id
        )

        for item in contents:

            item_type = item.get("type")
            item_id = item.get("id")
            attributes = item.get("attributes", {})

            # Folders normally use "name"
            # Files/items normally use "displayName"
            name = (
                attributes.get("displayName")
                or attributes.get("name")
                or ""
            )

            if item_type == "folders":

                new_path = folder_path + "\\" + name

                search_folder(
                    item_id,
                    new_path
                )

            elif item_type == "items":

                if name.upper().startswith("STP"):
                    found_file = {
                        "name": name,
                        "id": item_id,
                        "folder": folder_path
                    }
                    if name.lower().endswith(".rvt") and name[-9] != ".":
                        revit_files.append(found_file)
                    elif name.lower().endswith(".dwg"):
                        autocad_files.append(found_file)
                    else:
                        other_files.append(found_file)

    root_name = root_folder.get(
        "attributes",
        {}
    ).get("name", "Project Files")

    search_folder(
        root_folder["id"],
        root_name
    )

    return revit_files, autocad_files, other_files

def get_active_project_members(access_token, project_id, limit=200):

    # Project Admin API uses the project ID WITHOUT "b."
    if project_id.startswith("b."):
        project_id = project_id[2:]

    members = []
    offset = 0

    while True:

        url = (
            "https://developer.api.autodesk.com"
            "/construction/admin/v1/projects/{}/users"
            "?limit={}&offset={}"
        ).format(
            project_id,
            limit,
            offset
        )

        response = api_get_json(
            access_token,
            url
        )

        page_members = response.get("results", [])

        for member in page_members:

            status = member.get("status", "")

            if status.lower() == "active":
                members.append(member)

        pagination = response.get("pagination", {})

        total = pagination.get("totalResults", 0)
        current_limit = pagination.get("limit", limit)

        offset += current_limit

        if offset >= total:
            break

    return members

def acc_file_exists(token, project_id, folder_id, file_name):

    if not file_name.lower().endswith(".rvt"):
        file_name += ".rvt"

    url = (
        "https://developer.api.autodesk.com/"
        "data/v1/projects/{}/folders/{}/contents"
    ).format(
        project_id,
        folder_id
    )

    headers = {
        "Authorization": "Bearer " + token
    }

    params = {
        "filter[attributes.displayName]": file_name
    }

    response = requests.get(
        url,
        headers=headers,
        params=params
    )

    response.raise_for_status()

    items = response.json().get("data", [])

    return len(items) > 0


# CREATE PROJECT
def clean_text(value, replacements):
    """Clean a single value if it's a string."""
    if isinstance(value, str):
        for bad, good in replacements:
            value = value.replace(bad, good)
    return value

def clean_payload(data, replacements):
    """Recursively clean all string values inside dict/list."""
    if isinstance(data, dict):
        return {k: clean_payload(v, replacements) for k, v in data.items()}
    elif isinstance(data, list):
        return [clean_payload(item, replacements) for item in data]
    else:
        return clean_text(data, replacements)

def create_project(access_token, job_number, project_name, p_address, p_city, p_pcode):
    ACCOUNT_ID, TEMPLATE_PROJECT_ID = access(["ACCOUNT_ID", "TEMPLATE_PROJECT_ID"])
    url = "https://developer.api.autodesk.com/construction/admin/v1/accounts/{}/projects".format(ACCOUNT_ID)

    acc_project_name = "{} - {}".format(job_number, project_name)

    text_cleanup_rules = [
        (u'\xb8', ','),   # weird cedilla comma
        # Add more rules here in the future
    ]

    payload = {
        "name": acc_project_name,
        "jobNumber": job_number,
        "type": "Project",
        "classification": "production",
        "timezone": "Australia/Brisbane",
        "constructionType": "Other",
        
        "addressLine1": p_address,
        "city": p_city,
        "stateOrProvince": "Queensland",
        "postalCode": str(p_pcode),
        "country": "Australia",
    
        "template": {
            "projectId": TEMPLATE_PROJECT_ID
        }
    }

    #Clean everything before sending
    payload = clean_payload(payload, text_cleanup_rules)
    if ",," in payload["addressLine1"]:
        forms.alert(
            "There are multiple commas (',,') in the project address.\n"
            "Please review and correct the address in the Revit file before continuing.\n\n"
            + payload["addressLine1"]
        )
        return None
    
    return http_post_json(url, payload, access_token)

# ADD MEMBER
def import_project_member(access_token, project_id, user_email, products, role_ids=None, company_id=None):
    url = "https://developer.api.autodesk.com/construction/admin/v1/projects/{}/users:import".format(project_id)

    user_obj = {
        "email": user_email,
        "products": products
    }

    if role_ids:
        user_obj["roleIds"] = role_ids

    if company_id:
        user_obj["companyId"] = company_id

    payload = {
        "users": [user_obj]
    }


    return http_post_json(url, payload, access_token)

# Excel opening functions
def net_array(*args):
    return Array[Object](list(args))

def com_get(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.GetProperty,
        None,
        obj,
        net_array(*args) if args else None
    )

def com_set(obj, name, value):
    obj.GetType().InvokeMember(
        name,
        BindingFlags.SetProperty,
        None,
        obj,
        net_array(value)
    )

def com_call(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.InvokeMethod,
        None,
        obj,
        net_array(*args) if args else None
    )

def get_email_list():
    import os
    excel = None
    workbook = None
    excel_path = os.path.join(lib_path, "Data base", "ACC member summary.xlsx")

    try:
        excel_type = Type.GetTypeFromProgID("Excel.Application")
        excel = Activator.CreateInstance(excel_type)

        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)

        workbooks = com_get(excel, "Workbooks")
        workbook = com_call(workbooks, "Open", excel_path)

        sheets = com_get(workbook, "Worksheets")
        sheet = com_get(sheets, "Item", "Members")

        used_range = com_get(sheet, "UsedRange")
        rows = com_get(used_range, "Rows")
        last_row = com_get(rows, "Count")

        cells = com_get(sheet, "Cells")
        rows_data = []

        for r in range(2, last_row + 1):
            row_list = []

            for c in range(1, 10):
                current_cell = com_get(cells, "Item", r, c)
                value = com_get(current_cell, "Value2")
                row_list.append(value)

            rows_data.append(row_list)

    finally:
        try:
            if workbook:
                com_call(workbook, "Close", False)
        except:
            pass

        try:
            if excel:
                com_call(excel, "Quit")
        except:
            pass
    
    return rows_data
    
def clean_guid(value):
    value = str(value).strip()

    if value.startswith("b."):
        value = value[2:]

    return Guid(value)