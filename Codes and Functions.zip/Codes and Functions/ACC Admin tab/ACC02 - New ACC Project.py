#--------------------------------------------------------------------
#------------ ACC02 - New ACC Project.py ----------------------------
#--------------------------------------------------------------------

import sys
import os
from pyrevit import forms

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import get_project_info, project_number_format, track_data

tab_function_path = os.path.join(functions_path,"ACC Admin tab")
sys.path.append(tab_function_path)
import STP_ACC_Functions
from STP_ACC_Functions import *
set_lib_path(Lib_Path)

# Constants
#----------
# Get Project Number
user_name = os.environ.get("USERNAME")
uidoc = __revit__.ActiveUIDocument

if uidoc:
    doc = uidoc.Document
    rvt_Data = get_project_info(doc)
    pr_Numb = rvt_Data["Project Number"]
    acc_name = rvt_Data["Project Name"]
    p_addr = rvt_Data["Project Address"]
    p_sub = rvt_Data["Suburb"]
    p_post = rvt_Data["Postcode"]
    p_client = rvt_Data["Client Name"]

else:
    doc = None
    pr_Numb = "STP"
    acc_name = ""
    p_addr = ""
    p_sub = ""
    p_post = ""
    p_client = ""


acc_numb = forms.ask_for_string(
    default=pr_Numb,
    prompt="Enter Project Number::",
    title="Project Number"
)

if not acc_numb:
    sys.exit()

if not project_number_format(acc_numb):
    forms.alert("Project Number format doesn't match the standard STPYY-0000 format. \n\n"
    "Please try again. Contact STP Tools developer if the problem persists")
    sys.exit()

### DEBUG LINE ###
#if user_name != "Rafael":
#    forms.alert("This tool is under revision. It will be working again soon.")
#    sys.exit()

USER_EMAIL_TO_ADD = ""
email_list = []
add_member = False
email_list = get_email_list()   ### activate when ready. Don't delete


if email_list:
    for line in email_list:
        name = line[0].upper()
        email = line[1]
        email_name = email.split("@")[0].upper()
        if email_name == user_name.upper():
            USER_EMAIL_TO_ADD = email
            add_member = True
            break


X_USER_ID = "645828e1-0955-41ca-869b-51ac74185d1f"
DEFAULT_TIMEZONE = "Australia/Brisbane"
DEFAULT_CONSTRUCTION_TYPE = "Other"
TEMPLATE_PROJECT_ID = "d1a4bef3-ccff-40da-a768-a61159176b5e".strip()
ROLE_ID = None
COMPANY_ID = None

# Product access for imported member
# Adjust these to match your company workflow if needed
MEMBER_PRODUCTS = [
    {
        "key": "projectAdministration",
        "access": "administrator"
    },
    {
        "key": "docs",
        "access": "administrator"
    }
]

# ============================================================
# MAIN
# ============================================================

token_data = get_token()
access_token = token_data["access_token"]
existing = find_project_by_job_number_api(access_token, acc_numb)

if existing:
    msg = ("This project number already exists in Autodesk Construction Cloud.\n\n"
           "Project Numb:   {}\n"
           "Project Name:   {}\n\n"
           "If you don't see the project folder in the ACC STP account, "
           "please confirm that the folder is not archived.".format(get_project_job_number(existing), get_project_name(existing)[11:])
           )
    forms.alert(msg, exitscript=False)
    sys.exit()
else:
    if acc_name == "":
        acc_name = forms.ask_for_string(
            default="",
            prompt="Enter the project name:",
            title="Project Name"
        )
        
        if acc_name == "" or not acc_name:
            forms.alert("Project Name cannot be empty.\n\nPlease try again")
            sys.exit()
    
    if acc_name:
        acc_name = acc_name.upper()
        msg = (
            "A new project folder will be created in Autodesk Construction Cloud using the following information:\n\n"
            "Project Numb:   {}\n"
            "Project Name:   {}".format(acc_numb, acc_name)
        )
        action = forms.alert(msg, options=["Procced", "Cancel"], title="{} Project has not been created yet.".format(acc_numb))
    
        if not action or not "Procced" in action:
            sys.exit()

msg = "Project created"

create_response = create_project(access_token, acc_numb, acc_name, p_addr, p_sub, p_post)
if not create_response:
    sys.exit()

if add_member:
    projects_after = get_all_projects(access_token, limit=200)
    new_project = find_project_by_job_number(projects_after, acc_numb)
    role_Ids = ['ff4b4050-6530-4ead-9ad9-c0ca6c5bda68', '7268a583-4ddc-4c64-a11a-02eb2941ecb7']
    COMPANY_ID = '918d87da-2dca-4d56-972f-ac57de55dff6'
    
    if not new_project:
        forms.alert("Project was created, but could not be found again by job number.\n\n Member not added to project")
        msg = ""
    
    else:
        new_project_id = get_project_id(new_project)
        member_result = import_project_member(
            access_token,
            new_project_id,
            USER_EMAIL_TO_ADD,
            MEMBER_PRODUCTS,
            role_Ids,
            COMPANY_ID
        )
        msg += " and member " + user_name + " added to the project"
        
if msg:
    msg += ".\n\nNumber: {}\nName: {}\nMember: {}".format(acc_numb, acc_name, USER_EMAIL_TO_ADD)
    forms.alert(msg, exitscript=False)

#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": acc_numb,
    "user": user_name,
    "file": "New ACC Folder",
    "items": "1"
}
track_data(Lib_Path, data, "ACC02")



