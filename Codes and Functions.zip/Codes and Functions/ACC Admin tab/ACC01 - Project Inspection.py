#--------------------------------------------------------------------
#------------ ACC01 - Project Inspection.py -------------------------
#--------------------------------------------------------------------

import sys
import os
from pyrevit import forms, revit, script
import inspect

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")



# Get Project Number
user_name = os.environ.get("USERNAME")
uidoc = __revit__.ActiveUIDocument

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import track_data, title_for_drawings, get_project_info

tab_function_path = os.path.join(functions_path,"ACC Admin tab")
sys.path.append(tab_function_path)
import STP_ACC_Functions
from STP_ACC_Functions import *

if uidoc:
    doc = uidoc.Document
    rvt_Data = get_project_info(doc)
    pr_Numb = rvt_Data["Project Number"]

else:
    doc = None
    pr_Numb = "STP"

### DEBUG LINE ###
#if user_name != "Rafael":
#    forms.alert("This tool is under revision. It will be working again soon.")
#    sys.exit()

acc_numb = forms.ask_for_string(
    default=pr_Numb,
    prompt="Enter the project name:",
    title="Project Name"
)

if not acc_numb:
    sys.exit()

#Find project number and folder
token_data = get_token()
access_token = token_data["access_token"]
existing = find_project_by_job_number_api(
    access_token,
    acc_numb
)

if not existing:
    forms.alert(
        "No ACC Project found for "
        + acc_numb
        + " project number"
    )
    sys.exit()

# -------------------------------------------------
# PROJECT INFORMATION
# -------------------------------------------------
with forms.ProgressBar(title='Getting Project Information') as pb:
    pb.update_progress(0.25, 1)
    project_name = existing.get("name")
    project_id = existing.get("id")
    active_members = get_active_project_members(
        access_token,
        project_id
    )

    # GET ACC TOP FOLDERS
    pb.update_progress(0.5, 1)
    top_folders = get_acc_top_folders(access_token, ACCOUNT_ID, project_id)
    if not top_folders:
        sys.exit()


    # FIND "PROJECT FILES"
    pb.update_progress(0.6, 1)
    project_files_folder = None

    for folder in top_folders:
        folder_name = folder.get(
            "attributes",
            {}
        ).get("name", "")

        if folder_name == "Project Files":
            project_files_folder = folder
            break
    
    pb.update_progress(0.75, 1)
    if not project_files_folder:
        forms.alert(
            "ACC Project found:\n\n"
            + project_name
            + "\n\n"
            + "'Project Files' folder could not be found."
        )
        sys.exit()

    # SEARCH FOR STP REVIT FILES
    pb.update_progress(0.9, 1)
    found_files = find_stp_revit_files(
        access_token,
        project_id,
        project_files_folder
    )

    if not found_files:
        forms.alert(
            "ACC Project found:\n\n"
            + project_name
            + "\n\n"
            + "No Revit files starting with 'STP' were found."
        )
        sys.exit()

# -------------------------------------------------
# CREATE OUTPUT REPORT
# -------------------------------------------------
Lines = []
output = script.get_output()
output.set_height(1000)

Lines.append("PROJECT FOUND AS: {}\n".format(project_name))
revit_files, autocad_files, other_files = found_files

Lines.append(title_for_drawings("STP REVIT FILES FOUND IN PROJECT:"))
if revit_files:
    for f in sorted(
        revit_files,
        key=lambda x: x["name"].lower()
    ):
        Lines.append("-" + f["name"])
else:
    Lines.append("- No STP Revit files found.")


Lines.append(title_for_drawings("ACTIVE MEMBERS IN PROJECT:"))
if active_members:
    active_members = sorted(
        active_members,
        key=lambda x: x.get("name", "").lower()
    )

    for member in active_members:
        name = member.get("name", "")
        email = member.get("email", "")

        if name and email:
            Lines.append("- {} ({})".format(name, email))

        elif name:
            Lines.append("- " + name)

        elif email:
            Lines.append("- " + email)

else:
    Lines.append("- No active members found.")


if autocad_files:
    Lines.append(title_for_drawings("STP CAD FILES FOUND IN PROJECT:"))
    for f in sorted(
        autocad_files,
        key=lambda x: x["name"].lower()
    ):
        Lines.append("-" + f["name"])


if other_files:
    Lines.append(title_for_drawings("OTHER FILES FOUND IN PROJECT:"))
    for f in sorted(
        other_files,
        key=lambda x: x["name"].lower()
    ):
        Lines.append("-" + f["name"])


first_line = True
for line in Lines:
    if first_line:
        output.print_html(
            '<span style="font-weight:bold; font-size:18px; color:green;">'
            '{}</span>'.format(line)
        )
        first_line = False
    
    elif "=" in line:
        output.print_html(
            '<span style="font-weight:bold; font-size:16px;">'
            '{} <br></span>'.format(line)
        )
        
    else:
        output.print_html(
            '<span style="font-size:18px;">'
            '{} <br></span>'.format(line)
        )


output.inject_script("window.scrollTo(0, 0);")

#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": acc_numb,
    "user": user_name,
    "file": "ACC Inspection",
    "items": "1"
}
track_data(Lib_Path, data, "ACC01")