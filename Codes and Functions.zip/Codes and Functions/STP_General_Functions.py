import os
import re
import sys
import shutil
import traceback
import ctypes
from pyrevit import forms, revit
from System.IO import File, FileMode, FileAccess, FileShare

from Autodesk.Revit.UI import UIDocument
from Autodesk.Revit.DB import FilteredElementCollector, Viewport, View, ViewSheet, FamilyInstance, BuiltInCategory, FamilySymbol

# Excel Libraries
from System import Type, Activator, Array, Object
from System.Reflection import BindingFlags
import System.Windows.Forms as WinForms
import System.Threading as Threading
import System.Diagnostics as diag


def aborting_message(code, error_message = ""):
    error_message += "\nSTP TOOLS ERROR\nCode: " + code + "\nModule: "
    module_name = "Unknown"
    
    code_keys = {
        "GF": "STP_General_Functions",
        "ACC": "STP_ACC_Functions",
        "MN": "Main Tool Code File"
        }
        
    if code[:2] in code_keys:
        module_name = code_keys[code[:2]]
    if code[:3] in code_keys:
        module_name = code_keys[code[:3]]
    
    error_message += module_name + ".\nPlease contact the STP Tools developer and provide this error code.\n"
    return error_message
        
def delete_or_supersede_titleblock(doc, action, new_fam, old_list):
    old_fam_list = [item.replace(".rfa","") for item in old_list if item is not None]
    
    # Collect all title block types
    titleblock_types = FilteredElementCollector(doc)\
        .OfCategory(BuiltInCategory.OST_TitleBlocks)\
        .WhereElementIsElementType()\
        .ToElements()
    with revit.Transaction("Delete or supersed Family", doc = doc):
        for tb in titleblock_types:
            fam_name = tb.Family.Name
            if not fam_name == new_fam:
                if action:
                    if fam_name in old_fam_list or fam_name.endswith("_SS"):
                        try:
                            doc.Delete(tb.Family.Id)
                        except:
                            pass
                else:
                    if fam_name in old_fam_list:
                        try:
                            tb.Family.Name = fam_name + "_SS"
                        except:
                            pass

def confirm_file_is_not_opened(file_path):
    if not os.path.exists(file_path):
        return False
        
    stream = None
    try:
        stream = File.Open(
            file_path,
            FileMode.Open,
            FileAccess.ReadWrite,
            FileShare.None
        )

    except:
        return True

    finally:
        if stream:
            stream.Close()   
        
def compare_data_maps(map_QA, map_B, update = False):
    unmatch = {}
    excluded_keys = ["map_name", "Project Status"]
    result = None
    if "Revit" in map_B["map_name"]:
        file_type = "project"
    elif "Transmittal" in map_B["map_name"]:
        file_type = "trasnmittal"
    else:
        file_type = ""
    
    for key in map_QA:
        if key in map_B and key not in excluded_keys:
            value_A = map_QA[key]
            value_B = map_B[key]

            if value_A != value_B:
                unmatch[key] = [
                    value_A,
                    value_B
                ]

    if unmatch:
        mismatch_text = ""
        for param, values in unmatch.items():
            qa_value = values[0]
            rvt_value = values[1]

            mismatch_text += (
                "{}:\n"
                "    QA File__ : {}\n"
                "    Revit File : {}\n\n"
            ).format(param, qa_value, rvt_value)
    
        if update == True:
            action = forms.alert(
                "The following {} information does not match the QA file:\n\n".format(file_type)
                + mismatch_text
                + "What would you like to do?",
                title="Project Information Mismatch",
                options=[
                    "Update Data",
                    "Continue Without Updating",
                    "Cancel"
                ]
            )   
        
            if action == "Update Data":
                return unmatch
            
            return action
        
        else:
            return unmatch
        
    return None

def create_folders_in_project(pr_path):
    all_disciplines = ["Civil", "Elec", "Fire", "Hyd", "Mech", "Struct"]
    new_folders = {
        "Current Drawings": all_disciplines,
        "Issued Drawings": all_disciplines,
        "xref": ["superseded"]
    }

    try:
        with forms.ProgressBar(title='Creating project folders for STP Tools...') as pb:
            pb.update_progress(1, 20)
            drawings_folder_path = os.path.join(pr_path, "Drawings")
            if not os.path.exists(drawings_folder_path):
                os.makedirs(drawings_folder_path)
            
            if os.path.exists(drawings_folder_path):
                x = 1
                for folder, sub_folders in new_folders.items():
                    x += 1
                    pb.update_progress(x, 20)
                    new_folder = os.path.join(drawings_folder_path, folder)
                    if not os.path.exists(new_folder):
                        os.makedirs(new_folder)
                    
                    if sub_folders and os.path.exists(new_folder):
                        for item in sub_folders:
                            x += 1
                            pb.update_progress(x, 20)
                            new_subfolder = os.path.join(new_folder, item)
                            if not os.path.exists(new_subfolder):
                                os.makedirs(new_subfolder)
                                
            pb.update_progress(19, 20)
    except Exception as e:
        print(aborting_message("GF0002", "ERROR CREATING FOLDER IN LOCAL MACHINES."))
        raise
            
    try:
        with open(os.path.join(drawings_folder_path, "local_config.txt"), "w") as f:
            pass
    except Exception as e:
        print(aborting_message("GF0003", "ERROR WHILE CREATING LOCAL CONFIG. TXT FILE."))
        raise
            
def create_new_project(template_path):
    if not os.path.exists(template_path):
        forms.alert(
            "Revit template not found:\n\n{}".format(
                template_path
            )
        )
        return None

    new_doc = __revit__.Application.NewProjectDocument(
        template_path
    )
    new_uidoc = UIDocument(new_doc)

    viewport = (
        FilteredElementCollector(new_doc)
        .OfClass(Viewport)
        .WhereElementIsNotElementType()
        .FirstElement()
    )

    if viewport:
        new_uidoc.ShowElements(
            viewport.Id
        )
        return new_doc

    # OTHERWISE FIND AN ELEMENT IN A VIEW
    views = (
        FilteredElementCollector(new_doc)
        .OfClass(View)
    )

    for view in views:
        if view.IsTemplate:
            continue
        try:
            elements = (
                FilteredElementCollector(
                    new_doc,
                    view.Id
                )
                .WhereElementIsNotElementType()
                .ToElementIds()
            )

            for element_id in elements:
                new_uidoc.ShowElements(
                    element_id
                )
                return new_doc
        except:
            pass

    forms.alert(
        "The new project was created, but Revit "
        "could not activate a view."
    )
    return new_doc

def fill_design_info(doc, List):
    drafter = get_initials(List[0] if List[0] != "Other" else "")
    designer = get_initials(List[1] if List[1] != "Other" else "")
    approver_name = List[2]
    approver = get_initials(approver_name if approver_name != "Other" else "")
    signature = "Signature " + approver_name.replace(" Florence", "").replace(" Graham","")
    
    f15 = List[3]
    f15_sign = "Signature - " + f15
    f15_cred = "Cridentials - " + f15
    p_client = List[4]
    
    design_parameters = ["Drawn By", "Designed By", "Approved By"]
    design_parameters.extend((approver_name, signature))
    design_values = [drafter, designer, approver, int(1), int(1)]
    
    sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    
    # Filter only sheets whose number starts with "S"
    filtered_sheets = [sheet for sheet in sheets if sheet.SheetNumber.startswith("S")]
    
    #if os.environ.get("USERNAME") != "Rafael":
    with revit.Transaction("Update Design Info", doc = doc):
    # For each filtered sheet, collect its title block instances
        with forms.ProgressBar(title='Update Design Info') as pb:
            lim = len(filtered_sheets)
            for x, sheet in enumerate(filtered_sheets):
                title_blocks = FilteredElementCollector(doc, sheet.Id)\
                    .OfClass(FamilyInstance)\
                    .OfCategory(BuiltInCategory.OST_TitleBlocks)\
                    .ToElements()

                for tb in title_blocks:
                    if not "Brian" in approver_name:
                        param = tb.LookupParameter("Brian Mayer"); param and param.Set(int(0))
                        param = tb.LookupParameter("Signature Brian Mayer"); param and param.Set(int(0))
                
                    for par, val in zip(design_parameters, design_values):
                        param = tb.LookupParameter(par); param and param.Set(val)
                
                pb.update_progress(x, lim + 1)
                
            filtered_sheets = [sheet for sheet in sheets if sheet.SheetNumber.startswith("1")]

            for sheet in filtered_sheets:
                title_blocks = FilteredElementCollector(doc, sheet.Id).OfCategory(BuiltInCategory.OST_TitleBlocks).WhereElementIsNotElementType()
                for tb in title_blocks:
                    if tb.Name == "STP_A4_Transmittal-Vertical":
                        param = tb.LookupParameter("Distribution 1"); param and param.Set(p_client)
                    tb_type = doc.GetElement(tb.GetTypeId())
                    if not "Brian" in f15:
                        type_param = tb_type.LookupParameter("Cridentials - Brian"); type_param and type_param.Set(int(0))
                        type_param = tb_type.LookupParameter(f15_cred); type_param and type_param.Set(int(1))
                        param = tb.LookupParameter("Signature - Brian"); param and param.Set(int(0))
                        param = tb.LookupParameter(f15_sign); param and param.Set(int(1))
    
    if drafter:
        return drafter
    else:
        return ""

def find_extension_path(script_path):
    if "STPV3" in script_path:
        folder_name = "STPV3.extension"
    else:
        folder_name = "STP Tools.extension"

    stp_extension_path = (
        os.path.normpath(script_path)
          .split(os.sep + folder_name)[0]
        + os.sep + folder_name
    )
    
    if os.path.exists(stp_extension_path):
        return stp_extension_path
    else:
        return None

def find_post_code_main(lib_path, suburb):
    postcode = "" # No Code
    council = ""
    codes_path = os.path.join(lib_path, "Data Base", "postcode list.txt")
    suburb_line = ""
    sl = len(suburb)
    n = 0
    
    try:
        with open(codes_path, 'r+') as file:
            lines = file.readlines()
            # Find if the suburb exists in the list
            for line in lines:
                if "#" in line:
                    suburb_in_line = line.split("#")[0].strip()
                    if suburb.upper() == suburb_in_line.upper():
                        suburb_line = line
                        break
            
            # Depends on action, read the suburb or record new entry
            if suburb_line:
                n = line.find("#")
                if n > 0:
                    postcode = line[n+1:n+5]
                    if len(line) > n + 7:
                        council = line[n+6:].replace("\n","")
    except:
        pass
    
    return postcode, council

def fill_project_info(doc, params):
    aux_Address = ""

    try:
        project_info = doc.ProjectInformation
        if not project_info.LookupParameter("Suburb"):
            aux_Address = params[2][1] + ", " + params[3][1] + ", QLD, " + params[4][1]
        with revit.Transaction("STP Tools-parameters", doc = doc):
            for x, param in enumerate(params):
                param_name = ""
                for info_param in project_info.Parameters:
                    if info_param.Definition.Name == param[0]:
                        param_name = info_param
                        break
                if param_name:
                    param_name.Set(params[x][1])
                    if param_name.Definition.Name == "Project Address" and aux_Address:
                        info_param.Set(aux_Address)
        return True

    except Exception as e:
        print(aborting_message("GF0001", "ERROR WHILE FILLING PROJECT INFORMATION."))
        raise

def fill_titleblock_list(path):
    local_report = ""
    
    tb_names = []
    tb_pahts = []
    tb_version = []
    tb_side = []
    tb_size = []
    tb_Info = []
    
    # Open the file and read it line by line
    try:
        with open(path, 'r') as file:
            for line in file:
                # Look for lines starting with 'tb_path ='
                if line.strip().startswith('tb_path'):
                    tb_pahts.append(line.strip()[10:])
                if line.strip().startswith('name'):
                    tb_names.append(line.strip()[7:])
                if line.strip().startswith('version'):
                    tb_version.append(line.strip()[7:])
                if line.strip().startswith('side'):
                    tb_side.append(line.strip()[7:])
                if line.strip().startswith('size'):
                    tb_size.append(line.strip()[7:])
            
            tb_Info = ((tb_names, tb_pahts, tb_version, tb_side, tb_size))
            return tb_Info
            
    except Exception as e:
        print(aborting_message("GF0008", "ERROR WHILE FILLING FILLING TITLE BLOCK LIST."))
        raise

def get_initials(name):
    val = "".join(word[0].upper() for word in name.split() if word)
    return val if val != "BM" else "BRM"

def get_project_folders_from_onedrive(user_name, lib_path): 
    possible_job_paths = None
    if "bin" in lib_path: # This is for drafters who work in a local machine not connected to share point
        file_path = os.path.join(lib_path, "local_projects_path.txt")
        
        local_job_path = ""
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                local_job_path = file.readline().strip()
                possible_job_paths = [local_job_path]
                
        if not local_job_path or not os.path.exists(local_job_path):
            forms.alert("Select the STP Folder for Local Projects.\n"
                "This is a one time proccess. If your Local Project Location changes"
                "Please use 'Settings Tab' and select 'Define Local Folder'")
            selected_folder = forms.pick_folder(
                title="Select STP Tools Folder"
            )   

            if selected_folder and os.path.exists(selected_folder):
                possible_job_paths = [selected_folder]
                with open(file_path, "w") as f:
                    f.write(selected_folder)
            else:
                sys.exit()
    
    else: #And this is for everyone else
        possible_job_paths = [
            r"D:\OneDrive - STP Consultants",
            r"E:\OneDrive - STP Consultants",
            r"C:\STP Consultants\OneDrive - STP Consultants",
            r"D:\STP Consultants\OneDrive - STP Consultants",
            r"C:\Users\STP Consultants",
            r"C:\Users\{}\STP Consultants".format(user_name),
            r"E:\Users\{}\STP Consultants".format(user_name),
            r"C:\Users\{}\OneDrive - STP Consultants".format(user_name),
            r"E:\Users\{}\OneDrive - STP Consultants".format(user_name),
            r"C:\Users\{}\STP Consultants".format(user_name + ".STPTSV"),
            r"E:\Users\{}\STP Consultants".format(user_name + ".STPTSV"),
            r"C:\Users\{}\OneDrive - STP Consultants".format(user_name + ".STPTSV"),
            r"E:\Users\{}\OneDrive - STP Consultants".format(user_name + ".STPTSV")]
        
    stp_folders = []
    projects = []
    aux_list = []

    # Regular expression to match folder names starting with 'STP' followed by two digits
    pattern = re.compile(r"^STP\d{2}")
    for path in possible_job_paths:
        if os.path.exists(path):
            if os.path.exists(os.path.join(path, 'desktop.ini')) or "bin" in lib_path:
                try:
                    for item in os.listdir(path):  # List all items in the directory
                        if os.path.isdir(os.path.join(path, item)):  # Check if the item is a folder
                            if pattern.match(item):  # Check if it matches the STP format
                                confirm_folder_path = os.path.join(path, item, "QA")  # Confirm project folder
                                if os.path.exists(confirm_folder_path) or "bin" in lib_path:
                                    stp_folders.append((item, os.path.join(path, item)))
                                
                            # Now check one level down in this folder
                            subfolder_path = os.path.join(path, item)
                            for sub_item in os.listdir(subfolder_path):  # List all items in the sub-folder
                                if os.path.isdir(os.path.join(subfolder_path, sub_item)) and pattern.match(sub_item):
                                    confirm_folder_path = os.path.join(subfolder_path, sub_item, "QA")  # Confirm project folder
                                    if os.path.exists(confirm_folder_path):
                                        stp_folders.append((sub_item, os.path.join(subfolder_path, sub_item)))

                except:
                    pass
        
        #if stp_folders:
        #    break
    
    if stp_folders:
        for folder in stp_folders:
            code = folder[0][:10]
            p_numbs = ""
            p_names = ""
            
            # Check the project code and name based on different patterns
            try:
                if code[-3:] == "xxx":
                    p_numbs = folder[0][13:][:10]
                    p_names = folder[0][24:]
                elif code[5] == "-":
                    p_numbs = folder[0][:10]
                    p_names = folder[0][11:]
                elif code[-1] == " ":
                    p_numbs = folder[0][:5] + "-" + folder[0][5:9]
                    p_names = folder[0][10:]
                
                if p_numbs != "":
                    # Append the tuple with project number, name, and folder path
                    aux_list.append((p_numbs, p_names, folder[1]))
            except:
                pass
        
        if aux_list:
            # Sort the projects by project number
            projects = sorted(aux_list, reverse=True)


        return projects

def get_project_info(doc):
    List = {"map_name": "Revit Project Information"}
    local_report = ""
    
    project_info = doc.ProjectInformation
    params = ["Project Number", "Project Name", "Project Address",
              "Suburb", "Postcode", "Client Name", "Project Status",
              "Client Reference Number", "Qbuild Project Number"]
    
    
    for param in project_info.Parameters:
        if param.Definition.Name == "Building Name" and not param.IsShared:
            par_value = param.AsString()
            List["Building Name"] = str(par_value).strip().upper().replace(".0","")
            break
    
    for param in params:
        par_name = project_info.LookupParameter(param)
        if par_name:
            par_value = par_name.AsString()
            if par_value == None:
                List[param] = ""
            else:
                List[param] = par_value
        else:
            if param == "Suburb":
                List[param] = "N/F"
            else:
                List[param] = ""

    return List

def get_qa_path(lib_path, p_path, p_numb):
    qa_exist = False
    
    qa_folder = os.path.join(p_path, "Drawings")
    qa_path = os.path.join(qa_folder, p_numb + "_QA_Checklist.xlsx")
    txt_path = os.path.join(qa_folder, "r25_support_temp_file.txt") #Check if the previous version exists to change
    ss_path = os.path.join(qa_folder, "SS_support_temp_file_SS.txt")
    
    #if os.path.exists(txt_path):
    #    try:
    #        #Check if old macro excel file exists and delete it
    #        macro_path = qa_path.replace("xlsx", "xlsm")
    #        if os.path.exists(macro_path):
    #            os.remove(macro_path)
            
    #        #Copy the V2 file excel into folder
    #        qa_path = copy_QA_excel_file_to_folder(lib_path, qa_folder, p_numb)
    #        
    #        with open(txt_path, "r") as f:
    #            copied_lines = f.readlines()
            
    #        first_line = True
    #        qa_copied_lines = []
            
    #        for line in copied_lines:
    #            items = [x.strip() for x in line.strip().split(",")]
    #            if not first_line:
    #                qa_copied_lines.append(items)
    #            first_line = False
    #        write_qa_excel_file_V2(qa_path, qa_copied_lines)
    #        qa_exist = True
    #        os.rename(txt_path, ss_path)
    #        qa_exist = True
    #    except Exception as e:
    #        print(aborting_message("GF0005", "ERROR WHILE TRYING TO CHANGE FROM TXT QA FILE TO EXCEL"))
    #        raise
        

    if os.path.exists(qa_path):
        qa_exist = True
        
    return qa_exist, qa_path

def get_save_action(keymaps, from_temp, cloud = [False, False]):
    if not keymaps:
        return None
    
    for key, selected_map in keymaps.items():
        keymap = selected_map
        break

    file_path = selected_map["file_path"]
    p_path = os.path.dirname(file_path)
    p_numb = selected_map["pr_number"]
    file_name = selected_map["file_name"]
    std_folders = selected_map["std_folders"]

    
    save_options = [
        "Save to Autodesk Forma (Former ACC)",
        "Save to SharePoint Current Drawings Folder",
        "Select a Specific Location",
        "Don't Save or Allow to save manually"
    ]
    
    while True:
        save_action = forms.alert(
            "Where do you want to save the Revit file?",
            title="Save Revit File",
            options = save_options,
            warn_icon=False
        )
        
        # User closed the window
        if not save_action:
            return None
    
        # SHAREPOINT CURRENT DRAWINGS
        if "Current" in save_action and std_folders == False:
            extra_line = "\n\nProject Folder >> Drawings >> Current Drawings\n\n"
            forms.alert(
                "The folder structure for this project {}, "
                "does not match the STP standard folder structure shown below:"
                "\n\nProject Folder >> Drawings >> Current Drawings\n\n"
                "Please select 'Select a Specific Location' instead.".format(p_numb),
                title="Current Drawings Folder Not Found"
            )
            continue
    
        # SPECIFIC LOCATION
        if "Location" in save_action:
            selected_path = forms.pick_folder(
                title="Select the Location for the Revit File.")

            # If user cancels, go back to save options
            if not selected_path:
                continue
            
            else:
                # Use the folder selected by the user as-is
                selected_map["file_path"] = os.path.join(selected_path, file_name + ".rvt")
                return save_action

        if "Forma" in save_action:
            if not from_temp:
                # 1. Make sure current document is not already a cloud model
                if cloud[0] == True:
                    forms.alert(
                        "This script is intended for non-cloud saved files only.\n\n"
                        "Current document is already in the cloud."
                    )
                    continue

                # 2. Make sure document is not workshared
                if cloud[1] == True:
                    forms.alert(
                        "This script is intended for non-workshared files only.\n\n"
                        "Current document is already workshared."
                    )
                    continue
            
            selected_map["file_path"] = "acc_path"
            return save_action
            
        if "Allow" in save_action:
            selected_map["file_path"] = None
            return save_action
            
        # DON'T SAVE / MANUAL SAVE
        return save_action
        
def load_title_block(doc, tb_source, tb_target):
    
    if tb_source == "QA_data" and not os.path.exists(tb_target):
        forms.alert(
            os.path.basename(tb_target) + 
            " was expected in the 'Xref' folder but was not found." + 
            " It may have been deleted. \n\nTitle block could not be loaded."
        )
        return False
    
    with revit.Transaction("STP Tools-Load TB", doc = doc):
        if os.path.exists(tb_target):
            try:
                family = doc.LoadFamily(tb_target)

            except:
                forms.alert("Error while loading title block.\n\nPlease "
                "try again or contact STP Tool developer for assitance")
            
        else:
            if os.path.exists(tb_source):
                try:
                    tb_folder = os.path.dirname(tb_target)
                    if not os.path.exists(tb_folder):
                        os.makedirs(tb_folder)
                    shutil.copy2(tb_source, tb_target)
                    family = doc.LoadFamily(tb_target)
                    return "delete", tb_target
                except:
                    forms.alert("Error while copying title block or folders.\n\nPlease "
                    "try again or contact STP Tool developer for assitance")

                    if os.path.exists(tb_target):
                        os.remove(tb_target)
    
            else:
                forms.alert("Selected Title Block not found. STP Tools will skip title block load.")
    
    return False

def project_number_format(pr_number):
    if re.match(r"^STP\d{2}-\d{4}$", pr_number):
        return True
    else:
        return False

def read_qa_excel_file_V2(qa_path):
    excel = None
    workbook = None
    workbooks = None
    sheets = None
    sheet = None
    cells = None
    local_report = ""
    
    try:
        f = open(qa_path, "a")
        f.close()
    except:
        forms.alert(
            "STP Tools found a problem while reading the QA Excel file.\n\n"
            "This usually happens when the file is open or Excel is still running in the background.\n\n"
            "Please close all Excel windows (including background processes directly from 'Task Manager') and try again.\n\n"
            "If the issue continues, contact the STP Tools developer.",
            title="Error Reading QA File"
        )
        sys.exit()

    try:
        excel_type = Type.GetTypeFromProgID("Excel.Application")
        if excel_type is None:
            raise Exception("Excel COM ProgID not found")

        excel = Activator.CreateInstance(excel_type)
        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)

        workbooks = com_get(excel, "Workbooks")
        workbook = com_call(workbooks, "Open", qa_path)

        sheets = com_get(workbook, "Worksheets")
        sheet = com_get(sheets, "Item", "Changes_Record")
        cells = com_get(sheet, "Cells")
        
        data_sheet = com_get(sheets, "Item", "Project Checklist")
        data_cells = com_get(data_sheet, "Cells")

        # -------- Get info from Check lis page
        cell = com_get(data_cells, "Item", 12, 2)
        acc_file = com_get(cell, "Value2")
        
        main_data = {
            "map_name": "QA File Information",
            "acc_file": acc_file,
            "Qbuild Project Number": "",
            "Client Reference Number": ""
        }
        
        reng = 13
        while True:
            cell = com_get(data_cells, "Item", reng, 1)
            value = com_get(cell, "Value2")
            
            if not value or value == "":
                break
            
            if value == "Client Reference Number" or "CLIENT PROJECT" in value:
                cell = com_get(data_cells, "Item", reng, 3)
                ref_value = com_get(cell, "Value2")
                if ref_value is not None:
                    main_data["Client Reference Number"] = str(ref_value).replace(".0","").strip()
            
            elif value == "Qbuild Project Number":
                cell = com_get(data_cells, "Item", reng, 3)
                ref_value = com_get(cell, "Value2")
                if ref_value is not None:
                    main_data["Qbuild Project Number"] = str(ref_value).replace(".0","").strip()
            
            reng += 1
                
        
        # -------- find last row --------

        max_excel_rows = 1048576
        last_cell_col_a = com_get(cells, "Item", max_excel_rows, 1)
        end_up = com_get(last_cell_col_a, "End", -4162)   # xlUp
        last_row = com_get(end_up, "Row")

        # -------- find last column --------

        max_excel_cols = 16384
        last_cell_in_row = com_get(cells, "Item", last_row, max_excel_cols)
        end_left = com_get(last_cell_in_row, "End", -4159)   # xlToLeft
        last_col = com_get(end_left, "Column")

        # -------- read last row --------


        
        main_keys = ["No", "Project Name", "Client Name", "Project Address",
                     "Suburb", "Postcode", "tb_Name", "tb_Type", "tb_Side", "tb_Size",
                     "last_user", "revit_version", "modif_date"]

        for c, key in enumerate(main_keys, start=1):
            cell = com_get(
                cells,
                "Item",
                last_row,
                c
            )

            value = com_get(cell, "Value2")

            if isinstance(value, basestring):
                value = value.strip()

            elif value is None:
                value = ""

            elif isinstance(value, float) and value.is_integer():
                value = str(int(value))

            else:
                value = str(value)

            main_data[key] = value
        

        # -------- extra fixed values --------

        p_Type = com_get(com_get(cells, "Item", 1, 2), "Value2")

        qa_revit_version = com_get(com_get(cells, "Item", 2, 12), "Value2")
        qa_revit_version = str(qa_revit_version).replace(".0", "")

        first_user = com_get(com_get(cells, "Item", 2, 11), "Value2")

        # -------- collect unique values from column G --------

        type_list = []
        seen = set()

        for r in range(2, last_row + 1):  # skip header row
            cell = com_get(cells, "Item", r, 7)
            value = com_get(cell, "Value2")

            if value not in [None, ""]:
                value = str(value)

                if value not in seen:
                    seen.add(value)
                    type_list.append(value)

        # -------- combine extra data --------
        main_data["pr_type"] = p_Type[-4:]
        main_data["revit_version"] = qa_revit_version
        main_data["first_user"] = first_user
        main_data["tb_history"] = type_list
        main_data["Postcode"] = str(main_data["Postcode"]).replace(".0","")
        
        if main_data["No"] == "No.":
                mssg = "QA excel file is empty. \n\n" + \
                       "Please open QA manually to check if there is information available. " + \
                       "If the problem persists, contact the STP Tools Admin for further support."
                forms.alert(mssg)
                sys.exit()
        
        return main_data

    except Exception as e:
        print(aborting_message("GF0001", "ERROR WHILE READING QA EXCEL FILE:.\n" + qa_path))
        raise
        

    finally:
        try:
            if workbook:
                com_call(workbook, "Close", False)
        except:
            pass

        try:
            if excel:
                com_call(excel, "Quit")
        except:
            pass
            
        cells = None
        sheet = None
        sheets = None
        workbook = None
        workbooks = None
        excel = None

def read_transmittal_file(trm_path):
    excel = None
    workbook = None
    workbooks = None
    sheets = None
    sheet = None
    cells = None
    local_report = ""
    
    try:
        f = open(trm_path, "a")
        f.close()
    except:
        forms.alert(
            "STP Tools found a problem while reading the QA Excel file.\n\n"
            "This usually happens when the file is open or Excel is still running in the background.\n\n"
            "Please close all Excel windows (including background processes directly from 'Task Manager') and try again.\n\n"
            "If the issue continues, contact the STP Tools developer.",
            title="Error Reading QA File"
        )
        sys.exit()

    try:
        excel_type = Type.GetTypeFromProgID("Excel.Application")
        if excel_type is None:
            raise Exception("Excel COM ProgID not found")

        excel = Activator.CreateInstance(excel_type)

        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)

        workbooks = com_get(excel, "Workbooks")
        workbook = com_call(workbooks, "Open", trm_path)

        sheets = com_get(workbook, "Worksheets")
        sheet = com_get(sheets, "Item", 1)
        cells = com_get(sheet, "Cells")

        # -------- Get info from transmittal page
        main_keys = ["Project Name", "Project Address", "Client Name"]
        transm_map = {"map_name": "Transmittal Information"}
        for reng, key in enumerate(main_keys):
            cell = com_get(cells, "Item", 3 + reng, 4)
            value = com_get(cell, "Value2")
            transm_map[main_keys[reng]] = value

        if transm_map["Project Address"] == "":
            mssg = "Transmittal file is empty. \n\n" + \
                   "Please open Transmittal manually to check if there is information available. " + \
                   "If the problem persists, contact the STP Tools Admin for further support."
            forms.alert(mssg)
            sys.exit()

        address_items = [x.strip() for x in transm_map["Project Address"].split(",")]

        transm_map["Project Address"], \
        transm_map["Suburb"], \
        transm_map["State"], \
        transm_map["Postcode"] = address_items
        
        return transm_map

    except Exception as e:
        #raise
        print(aborting_message("GF0010", "ERROR WHILE READING QA EXCEL FILE:.\n" + trm_path))

    finally:
        try:
            if workbook:
                com_call(workbook, "Close", False)
        except:
            pass

        try:
            if excel:
                com_call(excel, "Quit")
        except:
            pass
            
        cells = None
        sheet = None
        sheets = None
        workbook = None
        workbooks = None
        excel = None

def remove_non_ascii(text):
    res = ""
    for c in text:
        if c == u'\u2019':
            c = "'"
        res = res + c
    return res

def remove_spaces_and_points(val):
    text = str(val)
    Symbols = [".", " ", "."]
    n = len(text)
    if n > 0:
        for n in range(n):
            if text[n] not in Symbols:
                break
    
    return text[n:]

def replace_title_block(doc, sheet_list, source_tblock, new_tb, dx, dy):
    local_report = ""

    # Collect all title block types
    titleblock_types = FilteredElementCollector(doc)\
        .OfCategory(BuiltInCategory.OST_TitleBlocks)\
        .WhereElementIsElementType()\
        .ToElements()

    current_tb_names = {tb.Family.Name: tb for tb in titleblock_types}
    if source_tblock in current_tb_names and new_tb in current_tb_names:
        source_type = current_tb_names[source_tblock]
        new_type = current_tb_names[new_tb]

        # First: collect all replacements
        to_replace = []

        sheets = FilteredElementCollector(doc)\
            .OfCategory(BuiltInCategory.OST_Sheets)\
            .WhereElementIsNotElementType()\
            .ToElements()
        
        with forms.ProgressBar(title='Finding Sheets to replace') as pb:
            dt = 0.5 / len(sheets)
            x = 0
            n_item = 0

            for sheet in sheets:
                pb.update_progress(x + dt, 1)
                x = x + dt
                n_item += 1
                pb.title = 'Finding Sheets to replace ' + str(n_item) + ' of ' + str(len(sheets))
                
                if sheet.SheetNumber in sheet_list or sheet_list == "ALL":
                    tblocks = FilteredElementCollector(doc, sheet.Id)\
                        .OfCategory(BuiltInCategory.OST_TitleBlocks)\
                        .WhereElementIsNotElementType()\
                        .ToElements()
                
                    for tb in tblocks:
                        tb_type = doc.GetElement(tb.GetTypeId())
                        if tb_type.Family.Name == source_tblock:
                            to_replace.append((sheet.Id, tb.Id))

            if to_replace:
                dt = 0.5 / len(to_replace)
                x = 0.5

                try:
                    with revit.Transaction(
                        "Replace Title Blocks",
                        doc=doc
                    ):

                        for sheet_id, tb_id in to_replace:
                            sheet = doc.GetElement(sheet_id)
                            tb = doc.GetElement(tb_id)

                            if not tb:
                                continue

                            pb.update_progress(x + dt, 1)
                            x += dt

                            pb.title = ("Replacing sheet " + sheet.SheetNumber)

                            # Replace the existing title block
                            tb.ChangeTypeId(new_type.Id)

                            # Move if required
                            if dx != 0 or dy != 0:

                                move_vector = XYZ(dx, dy, 0)

                                ElementTransformUtils.MoveElement(
                                    doc,
                                    tb.Id,
                                    move_vector
                                )

                except Exception as e:
                    print(
                        aborting_message(
                            "GF0008",
                            "ERROR WHILE REPLACING TITLE BLOCK."
                        )
                    )
                    raise

                    
    else:
        local_report += u"\u274C Stage: Replace Title Block Fail: One or both title block types not found.\n"
        return local_report, False
    
    return local_report, True

def save_file(doc):
    if doc.PathName: #Save to avoid problems
        try:
            doc.Save()
        except:
            pass

def select_stp_tabs(pyRevit_path):
    Tabs = ["ELECTRICAL TOOLS TAB", "STRUCTURAL TOOLS TAB"]
    Folders = ["STP Electrical", "STP Structural"]
    selected_tabs = forms.SelectFromList.show(
        sorted(Tabs),
        title="Select your discipline from the list below",
        multiselect=True,
        button_name='Select',
        group_by_value=False
        )
    
    if not selected_tabs == None:
        for x, tab in enumerate(Tabs):
            if tab in selected_tabs:
                old_path = os.path.join(pyRevit_path,Folders[x])
                new_path = os.path.join(pyRevit_path,Folders[x] + ".tab")
            else:
                old_path = os.path.join(pyRevit_path,Folders[x] + ".tab")
                new_path = os.path.join(pyRevit_path,Folders[x])
            
            if os.path.exists(old_path):
                os.rename(old_path, new_path)
                
        return True

def select_discipline(default_disc=None):

    disciplines = {
        "Electrical": "Elec",
        "Fire": "Fire",
        "Hydraulic": "Hyd",
        "Mechanical": "Mech",
        "Structural": "Struct"
    }

    options = list(disciplines.keys())

    dlg = forms.SelectFromList(
        options,
        "Select a Discipline",
        500,
        400,
        multiselect=False
    )

    # Preselect default
    if default_disc in options:

        default_index = options.index(default_disc)

        def set_default_disc(sender, args):

            dlg.list_lb.SelectedIndex = default_index

            dlg.list_lb.ScrollIntoView(
                dlg.list_lb.SelectedItem
            )

            dlg.list_lb.Focus()

            item = dlg.list_lb.ItemContainerGenerator.ContainerFromIndex(
                default_index
            )

            if item:
                item.Focus()

        dlg.Loaded += set_default_disc

    dlg.ShowDialog()

    selected_discipline = dlg.response

    if not selected_discipline:
        return None

    return [
        selected_discipline,
        disciplines[selected_discipline]
    ]

def set_default_disc(sender, args):

    dlg.list_lb.SelectedIndex = default_index
    dlg.list_lb.ScrollIntoView(
        dlg.list_lb.SelectedItem
    )

    dlg.list_lb.Focus()

    item = dlg.list_lb.ItemContainerGenerator.ContainerFromIndex(
        default_index
    )

    if item:
        item.Focus()

def supersed_tblock_family(tb_names):
    symbols = (
        FilteredElementCollector(revit.doc)
        .OfClass(FamilySymbol)
        .OfCategory(BuiltInCategory.OST_TitleBlocks)
    )
    
    with revit.Transaction("Rename Annotation Family"):
        for symbol in symbols:
            family = symbol.Family
            
            for item in tb_names:
                tb_name = item.replace(".rfa","")
                if family.Name in tb_name:
                    family.Name = family.Name + "_SS"
                    break

def split_address(lib_path, address):
    p_address = ""
    p_suburb = ""
    p_pcode = ""
    p_region = ""
    abrevations = [" ST", " RD", " DR"]
    roads = ["ROAD", "STREET", "AVENUE", "BOULEVARD", "DRIVE", "LANE", "CRESCENT", "TERRACE", "CIRCUIT", "COURT", "WAY", "CLOSE"]
    found_road = None
    #roads.extend(abrevations)
    len_word = 0
    p_address = "N/F"; p_suburb = ""; p_pcode = ""
    
    for road in roads:
        if road in address:
            found_road = road
            break
            
    if not found_road:
        for road in abrevations:
            if road in address:
                found_road = road
                break
        
    if found_road:
        position = address.find(road)
        if position > 0:
            len_word = len(road)
            p_address = address[:(position + len_word)]
            p_suburb = remove_spaces_and_points(address[(position + len_word) + 1:])

            if len(p_suburb) > 3 and p_suburb[:2] == "- ":
                p_suburb = p_suburb[2:]
            
    if p_suburb:
        p_pcode, p_region = find_post_code_main(lib_path, p_suburb)
    
    return p_address, p_suburb, p_pcode, p_region

def title_for_drawings(title):
    aux_msg = "\n============================================\n"
    aux_msg += "< < " + title + " > >\n"
    aux_msg += "============================================\n"
    return aux_msg

def write_qa_excel_file_V2(qa_path, action, qa_new_lines, eData):
    excel = None
    workbook = None
    success = False
    s_type = eData["p_type"]
    if action == "Modify":
        s_type = eData["ini_type"]
    
    try:
        excel_type = Type.GetTypeFromProgID("Excel.Application")
        excel = Activator.CreateInstance(excel_type)

        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)

        workbooks = com_get(excel, "Workbooks")
        workbook = com_call(workbooks, "Open", qa_path)

        sheets = com_get(workbook, "Worksheets")
        sheet = com_get(sheets, "Item", "Changes_Record")
        cells = com_get(sheet, "Cells")

        data_sheet = com_get(sheets, "Item", "Project Checklist")
        data_cells = com_get(data_sheet, "Cells")

        max_cols_to_check = max(len(qa_new_lines[0]), 13, 1)
        target_row = get_next_empty_row(sheet, max_cols_to_check)
        # Change header B1 only when s_type is not "G"
        
        #Get row for client ref and qbuild ref
        reng = 13
        client_row = None
        qbuild_row = None
        
        while True:
            cell = com_get(data_cells, "Item", reng, 1)
            value = com_get(cell, "Value2")
            
            if not value or value == "":
                break
            
            if value == "Client Reference Number" or "CLIENT PROJECT" in value:
                client_row = reng
            
            elif value == "Qbuild Project Number":
                qbuild_row = reng
            
            reng += 1  
        
        
        if action == "Create" or action == "Update":
            if s_type != "":
                header_cell = com_get(cells, "Item", 1, 2)
                com_set(header_cell, "Value2", "PROJECT NAME {}".format(s_type))
                
        # -------- Set the info from Check list page
        if action == "Create" and eData.get("acc_file"):           
            cell = com_get(data_cells, "Item", 12, 3)
            acc_file = com_set(cell, "Value2", eData["acc_file"])

        if action == "Create" or action == "Modify":
            if client_row > 0:
                cell = com_get(data_cells, "Item", client_row, 3)
                client_ref = com_set(cell, "Value2", eData["ref_client"])
            
            if qbuild_row > 0:
                cell = com_get(data_cells, "Item", qbuild_row, 3)
                qbuild_ref = com_set(cell, "Value2", eData["ref_qbuild"])

        # Write new row
        for qa_new_line in qa_new_lines:
            write_row(cells, target_row, qa_new_line)

            # Set automatic row number in first column
            no_cell = com_get(cells, "Item", target_row, 1)
            com_set(no_cell, "Value2", target_row - 1)
            target_row += 1


        if s_type == "[PR]" and action == "Create":
            try:
                if "initials" in eData:
                    checklist_cells = ["D3", "D4", "D5", "D7", "D8", "D9", "D10"]

                    for addr in checklist_cells:
                        cell = com_get(data_sheet, "Range", addr)
                        com_set(cell, "Value2", eData["initials"])

            except:
                pass

        com_call(workbook, "Save")

        WinForms.Application.DoEvents()
        Threading.Thread.CurrentThread.Join(150)
        WinForms.Application.DoEvents()
        
        if s_type != "[PR]" or action != "Create":
            user_name = os.environ.get("USERNAME")
            forms.alert("All done {}. \n\nPlease add your initials to Excel QA file.".format(user_name), "QA Record")
            com_set(excel, "Visible", True)

            try:
                com_set(excel, "WindowState", -4137)  # xlMaximized
            except:
                pass

            # maximize workbook window
            try:
                active_window = com_get(excel, "ActiveWindow")
                com_set(active_window, "WindowState", -4137)
            except:
                pass

            try:
                com_set(excel, "UserControl", True)
            except:
                pass

            try:
                com_set(excel, "Interactive", True)
            except:
                pass

            try:
                com_call(workbook, "Activate")
            except:
                pass

            try:
                com_call(sheet, "Activate")
            except:
                pass

            try:
                first_written_cell = com_get(cells, "Item", target_row, 1)
                com_call(first_written_cell, "Select")
            except:
                pass

            
            WinForms.Application.DoEvents()
            Threading.Thread.CurrentThread.Join(300)
            WinForms.Application.DoEvents()

            try:
                hwnd = com_get(excel, "Hwnd")
                user32 = ctypes.windll.user32
                user32.ShowWindow(hwnd, 3)  
                user32.SetForegroundWindow(hwnd)
                user32.BringWindowToTop(hwnd)
                user32.SetActiveWindow(hwnd)
            except:
                pass

        else:
            try:
                if workbook:
                    com_call(workbook, "Close", False)
            except:
                pass

            try:
                if excel:
                    com_call(excel, "Quit")
            except:
                pass
        
        success = True
        return True

    except Exception as e:
        raise
        print(str(e))

    finally:
        if not success:
            try:
                if workbook:
                    com_call(workbook, "Close", False)
            except:
                pass

            try:
                if excel:
                    com_call(excel, "Quit")
            except:
                pass


### - Excel Helper Functions
def com_get(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.GetProperty,
        None,
        obj,
        net_array(*args) if args else None
    )

def com_set(obj, name, value):
    obj.GetType().InvokeMember(
        name,
        BindingFlags.SetProperty,
        None,
        obj,
        net_array(value)
    )

def com_call(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.InvokeMethod,
        None,
        obj,
        net_array(*args) if args else None
    )

def is_row_empty(cells, row_number, max_cols_to_check):
    for c in range(1, max_cols_to_check + 1):
        cell = com_get(cells, "Item", row_number, c)
        value = com_get(cell, "Value2")
        if value not in [None, ""]:
            return False
    return True

def get_next_empty_row(sheet, max_cols_to_check):
    cells = com_get(sheet, "Cells")
    max_excel_rows = 1048576

    last_cell_col_a = com_get(cells, "Item", max_excel_rows, 1)
    end_up = com_get(last_cell_col_a, "End", -4162)   # xlUp
    last_row = com_get(end_up, "Row")

    if last_row == 1 and is_row_empty(cells, 1, max_cols_to_check):
        return 1

    row = last_row
    while not is_row_empty(cells, row, max_cols_to_check):
        row += 1

    return row

def write_row(cells, row_number, data):
    for c, value in enumerate(data, start=1):
        current_cell = com_get(cells, "Item", row_number, c)
        if value is None:
            com_set(current_cell, "Value2", "")
        else:
            com_set(current_cell, "Value2", str(value))

def net_array(*args):
    return Array[Object](list(args))

def get_open_document(file_path):

    target_path = os.path.normcase(
        os.path.abspath(file_path)
    )

    for open_doc in __revit__.Application.Documents:

        if not open_doc.PathName:
            continue

        open_path = os.path.normcase(
            os.path.abspath(open_doc.PathName)
        )

        if open_path == target_path:
            return open_doc

    return None

def track_data(lib_path, data, code = ""):
    import datetime
    from datetime import datetime
    new_line = ""
    
    
    try:
        start_time = data["time"]
        end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        year = datetime.now().year
        
        file_path = os.path.join(lib_path, "Data Tracking", "Tracking_{}.txt".format(str(year)))
        
        new_line = "Project Number:, " + data["p_numb"]
        new_line += ", User:, " + data["user"]
        new_line += ", File:, " + data["file"]
        new_line += ", Version:, 3.0"
        new_line += ", Start Time:, " + start_time
        new_line += ", End Time:, " + end_time
        new_line += ", Loaded Items:, " + str(data["items"])
    
    except Exception as e:
        new_line = "Error on code {}".format(code)
        
    
    if new_line:
        try:
            with open(file_path, "a") as f:
                f.write(new_line + "\n")
        except:
            pass


### - Update Function
def update(lib_path, user_name):
    from pyrevit.loader import sessionmgr
    import System.Diagnostics

    bat_path = os.path.join(lib_path, "Installers", "STP Tools (Installer).bat")
    started = False
    
    if os.path.exists(bat_path):
        proc = System.Diagnostics.Process()
        proc.StartInfo.FileName = bat_path
        proc.StartInfo.Arguments = "silent"
        proc.StartInfo.UseShellExecute = True

        try:
            if user_name != "Rafael":
                started = proc.Start()
            else:
                forms.alert("Update simulated for safety reasons")
                started = True
        except:
            forms.alert("Error during runing bat file.\n\nPlease contact STP Tool developer")

        if started:
            mssg = (
                "All done {}.\n\n".format(user_name) +
                "Revit now will reload."
            )
            title = "Setup Success"
            forms.alert(mssg, title)
            with forms.ProgressBar(title='Reloading pyRevit, please wait ...') as pb:
                pb.update_progress(0.5, 1)
                sessionmgr.load_session()


"""
import os
import sys
from pyrevit import forms

# Edit data
#===============================================
tab_name = ""
script_name = ""
project_type = "[]"
form_list = {
    "main_form": "gral_form.xaml"
}
#===============================================

# Find bib folder
python_file = os.path.abspath(__file__)
before, marker, after = python_file.partition("V3 Tools.tab")
bin_folder = os.path.join(before, "bin")

# Check for user discipline
file_path = r'C:\ProgramData\stp3_discipline.txt'
selected_discipline = ""
if os.path.exists(file_path):
    with open(file_path, 'r') as file:
        selected_discipline = file.readline().strip()
else:
    forms.alert(
        "Please select your main discipline.\n\n"
        "This is a one-time setup and will not be requested again."
    )
    disciplines = ["Electrical", "Fire", "Hydraulic", "Mechanical", "Structural"]
    selected_discipline = forms.SelectFromList.show(
        disciplines, multiselect=False, 
        title="Select your main discipline")
    
    if not selected_discipline:
        sys.exit()
        
    with open(file_path, "w") as f:
        f.write(selected_discipline)
            
# Check for stp_path file
file_path = r'C:\ProgramData\stp3_path.txt'
if not os.path.exists(file_path):
    forms.alert("The file path reference 'stp_path.txt' is missing. \n\n"
                "Please contact STP Tools admin.", title="STP Tool Error")
    sys.exit()
#-----------------------------------------------
# Check for Revit Library Folder
local = False
with open(file_path, 'r') as file:
    Lib_Path = file.readline().strip()
    if not os.path.exists(Lib_Path):
        forms.alert("STP tool '" + script_name + "' is missing. \n\n\Please contact STP Tools admin."
                    , title="STP Tool Error")
        sys.exit() 
    
    if Lib_Path[-3:] == "bin":
        local = True

#-----------------------------------------------
# Check for script files and xaml forms
python_file = os.path.join(Lib_Path, "Codes and Functions", tab_name, script_name)

for key in form_list:
    form_list[key] = os.path.join(Lib_Path, "Codes and Functions", "Xaml Forms", form_list[key])

if not os.path.exists(python_file):
    forms.alert("Python script file: " + script_name + " is missing. \n\nPlease contact STP Tools admin."
                , title="STP Tool Error")
    sys.exit() 

# Edit data
#======================================================
namespace = {
    "revit_library_path": Lib_Path,
    "discipline": selected_discipline,
    "local_version": local,
    "bin_folder": bin_folder,
    "proj_type": project_type,
    "xaml_forms": form_list
}
#======================================================

exec(open(python_file).read(), namespace)






except Exception as e:
    print(aborting_message("GF0001", "ERROR WHILE FILLING PROJECT INFORMATION."))
    raise


#======================================================
from pyrevit import script
output = script.get_output()

output.print_html(
    '<span style="font-weight:bold; font-size:18px; color:red;">'
    'TEXT HERE TEXT HERE {VARIABLE} <br>'
    '</span>'.format(variable)
)


#======================================================
import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "File Name",
    "items": 1
}
track_data(Lib_Path, data, "AAAA")



"""