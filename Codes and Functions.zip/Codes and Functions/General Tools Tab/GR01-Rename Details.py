#-----------------------------------------------------------------------------------
#--------------------------- GR01-Rename Details -----------------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import os
import sys
import re
import uuid
import random
from Autodesk.Revit.DB import FilteredElementCollector, ViewSheet, Viewport
from pyrevit import forms, revit, DB

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
bin_folder
local = local_version
##-------------------------------------

doc = __revit__.ActiveUIDocument.Document
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")

proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import track_data

# General_Variables
#------------------

def alphanum_key(t):
    return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', t[-1])]

def alphanum_key_2(t):
    return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', t)]

def split_on_first_letter_or_dot(s):
    match = re.search(r'[A-Za-z.]', s)
    if match:
        index = match.start()
        return s[:index], s[index:]
    else:
        return s, ''  # No match found, return original string and empty

def two_digits_detail(number):
    if number.isdigit() and len(number) == 1:
        return "0" + number
    else:
        return number

#-----------------------------------------------------------------------------------
#----------- GET SHEETS WHERE THE DETAILS ARE --------------------------------------
# region ---------------------------------------------------------------------------
stage = "Get Existing Sheets: "

sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
sheets_to_show = []
sheets_to_show = [sheet.SheetNumber + " - " + sheet.Name for sheet in sheets]

sorted_sheets_to_show = sorted(sheets_to_show, key=alphanum_key_2)
selected_sheets = forms.SelectFromList.show(sorted_sheets_to_show, multiselect=True, title="Select Sheets")

# endregion

#-----------------------------------------------------------------------------------
#----------- GET DETAILS IN PREVIOUS SHEETS ----------------------------------------
# region ---------------------------------------------------------------------------

if selected_sheets:
    filtered_sheets = []
    views_on_sheet = []
    all_details = []
    all_numbs = []

    for selected_sheet in selected_sheets:
        for sheet in sheets:
            if (sheet.SheetNumber + " - " + sheet.Name) == selected_sheet:
                filtered_sheets.append(sheet)

                aux = []
                viewport_ids = sheet.GetAllViewports()

                if viewport_ids:
                    for vp_id in viewport_ids:
                        vp = doc.GetElement(vp_id)
                        if vp:
                            param = vp.LookupParameter("Detail Number")
                            if param:
                                detail_number = param.AsString()
                                all_numbs.append(detail_number)
                            else:
                                detail_number = ""

                            param = vp.LookupParameter("View Name")
                            if param:
                                detail_name = param.AsString()
                            else:
                                detail_name = ""
                        
                            if vp.Name in ["STP DETAIL", "STP SECTION"]:
                                aux.append((vp, detail_number))
                            
                            all_details.append((vp, detail_name, detail_number))

                views_on_sheet.append(aux)

else:
    forms.alert("No sheet has been seleted. Please try again.", title = "Error")
    sys.exit()


List = []

if not any(views_on_sheet) or all(len(v) == 0 for v in views_on_sheet):
    mssg = "No applicable details found on these sheets.\n\n" + \
           "Please ensure that details on these drawings are under 'STP DETAIL' view port type and their sections under " + \
           "'STP SECTIONS' or 'STP DETAIL' type."
    forms.alert(mssg, "Warning")

else:
    for sheet, views in zip(filtered_sheets, views_on_sheet):
        aux = []
        for view in views:
            aux.append(( view[0], sheet.SheetNumber, view[1]))
        sorted_aux = sorted(aux, key=alphanum_key)
        List.append(sorted_aux)

final_list = []
new_det_list = []
new_names_list = []

if not List:
    sys.exit()

n = 1
for item in List:
    for clave in item:
        detail = clave[0]
        sh_numb = clave[1]
        det_numb = clave[2]
        
        n1, n2 = split_on_first_letter_or_dot(det_numb)
        if n2:
            n -= 1
        show_dn = two_digits_detail(str(n)) + n2
        new_det_num = str(n) + n2

        new_det_list.append(new_det_num)
        new_det_name = show_dn + "/" + sh_numb
        
        new_names_list.append(new_det_name)
        n += 1
        new_clave = (detail, new_det_name, new_det_num)
        final_list.append(new_clave)

# endregion


#-----------------------------------------------------------------------------------
#----------- CHANGE DETAIL NUMBERS AND NAMES ---------------------------------------
# region ---------------------------------------------------------------------------
num_details = 0
if final_list:
    with revit.Transaction("Rename new views"):
        for vp, new_view_name, new_detail_num in all_details:
            if isinstance(vp, Viewport):
                view_id = vp.ViewId
                view = doc.GetElement(view_id)
                
                if view.Name in new_names_list:
                    try:
                        view.Name = new_view_name + "_SS"
                    except:
                        for k in range(100):
                            unique_suffix = uuid.uuid4().hex[:6]
                            try:
                                view.Name = new_view_name + "_SS" + unique_suffix
                                break
                            except:
                                pass
                        else:
                            print("Failed to assign a unique view name after 100 attempts.\n\nPROGRAM ABORTED")
                            sys.exit()
                    
                param = view.LookupParameter("Detail Number")
                if param and param.AsString() in new_det_list:
                    try:
                        new_numb = "#" + param.AsString()
                        while new_numb in all_numbs:
                            new_numb = "#" + new_numb
                        param.Set(new_numb)
                    except:
                        for k in range(100):
                            try:
                                param.Set(str(random.randint(0, 1000)))
                                break
                            except:
                                pass
                        else:
                            print("Failed to assign a unique name after 100 attempts.\n\nPROGRAM ABORTED")
                            sys.exit()
        
        for vp, new_view_name, new_detail_num in final_list:
            if isinstance(vp, Viewport):
                view_id = vp.ViewId
                view = doc.GetElement(view_id)
                try:
                    view.Name = new_view_name
                    param = view.LookupParameter("Detail Number")
                    if param:
                        param.Set(new_detail_num)
                except Exception as e:
                    print(new_view_name + ": " + str(e))                    
                    
                    
    num_details = len(final_list)
    forms.alert(str(num_details) + " details and sections were succesufuly renamed", title = "Error")


#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "Rename/Order Details",
    "items": num_details
}
track_data(Lib_Path, data, "GR01")
