import os
import sys
from pyrevit import forms, revit
from collections import Counter
from System import Action
from System.Windows import Visibility
from System.Windows.Media import Brushes
from System.Windows.Threading import DispatcherPriority
from Autodesk.Revit.DB import BuiltInParameter, ElementId
from System.Collections.Generic import List as col_List

states_list = ["NT", "NSW", "NSW", "VIC", "QLD", "SA", "WA", "TAS", "VIC", "QLD"]

def find_post_code(lib_path, suburb):
    postcode = "" # No Code
    council = ""
    codes_path = os.path.join(lib_path, "Data Base", "postcode list.txt")
    suburb_line = ""
    sl = len(suburb)
    n = 0
    
    try:
        with open(codes_path, 'r+') as file:
            lines = file.readlines()
            # Find if the suburb exists in the list
            for line in lines:
                if "#" in line:
                    suburb_in_line = line.split("#")[0].strip()
                    if suburb.upper() == suburb_in_line.upper():
                        suburb_line = line
                        break
            
            # Depends on action, read the suburb or record new entry
            if suburb_line:
                n = line.find("#")
                if n > 0:
                    postcode = line[n+1:n+5]
                    if len(line) > n + 7:
                        council = line[n+6:].replace("\n","")
    except:
        pass
    
    return postcode, council

def fill_design_drafter(file_path):
    drafter_list = []  
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            drafter_list = [line.strip() for line in file.readlines()]
    else:
        drafter_list.append("File not found")
    
    if not "Design" in file_path:
        return sorted(drafter_list)
    else:
        return drafter_list

def check(selected_map, key_name):
    if key_name in selected_map:
        if selected_map[key_name] == None:
            return ""
        else:
            return selected_map[key_name]
    else:
        return ""

#--------------------------------------------------------------------
#----------- OPEN NEW GENERAL PROJECT FORM --------------------------
#--------------------------------------------------------------------

class GeneralProjectForm(forms.WPFWindow):
    def __init__(self, xaml_file_path, lib_path, input_map):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.tb_ok = True
        self.selected_file = ""
        self.process_go = False
        self.tb_n = ""
        self.Lib_Path = lib_path
        self.project_info = []
        self.tblock_info = []
        self.presets = ["", "FILL THIS BLANK", "PROJECT TYPE HERE","0000"]
        self.qa_info_exists = ("QA" in input_map["map_name"])
        self.qa_revit_version = check(input_map, "revit_version")
        self.tb_list = input_map["tb_list"]
        self.p_Region = check(input_map, "Region")
        self.tb_Name = check(input_map, "tb_Name")
        
    # Hook triggers
    #---------------------------
        self.okBtn.Click += self.on_ok
        self.CancelBtn.Click += self.on_cancel
        self.cmbTblocks.SelectionChanged += self.on_tb_selection_changed
        self.txbPcode.LostFocus += self.on_check_postcode_format
        self.txbState.Text = "QLD"
        self.txbSuburb.LostFocus += self.on_suburb_changed

        if not self.qa_info_exists:
            self.setup_textbox_events(self.txbProject)
            self.setup_textbox_events(self.txbAddress)
            self.setup_textbox_events(self.txbSuburb)
            self.setup_textbox_events(self.txbClient)
            self.setup_textbox_events(self.txbPcode)

    # Prefill textbox and combos
    #---------------------------
        self.txbNumber.Text = input_map["Project Number"]
        self.txbNumber.IsReadOnly = True
        self.txbProject.Text = input_map["Project Name"]
        self.txbAddress.Text = input_map["Project Address"]
        self.txbSuburb.Text = input_map["Suburb"]
        self.txbPcode.Text = input_map["Postcode"]
        self.txbClient.Text = input_map["Client Name"]
        self.txbClient_ref.Text = str(check(input_map, "Client Reference Number")).replace(".0","")
        self.txbQbuild_ref.Text = str(check(input_map, "Qbuild Project Number")).replace(".0","")

        self.txbProject.IsReadOnly = self.qa_info_exists
        self.txbAddress.IsReadOnly = self.qa_info_exists
        self.txbSuburb.IsReadOnly = self.qa_info_exists
        self.txbPcode.IsReadOnly = self.qa_info_exists
        self.txbClient.IsReadOnly = self.qa_info_exists
        self.txbTblocks.IsReadOnly = True

        for option in self.tb_list:
            self.cmbTblocks.Items.Add(option)
        
        if self.tb_list:
            self.cmbTblocks.SelectedIndex = 4

        if self.qa_info_exists:
            self.cmbTblocks.Visibility = Visibility.Collapsed
            if self.qa_revit_version == "DWG":
                self.tb_n = input_map["tb_Type"].replace(" STANDARD","").replace("McDONALDS ","").replace("QBUILD","BAS").replace("PAYNTERS","PYT")
                self.tb_n = self.tb_n + "_" + input_map["tb_Size"] + "_" + input_map["tb_Side"]
                self.idx = -1
                for x, option in enumerate(self.tb_list):
                    if option == self.tb_n:
                        self.idx = x
                        break
                if self.idx:
                    self.txbTblocks.Visibility = Visibility.Visible
                self.txbTblocks.Text = self.tb_n
                
            else:
                self.txbTblocks.Visibility = Visibility.Visible
                self.txbTblocks.Text = self.tb_Name.replace(".rfa","")
            self.lblUser.Content = "Last edited by " + input_map["last_user"]
            self.okBtn.Content = "Use this Info"
            self.txbHead.Text = "Project information for this job has been found, as shown below"
        else:
            self.cmbTblocks.Visibility = Visibility.Visible
            self.lblUser.Visibility = Visibility.Collapsed

    # Actions
    #---------------------------
    def on_tb_selection_changed(self, sender, args):
        if self.cmbTblocks.SelectedIndex == 0:
            self.tb_ok = False
            forms.alert("Please select the Title block family for this project.", title = "Select")
            self.selected_file = forms.pick_file(
                file_ext='rfa',
                title='Select a Revit Title Block Family File',
                multi_file=False
            )
            if self.selected_file:
                self.txbTb_other.Visibility = Visibility.Visible
                self.txbTb_other.Text = "Selected Title Block: \n" + os.path.basename(self.selected_file)
                self.tb_ok = True
        else:
            self.txbTb_other.Visibility = Visibility.Collapsed
            self.txbTb_other.Text = ""
            self.tb_ok = True

    def on_check_postcode_format(self, sender, args):
        postcode = self.txbPcode.Text.strip()
        if postcode and not self.qa_info_exists:
            aux = postcode.strip()
            if not aux.isdigit() or len(aux) != 4:
                forms.alert("Postcode must be exactly 4 digits.", title="Invalid Postcode")
                self.txbState.Text = ""
                return False
            else:
                st_index = int(postcode[0])
                self.txbState.Text = states_list[st_index]
            return True

    def on_lost_focus(self, sender, args):
        if sender.Text == "":
            if sender == self.txbPcode:
                sender.Text = "0000"
            else:
                sender.Text = "FILL THIS BLANK"
        else:
            sender.Text = sender.Text.upper().replace("MCDON","McDON")

    def on_preset_text_change(self, sender, args):
        if sender.Text in self.presets:
            sender.Foreground = Brushes.LightGray
        else:
            sender.Foreground = Brushes.Black

    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        # Wrap the Python function into a proper .NET delegate
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)
    
    def on_suburb_changed(self, sender, args):
        result = find_post_code(self.Lib_Path, self.txbSuburb.Text.upper())
        if result[0]:
            self.txbPcode.Text = result[0]

    def setup_textbox_events(self, txb):
        txb.TextChanged += self.on_preset_text_change
        txb.GotFocus += self.on_text_box_focus
        txb.LostFocus += self.on_lost_focus

    def on_ok(self, sender, args):
        # Capture the form input data
        next = all([self.txbProject.Text not in self.presets, 
                    self.txbClient.Text not in self.presets, 
                    self.txbAddress.Text not in self.presets, 
                    self.txbSuburb.Text not in self.presets, 
                    self.txbPcode.Text not in self.presets, 
                    self.cmbTblocks, self.tb_ok,
                    self.on_check_postcode_format(self, None)])
        if not next and not self.qa_info_exists:
            if not self.tb_ok:
                forms.alert("Please select a title block from the list", title = "Warning")
            else:
                forms.alert("Please fill out all the information.", title = "Warning")
        else:
            self.project_info.append(self.txbProject.Text.strip())
            self.project_info.append(self.txbClient.Text.strip())
            self.project_info.append(self.txbAddress.Text.strip())
            self.project_info.append(self.txbSuburb.Text.strip())
            self.project_info.append(self.txbPcode.Text.strip())
            self.project_info.append(self.txbState.Text.strip())
            self.project_info.append(self.p_Region + " REGIONAL COUNCIL" if self.p_Region else "")
            self.project_info.append(self.txbClient_ref.Text.strip())
            self.project_info.append(self.txbQbuild_ref.Text.strip())
            
            if self.qa_info_exists:
                if self.qa_revit_version == "DWG":
                    self.tblock_info.append("#" + self.tb_n)
                    self.tblock_info.append(self.idx)
                else:
                    self.tblock_info.append(self.tb_Name)
                    self.tblock_info.append(-1)
            else:
                self.tblock_info.append(self.cmbTblocks.SelectedItem)
                if self.cmbTblocks.SelectedIndex == 0:
                    self.tblock_info.append(self.selected_file) #temporary take the path to get the name
                elif self.cmbTblocks.SelectedIndex > 0:
                    self.tblock_info.append(self.cmbTblocks.SelectedIndex)
            self.process_go = True
            self.Close()  # Close the form after clicking OK
    
    def on_cancel(self, sender, args):
        self.Close()
        
        
#--------------------------------------------------------------------
#----------- OPEN NEW RESIDENTIAL PROJECT FORM ----------------------
#--------------------------------------------------------------------

class ResidentialProjectForm(forms.WPFWindow):
    def __init__(self, xaml_file_path, lib_path, input_map):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.tb_ok = True
        self.selected_file = ""
        self.process_go = False
        self.tb_n = ""
        self.project_info = []
        self.design_info = []
        self.tblock_info = []
        self.presets = ["", "FILL THIS BLANK", "PROJECT TYPE HERE","0000"]
        self.qa_info_exists = ("QA" in input_map["map_name"])
        self.qa_revit_version = check(input_map, "revit_version")
        self.tb_list = input_map["tb_list"]
        self.Lib_Path = lib_path
        self.p_Region = check(input_map, "Region")
        self.tb_Name = check(input_map, "tb_Name")

      
        # Tab Index
        #---------------------------
        self.txbProject.TabIndex = 0
        self.txbAddress.TabIndex = 1
        self.txbSuburb.TabIndex = 2
        self.txbPcode.TabIndex = 3
        self.txbClient.TabIndex = 4
        self.cmbDrafter.TabIndex = 5
        self.cmbDesigner.TabIndex = 6
        self.cmbApprover.TabIndex = 7
        self.cmbF15.TabIndex = 8
        self.okBtn.TabIndex = 9
        self.CancelBtn.TabIndex = 10
        self.cmbTblocks.TabIndex = 11
        
        # Hook triggers
        #---------------------------
        self.okBtn.Click += self.on_ok
        self.CancelBtn.Click += self.on_cancel
        self.cmbTblocks.SelectionChanged += self.on_tb_selection_changed
        self.txbPcode.LostFocus += self.on_check_postcode_format
        self.txbState.Text = "qld"
        self.txbSuburb.LostFocus += self.on_suburb_changed

        if not self.qa_info_exists:
            self.setup_textbox_events(self.txbProject)
            self.setup_textbox_events(self.txbAddress)
            self.setup_textbox_events(self.txbSuburb)
            self.setup_textbox_events(self.txbClient)
            self.setup_textbox_events(self.txbPcode)

        # Prefill textbox and combos
        #---------------------------
        self.txbNumber.Text = input_map["Project Number"]
        self.txbNumber.IsReadOnly = True
        self.txbProject.Text = input_map["Project Name"]
        self.txbAddress.Text = input_map["Project Address"]
        self.txbSuburb.Text = input_map["Suburb"]
        self.txbPcode.Text = input_map["Postcode"]
        self.txbClient.Text = input_map["Client Name"]

        self.txbProject.IsReadOnly = self.qa_info_exists
        self.txbAddress.IsReadOnly = self.qa_info_exists
        self.txbSuburb.IsReadOnly = self.qa_info_exists
        self.txbPcode.IsReadOnly = self.qa_info_exists
        self.txbClient.IsReadOnly = self.qa_info_exists
        self.txbTblocks.IsReadOnly = True

        drafter_list = fill_design_drafter(os.path.join(self.Lib_Path, "Data Base", "List_Drafters.txt"))
        self.cmbDrafter.ItemsSource = drafter_list
        
        for i, member in enumerate(drafter_list):
            if input_map["user_name"].upper() in member.upper():
                di = i
                break
        
        self.cmbDrafter.SelectedIndex = di if di > -1 else 0

        designer_list = fill_design_drafter(os.path.join(self.Lib_Path, "Data Base", "List_Designers.txt"))
        self.cmbDesigner.ItemsSource = designer_list
        self.cmbDesigner.SelectedIndex = 0

        engineer_list = ["Anthony Florence", "Brian Mayer", "Ross Forzatti", "Trent Graham"]
        self.cmbApprover.ItemsSource = sorted(engineer_list)
        self.cmbApprover.SelectedIndex = 1

        f15_list = ["Adrien", "Anthony", "Brian", "Ross", "Stephen", "Trevor"]
        self.cmbF15.ItemsSource = sorted(f15_list)
        self.cmbF15.SelectedIndex = 2

        for option in self.tb_list:
            self.cmbTblocks.Items.Add(option)
        self.cmbTblocks.SelectedIndex = 1
        if self.qa_info_exists:
            self.cmbTblocks.Visibility = Visibility.Collapsed
            if self.qa_revit_version == "DWG":
                self.tb_n = input_map["tb_Type"].replace(" STANDARD","").replace("McDONALDS ","").replace("QBUILD","BAS").replace("PAYNTERS","PYT")
                self.tb_n = self.tb_n + "_" + input_map["tb_Size"] + "_" + input_map["tb_Side"]
                self.idx = -1
                for x, option in enumerate(self.tb_list):
                    if option == self.tb_n:
                        self.idx = x
                        break
                if self.idx:
                    report += u"\u2705 Stage: Create tbName from DWG: Success \n"
                else:
                    report += u"\u26A0 Stage: Create tbName from DWG: Fail. Title block cannot be loaded \n"
                self.txbTblocks.Text = self.tb_n
            else:
                self.txbTblocks.Visibility = Visibility.Visible
                self.txbTblocks.Text = self.tb_Name.replace(".rfa","")
            self.lblUser.Content = "Last edited by " + input_map["last_user"]
            self.okBtn.Content = "Use this Info"
            self.txbHead.Text = "Project information for this job has been found, as shown below"
        else:
            self.cmbTblocks.Visibility = Visibility.Visible
            self.lblUser.Visibility = Visibility.Collapsed


    # Actions
    #---------------------------
    def on_tb_selection_changed(self, sender, args):
        if self.cmbTblocks.SelectedIndex == 0:
            self.tb_ok = False
            forms.alert("Please select the Title block family for this project.", title = "Select")
            self.selected_file = forms.pick_file(
                file_ext='rfa',
                title='Select a Revit Title Block Family File',
                multi_file=False
            )
            if self.selected_file:
                self.txbTb_other.Visibility = Visibility.Visible
                self.txbTb_other.Text = "Selected Title Block: \n" + os.path.basename(self.selected_file)
                self.tb_ok = True
        else:
            self.txbTb_other.Visibility = Visibility.Collapsed
            self.txbTb_other.Text = ""
            self.tb_ok = True

    def on_check_postcode_format(self, sender, args):
        postcode = self.txbPcode.Text
        if postcode and not self.qa_info_exists:
            aux = postcode.strip()
            if not aux.isdigit() or len(aux) != 4:
                forms.alert("Postcode must be exactly 4 digits.", title="Invalid Postcode")
                self.txbState.Text = ""
                return False
            else:
                st_index = int(postcode[0])
                self.txbState.Text = states_list[st_index]
            return True

    def on_lost_focus(self, sender, args):
        if sender.Text == "":
            if sender == self.txbPcode:
                sender.Text = "0000"
            else:
                sender.Text = "FILL THIS BLANK"
        else:
            sender.Text = sender.Text.upper().replace("MCDON","McDON")

    def on_preset_text_change(self, sender, args):
        if sender.Text in self.presets:
            sender.Foreground = Brushes.LightGray
        else:
            sender.Foreground = Brushes.Black

    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        # Wrap the Python function into a proper .NET delegate
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)

    def on_suburb_changed(self, sender, args):
        result = find_post_code(self.Lib_Path, self.txbSuburb.Text.upper())
        if result[0]:
            self.txbPcode.Text = result[0]
    
    def setup_textbox_events(self, txb):
        txb.TextChanged += self.on_preset_text_change
        txb.GotFocus += self.on_text_box_focus
        txb.LostFocus += self.on_lost_focus

    def on_ok(self, sender, args):
        # Capture the form input data
        next = all([self.txbProject.Text not in self.presets, 
                    self.txbClient.Text not in self.presets, 
                    self.txbAddress.Text not in self.presets, 
                    self.txbSuburb.Text not in self.presets, 
                    self.txbPcode.Text not in self.presets, 
                    self.cmbTblocks, self.tb_ok,
                    self.cmbDesigner.SelectedIndex > 0,
                    self.on_check_postcode_format(self, None)])
        if not next and not self.qa_info_exists:
            if not self.tb_ok:
                forms.alert("Please select a title block from the list", title = "Warning")
            else:
                forms.alert("Please fill out all the blanks and Design Options.", title = "Warning")
        else:
            self.project_info.append(self.txbProject.Text.strip())
            self.project_info.append(self.txbClient.Text.strip())
            self.project_info.append(self.txbAddress.Text.strip())
            self.project_info.append(self.txbSuburb.Text.strip())
            self.project_info.append(self.txbPcode.Text.strip())
            self.project_info.append(self.txbState.Text.strip())
            self.project_info.append(self.p_Region + " REGIONAL COUNCIL" if self.p_Region else "")
            self.project_info.append("")
            self.project_info.append("")
            
            if self.qa_info_exists:
                if self.qa_revit_version == "DWG":
                    self.tblock_info.append("#" + self.tb_n)
                    self.tblock_info.append(self.idx)
                else:
                    self.tblock_info.append(self.tb_Name)
                    self.tblock_info.append(-1)
            else:
                self.tblock_info.append(self.cmbTblocks.SelectedItem)
                if self.cmbTblocks.SelectedIndex == 0:
                    self.tblock_info.append(self.selected_file) #temporary take the path to get the name
                elif self.cmbTblocks.SelectedIndex > 1:
                    self.tblock_info.append(self.cmbTblocks.SelectedIndex)
                else:
                    self.tblock_info.append("Default")
            
            self.design_info.append(self.cmbDrafter.SelectedItem)
            self.design_info.append(self.cmbDesigner.SelectedItem)
            self.design_info.append(self.cmbApprover.SelectedItem)
            self.design_info.append(self.cmbF15.SelectedItem)
            self.design_info.append(self.txbClient.Text)
            
            self.process_go = True
            self.Close()  # Close the form after clicking OK
    
    def on_cancel(self, sender, args):
        self.Close()
        

#--------------------------------------------------------------------
#----------- OPEN NEW McDONALDS PROJECT FORM ------------------------
#--------------------------------------------------------------------

class McDonaldsProjectForm(forms.WPFWindow):
    def __init__(self, xaml_file_path, lib_path, input_map):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.tb_ok = True
        self.selected_file = ""
        self.process_go = False
        self.tb_n = ""
        self.project_info = []
        self.tblock_info = []
        self.presets = ["", "FILL THIS BLANK", "PROJECT TYPE HERE","0000"]
        self.qa_info_exists = ("QA" in input_map["map_name"])
        self.qa_revit_version = check(input_map, "revit_version")
        self.tb_list = input_map["tb_list"]
        self.Lib_Path = lib_path
        self.p_Region = check(input_map, "Region")
        self.tb_Name = check(input_map, "tb_Name")
    
    # Hook triggers
    #---------------------------
        self.okBtn.Click += self.on_ok
        self.CancelBtn.Click += self.on_cancel
        self.cmbTblocks.SelectionChanged += self.on_tb_selection_changed
        self.txbPcode.LostFocus += self.on_check_postcode_format
        self.txbState.Text = "QLD"
        self.txbSuburb.LostFocus += self.on_suburb_changed

        if not self.qa_info_exists:
            self.setup_textbox_events(self.txbProject)
            self.setup_textbox_events(self.txbAddress)
            self.setup_textbox_events(self.txbSuburb)
            self.setup_textbox_events(self.txbClient)
            self.setup_textbox_events(self.txbPcode)

    # Prefill textbox and combos
    #---------------------------
        self.txbNumber.Text = input_map["Project Number"]
        self.txbNumber.IsReadOnly = True
        self.txbProject.Text = input_map["Project Name"]
        self.txbAddress.Text = input_map["Project Address"]
        self.txbSuburb.Text = input_map["Suburb"]
        self.txbPcode.Text = input_map["Postcode"]
        self.txbClient.Text = "McDONALD'S AUSTRALIA LIMITED"

        self.txbProject.IsReadOnly = self.qa_info_exists
        self.txbAddress.IsReadOnly = self.qa_info_exists
        self.txbSuburb.IsReadOnly = self.qa_info_exists
        self.txbPcode.IsReadOnly = self.qa_info_exists
        self.txbClient.IsReadOnly = self.qa_info_exists
        self.txbTblocks.IsReadOnly = True

        for option in self.tb_list:
            self.cmbTblocks.Items.Add(option)
        
        if self.tb_list:
            self.cmbTblocks.SelectedIndex = 1

        if self.qa_info_exists:
            self.cmbTblocks.Visibility = Visibility.Collapsed
            if self.qa_revit_version == "DWG":
                self.tb_n = input_map["tb_Type"].replace(" STANDARD","").replace("McDONALDS ","").replace("QBUILD","BAS").replace("PAYNTERS","PYT")
                self.tb_n = self.tb_n + "_" + input_map["tb_Size"] + "_" + input_map["tb_Side"]
                self.idx = -1
                for x, option in enumerate(self.tb_list):
                    if option == self.tb_n:
                        self.idx = x
                        break
                if self.idx:
                    self.txbTblocks.Visibility = Visibility.Visible
                self.txbTblocks.Text = self.tb_n
                
            else:
                self.txbTblocks.Visibility = Visibility.Visible
                self.txbTblocks.Text = self.tb_Name.replace(".rfa","")
            self.lblUser.Content = "Last edited by " + input_map["last_user"]
            self.okBtn.Content = "Use this Info"
            self.txbHead.Text = "Project information for this job has been found, as shown below"
        else:
            self.cmbTblocks.Visibility = Visibility.Visible
            self.lblUser.Visibility = Visibility.Collapsed

    # Actions
    #---------------------------
    def on_tb_selection_changed(self, sender, args):
        if self.cmbTblocks.SelectedIndex == 0:
            self.tb_ok = False
            forms.alert("Please select the Title block family for this project.", title = "Select")
            self.selected_file = forms.pick_file(
                file_ext='rfa',
                title='Select a Revit Title Block Family File',
                multi_file=False
            )
            if self.selected_file:
                self.txbTb_other.Visibility = Visibility.Visible
                self.txbTb_other.Text = "Selected Title Block: \n" + os.path.basename(self.selected_file)
                self.tb_ok = True
        else:
            self.txbTb_other.Visibility = Visibility.Collapsed
            self.txbTb_other.Text = ""
            self.tb_ok = True

    def on_check_postcode_format(self, sender, args):
        postcode = self.txbPcode.Text
        if postcode and not self.qa_info_exists:
            aux = postcode.strip()
            if not aux.isdigit() or len(aux) != 4:
                forms.alert("Postcode must be exactly 4 digits.", title="Invalid Postcode")
                self.txbState.Text = ""
                return False
            else:
                st_index = int(postcode[0])
                self.txbState.Text = states_list[st_index]
            return True

    def on_lost_focus(self, sender, args):
        if sender.Text == "":
            if sender == self.txbPcode:
                sender.Text = "0000"
            else:
                sender.Text = "FILL THIS BLANK"
        else:
            sender.Text = sender.Text.upper().replace("MCDON","McDON")

    def on_preset_text_change(self, sender, args):
        if sender.Text in self.presets:
            sender.Foreground = Brushes.LightGray
        else:
            sender.Foreground = Brushes.Black

    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        # Wrap the Python function into a proper .NET delegate
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)
    
    def on_suburb_changed(self, sender, args):
        result = find_post_code(self.Lib_Path, self.txbSuburb.Text.upper())
        if result[0]:
            self.txbPcode.Text = result[0]

    def setup_textbox_events(self, txb):
        txb.TextChanged += self.on_preset_text_change
        txb.GotFocus += self.on_text_box_focus
        txb.LostFocus += self.on_lost_focus

    def on_ok(self, sender, args):
        # Capture the form input data
        next = all([self.txbProject.Text not in self.presets, 
                    self.txbClient.Text not in self.presets, 
                    self.txbAddress.Text not in self.presets, 
                    self.txbSuburb.Text not in self.presets, 
                    self.txbPcode.Text not in self.presets, 
                    self.cmbTblocks, self.tb_ok,
                    self.on_check_postcode_format(self, None)])
        if not next and not self.qa_info_exists:
            if not self.tb_ok:
                forms.alert("Please select a title block from the list", title = "Warning")
            else:
                forms.alert("Please fill out all the information.", title = "Warning")
        else:
            self.project_info.append(self.txbProject.Text.strip())
            self.project_info.append(self.txbClient.Text.strip())
            self.project_info.append(self.txbAddress.Text.strip())
            self.project_info.append(self.txbSuburb.Text.strip())
            self.project_info.append(self.txbPcode.Text.strip())
            self.project_info.append(self.txbState.Text.strip())
            self.project_info.append(self.p_Region + " REGIONAL COUNCIL" if self.p_Region else "")
            self.project_info.append("")
            self.project_info.append("")
            
            if self.qa_info_exists:
                if self.qa_revit_version == "DWG":
                    self.tblock_info.append("#" + self.tb_n)
                    self.tblock_info.append(self.idx)
                else:
                    self.tblock_info.append(self.tb_Name)
                    self.tblock_info.append(-1)
            else:
                self.tblock_info.append(self.cmbTblocks.SelectedItem)
                if self.cmbTblocks.SelectedIndex == 0:
                    self.tblock_info.append(self.selected_file) #temporary take the path to get the name
                elif self.cmbTblocks.SelectedIndex > 0:
                    self.tblock_info.append(self.cmbTblocks.SelectedIndex)
            self.process_go = True
            self.Close()  # Close the form after clicking OK
    
    def on_cancel(self, sender, args):
        self.Close()

#--------------------------------------------------------------------
#----------- OPEN FORM TO PICK REVIT TEMPLATE OR NOT ----------------
#--------------------------------------------------------------------

class NewFileOptionsForm(forms.WPFWindow):

    def __init__(
        self,
        xaml_file_path,
        local_mode,
        discipline,
        allow_current_job=True
    ):
        
        forms.WPFWindow.__init__(
            self,
            xaml_file_path
        )

        self.process_go = False
        self.key_map = {}
        self.from_template = None
        self.comb_models = True
        self.model_group.Visibility = Visibility.Collapsed
        
        # --------------------------------
        # EVENTS
        # --------------------------------

        self.services_rb.Checked += self.services_changed
        self.services_rb.Unchecked += self.services_changed
        self.structural_rb.Checked += self.services_changed
        self.hydraulic_rb.Checked += self.services_changed
        

        self.ok_button.Click += self.ok_click
        self.cancel_button.Click += self.cancel_click


        # --------------------------------
        # FILE SOURCE
        # --------------------------------

        if not allow_current_job:
            self.current_job_rb.IsEnabled = False
        else:
            self.current_job_rb.IsChecked = True

        if local_mode:
            self.template_rb.IsEnabled = False
            self.current_job_rb.IsChecked = True


        # --------------------------------
        # PRESET DISCIPLINE
        # --------------------------------

        if discipline:
            if "Struct" in discipline:
                self.structural_rb.IsChecked = True

            elif "Hyd" in discipline:
                self.hydraulic_rb.IsChecked = True

            elif (
                "Mech" in discipline
                or "Fire" in discipline
                or "Elec" in discipline
            ):

                self.services_rb.IsChecked = True

                if "Mech" in discipline:
                    self.mechanical_cb.IsChecked = True

                if "Fire" in discipline:
                    self.fire_cb.IsChecked = True

                if "Elec" in discipline:
                    self.electrical_cb.IsChecked = True


    def create_single_map(self, disc, folder):
        sing_map = {
            "folder_name": folder,
            "file_name": "",
            "file_path": "",
            "save_action": ""
        }
            
        self.key_map[disc] = sing_map
            

    def services_changed(self, sender, args):
        enabled = self.services_rb.IsChecked
        
        # ====Enable this when they decide to split models======
        #if enabled:
        #    self.model_group.Visibility = Visibility.Visible
        #else:
        #    self.model_group.Visibility = Visibility.Collapsed
        # ======================================================

        self.mechanical_cb.IsEnabled = enabled
        self.fire_cb.IsEnabled = enabled
        self.electrical_cb.IsEnabled = enabled

        # Clear selections when Services is no longer selected
        if not enabled:

            self.mechanical_cb.IsChecked = False
            self.fire_cb.IsChecked = False
            self.electrical_cb.IsChecked = False

    def ok_click(self, sender, args):

        # --------------------------------
        # DISCIPLINE
        # --------------------------------
        
        if self.structural_rb.IsChecked:
            self.create_single_map("Structural", "Struct")

        elif self.hydraulic_rb.IsChecked:
            self.create_single_map("Hydraulic", "Hyd")

        elif self.services_rb.IsChecked:
            if self.mechanical_cb.IsChecked:
                self.create_single_map("Mechanical", "Mech")

            if self.fire_cb.IsChecked:
                self.create_single_map("Fire", "Fire")

            if self.electrical_cb.IsChecked:
                self.create_single_map("Electrical", "Elec")

            # Services selected but nothing checked
            if not self.key_map:
                forms.alert(
                    "Please select at least one Services discipline.",
                    title="Select Discipline"
                )
                return


        # --------------------------------
        # FILE SOURCE
        # --------------------------------

        if self.template_rb.IsChecked:
            self.from_template = True

        elif self.current_job_rb.IsChecked:
            self.from_template = False

        if self.services_rb.IsChecked and self.combined_model_rb.IsChecked:
            self.comb_models = True
        else:
            self.comb_models = False
        
        self.process_go = True
        self.Close()


    def cancel_click(self, sender, args):

        self.process_go = False
        self.Close()
        
#--------------------------------------------------------------------
#----------- OPEN SAVE OPTION FORMS ---------------------------------
#--------------------------------------------------------------------

class NewFileNameForm(forms.WPFWindow):
    def __init__(
        self,
        xaml_file_path,
        discipline,
        info,
        action
    ):
        
        forms.WPFWindow.__init__(
            self,
            xaml_file_path
        )

        self.process_go = False
        self.discipline = discipline
        self.info = info
        self.action = action
        
        self.original_name = self.info["file_name"]

        # Get destination folder from original full path
        self.folder_path = os.path.dirname(
            self.info["file_path"]
        )

        self.final_name = self.original_name
        self.save_action = None


        # --------------------------------
        # DISPLAY INITIAL INFORMATION
        # --------------------------------
        self.discipline_text.Text = (
            str(discipline).upper()
        )

        self.stp_name_text.Text = (
            self.original_name
        )

        # Start the custom text box with the
        # same proposed name, making editing easier
        self.custom_name_tb.Text = (
            self.original_name
        )

        # --------------------------------
        # EVENTS
        # --------------------------------
        self.stp_name_rb.Checked += \
            self.name_option_changed
        self.custom_name_rb.Checked += \
            self.name_option_changed
        self.custom_name_tb.TextChanged += \
            self.custom_name_changed
        self.continue_button.Click += \
            self.continue_click
        self.cancel_button.Click += \
            self.cancel_click

        # --------------------------------
        # INITIAL CHECK
        # --------------------------------

        self.update_selected_name()

    def update_selected_name(self):
        if self.stp_name_rb.IsChecked:
            self.final_name = (
                self.original_name
            )

            self.custom_name_tb.IsEnabled = False

        elif self.custom_name_rb.IsChecked:
            self.custom_name_tb.IsEnabled = True
            self.final_name = (
                self.custom_name_tb.Text.strip()
            )

        self.selected_name_text.Text = (
            self.final_name + ".rvt"
            if self.final_name
            else ""
        )
        self.check_existing_file()

    def name_option_changed(
        self,
        sender,
        args
    ):
        self.update_selected_name()
        if self.custom_name_rb.IsChecked:
            self.custom_name_tb.Focus()

    def custom_name_changed(
        self,
        sender,
        args
    ):

        if self.custom_name_rb.IsChecked:
            self.final_name = (
                self.custom_name_tb.Text.strip()
            )

            self.selected_name_text.Text = (
                self.final_name
            )

            self.check_existing_file()

    def check_existing_file(self):
        if not "Forma" in self.action:
            if not self.final_name:
                self.existing_file_panel.Visibility = \
                    Visibility.Collapsed
                self.save_action = None
                return

            final_path = os.path.join(
                self.folder_path,
                self.final_name + ".rvt"
            )

            if os.path.exists(final_path):
                self.existing_file_panel.Visibility = \
                    Visibility.Visible

                # Safest default
                self.save_action = "Skip"

            else:
                self.existing_file_panel.Visibility = \
                    Visibility.Collapsed
                self.save_action = "Save"

    def get_save_action(self):
        final_path = os.path.join(
            self.folder_path,
            self.final_name + ".rvt"
        )

        # File does not exist
        if not os.path.exists(final_path):
            return "Save"

        # File exists
        if self.replace_rb.IsChecked:
            return "Replace"

        elif self.skip_rb.IsChecked:
            return "Skip"

        elif self.supersede_rb.IsChecked:
            return "Supersede"

        return None
        
    def continue_click(self, sender, args):
        self.update_selected_name()

        # --------------------------------
        # VALIDATE FILE NAME
        # --------------------------------
        if not self.final_name:
            forms.alert(
                "Please enter a file name.",
                title="File Name Required"
            )
            return

        # --------------------------------
        # GET SAVE ACTION
        # --------------------------------
        self.save_action = (self.get_save_action())
        if not self.save_action:
            forms.alert(
                "Please select what to do with "
                "the existing file.",
                title="Select File Action"
            )
            return

        # --------------------------------
        # UPDATE INFO DICTIONARY
        # --------------------------------
        self.info["file_name"] = (
            self.final_name
        )
        
        self.info["file_path"] = os.path.join(
            self.folder_path,
            self.final_name + ".rvt"
        )

        self.info["save_action"] = (
            self.save_action
        )

        self.process_go = True
        self.Close()        

    def cancel_click(
        self,
        sender,
        args
    ):
        self.process_go = False
        self.Close()


#--------------------------------------------------------------------
#----------- OPEN FORM TO SAVE A REVIT FILE  ------------------------
#--------------------------------------------------------------------

class DisciplineFileNameForm(forms.WPFWindow):

    def __init__(
        self,
        xaml_file_path,
        project_number,
        revit_version,
        folder_path,
        modify_path = True
    ):

        forms.WPFWindow.__init__(
            self,
            xaml_file_path
        )

        self.process_go = False

        self.project_number = project_number
        self.revit_version = revit_version
        self.folder_path = folder_path
        self.modify_path = modify_path

        self.discipline = None
        self.final_name = None
        self.final_path = None

        self.option_1 = None
        self.option_2 = None


        # --------------------------------
        # EVENTS - DISCIPLINE
        # --------------------------------

        self.electrical_rb.Checked += self.discipline_changed
        self.fire_rb.Checked += self.discipline_changed
        self.hydraulic_rb.Checked += self.discipline_changed
        self.mechanical_rb.Checked += self.discipline_changed
        self.structural_rb.Checked += self.discipline_changed


        # --------------------------------
        # EVENTS - FILE NAME
        # --------------------------------

        self.option_1_rb.Checked += self.name_option_changed
        self.option_2_rb.Checked += self.name_option_changed
        self.custom_rb.Checked += self.name_option_changed

        self.custom_name_tb.TextChanged += self.custom_text_changed


        # --------------------------------
        # BUTTONS
        # --------------------------------

        self.ok_button.Click += self.ok_click
        self.cancel_button.Click += self.cancel_click


        # --------------------------------
        # INITIALISE
        # --------------------------------

        self.electrical_rb.IsChecked = True
        self.option_1_rb.IsChecked = True

        self.update_discipline()
        self.update_name_options()

    def update_discipline(self):
        if self.electrical_rb.IsChecked:
            self.discipline = "Elect"

        elif self.fire_rb.IsChecked:
            self.discipline = "Fire"

        elif self.hydraulic_rb.IsChecked:
            self.discipline = "Hyd"

        elif self.mechanical_rb.IsChecked:
            self.discipline = "Mech"

        elif self.structural_rb.IsChecked:
            self.discipline = "Struct"

    def update_name_options(self):
        discipline = self.discipline

        if not discipline:
            return


        self.option_1 = (
            self.project_number
            + "_"
            + discipline.upper()
            + "_RVT"
            + self.revit_version
        )

        self.option_2 = (
            self.project_number
            + "_"
            + discipline[0].upper()
            + "_R"
            + self.revit_version
        )


        # Double "_" only for WPF display.
        # Original variables remain unchanged.
        self.option_1_rb.Content = self.option_1.replace("_", "__")
        self.option_2_rb.Content = self.option_2.replace("_", "__")
        self.update_final_name()
        
    def discipline_changed(self, sender, args):
        self.update_discipline()
        self.update_name_options()

    def name_option_changed(self, sender, args):
        if self.custom_rb.IsChecked:
            self.custom_name_tb.IsEnabled = True
            self.custom_name_tb.Focus()

        else:
            self.custom_name_tb.IsEnabled = False


        self.update_final_name()

    def update_final_name(self):
        if self.option_1_rb.IsChecked:
            self.final_name = self.option_1

        elif self.option_2_rb.IsChecked:
            self.final_name = self.option_2

        elif self.custom_rb.IsChecked:
            self.final_name = (
                self.custom_name_tb.Text.strip()
            )

        self.check_existing_file()

    def custom_text_changed(self, sender, args):
        if self.custom_rb.IsChecked:

            self.final_name = (
                self.custom_name_tb.Text.strip()
            )

            self.check_existing_file()

    def check_existing_file(self):
        if not self.final_name:
            self.alert_text.Text = ""
            return
        
        if self.modify_path:
            self.final_path = os.path.join(
                self.folder_path, "Drawings", "Current Drawings", self.discipline,
                self.final_name + ".rvt"
            )
        else:
            self.final_path = os.path.join(self.folder_path, self.final_name + ".rvt")

        if os.path.exists(self.final_path):

            self.alert_text.Text = (
                "A file with that name already exists in this location."
            )
        else:

            self.alert_text.Text = ""

    def ok_click(self, sender, args):
        self.update_discipline()
        self.update_final_name()

        if not self.final_name:

            forms.alert(
                "Please enter a valid file name.",
                title="File Name Required"
            )
            return

        self.process_go = True
        self.Close()

    def cancel_click(self, sender, args):
        self.process_go = False
        self.final_name = None
        self.Close()

#--------------------------------------------------------------------
#----------------- EDIT PROJECT PARAMETERS  -------------------------
#--------------------------------------------------------------------

class EditProjInfo(forms.WPFWindow):

    def __init__(self, 
        xaml_file_path,
        lib_path, pr_map, qa_map
    ):

        forms.WPFWindow.__init__(self, xaml_file_path)
        
        # Input variables
        self.Lib_Path = lib_path
        self.go_for_qa = False
        self.Numb = pr_map["Project Number"]
        show_wrong = False
        
        self.pr_Name = pr_map["Project Name"]
        self.pr_Address = pr_map["Project Address"]
        self.pr_Suburb = pr_map["Suburb"]
        self.pr_Pcode = str(pr_map["Postcode"]).replace(".0","")
        self.pr_Client = pr_map["Client Name"]
        self.pr_ClientRef = check(pr_map, "Client Reference Number").replace("N/F","")
        self.pr_QbuildRef = check(pr_map, "Qbuild Project Number").replace("N/F","")
        
        self.qa_Name = qa_map["Project Name"]
        self.qa_Address = qa_map["Project Address"]
        self.qa_Suburb = qa_map["Suburb"]
        self.qa_Pcode = str(qa_map["Postcode"]).replace(".0","")
        self.qa_Client = qa_map["Client Name"]
        self.qa_ClientRef = str(check(qa_map, "Client Reference Number")).replace(".0","")
        self.qa_QbuildRef = str(check(qa_map, "Qbuild Project Number")).replace(".0","")
        
        self.presets = ["", "FILL THIS BLANK", "PROJECT TYPE HERE","0000"]
        self.params = ["Project Name", "Client Name",
                       "Project Address", "Suburb", "Postcode",
                       "Client Reference Number", "Qbuild Project Number"]
        self.process_go = False
        self.change_pars = []
         
        # Hook triggers
        #---------------------------
        self.okBtn.Click += self.on_ok
        self.updateBtn.Click += self.on_update
        self.CancelBtn.Click += self.on_cancel
        self.txbPcode.LostFocus += self.on_check_postcode_format
        self.txbSuburb.LostFocus += self.on_suburb_changed
        
        self.setup_textbox_events(self.txbProject)
        self.setup_textbox_events(self.txbAddress)
        self.setup_textbox_events(self.txbSuburb)
        self.setup_textbox_events(self.txbClient)
        self.setup_textbox_events(self.txbPcode)

        # Prefill textbox and combos
        #---------------------------
        self.txbNumber.Text = self.Numb
        self.txbNumber.IsReadOnly = True
        
        self.txbProject.Text = self.pr_Name
        self.txbAddress.Text = self.pr_Address
        self.txbSuburb.Text = self.pr_Suburb
        self.txbPcode.Text = self.pr_Pcode
        self.txbClient.Text = self.pr_Client
        self.txbClientRef.Text = self.pr_ClientRef
        self.txbQbuildRef.Text = self.pr_QbuildRef
        
        self.on_check_postcode_format(None, None)
        
        self.wrong_pr_name.Content = "QA Sheet Name: " + self.qa_Name
        self.wrong_pr_address.Content = "QA Sheet Address: " + self.qa_Address
        self.wrong_pr_suburb.Content = "QA Sheet Suburb: " + self.qa_Suburb
        self.wrong_pr_pcode.Content = "QA Sheet Post Code: " + self.qa_Pcode
        self.wrong_pr_client.Content = "QA Sheet Client Name: " + self.qa_Client
        self.wrong_client_ref.Content = "QA Client Number: " + self.qa_ClientRef
        self.wrong_qbuild_ref.Content = "QA Qbuild Number: " + self.qa_QbuildRef
        
        msg = (
            "The red text shown below each parameter displays the information "
            "from the STP QA Checklist file. This information does not match "
            "the corresponding data in the current Revit file.\n\n"
            "Select Update from QA Data to match the information from QA file and "
            "then click 'Change' button to apply the changes"
        )
        self.wrong_info.Text = msg
        						   
        
        if self.pr_Name != self.qa_Name:
            self.wrong_pr_name.Visibility = Visibility.Visible
            show_wrong = True
        if self.pr_Address != self.qa_Address:
            self.wrong_pr_address.Visibility = Visibility.Visible
            show_wrong = True
        if self.pr_Suburb != self.qa_Suburb:
            self.wrong_pr_suburb.Visibility = Visibility.Visible
            show_wrong = True
        if self.pr_Pcode != self.qa_Pcode:
            self.wrong_pr_pcode.Visibility = Visibility.Visible
            show_wrong = True
        if self.pr_Client != self.qa_Client:
            self.wrong_pr_client.Visibility = Visibility.Visible
            show_wrong = True
        if self.pr_ClientRef != self.qa_ClientRef:
            self.wrong_client_ref.Visibility = Visibility.Visible
            show_wrong = True
        if self.pr_QbuildRef != self.qa_QbuildRef:
            self.wrong_qbuild_ref.Visibility = Visibility.Visible
            show_wrong = True
            
        if show_wrong:
            self.wrong_grid.Visibility = Visibility.Visible
            

    def on_check_postcode_format(self, sender, args):
        postcode = self.txbPcode.Text
        if postcode:
            aux = postcode.strip()
            if not aux.isdigit() or len(aux) != 4:
                forms.alert("Postcode must be exactly 4 digits.", title="Invalid Postcode")
                self.txbState.Text = ""
                return False
            else:
                st_index = int(postcode[0])
                self.txbState.Text = states_list[st_index]
            return True

    def on_lost_focus(self, sender, args):
        text = sender.Text.strip()
        if text == "":
            if sender == self.txbPcode:
                # If postcode is empty, maybe don't fill '0000' automatically
                pass
            else:
                sender.Text = "FILL THIS BLANK"
        else:
            sender.Text = sender.Text.upper().replace("MCDON", "McDON")


    def on_preset_text_change(self, sender, args):
        if sender.Text in self.presets:
            sender.Foreground = Brushes.LightGray
        else:
            sender.Foreground = Brushes.Black

    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        # Wrap the Python function into a proper .NET delegate
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)
    
    def on_suburb_changed(self, sender, args):
        aux = self.txbPcode.Text
        result = find_post_code(self.Lib_Path, self.txbSuburb.Text.upper())
        if result and result[0]:
            self.txbPcode.Text = result[0]
        else:
            self.txbPcode.Text = aux

    def setup_textbox_events(self, txb):
        txb.TextChanged += self.on_preset_text_change
        txb.GotFocus += self.on_text_box_focus
        if txb != self.txbPcode:
            txb.LostFocus += self.on_lost_focus

    def on_update(self, sender, args):
        self.txbProject.Text = self.qa_Name
        self.txbAddress.Text = self.qa_Address
        self.txbSuburb.Text = self.qa_Suburb
        self.txbPcode.Text = self.qa_Pcode
        self.txbClient.Text = self.qa_Client
        self.txbClientRef.Text = self.qa_ClientRef
        self.txbQbuildRef.Text = self.qa_QbuildRef
        self.on_check_postcode_format(None, None)

    def on_ok(self, sender, args):
        old_List = [self.qa_Name, self.qa_Client, self.qa_Address, self.qa_Suburb,
                    self.qa_Pcode, self.qa_ClientRef, self.qa_QbuildRef]
        new_List = [
            self.txbProject.Text.strip().upper().replace("MCDON","McDON"),
            self.txbClient.Text.strip().upper().replace("MCDON","McDON"),
            self.txbAddress.Text.strip().upper(),
            self.txbSuburb.Text.strip().upper(),
            self.txbPcode.Text.strip(),
            self.txbClientRef.Text.strip(),
            self.txbQbuildRef.Text.strip()
        ]

        mssg = ""
        for par, old, new in zip(self.params, old_List, new_List):
            if new != old: 
                self.change_pars.append((par, new))
                mssg += "Parameter: [" + par + "]\nCurrent :  " + old + "\nNew      :  " + new + "\n\n"
            else:
                self.change_pars.append((par, old))
        
        if mssg:
            mssg = "The following project information will be updated:\n\n" + mssg
            self.go_for_qa = True

        
            response = forms.alert(mssg, title="Update Confirmation", options=["Yes", "No"])
            if response == "Yes":
                self.Close()
        
        else:
            self.Close()
        
    
    def on_cancel(self, sender, args):
        self.change_pars = []
        self.Close()
        


#--------------------------------------------------------------------
#----------------- CHANGE TITLE BLOCK -------------------------------
#--------------------------------------------------------------------

class EditTitleBlock(forms.WPFWindow):
    def __init__(self, 
        xaml_file_path,
        lib_path, input_map
    ):

        # Input variables
        self.p_Numb = input_map["Project Number"]
        self.p_Name = input_map["Project Name"]
        self.p_Address = input_map["Project Address"]
        self.p_Suburb = input_map["Suburb"]
        self.p_Pcode = input_map["Postcode"]
        self.p_Client = input_map["Client Name"]
        self.Lib_Path = lib_path
        self.p_Type = input_map["pr_type"]
        self.tb_list = input_map["tb_list"]
        self.T_Block_paths = input_map["tb_paths"]

        forms.WPFWindow.__init__(self, xaml_file_path)
        self.tblock_info = []
        self.process_go = False
        self.change_pars = []

        # Hook triggers
        #---------------------------
        self.cmbTblocks.SelectionChanged += self.on_tb_selection_changed
        self.okBtn.Click += self.on_ok
        self.CancelBtn.Click += self.on_cancel

        # Prefill textbox and combos
        #---------------------------
        self.txbNumber.Text = self.p_Numb
        if self.p_Type == "R":
            self.lblProject.Content = "Project Address:"
            self.txbProject.Text = self.p_Address + ", " + self.p_Suburb
        else:
            self.txbProject.Text = self.p_Name
        for option in self.tb_list:
            self.cmbTblocks.Items.Add(option)

        self.cmbTblocks.SelectedIndex = self.T_Block_paths[self.p_Type][1]

    def on_tb_selection_changed(self, sender, args):
        if self.cmbTblocks.SelectedIndex == 0:
            self.tb_ok = False
            forms.alert("Please select the Title block family for this project.", title = "Select")
            self.selected_file = forms.pick_file(
                file_ext='rfa',
                title='Select a Revit Title Block Family File',
                multi_file=False
            )
            if self.selected_file:
                self.txbTb_other.Visibility = Visibility.Visible
                self.txbTb_other.Text = "Selected Title Block: \n" + os.path.basename(self.selected_file)
                self.tb_ok = True
        else:
            self.txbTb_other.Visibility = Visibility.Collapsed
            self.txbTb_other.Text = ""
            self.tb_ok = True

    def on_ok(self, sender, args):
        
        self.tblock_info.append(self.cmbTblocks.SelectedItem)
        if self.cmbTblocks.SelectedIndex == 0:
            self.tblock_info.append(self.selected_file) #temporary take the path to get the name
        elif self.cmbTblocks.SelectedIndex > 0:
            self.tblock_info.append(self.cmbTblocks.SelectedIndex)
        
        self.Close()  # Close the form after clicking OK
            
        self.process_go = True

    def on_cancel(self, sender, args):
        self.Close()


#--------------------------------------------------------------------
#----------- GET DRAWING SHEET COLLECTORS ---------------------------
#--------------------------------------------------------------------

def find_rev_info_for_list(doc, sheet):
    highest_rev = None
    highest_seq = -1
    
    if not sheet.GetAllRevisionIds():
        return None, None
        
    for rev_id in sheet.GetAllRevisionIds():
        rev = doc.GetElement(rev_id)

        if rev.SequenceNumber > highest_seq:
            highest_seq = rev.SequenceNumber
            highest_rev = rev  

    return highest_rev.Description, highest_rev.RevisionDate

def final_drawing_list(drawings, r_map):
    final_list = []
    for item in drawings.Items:
        if item.IsSelected:
            final_list.append(item.Sheet)
    
    r_map["rev_sheets"] = final_list

def get_pdf_keywords(pdf_path):
    with open(pdf_path, "rb") as f:
        pdf_data = f.read()

    marker = "/Keywords"
    pos = pdf_data.find(marker)

    if pos == -1:
        return ""

    pos += len(marker)

    # Skip spaces
    while pos < len(pdf_data) and pdf_data[pos] in " \r\n\t":
        pos += 1

    # Normal PDF text string:
    # /Keywords (metadata test)
    if pos < len(pdf_data) and pdf_data[pos] == "(":
        pos += 1
        result = ""
        escaped = False

        while pos < len(pdf_data):
            char = pdf_data[pos]
            if escaped:
                result += char
                escaped = False

            elif char == "\\":
                escaped = True

            elif char == ")":
                break

            else:
                result += char

            pos += 1

        return result.strip()

    return ""

def find_existing_sequence_folder(parent_folder, rev_seq, seq_code):

    if not os.path.exists(parent_folder):
        return

    seq_code = ("rev_seq_" + str(rev_seq).replace(".0", "") + seq_code)
    txt_name = seq_code + ".txt" #to eliminate old txt file
    
    for issue_folder in os.listdir(parent_folder):
        issue_folder_path = os.path.join(
            parent_folder,
            issue_folder
        )

        # Ignore files directly inside parent_folder
        if not os.path.isdir(issue_folder_path):
            continue

        for file_name in os.listdir(issue_folder_path):
            if file_name == txt_name:
                return issue_folder_path
                
            if "TRANSMITTAL" in file_name.upper():
                file_path = os.path.join(issue_folder_path, file_name)

                aux_code = get_pdf_keywords(file_path)             
                if aux_code == seq_code:
                    return issue_folder_path


def check_initials_status(names, sheets):
    empty_list = ["", "Author", "Designer", "Approver"]
    # Parameter name shown to user : Revit parameter
    parameters = {
        "Author": BuiltInParameter.SHEET_DRAWN_BY,
        "Designer": BuiltInParameter.SHEET_DESIGNED_BY,
        "Approver": BuiltInParameter.SHEET_APPROVED_BY
    }

    missing_parameters = []
    missing_sheets = []

    # Store valid initials found in the sheets
    initials_map = {
        "Author": [],
        "Designer": [],
        "Approver": []
    }

    for sheet in sheets:
        if sheet.Name not in names:
            continue

        sheet_has_missing = False
        for param_name, bip in parameters.items():
            param = sheet.get_Parameter(bip)
            if param:
                value = param.AsString()
                if value:
                    value = value.strip()
            else:
                value = ""

            if value in empty_list:
                sheet_has_missing = True
                if param_name not in missing_parameters:
                    missing_parameters.append(param_name)

            else:
                initials_map[param_name].append(value)

        # Add sheet only once even if multiple
        # parameters are missing
        if sheet_has_missing:
            missing_sheets.append(sheet.SheetNumber)

    suggested_initials = {}
    for param_name, initials in initials_map.items():
        if initials:
            counter = Counter(initials)
            suggested_initials[param_name] = (
                counter.most_common(1)[0][0]
            )
        else:
            suggested_initials[param_name] = ""

    if missing_parameters:
        parameter_text = ", ".join(missing_parameters)
        sheet_text = ", ".join(missing_sheets)

        message = (
            "The following drawings have missing initials for these parameters: {}.\n\n"
            "Sheets: {}\n\n"
            "Select 'Pick Initials to Fill Blanks' to choose the initials that should "
            "be used for the missing fields."
        ).format(parameter_text, sheet_text)

        action = forms.alert(
            message,
            title="Missing Drawing Initials",
            options=[
                "Pick Initials to Fill Blanks",
                "Cancel"
            ]
        )
        
        if action and "Pick" in action:
            for param in missing_parameters:
                text = ""
                while text == "":
                    text = forms.ask_for_string(
                        default=suggested_initials[param],
                        prompt="Enter Initials for {}:".format(param),
                        title="Input"
                    )
                    
                    if text == "":
                        forms.alert("This field cannot be empty")

                    if text is None:
                        sys.exit()
                    suggested_initials[param] = text.strip()
        
            with revit.Transaction("Update Initials"):
                for sheet in sheets:
                    if sheet.SheetNumber in missing_sheets:
                        for param_name in missing_parameters:
                            bip = parameters[param_name]
                            param = sheet.get_Parameter(bip)

                            if not param:
                                continue

                            value = param.AsString()
                            if value:
                                value = value.strip()
                            else:
                                value = ""

                            # Only fill parameters that are currently blank/default
                            if value in empty_list:
                                new_value = suggested_initials[param_name].upper()
                                if not param.IsReadOnly:
                                    param.Set(new_value)

            return "Go"
    else:
        return "Go"

def save_local_settings(file_path, settings):
    folder = os.path.dirname(file_path)

    # Create the folder if it doesn't exist
    if folder and not os.path.exists(folder):
        os.makedirs(folder)

    # Overwrite the existing file
    with open(file_path, "w") as f:
        for key, value in settings.items():
            f.write("{}={}\n".format(key, value))

class DrawingItem(object):
    def __init__(self, sheet, sheet_number, sheet_name, revision, rev_description, issue_date):
        self.IsSelected = False
        self.RowColor = "Gray"
        self.FontWeight = "Normal"
        self.CanEdit = False

        self.Sheet = sheet
        self.SheetNumber = sheet_number
        self.SheetName = sheet_name
        self.Revision = revision
        self.RevName = rev_description
        self.RevDate = issue_date

class DistributionItem(object):
    def __init__(self, name, selected=False):
        self.IsSelected = selected
        self.Name = name

class QuickPrintForm(forms.WPFWindow):
    def __init__(self, 
        xaml_file_name, 
        data
    ):
        forms.WPFWindow.__init__(self, xaml_file_name)

        self.disc_list = ["None", "Electrical", "Fire", "Hydraulic", "Mechanical", "Structural"]        
        self.rev_list = ["None"]
        self.rev_list.extend(data["rev_maps"][1])
        self.set_list = data["rev_maps"][3]
        self.full_list = data["sheets"]
        self.starter = False
        self.rev_map = data["rev_maps"][0]
        self.set_map = data["rev_maps"][2]
        self.print_list = []
        self.select_all = False
        self.final_map = {}

        
        # Visibility
        if len(self.rev_list) == 1:
            self.filter_rev_cb.Visibility = Visibility.Collapsed
        if len(self.set_list) == 1:
            self.filter_set_cb.Visibility = Visibility.Collapsed          
        
        # Hook triggers
        #---------------------------
        self.filter_disc_cb.SelectionChanged += self.update_drawing_list
        self.filter_rev_cb.SelectionChanged += self.update_drawing_list
        self.filter_set_cb.SelectionChanged += self.update_drawing_list
        self.select_all_btn.Click += self.select_all_none
        self.select_none_btn.Click += self.select_all_none
        self.cancel_btn.Click += self.cancel_click
        self.print_btn.Click += self.accept_click
        
        
        # Prefill textbox and combos
        #---------------------------
        for item in self.disc_list:
            self.filter_disc_cb.Items.Add(item)

        for item in self.rev_list:
            self.filter_rev_cb.Items.Add(item)
           
        for item in self.set_list:
            self.filter_set_cb.Items.Add(item)

        


        # Initial settings
        #-------------------------------
        self.filter_set_cb.SelectedIndex = 0
        self.filter_disc_cb.SelectedIndex = 0
        self.filter_rev_cb.SelectedIndex = 0
        self.starter = True
        self.update_drawing_list(self)

       
### - Helpers ----------------------------           
    def update_drawing_list(self, sender=None, args=None):
        if not self.starter:
            return
        
        self.drawings_list.Items.Clear()
        doc = __revit__.ActiveUIDocument.Document
        filtered_list_disc = []
        
        # Filter by discipline first
        selected_disc = self.filter_disc_cb.SelectedItem
        if selected_disc != "None":
            disc_letter = selected_disc[0]
            for p_sheet in self.full_list:
                if p_sheet.SheetNumber[0].upper() == disc_letter:
                    filtered_list_disc.append(p_sheet)
        else:
            filtered_list_disc = self.full_list
        
        # Filter by Current Revision
        filtered_list_revs = []
        selected_rev = self.filter_rev_cb.SelectedItem
        if selected_rev != "None":
            rev_sheets = self.rev_map[selected_rev]["rev_sheets"]
            rev_sheet_numbers = [r_sheet.SheetNumber for r_sheet in rev_sheets]
            for p_sheet in filtered_list_disc:
                if p_sheet.SheetNumber in rev_sheet_numbers:
                    filtered_list_revs.append(p_sheet)
                
        else:
            filtered_list_revs = filtered_list_disc

        # Filter by Print Set
        filtered_list_set = []
        selected_set = self.filter_set_cb.SelectedItem
        if selected_set != "None":
            set_sheets = self.set_map[selected_set]
            set_sheet_numbers = [s_sheet.SheetNumber for s_sheet in set_sheets]
            for p_sheet in filtered_list_revs:
                if p_sheet.SheetNumber in set_sheet_numbers:
                    filtered_list_set.append(p_sheet)
                
        else:
            filtered_list_set = filtered_list_revs


        # Fill the list
        if not filtered_list_set:
            return
            
        for p_sheet in filtered_list_set:
            param = p_sheet.LookupParameter("Current Revision")
            if param:
                current_rev = param.AsString() or ""

            rev_desc, rev_date = find_rev_info_for_list(doc, p_sheet)
            item = DrawingItem(
                p_sheet,
                p_sheet.SheetNumber,
                p_sheet.Name,
                current_rev,
                rev_desc,
                rev_date
            )
            self.drawings_list.Items.Add(item)
        
        self.select_all_none()
        self.drawings_list.Items.Refresh()
        self.print_list = filtered_list_set
        
    def drawing_checked(self, sender, args):
        for item in self.drawings_list.Items:
            if item.IsSelected:
                item.RowColor = "Black"
                item.FontWeight = "Bold"
            else:
                item.RowColor = "Gray"
                item.FontWeight = "Normal"

        self.drawings_list.Items.Refresh()

       
### - Buttons ---------------------------
    def cancel_click(self, sender, args):
        self.print_list = []
        self.Close()

    def select_all_none(self, sender=None, args = None):
        if sender is not None:
            self.select_all = sender.Name == "select_all_btn"

        for item in self.drawings_list.Items:
            item.IsSelected = self.select_all            
        
        self.drawing_checked(None, None)
        self.drawings_list.Items.Refresh()

    def accept_click(self, sender, args):
        # Complete final map to print
        self.final_map = {}
        final_drawing_list(self.drawings_list, self.final_map)
                
        if not self.final_map:
            forms.alert("Please select at least one drawing to print")
            return
        
        self.Close()


#======================================================================================================
#======================================================================================================

class IssuePrintForm(forms.WPFWindow):
    def __init__(self, 
        xaml_file_name, 
        rev_map,
        print_map,
        f15_list = []
    ):
        forms.WPFWindow.__init__(self, xaml_file_name)
        
        self.rev_maps, self.rev_list, self.set_maps, self.set_list = rev_map
        self.f15_list = f15_list
        self.formats = print_map["formats"]
        self.purpose_items = print_map["purpose_items"]
        self.printable_sheets = print_map["prt_sheets"]
        self.print_settings = print_map["prt_settings"]
        self.pr_folder = print_map["pr_folder"]
        self.print_type = print_map["prt_type"]
        self.bin_folder = print_map["bin"]
        self.ClientRef = print_map["client_ref"]
        self.QbuildRef = print_map["qbuild_ref"]
        self.status = print_map["pr_status"]
        self.building_code = print_map["building_code"]
        self.ok_for_name = True
        self.custom_loc = False
        self.include_all = False
        client = print_map["client"]
        
        # Define variables 
        #---------------------------
        self.selected_issue = None
        self.rev_map = {}
        self.Export = False
        self.replace_message = ""
        self.selected_set = ""
        self.selected_discipline = ""
        self.disc_code = ""
        
        # Hook triggers
        #---------------------------
        self.back_btn.Click += self.back_click
        self.next_btn.Click += self.next_click
        self.cancel_btn.Click += self.cancel_click
        self.custom_issue_cb.Checked += self.custom_issue_changed
        self.custom_issue_cb.Checked += self.issue_selection_changed
        self.custom_issue_cb.Unchecked += self.custom_issue_changed
        self.custom_issue_cb.Unchecked += self.issue_selection_changed
        self.issue_list.SelectionChanged += self.issue_selection_changed
        self.include_all_cb.Checked += self.include_previous_changed
        self.include_all_cb.Unchecked += self.include_previous_changed
        self.copies_slider.ValueChanged += self.copies_changed

        self.issue_name_tb.TextChanged += self.update_print_page
        self.issue_name_tb.LostFocus += self.upper_letters
        self.issue_date_dp.SelectedDateChanged += self.update_print_page
        self.filter_set_cb.SelectionChanged += self.update_drawing_list
        self.filter_disc_cb.SelectionChanged += self.update_drawing_list
        self.filter_set_cb.SelectionChanged += self.include_previous_changed
        self.filter_disc_cb.SelectionChanged += self.include_previous_changed
        self.add_distribution_btn.Click += self.add_new_dist_name
        self.select_all_btn.Click += self.select_all_none
        self.select_none_btn.Click += self.select_all_none
        self.naming_type_cb.SelectionChanged += self.naming_type_changed
        self.custom_folder.Click += self.custom_location
        self.custom_folder.Visibility = Visibility.Collapsed
        self.form15_cb.Checked += self.form_15_changed
        self.form15_cb.Unchecked += self.form_15_changed
        self.folder_type_cb.SelectionChanged += self.update_discipline
        
        # Prefill textbox and combos
        #---------------------------
        for _rev in self.rev_list:
            self.issue_list.Items.Add(_rev)
        
        for _set in self.set_list:
            self.filter_set_cb.Items.Add(_set)
            
        disciplines = ["None", "Electrical", "Fire", "Hydraulic", "Mechanical", "Structural"]

        for _disc in disciplines:
            self.filter_disc_cb.Items.Add(_disc)
            if _disc != "None":
                self.folder_type_cb.Items.Add(_disc)
        
        if client:
            self.distribution_list.Items.Add(DistributionItem(client))
        
        if "local" in self.print_settings:
            for dist_name in self.print_settings:
                if dist_name[:4] == "dist" and self.print_settings[dist_name] != client:
                    self.distribution_list.Items.Add(DistributionItem(self.print_settings[dist_name]))
        
        for frmt in self.formats:
            self.naming_type_cb.Items.Add(frmt)
        
        for purpose in self.purpose_items:
            self.purpose_cb.Items.Add(purpose)
        
        self.method_list = ["E-mail", "SharePoint", "E-mail + SharePoint", "Collected"]
        for method in self.method_list:
            self.method_cb.Items.Add(method)
        
        
        # Initial settings
        #-------------------------------

        if print_map.get("def_disc"):
            self.folder_type_cb.SelectedItem = print_map.get("def_disc")
        
        try:
            self.naming_type_cb.SelectedItem = "STP-Standard"
        except:
            self.naming_type_cb.SelectedIndex = 0
        self.issue_folder.IsEnabled = False
        self.filter_set_cb.SelectedIndex = 0
        self.filter_disc_cb.SelectedIndex = 0
        self.method_cb.SelectedIndex = 0
        
        self.fill_pref_settings()
            
### - Hooks ----------------------------
    def update_discipline(self, sender, args):
        self.selected_discipline = self.folder_type_cb.SelectedItem
        if self.selected_discipline == "Structural":
            self.disc_code = "Struct"
        else:
            self.disc_code = self.selected_discipline[:4]
        
        self.update_print_page(None, None)

    def form_15_changed(self, sender, args):
        if not self.rev_map:
            return
            
        rev_item = self.rev_map["rev_item"]
        if rev_item is None:
            return
            
        rev_id = rev_item.Id

        this_doc = __revit__.ActiveUIDocument.Document
        with revit.Transaction("Update Revision on F15 Sheets", this_doc):
            for sheet in self.f15_list:
                additional_revisions = list(
                    sheet.GetAdditionalRevisionIds()
                )

                # CHECKED -> add revision
                if self.form15_cb.IsChecked:

                    if rev_id not in additional_revisions:
                        additional_revisions.append(rev_id)

                # UNCHECKED -> remove revision
                else:

                    if rev_id in additional_revisions:
                        additional_revisions.remove(rev_id)

                sheet.SetAdditionalRevisionIds(
                    col_List[ElementId](additional_revisions)
                )           
        
        
    
    def custom_issue_changed(self, sender, args):
        self.issue_list.IsEnabled = not sender.IsChecked

    def issue_selection_changed(self, sender, args):
        #print(self.issue_list.SelectedItem)
        self.purpose_cb.SelectedIndex = -1            
        if self.issue_list.SelectedItem is None and not self.custom_issue_cb.IsChecked:
            return
        
        if self.custom_issue_cb.IsChecked:
            self.rev_map = self.rev_maps["Custom"]
            self.issue_date_dp.IsEnabled = True
        else:
            selected_issue = str(self.issue_list.SelectedItem)
            self.rev_map = self.rev_maps[selected_issue]                
            self.issue_date_dp.IsEnabled = False
        
        self.form_15_changed(None, None)
        
        
        # Fill final page controls
        self.issue_name_tb.Text = self.rev_map["rev_desc"].upper()
        self.update_print_page(None, None, "change_code")

    def include_previous_changed(self, sender, args):
        include_previous = self.include_all_cb.IsChecked == True
        for item in self.drawings_list.Items:
            if item.RowColor == "Gray":
                if item.Revision:
                    item.IsSelected = include_previous
                else:
                    item.IsSelected = False
                

        self.drawings_list.Items.Refresh()

    def drawing_checked(self, sender, args):
        for item in self.drawings_list.Items:
            if item.IsSelected:
                item.RowColor = "Black"
                item.FontWeight = "Bold"
            else:
                item.RowColor = "Gray"
                item.FontWeight = "Normal"

        self.drawings_list.Items.Refresh()

    def copies_changed(self, sender, args):
        num_copies = str(int(self.copies_slider.Value))
        self.copies_tx.Text = "Number of Copies: [ {} ]".format(num_copies)

    def add_new_dist_name(self, sender, args):
        result = forms.ask_for_string(
            default="",
            prompt="Enter a new distribution name, or close to Cancel:",
            title="New Distribution Name"
        )
        
        if result and result != "":
            self.distribution_list.Items.Add(DistributionItem(result.upper().replace("MCDON","McDON")))
            
    def select_all_none(self, sender, args = None):
        active_cells = sender.Name == "select_all_btn"

        for item in self.drawings_list.Items:
            item.IsSelected = active_cells            
        self.drawing_checked(None, None)
        self.drawings_list.Items.Refresh()
       
    def naming_type_changed(self, sender, args = None):
        n_type = self.naming_type_cb.SelectedItem
        self.ok_for_name = True
        #==================delete me ======================
        #return
        #==================delete me ======================
        msg = ""
        if "PYT" in n_type:
            if not self.status:
                msg += "Project Status\n"
        
        elif "QBL" in n_type:
            if not self.QbuildRef:
                msg += "Qbuild Project Number\n"
            if not self.status:
                msg += "Project Status\n"
        
        elif "Coles" in n_type:
            if not self.ClientRef:
                msg += "Client/Project Reference Number\n"
        
        if msg:
            forms.alert("The following parameters are missing in this project:\n\n" + msg +
                "\nThese parameters from project information are relevant for the selected file naming option.")
            self.ok_for_name = False
    
    
### - Helpers ----------------------------           
    def update_drawing_list(self, sender=None, args=None):
        self.drawings_list.Items.Clear()
        doc = __revit__.ActiveUIDocument.Document

        on_set = self.filter_set_cb.SelectedItem
        on_discipline = self.filter_disc_cb.SelectedItem
        
        if not on_set or not on_discipline:
            return

        filtered_list = self.printable_sheets
        
        # Filter by discipline        
        if on_discipline != "None":
            aux_list = []
            for sheet in filtered_list:
                sheet_number = sheet.SheetNumber
                if not sheet_number:
                    continue
                
                if sheet_number[0].upper() == on_discipline[0].upper():
                    aux_list.append(sheet)
        
            filtered_list = aux_list
        
        # Filter by set:
        if on_set != "None":
            aux_list = []
            set_sheet_ids = set(
                sheet.Id
                for sheet in self.set_maps[on_set]
            )
            
            for sheet in filtered_list:
                if sheet.Id in set_sheet_ids:
                    aux_list.append(sheet)

            filtered_list = aux_list

        for p_sheet in filtered_list:
            current_rev = ""

            param = p_sheet.LookupParameter("Current Revision")
            if param:
                current_rev = param.AsString() or ""

            rev_desc, rev_date = find_rev_info_for_list(doc, p_sheet)

            item = DrawingItem(
                p_sheet,
                p_sheet.SheetNumber,
                p_sheet.Name,
                current_rev,
                rev_desc,
                rev_date
            )

            self.drawings_list.Items.Add(item)
        
        if self.custom_issue_cb.IsChecked:
            self.include_all_cb.Visibility = Visibility.Collapsed
            self.select_all_btn.Visibility = Visibility.Visible
            self.select_none_btn.Visibility = Visibility.Visible
            self.custom_edit = True
        
        
        else:
            self.include_all_cb.Visibility = Visibility.Visible
            self.select_all_btn.Visibility = Visibility.Collapsed
            self.select_none_btn.Visibility = Visibility.Collapsed
            self.custom_edit = False
        
            # Check or uncheck in drawing list
            if self.rev_map:
                rev_sheet_names = [sh.SheetNumber for sh in self.rev_map["rev_sheets"]]
                for item in self.drawings_list.Items:
                    if item.SheetNumber in rev_sheet_names:
                        item.IsSelected = True
                        item.RowColor = "Black"
                        item.FontWeight = "Bold"
                    else:
                        item.IsSelected = False
                        item.RowColor = "Gray"
                        item.FontWeight = "Normal"
        
            if self.include_all_cb.IsChecked:
                self.include_previous_changed(None, None)
        
        
        # Block drawing selection in next page
        for item in self.drawings_list.Items:
            item.CanEdit = self.custom_edit

        self.drawings_list.Items.Refresh()
        return True

    def update_buttons(self):
        self.back_btn.IsEnabled = self.wizard_tabs.SelectedIndex > 0
        
        if self.print_type == "I":
            if self.wizard_tabs.SelectedIndex == 2:
                self.next_btn.Content = "Create Issue"
            else:
                self.next_btn.Content = "Next"

        if self.print_type == "Q":
            if self.wizard_tabs.SelectedIndex == 1:
                self.next_btn.Content = "Quick Print"
            else:
                self.next_btn.Content = "Next"
            
        
        if self.wizard_tabs.SelectedIndex == 1:
            self.Width = 800
        else:
            self.Width = 650       

    def update_print_page(self, sender, args, called_from = None):
        if not self.rev_map:
            return
        
        self.location_warning_tb.Visibility = Visibility.Collapsed
        
        if sender and sender.Name == "issue_date_dp":
            self.rev_map["rev_date"] = self.issue_date_dp.SelectedDate
        else:
            self.issue_date_dp.SelectedDate = self.rev_map["rev_date"]

        if sender and sender.Name == "issue_name_tb":
            for x, purpose in enumerate(self.purpose_items):
                if purpose.upper() in self.issue_name_tb.Text.upper():
                    self.purpose_cb.SelectedIndex = x
                    break

            if "PRELIM" in self.issue_name_tb.Text.upper():
                self.purpose_cb.SelectedIndex = 0
        
        if self.rev_map["rev_date"]:
            # Update form last page folder location
            issue_date = self.rev_map["rev_date"].ToString("yyMMdd")
            folder_name = " - ".join([issue_date, self.building_code, self.issue_name_tb.Text.upper()])
            folder_name = folder_name.replace("-  -","-") # Fix if there is no building code parameter
            folder_path = os.path.join("Drawings", "Issued Drawings", self.disc_code)
            folder_loc = os.path.join(folder_path, folder_name)
            
            if self.pr_folder:
                aux_folder = os.path.join(self.pr_folder, folder_path)
                #find_existing_issue_folder(os.path.join(self.pr_folder, folder_path), self.rev_map)
                if called_from != None:
                    existing_folder = find_existing_sequence_folder(
                        aux_folder, 
                        self.rev_map["rev_seq"], 
                        self.building_code
                    )
                    
                    if existing_folder:
                        self.rev_map["rev_to_delete"] = existing_folder
            
                target_folder = os.path.join(self.pr_folder, folder_loc)
                self.issue_folder.Text = folder_loc
            else:
                target_folder = ""
            
            # Update revision map
            self.rev_map["rev_date_text"] = issue_date
            self.rev_map["rev_name"] = folder_name
            self.rev_map["rev_folder"] = target_folder
            
            #print("rev_folder", self.rev_map["rev_folder"])
            #print("delte folder", self.rev_map["rev_to_delete"])

            if os.path.exists(target_folder):
                self.location_warning_tb.Visibility = Visibility.Visible
                self.replace_message = "  ** The folder already exists, its contents will be replaced."
            elif self.rev_map["rev_to_delete"]:
                self.location_warning_tb.Visibility = Visibility.Visible
                self.replace_message = " ** A previous Folder for this issue will be deleted."
            
            if self.replace_message:
                self.location_warning_tb.Text = self.replace_message
                
    def fill_pref_settings(self):
        if "local" in self.print_settings:
            if "naming_type" in self.print_settings:
                saved_format = self.print_settings["naming_type"]
                if saved_format:
                    for i, item in enumerate(self.naming_type_cb.Items):
                        if item == saved_format:
                            self.naming_type_cb.SelectedIndex = i
                            break 
            
            for key, checkbox in [
                ("dwg_files", self.dwg_files_cb),
                ("pdf_files", self.pdf_files_cb),
                ("combined", self.combine_pdf_cb),
                ("form15", self.form15_cb),
                ("formSID", self.SID_cb),
                ("specs", self.spec_cb),
                ("rvt_file", self.rvt_files_cb)
            ]:

                if key in self.print_settings and self.print_settings[key] == "1":
                    checkbox.IsChecked = True
                else:
                    checkbox.IsChecked = False
              
            if "purpose" in self.print_settings:
                saved_purpose = self.print_settings["purpose"]
                for purpose in self.purpose_items:
                    if saved_purpose == purpose:
                        self.purpose_cb.SelectedItem = saved_purpose
                        break
        
            if "method" in self.print_settings and self.print_settings["method"] in self.method_list:
                self.method_cb.SelectedItem = self.print_settings["method"]
                
            if "include_all" in self.print_settings:
                self.include_all = self.print_settings["include_all"] == "1"
            else:
                self.include_all = False

            self.include_all_cb.IsChecked = self.include_all

    def upper_letters(self, sender, args):
        sender.Text = sender.Text.upper()

              
### - Buttons ---------------------------
    def custom_location(self, sender, args):
        if self.custom_folder.Content == "Custom":
            selected_issue_path = forms.pick_folder(
                title="Select Folder to Save this issue."
            )
            
            if selected_issue_path:
                self.custom_folder.Content = "Default"
                self.custom_loc = True
        else:
            self.custom_folder.Content = "Custom"
            self.custom_loc = False

    def back_click(self, sender, args):
        if self.wizard_tabs.SelectedIndex > 0:
            self.wizard_tabs.SelectedIndex -= 1
        self.update_buttons()

    def cancel_click(self, sender, args):
        self.rev_map = {}
        self.Close()

    def next_click(self, sender, args):
        if self.wizard_tabs.SelectedIndex == 0:
            if self.issue_list.SelectedItem is None and not self.custom_issue_cb.IsChecked:
                forms.alert("Please select an issue or custom issue before continuing.")
                return
            
            if not self.custom_issue_cb.IsChecked and self.rev_map["rev_date"] == None and self.print_type != "Q":
                forms.alert(
                    (
                        "Selected issue sequence date could not be recognised.\n\n"
                        "Found date:\n"
                        "{}\n\n"
                        "Please ensure the issue date is entered in the following format:\n"
                        "dd.mm.yy\n\n"
                        "Example: 29.06.26"
                    ).format(self.rev_map["rev_date_text"])
                )
                return
            
            self.update_print_page(None, None)
            #self.include_all_cb.IsChecked = self.include_all
            self.update_drawing_list(None, None)

        
        if self.wizard_tabs.SelectedIndex == 1:
            # Collect the selected sheets and check pass to step 3
            self.sheet_selection = [item.Sheet for item in self.drawings_list.Items if item.IsSelected]
            if not self.sheet_selection:
                forms.alert(
                    "The current issue selection is empty.\n\n"
                    "Please select a valid issue sequence or go back to create a 'Custom Issue' before continuing."
                )
                return
            
            # Check if there are no duplicated names in exporting drawings to avoid problems when exporting indivicual files.
            if self.print_type == "I":
                sheet_names = [item.SheetName for item in self.drawings_list.Items if item.IsSelected]
                self.duplicated_names = [
                    item for item, count in Counter(sheet_names).items()
                    if count > 1
                ]

                if self.duplicated_names:
                    msg = (
                        "The following sheet names are duplicated:\n\n"
                        "{}\n\n"
                        "Each sheet must have a unique name before you can continue."
                    ).format("\n".join(self.duplicated_names))

                    forms.alert(
                        msg,
                        title="Duplicate Sheet Names"
                    )
                    return
                    
            # Check if all drawings have Designed, Drawn and approved by names.
            if not self.print_type == "Q":
                result = check_initials_status(sheet_names, self.printable_sheets)
                if not result == "Go":
                    return
        
        lim_buttons = 2 if self.print_type == "I" else 1
        if self.wizard_tabs.SelectedIndex < lim_buttons:
            self.wizard_tabs.SelectedIndex += 1
            self.update_buttons()

        else:
            if self.print_type == "I":
                # Check if all controls are selected
                if not any((self.dwg_files_cb.IsChecked, 
                    self.pdf_files_cb.IsChecked, 
                    self.combine_pdf_cb.IsChecked
                    )):
                    forms.alert("Please select at least one format for Drawings 'DWG' / 'PDF'.")
                    return
                
                if self.issue_name_tb.Text == "":
                    forms.alert("Please select an Issue Name for this set.")
                    return
                
                if self.purpose_cb.SelectedIndex < 0:
                    forms.alert("Please select one purpose for distribution.")
                    return
                
                distrib_list = []
                distrib_record = []
                for item in self.distribution_list.Items:
                    distrib_record.append(item.Name)
                    if item.IsSelected:
                        distrib_list.append(item.Name)
                
                if not distrib_list:
                    forms.alert("Please select at least one Distribution Element to continue.") 
                    return
                else:
                    self.rev_map["dist_list"] = distrib_list
                    self.rev_map["num_copies"] = self.copies_slider.Value
                
                if self.location_warning_tb.Visibility == Visibility.Visible:
                    if "delete" in self.replace_message:
                        msg = (
                            "Due to an issue date mismatch, the existing folder for this issue will be deleted "
                            "and replaced with a new folder using the updated issue date in its name."
                            "\n\nDo you want to continue?"
                        )
                    elif "replace" in self.replace_message:
                        msg = (
                            "The existing folder and all of its contents will be replaced "
                            "with the new issue documents."
                            "\n\nDo you want to continue?"
                        )
                    result = forms.alert(msg, ok=False, yes=True, no=True)
                    if not result:
                        return

                if not self.ok_for_name:
                    forms.alert("Missing parameters from project information are preventing "
                        "the code from complete the printing process. \n\nPlease contact STP Tools developer "
                        "if the problem persists"
                    )
                    return

                # Complete rev_map to print
                final_drawing_list(self.drawings_list, self.rev_map)
                
                format_text = ""
                if self.pdf_files_cb.IsChecked or self.combine_pdf_cb.IsChecked:
                    format_text += "P"
                if self.dwg_files_cb.IsChecked:
                    format_text += "D"
                if self.rvt_files_cb.IsChecked:
                    format_text += "R"
                self.rev_map["formats"] = format_text
                
                purpose_text = "".join(word[0] for word in self.purpose_cb.SelectedItem.split())
                self.rev_map["purpose"] = purpose_text
                
                selected_method = self.method_cb.SelectedItem
                if "+" in selected_method:
                    selected_method = "ES"
                else:
                    selected_method = selected_method[0]

                self.rev_map["method"] = selected_method
                self.rev_map["naming_type"] = self.naming_type_cb.SelectedItem
                self.rev_map["individ_pdf"] = self.pdf_files_cb.IsChecked
                self.rev_map["form15"] = self.form15_cb.IsChecked
                self.rev_map["formSID"] = self.SID_cb.IsChecked
                self.rev_map["specs"] = self.spec_cb.IsChecked
                self.rev_map["rvt_file"] = self.rvt_files_cb.IsChecked
                self.rev_map["combined_pdf"] = self.combine_pdf_cb.IsChecked
                self.rev_map["discipline"] = self.selected_discipline
                self.rev_map["disc_code"] = self.disc_code
                self.rev_map["full_dist"] = distrib_record
                self.rev_map["Client Reference Number"] = self.ClientRef
                self.rev_map["Qbuild Project Number"] = self.QbuildRef
                self.rev_map["pr_status"] = self.status
                
                self.Export = True
                
                # Refresh print setting file
                self.print_settings = {
                    "local": "xxx",
                    "naming_type": self.rev_map["naming_type"],
                    "purpose": self.purpose_cb.SelectedItem,
                    "method": self.method_cb.SelectedItem,
                    "copies": self.copies_slider.Value,
                    "dwg_files": "1" if self.dwg_files_cb.IsChecked else "0",
                    "pdf_files": "1" if self.pdf_files_cb.IsChecked else "0",
                    "combined": "1" if self.combine_pdf_cb.IsChecked else "0",
                    "form15": "1" if self.form15_cb.IsChecked else "0",
                    "formSID": "1" if self.SID_cb.IsChecked else "0",
                    "specs": "1" if self.spec_cb.IsChecked else "0",
                    "rvt_file": "1" if self.rvt_files_cb.IsChecked else "0",
                    "include_all": "1" if self.include_all_cb.IsChecked else "0"
                }
                
                for x, item in enumerate(distrib_record):
                    self.print_settings["dist_" + str(x)] = item
                
                file_path = os.path.join(self.pr_folder,"Drawings","xref", "issue_print_preferences.txt")
                save_local_settings(file_path, self.print_settings)
            
            else:
                final_drawing_list(self.drawings_list, self.rev_map)
                    
                
                self.Export = True
            
            
            self.Close()


#--------------------------------------------------------------------
#----------- CREATE TRANSMITTAL FROM SEQUENCES ----------------------
#--------------------------------------------------------------------

class Transm_from_Seq_Form(forms.WPFWindow):
    def __init__(self, xaml_file_name, def_disc, parent_form=None):
        forms.WPFWindow.__init__(self, xaml_file_name)

        self.parent_form = parent_form

        self.discipline = None
        self.folder = None
        self.type_option = None
        self.process_go = False

        self.cmbDiscipline.ItemsSource = [
            "Electrical",
            "Fire",
            "Hydraulic",
            "Mechanical",
            "Structural"
        ]

        self.radCombined.IsChecked = True

        self.btnOK.Click += self.ok_click
        self.btnCancel.Click += self.cancel_click
        
        if def_disc:
            try:
                self.cmbDiscipline.SelectedItem = def_disc
            except:
                pass


    def ok_click(self, sender, args):
        if self.cmbDiscipline.SelectedItem is None:
            forms.alert("Please select a discipline.")
            return

        self.discipline = self.cmbDiscipline.SelectedItem
        if self.discipline == "Structural":
            self.folder = "Struct"
        else:
            self.folder = self.discipline[:4]

        if self.radCombined.IsChecked:
            self.type_option = "Combined Type"
        else:
            self.type_option = "Individual Type"

        self.process_go = True
        self.Close()


    def cancel_click(self, sender, args):
        self.process_go = False
        self.Close()




#-------------

