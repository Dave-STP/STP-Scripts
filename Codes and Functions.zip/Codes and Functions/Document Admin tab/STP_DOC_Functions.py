#--------------------------------------------------------------------
#----- FUNCTIONS FOR STP GENERAL TOOLS ------------------------------
#--------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import os
import time
import uuid
import re
import shutil
import stat
import math
import time
import traceback
import clr
from System.Collections.Generic import List
from Autodesk.Revit.DB import *
from pyrevit import revit, forms
from datetime import datetime
from System import DateTime
from System.Globalization import CultureInfo


# Excel Libraries
from System import Type, Activator, Array, Object
from System.Reflection import BindingFlags
import System.Windows.Forms as WinForms
import System.Threading as Threading

#-------------------------------------------------------------------------------
#------GENERAL FUNCTIONS -------------------------------------------------------
#-------------------------------------------------------------------------------

def check_against_QA_file(pr_Info, qa_Info):
    diff_list = []
    qa_Info["P_code"] = str(qa_Info["P_code"])
    for key, value in pr_Info.items():
        aux_key = ""
        if key != "Number":
            if key == "Name":
                aux_key = "Project Name"
            elif key == "Address":
                aux_key = "Project Address"
            elif key == "P_code":
                aux_key = "Postcode"
            elif key == "Client":
                aux_key = "Client Name"
                
            if pr_Info[key] != qa_Info[key]:
                diff_list.append((key, aux_key, "Parameter: [ " + key + " ]\nCurrent: " + pr_Info[key] + "\nQA Data: " + qa_Info[key]))

    return diff_list

#-------------------------------------------------------------------------------
#------ISSUE PRINTING FUNCTIONS ------------------------------------------------
#-------------------------------------------------------------------------------

def alternative_folder():
    if os.path.exists(r"C:\XREV"):
        rev_fold = r"C:\XREV"
        fold_name = "XREV"
    
    else:
        rev_fold = r"C:\STP Check Prints"
        fold_name = "STP Check Prints"
        if not os.path.exists(rev_fold):
            os.makedirs(rev_fold)

    return rev_fold, fold_name

def clean_up_folder(folder_path, exceptions = []):
    if os.path.basename(folder_path) == "bin":
        print("bin folder cannot be cleaned up")
        return
        
        
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        
        try:
            if os.path.isfile(file_path) and file_name not in exceptions:
                os.remove(file_path)
        except Exception as e:
            if "is being used by another process" in str(e):
                forms.alert("Please close the following file and try again:\n\n" + os.path.basename(file_path))
                sys.exit()

def collect_all_drawings(doc):
    raw_sheets = [
        s for s in FilteredElementCollector(doc).OfClass(ViewSheet)
        if not s.IsPlaceholder and s.CanBePrinted and s.SheetNumber != "01"
    ]

    # Collect all drawings in the project and sort
    if not raw_sheets:
        forms.alert("No printable sheets found.", exitscript=True)

    # Sort sheets by sheet number
    all_sheets = sorted(raw_sheets, key=lambda x: x.SheetNumber)
    
    return all_sheets

def delete_files_when_fail(delete_paths):
    
    for path in delete_paths:
        if os.path.exists(path):
            try:
                os.remove(path)
            except:
                pass

def find_issue_folder(k_map, pr_path, selected_disc, today):
    disciplines = {
        "Electrical": "Elec",
        "Fire": "Fire",
        "Mechanical": "Mech",
        "Hydraulic": "Hyd",
        "Structural": "Struct"
    }
    
    issue_folder = None
    issue_name = None
    disc_code = disciplines[selected_disc]
    seq = str(k_map["rev_seq"])
    seq_name = "seq_" + disc_code + "_#" + seq + ".txt"    
    discipline_folder = os.path.join(pr_path,"Drawings","Issued Drawings",disc_code)

    existing_issue_folder = find_sequence_files(discipline_folder, seq_name)
    if existing_issue_folder:
        k_map["rev_exists"] = True
        k_map["issue_path"] = existing_issue_folder
    else:
        k_map["issue_path"] = os.path.join(discipline_folder, k_map["rev_name"])
    k_map["seq_txt_path"] = os.path.join(k_map["issue_path"], seq_name)
    
def find_sequence_files(parent_folder, seq_name):
    for folder_name in os.listdir(parent_folder):
        folder_path = os.path.join(parent_folder, folder_name)

        # Only search 1 level down
        if os.path.isdir(folder_path):
            for file_name in os.listdir(folder_path):
                if file_name == seq_name:
                    return folder_path

def get_revisions_and_sets(doc, sheets):
    revisions = list(FilteredElementCollector(doc).OfClass(Revision).ToElements())
    view_sheet_sets = (FilteredElementCollector(doc).OfClass(ViewSheetSet).ToElements())

    rev_maps = {}
    set_maps = {}
    rev_list = []
    set_list = []

    # Create rev map and names for print by sequences list
    if revisions:
        for rev in revisions:
            rev_name = "{} - {}".format(
                rev.RevisionDate,
                rev.Description
            )
            rev_maps[rev_name] = fill_rev_map(rev)
            
            rev_list.append(rev_name)
            
            if sheets:
                sheets_in_sequence(doc, rev_maps[rev_name], sheets)
        
        rev_maps["Custom"] = fill_rev_map(None)
    
    # Create set map and names for filtering by set prints
    set_list.append("None")

    if view_sheet_sets:
        for vss in view_sheet_sets:
            set_sheets = []
            for view in vss.Views:
                if isinstance(view, ViewSheet):
                    set_sheets.append(view)
            
            set_list.append(vss.Name)
            set_maps[vss.Name] = set_sheets
    

    return rev_maps, rev_list, set_maps, set_list

def fill_rev_map(rev, item_type=None):
    if rev:
        aux_seq = rev.SequenceNumber
        aux_desc = rev.Description
        date_text = rev.RevisionDate
        rev_date = revit_date_to_datetime(date_text)
        
    else:
        aux_seq = "c"
        aux_desc = "CUSTOM ISSUE"
        rev_date = DateTime.Today
        date_text = ""

    rev_def = {
        "rev_item": rev,
        "rev_seq": aux_seq,
        "rev_desc": aux_desc.upper(),
        "rev_date": rev_date,
        "rev_date_text": "" if rev_date else date_text,
        "rev_name": "",
        "rev_folder": "",
        "rev_to_delete": "",
        "rev_sheets": []
    }

    return rev_def

def filter_pdf_by_discipline(name, code, sheets, discipline):
    filtered_list = []
    letter = discipline[0]
    file_name = "{}{} - {} {}".format(letter, code, discipline, name)
    
    for sheet in sheets:
        if sheet.SheetNumber[0].upper() == letter:
            filtered_list.append(sheet)
            
    return [filtered_list, file_name]

def insert_new_drawing_lines(sheet, lines_to_add, target_row):
    for x in range(lines_to_add):
        com_call(com_get(sheet, "Rows", target_row), "Insert")
        merge_range = com_get(sheet, "Range",
            cell_obj(sheet, target_row, 2),
            cell_obj(sheet, target_row, 5))

        com_call(merge_range, "Merge")
        com_set(merge_range, "HorizontalAlignment", -4131)
        
        # Copy formula from row below, but adapt it to the new row
        source_cell = cell_obj(sheet, target_row + 1, 6)  # F row below
        target_cell = cell_obj(sheet, target_row, 6)      # F new row

        formula_r1c1 = com_get(source_cell, "FormulaR1C1")
        com_set(target_cell, "FormulaR1C1", formula_r1c1)
        errors = com_get(target_cell, "Errors")
        err = com_get(errors, "Item", 4)
        com_set(err, "Ignore", True)

def move_files_from_temp(relocate_paths):
    total = len(relocate_paths)
    i = 0
    with forms.ProgressBar(title="Copying Files to Issue Folder") as pb:
        for source_path, target_path in relocate_paths:
            i += 1
            pb.update_progress(i, total)
            target_folder = os.path.dirname(target_path)

            if target_folder and not os.path.exists(target_folder):
                os.makedirs(target_folder)

            if target_path and os.path.exists(target_path):
                os.remove(target_path)


            try:
                shutil.move(source_path, target_path)
            except:
                return False

    return True

def naming_sets(p_numb, final_map):
    selected_format = final_map["naming_type"]
    qbuild_ref = final_map["Qbuild Project Number"]
    client_ref = final_map["Client Reference Number"]
    pr_status = final_map["pr_status"]
    rev_date = final_map["rev_date"]
    rev_name = final_map["rev_desc"]
    date_text = rev_date.ToString("yyyy-MM-dd")
    discipline = final_map["discipline"]

    default_trm_name = name = "_".join([p_numb, discipline.upper(), "TRANSMITTAL"])
    default_others = "_".join([p_numb, discipline.upper(), ""]) 

    if selected_format == "quick print":
        set_name = "_".join([date_text + " " + p_numb, discipline.upper(), "CHECK PRINT"])
    
    elif selected_format == "STP-Residential":
        set_name = " - ".join([date_text + " " + p_numb, discipline.upper(), "ENGINEERING"])
        transm_name = set_name.replace("ENGINEERING", "TRANSMITTAL")
        other_names = set_name.replace("ENGINEERING", "")
    
    elif selected_format == "PYT-Paynters":
        set_name = "_".join([p_numb, pr_status, rev_name, "Combined"])
        transm_name = default_trm_name
        other_names = default_others
    
    elif selected_format == "QBL-Qbuild":
        set_name = "_".join([qbuild_ref, pr_status, rev_name, "Combined"])
        transm_name = default_trm_name
        other_names = default_others
    
    elif "Coles" in selected_format:
        set_name = "_".join([client_ref, rev_name, "Combined"])
        transm_name = default_trm_name
        other_names = default_others 
    
    else:
        set_name = "_".join([p_numb, rev_name, "Combined"])
        transm_name = default_trm_name
        other_names = default_others
    
    return set_name, transm_name, other_names

def naming_sheets(doc, pr_numb, final_map):
    sheets = final_map["rev_sheets"]
    selected_format = final_map["naming_type"]
    qbuild_ref = final_map["Qbuild Project Number"]
    client_ref = final_map["Client Reference Number"]
    pr_status = final_map["pr_status"]
    
    stp_standards = ["STP-Standard", "STP-Residential"]
    names = []
    print_name = ""
    
    for sheet in sheets:
        param = sheet.LookupParameter("Current Revision")
        current_rev = param.AsString()
        sheet_name = sheet.Name
        sheet_number = sheet.SheetNumber
        
        
        if selected_format == "PYT-Paynters":
            print_name = "_".join([client_ref, pr_status, sheet_number, current_rev, sheet_name])
            
        elif selected_format == "QBL-Qbuild":
            print_name = "_".join([qbuild_ref, pr_status, sheet_number, current_rev])
        
        elif selected_format == "Coles and Woolworths":
            print_name = "_".join([client_ref, sheet_number, sheet_name])
        
        else:
            print_name = "_".join([pr_numb, sheet_number, sheet_name + " [" + current_rev + "]"])           
        
        names.append((sheet, print_name))

    return names

def print_combined_pdf_files(doc, file_name, temp_folder, target_folder, sheets, progress):
    opts_pdf = PDFExportOptions() # Export options
    opts_pdf.Combine = True
    opts_pdf.HideUnreferencedViewTags = True 
    sheets_ids = List[type(sheets[0].Id)]()
    temp_printed = []
    
    [sheets_ids.Add(sh.Id) for sh in sheets]  
    opts_pdf.FileName = file_name
    
    with forms.ProgressBar(title = progress[0]) as pb:
        pb.update_progress(progress[1], 100)
        result = doc.Export(temp_folder, sheets_ids, opts_pdf)
    
    
    #print(result, target_folder)
    if result and target_folder != None:
        temp_printed.append((os.path.join(temp_folder, file_name+".pdf"), os.path.join(target_folder, file_name+".pdf")))

    if not result:
        forms.alert(
            "PDF Export Error\n\n"
            "An error occurred while exporting the selected drawing sheets to PDF.\n\n"
            "Please try again.\n\n"
            "If the problem persists, contact the STP Tools developer for further assistance."
        )
        sys.exit()

    return temp_printed 

def print_separated_dwg_files(doc, temp_folder, target_folder, sheets):
    failed_sheets = []
    temp_printed = []
    
    dwg_opts = None
    try:
        dwg_opts = DWGExportOptions.GetPredefinedOptions(doc,"STP REVIT TO CAD LAYER EXPORT")
    except:
        pass
        
    if not dwg_opts:
        try:
            dwg_opts = DWGExportOptions()
        except:
            pass
    
    if not dwg_opts:
        forms.alert("No dwg_opts")
    
    dwg_opts.MergedViews = True
    dwg_opts.FileVersion = ACADVersion.R2018

    delta = float(30) / len(sheets)
    i = 0
    with forms.ProgressBar(title="Exporting DWG files.") as pb:
        for sheet, sheet_name in sheets:
            i += delta
            pb.update_progress(i, 100)
            pb.title = "Exporting DWG file: " + " - " + sheet_name
            
            sheets_ids = List[type(sheet.Id)]()
            sheets_ids.Add(sheet.Id)

            result = doc.Export(
                temp_folder,
                sheet_name,
                sheets_ids,
                dwg_opts
            )

            if result:
                temp_printed.append((
                    os.path.join(temp_folder, sheet_name + ".dwg"),
                    os.path.join(target_folder, sheet_name + ".dwg")
                ))
                
                

            else:
                failed_sheets.append(sheet_name)

        if failed_sheets:
            forms.alert(
                "DWG Export Error\n\n"
                "Some sheets could not be exported to DWG.\n\n"
                "Failed sheets:\n"
                + "\n".join(failed_sheets) +
                "\n\nPlease try again.\n\n"
                "If the problem persists, contact the STP Tools developer for further assistance."
            )
            sys.exit()

    return temp_printed

def print_separated_pdf_files(doc, temp_folder, target_folder, sheets, progress):
    actions = ["Open Folder", "Close"]
    failed_sheets = []
    temp_printed = []

    opts_pdf = PDFExportOptions()
    opts_pdf.Combine = False
    opts_pdf.HideUnreferencedViewTags = True 
    opts_pdf.FileName = "Temp name"
 
    delta = float(35) / len(sheets)
    
    with forms.ProgressBar(title="Exporting PDF single files.") as pb:    
        for sheet, sheet_name in sheets:
            progress += delta
            pb.update_progress(progress, 100)
            pb.title = "Exporting PDF single file: " + " - " + sheet_name
            
            sheets_ids = List[type(sheet.Id)]()
            sheets_ids.Add(sheet.Id)

            result = doc.Export(temp_folder, sheets_ids, opts_pdf)
            
            if result:
                temp_printed.append((os.path.join(temp_folder,"Sheet-" + sheet.Name+".pdf"),os.path.join(target_folder, sheet_name + ".pdf")))
            if not result:
                failed_sheets.append(sheet_name)

        if failed_sheets:
            forms.alert(
                "PDF Export Error\n\n"
                "Some sheets could not be exported to PDF.\n\n"
                "Failed sheets:\n"
                + "\n".join(failed_sheets) +
                "\n\nPlease try again.\n\n"
                "If the problem persists, contact the STP Tools developer for further assistance."
            )
            sys.exit()

    return temp_printed

def sheets_in_sequence(doc, k_map, sheets, all_sheets = False):
    for sheet in sheets:
        rev_ids = sheet.GetAllRevisionIds()

        if rev_ids.Count == 0:
            continue

        sheet_revisions = [
            doc.GetElement(rev_id)
            for rev_id in rev_ids
        ]

        latest_rev = max(
            sheet_revisions,
            key=lambda x: x.SequenceNumber
        )


        latest_seq = latest_rev.SequenceNumber
        if all_sheets:
            k_map["rev_sheets"].append(sheet)
        else:
            if latest_seq == k_map["rev_seq"]:
                k_map["rev_sheets"].append(sheet)

def sheets_by_seq(doc, seq_rev, sheets):
    sheets_in_seq = []
    
    for sheet in sheets:
        rev_ids = sheet.GetAllRevisionIds()

        if rev_ids.Count == 0:
            continue

        sheet_revisions = [
            doc.GetElement(rev_id)
            for rev_id in rev_ids
        ]
        
        for rev in sheet_revisions:
            if rev.SequenceNumber == seq_rev:
                sheets_in_seq.append(sheet)
    
    return sheets_in_seq

def revit_date_to_datetime(date_text):#Return date from dd.mm.yy string format to revit object date only if it has that specific format.
    try:
        return DateTime.ParseExact(
            date_text,
            "dd.MM.yy",
            CultureInfo.InvariantCulture
        )
    except:
        return None

def read_local_settings(file_path, settings):
    lines = None
    if os.path.exists(file_path):
        with open(file_path, "r") as f:
            for line in f:
                line = line.strip()
                
                if not line or "=" not in line:
                    continue
                
                key, value = line.split("=", 1)
                settings[key.strip()] = value.strip()

def remove_folder(folder_path):
    if not os.path.exists(folder_path):
        return True

    def onerror(func, path, exc_info):
        try:
            os.chmod(path, stat.S_IWRITE)
            func(path)
        except Exception:
            pass

    try:
        shutil.rmtree(folder_path, onerror=onerror)
        Threading.Thread.CurrentThread.Join(500)

        if os.path.exists(folder_path):
            os.rmdir(folder_path)

        return True

    except Exception as ex:
        return False
        
#-------------------------------------------------------------------------------
#------TRANSMITTAL FUNCTIONS ---------------------------------------------------
#-------------------------------------------------------------------------------
"Client Reference Number"

def review_transmittal_info(qa_info_list, selected_disc, pr_numb, pr_path):
    disc_map = {
        "Civil": "Civil",
        "Electrical": "Elec",
        "Fire": "Fire",
        "Hydraulic": "Hyd",
        "Mechanical": "Mech",
        "Structural": "Struct"
    }

    error_transmittal = None

    file_name = (
        pr_numb + " - " +
        selected_disc + " - Transmittal.xlsx"
    )

    file_path = os.path.join(
        pr_path,
        "Drawings",
        "Issued Drawings",
        disc_map[selected_disc],
        file_name
    )

    if not os.path.exists(file_path):
        return "Go"

    qa_name = qa_info_list[1]
    qa_client = qa_info_list[2]
    last_user = qa_info_list[-3]

    qa_address = (
        qa_info_list[3] + ", " +
        qa_info_list[4] + ", QLD, " +
        str(qa_info_list[5]).replace(".0","")
    )
    
    excel = None
    workbooks = None
    workbook = None
    sheets = None
    sheet = None
    cells = None
    cell = None

    try:
        excel_type = Type.GetTypeFromProgID("Excel.Application")

        if excel_type is None:
            raise Exception("Excel COM ProgID not found")

        excel = Activator.CreateInstance(excel_type)
        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)
        workbooks = com_get(excel, "Workbooks")

        workbook = None
        try:
            workbook = com_call(
                workbooks,
                "Open",
                file_path
            )

            sheets = com_get(
                workbook,
                "Worksheets"
            )

            sheet = com_get(
                sheets,
                "Item",
                "Transmittal"
            )

            cells = com_get(
                sheet,
                "Cells"
            )
            
            trm_name = cell_get(sheet, 3, 4)
            trm_address = cell_get(sheet, 4, 4)
            trm_client = cell_get(sheet, 5, 4)
            
            not_matching = ""
            if trm_name != qa_name:
                not_matching += "Project Name\nCurrent Transmittal Name: " + trm_name + "\n"
                not_matching += "QA Check  List  File Name: " + qa_name + "\n\n"
                
            if trm_address != qa_address:
                not_matching += "Project Address\nCurrent Transmittal Address: " + trm_address + "\n"
                not_matching += "QA Check  List  File Address: " + qa_address + "\n\n"
            
            if trm_client != qa_client:
                not_matching += "Project Name\nCurrent Transmittal Client: " + trm_client + "\n"
                not_matching += "QA Check  List  File Client: " + qa_client + "\n\n"
                        

            if not_matching:
                msg = ("The following Information in " + file_name + 
                        " file doesn't match its QA Excel file last edited by: {}.\n\n".format(last_user) + 
                        not_matching + "\n\n" + 
                        "What do you want to do?"
                        )
                        
                action = forms.alert(
                    msg, 
                    options = [
                        "Update Transmittal using latest QA Information", 
                        "Ignore Unmatching Information and Continue", 
                        "Cancel Publishing Issue and Transmittal"
                    ]
                )
                
                if "Cancel" in action:
                    return action
                
                if "Update" in action:
                    dist_row = find_target_row(sheet, "Distribution") + 1
                    # row, column, value
                    cell_values = [
                        (3, 4, qa_name),       # D3
                        (4, 4, qa_address),    # D4
                        (5, 4, qa_client)      # D5
                    ]
            
                    for row, column, value in cell_values:
                        cell = com_get(
                            cells,
                            "Item",
                            row,
                            column
                        )

                        com_set(
                            cell,
                            "Value2",
                            value
                        )

                    com_call(
                        workbook,
                        "Save"
                    )

        except Exception as e:
            #print(str(e))
            forms.alert("STP Tools found a problem when reading: " + os.path.basename(file_path) + "\n\n" +
                "Please close the Excel transmittal file if opened, or ensure it is not running in the background.\n\n" + 
                "If the problem persists, please contact STP Tool developer")
            return "Cancel"
        
        finally:
            if workbook:
                com_call(
                    workbook,
                    "Close",
                    False
                )

            workbook = None
            sheet = None
            sheets = None
            cells = None
            cell = None

    finally:
        if excel:
            com_call(
                excel,
                "Quit"
            )

        excel = None
        workbooks = None
        
    return "Go"

def create_transmittal(doc, pr_info, rev_maps, drawings, options):
    excel = None
    workbook = None
    workbooks = None
    sheets = None
    sheet = None
    cells = None
    unicode = uuid.uuid4().int % 900 + 100
    transm_type = options["type"]
    
    excel_type = Type.GetTypeFromProgID("Excel.Application")
    if excel_type is None:
        raise Exception("Excel COM ProgID not found")

    excel = Activator.CreateInstance(excel_type)
    com_set(excel, "Visible", False)
    com_set(excel, "DisplayAlerts", False)

    workbooks = com_get(excel, "Workbooks")
    workbook = com_call(workbooks, "Open", options["path"])

    sheets = com_get(workbook, "Worksheets")
    sheet = com_get(sheets, "Item", "Transmittal")
    cells = com_get(sheet, "Cells") 
    
    # Base indicators (change if transmittal page layout changes)
    top_cell = 13 # Drawing List, this is the latest fixed row
    current_rev_col = 6 # Current revision formula in E column
    date_row = 9
    revs_row = 10
    dist_row = find_target_row(sheet, "Distribution") + 1
    seq_code = str(pr_info["Building Name"]).replace(".0","")
    
    rev_col = current_rev_col + 1
    # Fill project Information
    full_address = pr_info["Project Address"]
    post_code = pr_info["Postcode"].replace(".0","")
    if not pr_info["Suburb"] == "N/F":
        full_address += ", " + pr_info["Suburb"] + ", QLD, " + post_code
    cell_set(cells, 3, 4, pr_info["Project Name"])
    cell_set(cells, 5, 4, pr_info["Client Name"])
    cell_set(cells, 4, 4, full_address)
    cell_set(cells, 8, 1, "Project No. :         " + pr_info["Project Number"])   
    
    try:
        total = len(rev_maps)
        with forms.ProgressBar(title = "Updating transmittal") as pb:
            for num in range(len(rev_maps)):
                pb.title = "Updating Sequence #" + str(num) + " / " + str(total-1)
                pb.update_progress(num, total)
                for rev_name, data in rev_maps.items():
                    rev_seq = data["rev_seq"]
                    if rev_seq == num:

                        cell_set(cells, 9, rev_col, data["rev_date"])
                        cell_set(cells, 7, rev_col, data["rev_desc"])
                        cell_set(cells, 6, rev_col, str(rev_seq).strip().replace(".0","") + seq_code)
                        
                        rev_sheets = sheets_by_seq(doc, data["rev_seq"], drawings)
                        rev_numbers = []
                        for shhhh in rev_sheets:
                            rev_numbers.append(shhhh.SheetNumber)
                        
                        for sh in rev_sheets:
                            rev_row, exists = find_or_insert_sheet_row(top_cell, sheet, sh.SheetNumber)

                            if not exists:
                                if not cell_get(sheet, rev_row, 1) in [None, ""] or cell_get(sheet, rev_row + 2, 1) == "Distribution":
                                    com_call(com_get(sheet, "Rows", rev_row), "Insert")
                                    
                                    # If inserting at the top of the sheet list,
                                    # copy formatting from the row below.
                                    if rev_row == 13:
                                        source_row = com_get(sheet, "Rows", rev_row + 1)
                                        target_row = com_get(sheet, "Rows", rev_row)

                                        com_call(source_row, "Copy")
                                        com_call(target_row, "PasteSpecial", -4122)  # xlPasteFormats
                                    
                                    merge_range = com_get(sheet, "Range",
                                        cell_obj(sheet, rev_row, 2),
                                        cell_obj(sheet, rev_row, 5))

                                    com_call(merge_range, "Merge")
                                    com_set(merge_range, "HorizontalAlignment", -4131)
                                    
                                    # Copy formula from row below, but adapt it to the new row
                                    source_cell = cell_obj(sheet, rev_row + 1, 6)  # F row below
                                    target_cell = cell_obj(sheet, rev_row, 6)      # F new row

                                    formula_r1c1 = com_get(source_cell, "FormulaR1C1")
                                    com_set(target_cell, "FormulaR1C1", formula_r1c1)
                                    errors = com_get(target_cell, "Errors")
                                    err = com_get(errors, "Item", 4)
                                    com_set(err, "Ignore", True)                        
                                
                            
                            cell_set(cells, rev_row, 1, sh.SheetNumber)
                            cell_set(cells, rev_row, 2, sh.Name)
                            this_rev = sh.GetRevisionNumberOnSheet(data["rev_item"].Id)
                            cell_set(cells, rev_row, rev_col, this_rev)

                            if transm_type == "Combined Type" and rev_col > 7:
                                reng = top_cell
                                cell_numb = "start"
                                
                                while cell_numb not in [None, ""]:
                                    cell_numb = cell_get(sheet, reng, 1)

                                    if cell_numb != sh.SheetNumber:
                                        if cell_numb not in rev_numbers:
                                            cell_set(cells, reng, rev_col, cell_get(sheet, reng, rev_col - 1))

                                    reng += 1
                        rev_col += 1
                        break
            
    except:
        raise
        com_call(workbook, "Close", False)
        com_call(excel, "Quit")
        
        cells = None
        sheet = None
        sheets = None
        workbook = None
        workbooks = None
        excel = None

    try:
        if workbook:
            com_call(workbook, "Close", True)
    except:
        pass 
    
    try:
        if excel:
            com_call(excel, "Quit")
    except:
        pass

    cells = None
    sheet = None
    sheets = None
    workbook = None
    workbooks = None
    excel = None  

def update_transmittal(pr_info, qa_info, k_map, temp_folder, target_folder, trm_path, fix_map = {}):
    excel = None
    workbook = None
    workbooks = None
    sheets = None
    sheet = None
    cells = None
    local_report = ""
    failed_sheets = []
    temp_printed = []
    trm_sheets = k_map["rev_sheets"]
    seq_code = str(k_map["seq_code"]).replace(".0","")
    unicode = uuid.uuid4().int % 900 + 100

    if os.path.exists(trm_path):
        
        # Verify if excel is not running in background.
        try:
            f = open(trm_path, "a")
            f.close()
        except:
            forms.alert(
                "STP Tools found a problem while reading the QA Excel file.\n\n"
                "This usually happens when the file is open or Excel is still running in the background.\n\n"
                "Please close all Excel windows (including background processes directly from 'Task Manager') and try again.\n\n"
                "If the issue continues, contact the STP Tools developer.",
                title="Error Reading QA File"
            )
            sys.exit()    
    
        excel_type = Type.GetTypeFromProgID("Excel.Application")
        if excel_type is None:
            raise Exception("Excel COM ProgID not found")
    
        excel = Activator.CreateInstance(excel_type)
        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)

        workbooks = com_get(excel, "Workbooks")
        workbook = com_call(workbooks, "Open", trm_path)

        sheets = com_get(workbook, "Worksheets")
        sheet = com_get(sheets, "Item", "Transmittal")
        cells = com_get(sheet, "Cells")    
    
        # Base indicators (change if transmittal page layout changes)
        top_cell = 13 # Drawing List, this is the latest fixed row
        current_rev_col = 6 # Current revision formula in E column
        date_row = 9
        revs_row = 10
        dist_row = find_target_row(sheet, "Distribution") + 1
        
        # Check if it's new transmittal
        if cell_get(sheet, top_cell, 1) in [None, ""]:
            rev_col = current_rev_col + 1
            # Fill project Information
            full_address = pr_info["Project Address"]
            if not pr_info["Suburb"] == "N/F":
                full_address += ", " + pr_info["Suburb"] + ", QLD, " + pr_info["Postcode"]
            cell_set(cells, 3, 4, pr_info["Project Name"])
            cell_set(cells, 5, 4, pr_info["Client Name"])
            cell_set(cells, 4, 4, full_address)
            cell_set(cells, 8, 1, "Project No. :         " + pr_info["Project Number"])
            
        else:
            # Find existing issue excel column
            rev_col = find_rev_col(7, sheet, seq_code)
            
            # Clean all cells belonging to that revision
            clean_line = top_cell
            while cell_get(sheet, clean_line, 1):
                cell_set(cells, clean_line, rev_col, "")
                clean_line += 1
                
            # Fix transmittal if required
            if fix_map:
                new_address = ""
                keys = ["Project Address", "Suburb", "State", "Postcode"]
                change_address = False
                for key in keys:
                    if key == "State":
                        new_address += "QLD"
                    elif key in fix_map:
                        new_address += fix_map[key][0]
                        change_address = True
                    else:
                        new_address += qa_info[key]
                    
                    if key != "Postcode":
                        new_address += ", "
            
                if "Project Name" in fix_map:
                    cell_set(cells, 3, 4, fix_map["Project Name"])
                if change_address:
                    cell_set(cells, 4, 4, new_address)
                if "Client Name" in fix_map:
                    cell_set(cells, 5, 4, fix_map["Client Name"])
        
        
        # Update distribution list:

        for dist_name in k_map["dist_list"]:
            x = dist_row
            found = False
            
            while cell_get(sheet, x, 1):
                if cell_get(sheet, x, 1) == dist_name:
                    found = True
                    break
                x += 1
            
            if not found:
                if x > dist_row + 1:
                    new_row = dist_row + 1
                    com_call(com_get(sheet, "Rows", new_row), "Insert")
                    merge_range = com_get(sheet, "Range",
                        cell_obj(sheet, new_row, 1),
                        cell_obj(sheet, new_row, 6))

                    com_call(merge_range, "Merge")
                    com_set(merge_range, "HorizontalAlignment", -4131)                    
                    cell_set(cells, new_row, 1, dist_name)
                
                else:
                    cell_set(cells, x, 1, dist_name)       
        
        
        # Purge unused revision columns (if there is no revision date, clean 6 and 7 rows to prevent from errors)
        for clean_col in range(18):
            if not cell_get(sheet, 9, clean_col + 7):
                cell_set(cells, 6, clean_col + 7, "")
                cell_set(cells, 7, clean_col + 7, "")        
        
        if rev_col:
            cell_set(cells, 9, rev_col, k_map["rev_date"])
            cell_set(cells, 7, rev_col, k_map["rev_name"])
            cell_set(cells, 6, rev_col, seq_code)
            
            # Fill sheets and revisions
            for sh in trm_sheets:
                if isinstance(sh, ViewSheet):
                    sheet_number, sheet_name = [sh.SheetNumber, sh.Name]
                else:
                    sheet_number, sheet_name = sh.split(" - ", 1)
                
                # Check if drawing exists and get its row line
                rev_row, exists = find_or_insert_sheet_row(top_cell, sheet, sheet_number)

                if not exists:
                    if not cell_get(sheet, rev_row, 1) in [None, ""] or cell_get(sheet, rev_row + 2, 1) == "Distribution":
                        com_call(com_get(sheet, "Rows", rev_row), "Insert")
                        
                        # If inserting at the top of the sheet list,
                        # copy formatting from the row below.
                        if rev_row == 13:
                            source_row = com_get(sheet, "Rows", rev_row + 1)
                            target_row = com_get(sheet, "Rows", rev_row)

                            com_call(source_row, "Copy")
                            com_call(target_row, "PasteSpecial", -4122)  # xlPasteFormats
                        
                        merge_range = com_get(sheet, "Range",
                            cell_obj(sheet, rev_row, 2),
                            cell_obj(sheet, rev_row, 5))

                        com_call(merge_range, "Merge")
                        com_set(merge_range, "HorizontalAlignment", -4131)
                        
                        # Copy formula from row below, but adapt it to the new row
                        source_cell = cell_obj(sheet, rev_row + 1, 6)  # F row below
                        target_cell = cell_obj(sheet, rev_row, 6)      # F new row

                        formula_r1c1 = com_get(source_cell, "FormulaR1C1")
                        com_set(target_cell, "FormulaR1C1", formula_r1c1)
                        errors = com_get(target_cell, "Errors")
                        err = com_get(errors, "Item", 4)
                        com_set(err, "Ignore", True)                        
                                   
                cell_set(cells, rev_row, 1, sheet_number)
                cell_set(cells, rev_row, 2, sheet_name)

                # Adjust row height
                lines = max(1, int(math.ceil(len(sheet_name) / 45.0)))
                adjusted_height = 15 * lines
                row = com_get(sheet, "Rows", rev_row)

                com_set(row, "RowHeight", adjusted_height)
                
                if isinstance(sh, ViewSheet):
                    param = sh.LookupParameter("Current Revision")
                    if param:
                        show_rev = param.AsString()
                    else:
                        show_rev = "N/A"
                    cell_set(cells, rev_row, rev_col, show_rev)
                else:
                    if rev_col == current_rev_col + 1:
                        fake_rev = "1"
                    elif not exists:
                        fake_rev = "1"
                    else:
                        fake_rev = int(cell_get(sheet, rev_row, current_rev_col))
                        if fake_rev < 1:
                            fake_rev = "1"
                        else:
                            fake_rev = str(fake_rev + 1).replace(".0", "")
                            

                    cell_set(cells, rev_row, rev_col, fake_rev)

            
            #Clean up sheets not used (if the current rev column is empty
            #============================================================
            clean_line = top_cell
            while cell_get(sheet, clean_line, 1):
                value = cell_get(sheet, clean_line, 6)
                if not value or str(value).strip() == "":
                    row = com_get(sheet, "Rows", clean_line)
                    com_call(row, "Delete")
                else:
                    clean_line += 1
             
            # Fill distribution list:
            #============================================================
            dist_row = find_target_row(sheet, "Distribution") + 1
            x = dist_row
            while cell_get(sheet, x, 1):
                num_copies = k_map["num_copies"] if cell_get(sheet, x, 1) in k_map["dist_list"] else ""
                cell_set(cells, x, rev_col, num_copies)
                x += 1

            # Find final rows for Transmittal PDF format
            #============================================================
            form_row = find_target_row(sheet, "Format") + 1  
            cell_set(cells, form_row, rev_col, k_map["formats"])
            cell_set(cells, form_row + 2, rev_col, k_map["purpose"])
            cell_set(cells, form_row + 5, rev_col, k_map["method"])
       
            # Set printing area and layout
            #============================================================
            last_row = find_target_row(sheet, "Method") + 1
            printable_height = 745
            tot_height = 0
            for reng in range(1, last_row + 1):
                row = com_get(sheet, "Rows", reng)
                if reng > 12 and cell_get(sheet, reng, 1) in ["", None]:
                    com_set(row, "RowHeight", 15)
                    tot_height += 15
                else:
                    row_height = com_get(row, "RowHeight")
                    tot_height += row_height
                
            h_to_fix = tot_height - printable_height
            if h_to_fix < -15:
                #print("control", h_to_fix)
                lines_to_add = int(math.ceil(-h_to_fix / 15.0))
                target_row = dist_row - 3
                insert_new_drawing_lines(sheet, lines_to_add, target_row)
                
            
            elif h_to_fix > 0:
                lines_to_remove = int(math.ceil(h_to_fix / 15.0))
                #print("lines to remove", lines_to_remove)

                target_row = int(dist_row - 3 - lines_to_remove)
                if cell_get(sheet, target_row, 1) in ["", None]:
                    end_row = (target_row + lines_to_remove - 1)
                    #print(target_row, end_row)
                    row_range = com_get(
                        sheet, "Rows",
                        "{}:{}".format(target_row, end_row)
                    )

                    com_call(row_range, "Delete")
                else:
                    foot_lines = reng - dist_row + 2
                    foot_height = 15 * foot_lines
                    if tot_height - foot_height < printable_height:
                        #print("control")
                        lines_to_add = foot_lines - lines_to_remove + 1
                        target_row = dist_row - 3
                        insert_new_drawing_lines(sheet, lines_to_add, target_row)

            last_row = find_target_row(sheet, "Method") + 1
            print_area = "$A$1:$U${}".format(last_row)

            page_setup = com_get(sheet, "PageSetup")
            com_set(page_setup, "PrintArea", print_area)

            com_set(page_setup, "FitToPagesWide", 1)
            com_set(page_setup, "FitToPagesTall", False)
            com_set(page_setup, "Zoom", False)
            com_set(page_setup, "CenterVertically", False)
            com_set(page_setup, "CenterHorizontally", True)

        # Export PDF File
        pdf_name = k_map["trm_name"] + ".pdf"
        temp_path = os.path.join(temp_folder, pdf_name)
        target_path = os.path.join(target_folder, pdf_name)
        current_transm_folder = os.path.dirname(target_folder)
        current_transm_path = os.path.join(current_transm_folder, pdf_name)

        seq_id = "rev_seq_" + seq_code
        result = export_excel_sheet_to_pdf(workbook, sheet, temp_path, seq_id)
        if result: #result contains the path of the second transmittal that should go in the main folder
            temp_printed.append((temp_path, target_path))
            if k_map.get("naming_type") != "STP-Residential":
                temp_printed.append((result, current_transm_path))
                
            com_call(workbook, "Save")
  
        else:
            failed_sheets.append(pdf_name)            

        if failed_sheets:
            forms.alert(
                "Transmittal Export Error\n\n"
                "Failed PDF:\n"
                + "\n".join(failed_sheets) +
                "\n\nPlease try again.\n\n"
                "If the problem persists, contact the STP Tools developer for further assistance."
            )
            sys.exit()
        try:
            if workbook:
                com_call(workbook, "Close", False)
        except:
            pass 
        
        try:
            if excel:
                com_call(excel, "Quit")
        except:
            pass

        cells = None
        sheet = None
        sheets = None
        workbook = None
        workbooks = None
        excel = None

    return temp_printed

def net_array(*args):
    return Array[Object](list(args))

def com_get(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.GetProperty,
        None,
        obj,
        net_array(*args) if args else None
    )

def com_set(obj, name, value):
    obj.GetType().InvokeMember(
        name,
        BindingFlags.SetProperty,
        None,
        obj,
        net_array(value)
    )

def com_call(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.InvokeMethod,
        None,
        obj,
        net_array(*args) if args else None
    )

def cell_get(sheet, row, col):
    cells = com_get(sheet, "Cells")
    cell = com_get(cells, "Item", row, col)
    return com_get(cell, "Value2")

def cell_obj(sheet, row, col):
    cells = com_get(sheet, "Cells")
    return com_get(cells, "Item", row, col)

def cell_set(cells, row, col, value):
    cell = com_get(cells, "Item", row, col)
    com_set(cell, "Value2", value)

def insert_row(sheet, row):
    rows = com_get(sheet, "Rows")
    target_row = com_get(rows, "Item", row)
    com_call(target_row, "Insert")

def copy_formula(cells, from_row, to_row, col):
    source_cell = com_get(cells, "Item", from_row, col)
    target_cell = com_get(cells, "Item", to_row, col)

    com_call(source_cell, "Copy")
    com_call(target_cell, "PasteSpecial", -4123)  # xlPasteFormulas

def merge_and_left_align(sheet, row, start_col, end_col):
    cells = com_get(sheet, "Cells")

    start_cell = com_get(cells, "Item", row, start_col)
    end_cell = com_get(cells, "Item", row, end_col)

    rng = com_get(
        sheet,
        "Range",
        start_cell,
        end_cell
    )

    # Merge cells
    com_set(rng, "MergeCells", True)

    # Left align
    com_set(rng, "HorizontalAlignment", -4131)  # xlLeft

def export_excel_sheet_to_pdf(workbook, sheet, pdf_path, metadata):
    properties = com_get(workbook, "BuiltinDocumentProperties")
    keywords = com_get(properties, "Item", "Keywords")

    com_set(keywords, "Value", metadata)

    com_call(
        sheet,
        "ExportAsFixedFormat",
        0,
        pdf_path,
        0,              # Standard quality
        True,           # IncludeDocProperties
        False
    )

    for i in range(20):      # wait up to 2 seconds
        if os.path.exists(pdf_path):
            new_path = pdf_path.replace(".pdf","_c.pdf")
            shutil.copy2(pdf_path, new_path)
            return new_path
        Threading.Thread.CurrentThread.Join(100)
        
    return False

def find_target_row(sheet, target_text):
    for x in range(1, 200):
        if target_text in str(cell_get(sheet, x, 1)):
            return x

    return None

def find_distrib_name(i_row, sheet, dist_name):
    x = i_row
    while True:
        cell_content = str(cell_get(sheet, distrib_row + x, 1))
        if cell_content == dist_name:
            return x
        if cell_content == "":
            return None
        
        x += 1

def find_rev_col(j_col, sheet, seq_code):
    y = j_col
    while True:
        raw_value = cell_get(sheet, 6, y)
        if raw_value is None or str(raw_value).strip() == "":
            return y

        issue_seq = str(raw_value).strip().replace(".0", "")
        if issue_seq == str(seq_code):
            return y

        y += 1

def find_or_insert_sheet_row(top_cell, sheet, sh_numb):
    new_key = sheet_sort_key(sh_numb)

    x = top_cell

    while True:
        cell_content = cell_get(sheet, x, 1)

        if cell_content is None or str(cell_content).strip() == "":
            return x, False   # insert at the end

        cell_text = str(cell_content).strip()

        if cell_text == sh_numb:
            return x, True    # already exists

        existing_key = sheet_sort_key(cell_text)

        if new_key < existing_key:
            return x, False   # insert before this row

        x += 1

def sheet_sort_key(sheet_number):
    parts = re.findall(r'\d+|[A-Za-z]+', sheet_number)

    key = []
    for part in parts:
        if part.isdigit():
            key.append(int(part))
        else:
            key.append(part.upper())

    return key

def text_to_datepicker_date(text):
    try:
        return DateTime.ParseExact(
            text,
            "dd.MM.yy",
            None
        )
    except:
        return None
    
def update_row_values(control, offset=1):
    for key in control:
        control[key] += offset

#def ():
    #local_report = ""
    #Out_Data = []

#local_report += u"\u2705 Stage: " + stage + ":  \n"
#local_report += u"\u26A0 Stage: " + stage + ":  \n"
#local_report += u"\U0001F4CC Stage:" + stage + ":  /n"

#except Exception as e:
    #local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
    #local_report += traceback.format_exc()

#    return continue_task, local_report, Out_Data
