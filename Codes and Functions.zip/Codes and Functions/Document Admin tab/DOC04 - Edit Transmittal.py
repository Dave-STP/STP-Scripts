#--------------------------------------------------------------------
#------------ DOC04 - Edit Transmittal.py ------------------------------
#--------------------------------------------------------------------


import sys
import os
import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

print("Tool in process")
sys.exit()


##---Constants brought from main script
Lib_Path = revit_library_path
bin_folder
local_mode = local_version
xaml_forms
##-------------------------------------

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
temp_folder = os.path.join(bin_folder, "Temp_drawings")
print_settings = {}
extra_data = {
        # Read params
        "ini_type": "",
        "qa_revit_version": "",
        "first_user": "",
        "tb_history": [],
        # Write params
        "p_type": "",
        "initials": ""
    }

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

tab_function_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(tab_function_path)
import STP_DOC_Functions
from STP_DOC_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import IssuePrintForm

#--------------------------------------------------------------------
#----------- GET PRELIMINARY INFO -----------------------------------
#--------------------------------------------------------------------

Info_Data = get_project_info(doc)
project_Info = {
    "Number": Info_Data[0],
    "Name": Info_Data[1],
    "Address": Info_Data[2],
    "Suburb": Info_Data[3],
    "P_code": Info_Data[4],
    "Client": Info_Data[5]
}

# Get formats for combo box
formats_path = os.path.join(Lib_Path, "Data Base","List_Print Naming.txt")
formats = []
with open(formats_path, "r") as f:
    for line in f:
        #line = line.strip()
        formats.append(line.strip())
        #key, value = line.split("#", 1)
        #if key not in formats:
        #    formats.append(key)


# Check project info is complete:
msg = ""
empty_values = [None, '', "EXAMPLE", "TEST", "SUBURB", "CLIENT NAME", "SAMPLE", "McDONALDS -",
                "STP20-", "STP21-", "STP22-", "STP20-", "STP23-", "STP24-", "STP25-", "STP26-"]
purpose_items = ["Preliminary", "Approval", "Tender", "Construction", "Council Sumbmission"]

for param, val in project_Info.items():
    if val in empty_values or "XXXX" in val or "?" in val:
        msg += (param + ": " + str(val) + "\n")
        

if msg:
    forms.alert("Please Check the following Project Information Parameters before continuing.\n\n" + msg)
    sys.exit()


project_params = doc.ProjectInformation
params = ["Client Reference Number", "Project Status", "Client Name"]


for param in params:
    par = project_params.LookupParameter(param)
    if par:
        project_Info[param] = par.AsString()


#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------

Info_Data = get_project_info(doc)
if Info_Data:
    p_Numb = Info_Data[0]
    match = re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE)
    
if not p_Numb:
    sys.exit()
if not match:
    forms.alert(
        "Project Number for this file doesn't match 'STPYY-0000' standard code",
        exitscript = True
    )

projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
p_numb_found = False
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)


p_Numb, code_name, p_Path = selected_project
p_Name = code_name.replace(" - Documents", "").upper().replace("MCDON","McDON")


#--------------------------------------------------------------------
#----------- READ QA FILE -------------------------------------------
#--------------------------------------------------------------------
qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb, extra_data)

if qa_info_exists:
    info_list = read_qa_excel_file_V2(qa_path, extra_data)
    
    if info_list and extra_data:
        (reng, p_Name, p_Client, p_Address, p_Suburb, p_Pcode, tb_Name,
         tb_Type, tb_Side, tb_Size, last_user) = info_list[0:11]
        tb_target_path = os.path.join(p_Path,"Drawings","xref",tb_Name)
    
    if extra_data["ini_type"] == "[PG]" and p_Suburb == "N/A":
        mssg = "The QA Check List for this project is not compatible with new STP Tools QA Format.\n\n" + \
               "Please execute edit Project parameters to update a compatible Project Address Format"
        forms.alert(mssg)
        sys.exit()

else:
    forms.alert("QA file has not been created for this job yet.", exitscript = True)


#--------------------------------------------------------------------
#----------- GET DRAWING SHEET COLLECTORS ---------------------------
#--------------------------------------------------------------------

# Collect printable sheets
# Collect printable sheets
all_sheets = collect_all_drawings(doc)

# Filter only printable sheets.
printable_sheets = []
form15_sheets = []

for sheet in all_sheets:
    if "FORM 15" in sheet.Name.upper() or "FORM15" in sheet.Name.upper():
        form15_sheets.append(sheet)
    elif not "TRANSMITTAL" in sheet.Name.upper() and not "3D Export" in sheet.Name:
        printable_sheets.append(sheet)


# Collect current revision sequences and store them in their respective key map
rev_and_sets = get_revisions_and_sets(doc, printable_sheets)
rev_maps, rev_list, set_maps, set_list = rev_and_sets
trm_source = os.path.join(Lib_Path, "Data Base", "STPXX-xxxx General Transmittal.xlsx")
trm_temporal = os.path.join(temp_folder, "temp_transmittal.xlsx")


if p_Path:
    for num in range(len(rev_maps)):
        for key, rev in rev_maps.items():
            if rev["rev_seq"] == num:
 


    
  


        













#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "Edit Transm",
    "items": 1
}
track_data(Lib_Path, data, "AAAA")