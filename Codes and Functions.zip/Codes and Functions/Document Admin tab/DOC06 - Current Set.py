import os
import shutil
from datetime import datetime
from collections import defaultdict
from pyrevit import script
from pyrevit import forms
from pyrevit import revit, DB
from Autodesk.Revit.DB import *
import sys
import re
import unicodedata

doc = revit.doc
#------start time
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

final_report = ""
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()
#-----get Discipline--------#
cloud_path = doc.PathName

if cloud_path:
    fileName = os.path.splitext(os.path.basename(cloud_path))[0]
    discipline_map = {
        'S':'Struct',
        'E': 'Elec',
        'C':'Civil',
        'H':'Hydr',
        'F':'Fire',
        'M':'Mech'
    }
    Discipline = discipline_map.get(fileName[11].upper())

if not cloud_path or Discipline is None:
    selected_discipline = select_discipline()
    Discipline = selected_discipline[1]

if not Discipline:
    script.exit("Discipline not found. check your Revit Model Name :)")

#---------FUNCTIONS----------------#

def get_project_name_and_folder_path(project_number):  
    result = get_project_folders_from_onedrive(user_name, Lib_Path)
    project_list = result

    selected_project = None
    for project in project_list:
        if project[0] == project_number:
            selected_project = project

    if selected_project:
        p_name = selected_project[1]
        p_path = selected_project[2]
    else:
        forms.alert("No projects found", exitscript = True)

    return p_name, p_path

def version_key_stp(version):
    v = version.upper()
    if v.isalpha():
        # Convert letter to order number (A=1, B=2, ..., Z=26)
        return (0, ord(v) - ord('A') + 1)
    else:
        try:
            # numeric version
            return (1, int(v))
        except ValueError:
            # unknown version - put at the end
            return (2, v)
status_order = ["SD", "DD", "CD", "CN","IFC"]

def version_key_qbuild(version):
    version = version.upper() #CDP2
    for status in status_order:
        if version.startswith(status):
            base = status #CD
            suffix = version[len(status):] #CDP1[2]=P2
            break
    else:
        forms.alert("Unexpected version format: {}.".format(version))
        return (len(status_order)+1 , 99 , version)
    if base == "IFC":
        base_index = status_order.index("CN")
    else:
        base_index = status_order.index(base) #2

    if suffix == "" and base in ["CD","CN","IFC"]:
        return (base_index,1,-1) # 2,1,-1
    
    if suffix.startswith("P") and suffix[1:].isdigit():
        return (base_index,0,int(suffix[1:])) # 2,0,1/2/3
    if suffix.isalpha():
        return (base_index,1, ord(suffix)-ord("A")) # 2,1,0/1/2
    return (base_index,2,suffix) # 2,2,P1/A/B/C

def version_key_qbuild_mmc_new(version):
    version = version.upper() #CD1,SD2,CNA,CDB
    for status in status_order:
        if version.startswith(status):
            base = status #CD
            suffix = version[len(status):] #CD1[2]=1,2,3,A,B
            break
    else:
        forms.alert("Unexpected version format: {}.".format(version))
        return (len(status_order)+1 , 99 , version)
        
    base_index = status_order.index(base) #2

    if suffix.isalpha():
        return (base_index,1, ord(suffix)-ord("A")) # 2,1,0/1/2
    elif suffix.isdigit():
        return (base_index,0,suffix) #2,0,0/1/2
    return (base_index,2,suffix) # 2,2,A/B/C

def clean_filename(name):
    # Remove zero-width chars
    name = ''.join(c for c in name if not unicodedata.category(c) in ['Cf'])
    # Remove trailing underscores before extension
    name = re.sub(r'_+(?=\.)', '', name)
    return name
    # then do regex matching on cleaned filename

def extract_match_data(filename, pattern, selected_pattern):
    match = pattern.match(filename)
    if not match:
        return None
    data = {
        'projnum': match.group('projnum').strip(),
        'sheetname':match.group('sheetname').strip(),
    }
    # for patterns with sheetnum
    if 'sheetnum' in match.groupdict():
        data['sheetnum'] = match.group('sheetnum').strip()
    else:
        data['sheetnum'] = ""
    # version depending on pattern
    if selected_pattern == "STP":
        data['version'] = match.group('version').strip()
    elif selected_pattern in ["Qbuild","QBuild MMC Old"]:
        version_suffix = match.group('version')
        if version_suffix:
            data['version'] = match.group('status').strip() + version_suffix.strip()
        else:
            data["version"] = match.group('status').strip()
    elif selected_pattern == "Qbuild MMC New":
        data['version'] = match.group('status').strip() + match.group('version').strip()
    return data


#-------- Get xrev and onedrive paths-----#
XREV_SOURCE_PATH = r"C:\Xrev"
# -------- Get project number from Revit fileName -------- #
project_number = p_Numb
# -------- Get Project Name  -------- #
project_name,project_folder_path = get_project_name_and_folder_path(project_number)
if project_name==None and project_folder_path==None:
    forms.alert("No project name found for number: " + project_number, exitscript=True)

#################################################
# -------- Copy Drawings to Current -------- #
#################################################
pattern_options = [
    "STP",
    "QBuild",
    "QBuild MMC New",
    "QBuild MMC Old"
]

#selected_pattern = forms.CommandSwitchWindow.show(pattern_options,message = 'Select the file name pattern to use.')
selected_pattern = forms.SelectFromList.show(pattern_options,multiselect=False,title="Select file name pattern to use:")
if not selected_pattern:
    script.exit("No Pattern Selected :/")

filename_pattern_STP = re.compile(
    r'(?P<projnum>STP\d{2}-\d{4})_(?P<sheetname>.*?)\s*\[(?P<version>[A-Z0-9]{1})\]\.(pdf|dwg)$',
    re.IGNORECASE
)
filename_pattern_QBuild = re.compile(
    r'(?P<projnum>\d{5})_(?P<status>PD|DD|SD|CD|CN)_(?P<sheetnum>[CEFHMS]\d{2}\.\d{2})_(?P<sheetname>.+?)(_(?P<version>P\d+|[A-Z]))?\.(pdf|dwg)$',
    re.IGNORECASE
)

filename_pattern_QBuild_MMC_New = re.compile(
    r'(?P<projnum>\d{5})_(?:MMC|SITE)_(?P<status>PD|DD|SD|TD|CD|CN)_(?P<sheetnum>[CEFHMS]\d{2}\.\d{2})_(?P<sheetname>.+?)_(?P<version>\d{1}|[A-Z])\.(pdf|dwg)$',
    re.IGNORECASE
)

filename_pattern_QBuild_MMC_Old = re.compile(
    r'(?P<projnum>\d{5})_(?:MMC|SITE)_(?P<status>PD|DD|SD|CD|CN|IFC)_(?P<sheetnum>[CEFHMS]\d{2}\.\d{2})_(?P<sheetname>.+?)(?:_(?P<version>P\d+|[A-Z]))?\.(pdf|dwg)$',
    re.IGNORECASE
)
issued_drawings_dir = os.path.join(project_folder_path, "Drawings", "Issued Drawings", Discipline)
current_drawings_dir = os.path.join(issued_drawings_dir,"Current Set")

if not issued_drawings_dir:
    forms.alert("Folder not found: " + issued_drawings_dir, exitscript=True)

# ---- 
if selected_pattern == "STP":
    pattern = filename_pattern_STP
    key_func = version_key_stp
elif selected_pattern == "QBuild":
    pattern = filename_pattern_QBuild
    key_func = version_key_qbuild
elif selected_pattern == "QBuild MMC New":
    pattern = filename_pattern_QBuild_MMC_New
    key_func = version_key_qbuild_mmc_new
elif selected_pattern == "QBuild MMC Old":
    pattern = filename_pattern_QBuild_MMC_Old
    key_func = version_key_qbuild

#----find the latest drawings based on Version-----#
all_issued_files = []
for root, dirs, files in os.walk(issued_drawings_dir):
    for file in files:
        if file.lower().endswith((".pdf", ".dwg")):
            all_issued_files.append(os.path.join(root, file))

latest_files = {}
unmatched_files = []
for f in all_issued_files:
    filename = os.path.basename(f)
    filename = clean_filename(filename)
    #Skip transmittals:
    if "transmittal" in filename.lower():
        continue
    match_data = extract_match_data(filename,pattern,selected_pattern)
    if not match_data:
        unmatched_files.append(filename)
        continue
    key = (match_data['projnum'], match_data['sheetname'], match_data['sheetnum'] ,os.path.splitext(f)[1].lower())
    version = match_data['version']
# --- Building the latest_files dictionary --- #
    if key in latest_files:
        current = latest_files[key]
        if key_func(version) > key_func(current['version']):
            latest_files[key] = {'path': f, 'version': version}
    else:
        latest_files[key] = {'path': f, 'version': version}

# --- create current set folder --- #
if latest_files and not os.path.exists(current_drawings_dir):
    os.makedirs(current_drawings_dir)
if not latest_files:
    forms.alert("No sheets matched the expected naming convention. Please create the Current Set manually.",title="No matching files",exitscript=True)

# --- Remove older versions in 'Current Set' before copying ---
current_files=[]
#get all files under subfolders too:
for root, dirs, files in os.walk(current_drawings_dir):
    for f in files:
        current_files.append(os.path.join(root, f))

for file_path in current_files:
    file_name=os.path.basename(file_path)

    #skip files are not dwg/pdf
    if not file_name.lower().endswith(('.pdf', '.dwg')):
        continue

    match_data = extract_match_data(file_name,pattern,selected_pattern)

    #skip unmatched naming files
    if match_data is None:
        print("no match: {}".format(file_name))
        continue
    #compare versions
    key=(match_data['projnum'], match_data['sheetname'], match_data['sheetnum'] ,os.path.splitext(file_name)[1].lower())
    if key in latest_files:
        current_version = match_data['version']
        latest_version = latest_files[key]['version']
        #debug:
        #print("file:{}".format(file_name))
        #print("current:{}".format(current_version))
        #print("latest:{}".format(latest_version))
        #print("compare:{}<{}".format(key_func(current_version),key_func(latest_version)))

        if key_func(current_version) < key_func(latest_version):
            # Remove older version
            #print("delete")
            file_to_remove = file_path
            #print("file to remove: {}".format(file_to_remove))
            try:
                os.remove(file_to_remove)
            except Exception as e:
                print("Failed to delete {}: {}".format(file_to_remove, str(e)))

#----debug
#for key , value in latest_files.items():
    #print("Key:",key, "->",value['version'])
    #print("key: {} -> {}".format(key,value['version']))

# --- Copy the latest files --- #
copied_count = 0
for lf in latest_files.values():
    src = lf['path']
    f_name = os.path.basename(src)
    ext = os.path.splitext(f_name)[1].lower()
    subfolder = "PDF" if ext == ".pdf" else "DWG"
    match_data = extract_match_data(f_name,pattern,selected_pattern)

    if not match_data:
        continue # skip
    proj_num = match_data['projnum']

    if selected_pattern in ["QBuild MMC New", "QBuild MMC Old"]:
        project_dir = os.path.join(current_drawings_dir,proj_num)
        subfolder_path = os.path.join(project_dir,subfolder)
        if not os.path.exists(subfolder_path):
            os.makedirs(subfolder_path)
        dst = os.path.join(subfolder_path, f_name)
    else:
        subfolder_path = os.path.join(current_drawings_dir,subfolder)
        if not os.path.exists(subfolder_path):
            os.makedirs(subfolder_path)
        dst = os.path.join(subfolder_path,f_name)

    shutil.copy2(src, dst)
    copied_count += 1

forms.alert("Copied {} latest drawing(s) to:\n{}".format(copied_count, current_drawings_dir), title="Current Drawings Updated")


#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------
if copied_count > 0:
    data = {
        "time": start_time,
        "p_numb": p_Numb,
        "user": user_name,  
        "file": "Current Set ",
        "items": str(copied_count)
    }
    track_data(Lib_Path, data, "DOC06")