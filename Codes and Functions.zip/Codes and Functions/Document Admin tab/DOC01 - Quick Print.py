#--------------------------------------------------------------------
#------------ DOC01 - Print Issue.py --------------------------------
#--------------------------------------------------------------------

import sys
import os
import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

from pyrevit import forms

##---Constants brought from main script
Lib_Path = revit_library_path
xaml_forms
##-------------------------------------

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
today = datetime.today().strftime("%Y-%m-%d")

#Debug bypass
#================================================================
#if user_name != "Rafael":
#    forms.alert("This tool is under revision. Will be back soon")
#    sys.exit()
#================================================================

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import get_project_info, confirm_file_is_not_opened, track_data

tab_function_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(tab_function_path)
import STP_DOC_Functions
from STP_DOC_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import QuickPrintForm

data = {}

#--------------------------------------------------------------------
#----------- GET DRAWING SHEET COLLECTORS ---------------------------
#--------------------------------------------------------------------

# Collect printable sheets
all_sheets = collect_all_drawings(doc)
data["sheets"] = all_sheets

# Collect current revision sequences and store them in their respective key map
data["rev_maps"] = get_revisions_and_sets(doc, all_sheets)


form = QuickPrintForm(xaml_forms["main_form"], data)
form.ShowDialog()

if not form.final_map:
    sys.exit()

#--------------------------------------------------------------------
#----------- PRINT DRAWINGS FOR MARKUPS -----------------------------
#--------------------------------------------------------------------

def error_printing(f_name, numb = ""):
    msg = ("Unknown error {} encountered while saving {}.\n\n".format(numb, f_name) + 
           "Please contact STP Tool developer for further assistance.")

    forms.alert(msg)
    sys.exit()

actions =["Open Folder", "Open File", "Close"]
print_sheets = form.final_map["rev_sheets"]
msg = ""
go_for_tracking = False

target_folder, folder_name = alternative_folder()
pr_number = get_project_info(doc)["Project Number"]
if print_sheets:
    with forms.ProgressBar(title='Exporting PDF Quick CheckPrint...') as pb:
        file_name = today + "_" + pr_number + " - CHECK PRINT"
        file_path = os.path.join(target_folder, file_name + ".pdf")
        pb.update_progress(0.5, 1)
        if os.path.exists(target_folder):
            if os.path.exists(file_path):
                if confirm_file_is_not_opened(file_path):
                    forms.alert(
                        "The PDF file {} is currently open or being used by another process.\n\n".format(file_name) + 
                        "Please close the file and try again."
                    )
                    sys.exit()

                action = forms.alert("The file already exists.\n\nWhat would you like to do?",
                    options = ["Save and Replace", "Save a Copy", "Cancel"])
                
                if "Replace" in action:
                    try:
                        os.remove(file_path)
                    except Exception as e:
                        error_printing(file_name, "#1")
                elif "Copy" in action:
                    file_name += "_copy"
                else:
                    sys.exit()
            
            #try:
            temp_printed_files = print_combined_pdf_files( #Temp folder and target folder change
                doc, file_name, target_folder, 
                None, print_sheets,
                ["Exporting PDF Combined file.", 50]
            )
            result = True #move_files_from_temp(temp_printed_files) No needed for quick print
            #except Exception as e:
            #    error_printing(file_name, "#2")
        else:
            msg += Stage + "Error while finding temporary or target folder"
    
    if result and not msg:
        go_for_tracking = True
        action = forms.alert(
            "All done " + user_name + ". Check print succesfully saved to \n\n" + target_folder,
            options = actions
        )
        
        if action == "Open Folder":
            
            try:
                import subprocess
                subprocess.Popen([
                    "powershell",
                    "-Command",
                    "Start-Process explorer.exe '{}'".format(target_folder)
                ])
            except:
                os.startfile(target_folder)
        
        elif action == "Open File":
            os.startfile(file_path)
        
    else:
        forms.alert("Quick Check Print process failed. Check Error window.\n\n"
                "If the problem persists contact STP tools developer for further assitance")

#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

if go_for_tracking:
    data = {
        "time": start_time,
        "p_numb": pr_number,
        "user": user_name,
        "file": "Quick Print",
        "items": "1"
    }
    track_data(Lib_Path, data, "DOC01")