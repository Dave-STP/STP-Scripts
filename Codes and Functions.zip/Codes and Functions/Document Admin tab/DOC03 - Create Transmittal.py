#--------------------------------------------------------------------
#------------ DOC03 - Create Transmittal.py -------------------------
#--------------------------------------------------------------------

import sys
import os
import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
bin_folder
local_mode = local_version
xaml_forms
default_disc
##-------------------------------------

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
temp_folder = os.path.join(bin_folder, "Temp_drawings")
print_settings = {}
extra_data = {
        # Read params
        "ini_type": "",
        "qa_revit_version": "",
        "first_user": "",
        "tb_history": [],
        # Write params
        "p_type": "",
        "initials": ""
    }

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

tab_function_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(tab_function_path)
import STP_DOC_Functions
from STP_DOC_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import Transm_from_Seq_Form


#--------------------------------------------------------------------
#------ CREATE TRANSMITTAL FROM SEQ. FORM ---------------------------
#--------------------------------------------------------------------

form = Transm_from_Seq_Form(xaml_forms["main_form"], default_disc)
form.show_dialog()

if not form.process_go:
    sys.exit()

transm_options = {
    "discipline": form.discipline,
    "type": form.type_option,
    "folder": form.folder
    }
relocate_files = []

#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
rvt_Data = get_project_info(doc)
if rvt_Data:
    p_Numb = rvt_Data["Project Number"]
    p_Address = rvt_Data["Project Address"]
    if not p_Numb:
        sys.exit()
    
    if not re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE):
        forms.alert(
            "Project Number for this file doesn't match 'STPYY-0000' standard code",
            exitscript = True
        )

    p_Suburb = rvt_Data["Suburb"]
    
projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
p_numb_found = False
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)


p_Numb, code_name, p_Path = selected_project
p_Name = code_name.replace(" - Documents", "").upper().replace("MCDON","McDON")

transm_name = p_Numb + " - " + transm_options["discipline"] + " - Transmittal.xlsx"
transm_folder = os.path.join(p_Path, "Drawings", "Issued Drawings", transm_options["folder"])
transm_path = os.path.join(transm_folder, transm_name)

# Stop if trasnmittal already exists in folder
if os.path.exists(transm_path):
    forms.alert(
        "A transmittal for this discipline already exists in:\n\n"
        + "'Issued Drawings - " + transm_options["folder"] + "'"
        + "\n\nThis tool can only be used to create new transmittals.",
        exitscript=True
    )

#--------------------------------------------------------------------
#----------- READ QA FILE -------------------------------------------
#--------------------------------------------------------------------
qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb)

if qa_info_exists:
    while confirm_file_is_not_opened(qa_path):
        file_name = os.path.basename(qa_path)

        action = forms.alert(
            "The QA Excel file '{}' is currently open or being used by another process.\n\n"
            "Please close the file and select 'Try Again'.\n\n"
            "If the file is not visibly open, Microsoft Excel may still be running in the background. "
            "Open Task Manager, check for any Microsoft Excel processes, and close them before trying again."
            .format(file_name),
            title="QA File In Use",
            options=[
                "Try Again",
                "Cancel"
            ]
        )

        if action != "Try Again":
            sys.exit()
        
    qa_Data = read_qa_excel_file_V2(qa_path)
    
    if qa_Data["pr_type"] == "[PG]" and p_Suburb == "N/A":
        mssg = "The QA Check List for this project is not compatible with new STP Tools QA Format.\n\n" + \
               "Please execute edit Project parameters to update a compatible Project Address Format"
        forms.alert(mssg)
        sys.exit()

else:
    forms.alert("QA file has not been created for this job yet.", exitscript = True)

#--------------------------------------------------------------------
#----------- GET DRAWING SHEET COLLECTORS ---------------------------
#--------------------------------------------------------------------

all_sheets = collect_all_drawings(doc)

# Filter only printable sheets.
printable_sheets = []
form15_sheets = []

for sheet in all_sheets:
    if "FORM 15" in sheet.Name.upper() or "FORM15" in sheet.Name.upper():
        form15_sheets.append(sheet)
    elif not "TRANSMITTAL" in sheet.Name.upper() and not "3D Export" in sheet.Name:
        printable_sheets.append(sheet)

# Collect current revision sequences and store them in their respective key map
rev_and_sets = get_revisions_and_sets(doc, printable_sheets)
rev_maps = rev_and_sets[0]


if not rev_maps:
    forms.alert("No revisions found in this file", exitscript = True)


#--------------------------------------------------------------------
#----------- CREATE NEW TRASMITTAL ----------------------------------
#--------------------------------------------------------------------

source_path = os.path.join(Lib_Path, "Data Base", "STPXX-xxxx General Transmittal.xlsx")
temp_folder = os.path.join(bin_folder, "Temp_drawings")
temp_path = os.path.join(temp_folder, transm_name)
transm_options["path"] = temp_path

clean_up_folder(temp_folder)
shutil.copy(source_path, temp_path)
relocate_files.append((temp_path, transm_path))

create_transmittal(doc, rvt_Data, rev_maps, printable_sheets, transm_options)

if os.path.exists(temp_path):
    move_files_from_temp(relocate_files)

if os.path.exists(transm_path):
    action = forms.alert(transm_name + " has been created succesfully. "
        "Please fill distribution parameters manually to complete the process\n\n"
        "Do you want to open file?", options = ["Yes", "No"])
    
    if action == "Yes":
        try:
            os.startfile(transm_path)
        except:
            forms.alert("Error while opening the file. Please try open the file manually")
    
    
else:
    forms.alert("STP Tools found a problem while copying transmittal file from temporary folder.\n\n"
        "Please try again. If the problem persist, contact STP Tools developer")



#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "Create Transm",
    "items": 1
}
track_data(Lib_Path, data, "DOC03")

