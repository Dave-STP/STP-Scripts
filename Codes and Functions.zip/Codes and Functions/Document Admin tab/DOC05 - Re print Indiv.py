#--------------------------------------------------------------------
#------------ DOC05 - Re issue Indiv.py ------------------------------
#--------------------------------------------------------------------

import sys
import os
import re
from pyrevit import revit, forms

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
discipline
bin_folder
local_mode = local_version
xaml_forms
##-------------------------------------

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")
temp_folder = os.path.join(bin_folder, "Temp_drawings")
if not os.path.exists(temp_folder):
    try:
        os.makedirs(temp_folder)
    except:
        forms.alert("Temporary folder not created, please contact STP Tools developer", exitscript = True)


functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

tab_function_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(tab_function_path)
import STP_DOC_Functions
from STP_DOC_Functions import *

#=================== MAINTAINANCE BY PASS =======================
#if user_name != "Rafael":
#    forms.alert("This tool is under revision. Will be back soon")
#    sys.exit()
#================================================================

#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
rvt_Data = get_project_info(doc)
if rvt_Data:
    p_Numb = rvt_Data["Project Number"]
    if not p_Numb:
        sys.exit()
    
    if not re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE):
        forms.alert(
            "Project Number for this file doesn't match 'STPYY-0000' standard code",
            exitscript = True
        )

projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)


p_Numb, code_name, p_Path = selected_project

#--------------------------------------------------------------------
#----------- SELECT ISSUE SEQUENCE AND DISCIPLINE -------------------
#--------------------------------------------------------------------
all_sheets = collect_all_drawings(doc)

rev_map, rev_list, set_map, set_list = get_revisions_and_sets(doc, all_sheets)
selected_sequence = forms.SelectFromList.show(rev_list, multiselect=False, title="Select one Issue Sequence")

if not selected_sequence:
    sys.exit()
else:
    seq_code = str(rev_list.index(selected_sequence) + 1)

selected_discipline, disc_code = select_discipline(discipline)
if not selected_discipline:
    sys.exit()

#--------------------------------------------------------------------
#----------- FIND TARGET FOLDER AND COMBINED PDF FILE ---------------
#--------------------------------------------------------------------

target_folder = os.path.join(p_Path, "Drawings", "Issued Drawings", disc_code)
issue_folder = find_existing_sequence_folder(target_folder, seq_code, "")

if not issue_folder:
    forms.alert("Selected Project and discipline has no STP Tools generated Transmittals.\n\n"
                "Please publish a valid issue transmittal before using this tool", exitscript = True)


#--------------------------------------------------------------------
#----------- CREATE LIST OF DRAWINGS --------------------------------
#--------------------------------------------------------------------
issued_sheets = {}
excluded_sheets = ["1", "00"]

# Collect existing issued drawings
for name in os.listdir(issue_folder):
    full_path = os.path.join(issue_folder, name)

    if not os.path.isfile(full_path):
        continue

    if "_combined" in name.lower():
        forms.alert(
            "This issue contains a combined PDF set.\n\n"
            "Please print the full set again or delete the combined PDF "
            "from the folder to continue.",
            exitscript=True
        )

    # Get file extension
    file_name, extension = os.path.splitext(name)
    file_format = extension.lower().replace(".", "")

    if file_format not in ["pdf", "dwg"]:
        continue

    for sheet in all_sheets:
        sh_Numb = sheet.SheetNumber
        key = sh_Numb + " - " + sheet.Name

        if sh_Numb in file_name and sh_Numb not in excluded_sheets:
            if key not in issued_sheets:
                issued_sheets[key] = {
                    "file_name": file_name,
                    "sheet": sheet,
                    "formats": []
                }

            if file_format not in issued_sheets[key]["formats"]:
                issued_sheets[key]["formats"].append(file_format)

            #break


# Select sheets to reprint
if not issued_sheets:
    forms.alert(
        "No issued drawings matching the current Revit model were found.",
        exitscript=True
    )

while True:
    selected_keys = forms.SelectFromList.show(
        sorted(issued_sheets.keys()),
        multiselect=True,
        title="Select Drawings to Reprint"
    )

    if selected_keys is None:
        sys.exit()  # User cancelled or closed the window

    if selected_keys:
        break  # Valid selection, continue script

    forms.alert(
        "No drawings were selected.\n\n"
        "Please select at least one drawing to continue.",
        title="No Drawings Selected"
    )


# Separate selected drawings by original file format
pdf_sheets = []
dwg_sheets = []

for key in selected_keys:
    #print(issued_sheets[key])
    file_name = issued_sheets[key]["file_name"]
    sheet = issued_sheets[key]["sheet"]
    formats = issued_sheets[key]["formats"]

    if "pdf" in formats:
        pdf_sheets.append((sheet, file_name))

    if "dwg" in formats:
        dwg_sheets.append((sheet, file_name))


printed_list = []
clean_up_folder(temp_folder)

if dwg_sheets:
    temp_files = print_separated_dwg_files(doc, 
        temp_folder, 
        issue_folder, 
        dwg_sheets
    )
    if temp_files:
        printed_list.extend(temp_files)

if pdf_sheets:
    temp_files = print_separated_pdf_files(doc, 
        temp_folder, 
        issue_folder, 
        pdf_sheets,
        50 #Progress bar initial count XX/100
    )
    if temp_files:
        printed_list.extend(temp_files)


if printed_list:
    if os.path.exists(issue_folder):
        action = forms.alert(
            "This process will replace the selected files.\n\n,Do you want to Continue?",
            options = ["OK", "Cancel"]
        )
        
        if action == "OK":
            result = move_files_from_temp(printed_list)
            #if result:
            #    forms.alert("


#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

#data = {
#    "time": start_time,
#    "p_numb": p_Numb,
#    "user": user_name,
#    "file": "Publish Issue",
#    "items": track_count
#}
#track_data(Lib_Path, data, "DOC02")