#--------------------------------------------------------------------
#-------- DOC05 - Open Folders.py --------------
#--------------------------------------------------------------------

import os
import sys
import re
from pyrevit import forms

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path 
local_mode = "bin" in Lib_Path
folder_to_open
##-------------------------------------

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import get_project_info, get_project_folders_from_onedrive, track_data

doc = __revit__.ActiveUIDocument.Document
rvt_Data = get_project_info(doc)
user_name = os.environ.get("USERNAME")


#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
projects = []
selected_folder = None

projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if local_mode and projects:
    selected_folder = projects[0]
    folder_name = os.path.basename(selected_folder)
    match = re.search(r"(STP\d{2}-\d{4})", folder_name, re.IGNORECASE)
    tentative_job_numb = match.group(1).upper() if match else ""
    p_Numb = forms.ask_for_string(default=tentative_job_numb, prompt="Enter the project number:", title="STP Tools")
    p_Code = ""
    p_Path = selected_folder

    if not os.path.exists(os.path.join(p_Path, "Drawings", "local_config.txt")):
        create_folders_in_project(p_Path)


else:
    if not projects:
        mssg = "No Project Folders Found. \n\n" + \
               "Please make sure OneDrive shortcuts are available on your computer. " + \
               "If the problem persists, contact the STP Tools Admin for further support."
        forms.alert(mssg)
        sys.exit()
        
    # Show Project Select Form
    if rvt_Data:
        p_Numb = rvt_Data["Project Number"]
        pnumb_exists = False
        
        for project in projects:
            if p_Numb in project[0]:
                pnumb_exists = True
                p_Path = project[2]
                break
    
    if not pnumb_exists:
        mssg = "The Project Number from this file was not found. \n\n" + \
               "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
               "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
               "If the problem persists, contact the STP Tools Admin for further support."
        forms.alert(mssg)
        sys.exit()



if folder_to_open == None:
    folder_path = p_Path
else:
    folder_path = p_Path
    for folder in folder_to_open:
        folder_path = os.path.join(folder_path, folder)

if os.path.exists(folder_path):
    os.startfile(folder_path)
else:
    forms.alert("This project folder doesn't have a '" + folder_to_open[-1] + "' folder.")

#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

data = {
    "time": start_time,
    "p_numb": p_Numb,
    "user": user_name,
    "file": "Open SP Folder",
    "items": 1
}
track_data(Lib_Path, data, "DOC05")