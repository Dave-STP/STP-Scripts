#--------------------------------------------------------------------
#------------ DOC02 - Publish Issue.py ------------------------------
#--------------------------------------------------------------------

import sys
import os
import re
from pyrevit import revit, forms

import datetime
from datetime import datetime
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##---Constants brought from main script
Lib_Path = revit_library_path
discipline
bin_folder
local_mode = local_version
xaml_forms
##-------------------------------------

doc = __revit__.ActiveUIDocument.Document
user_name = os.environ.get("USERNAME")

#Debug bypass
#================================================================
#if user_name != "Rafael":
#    forms.alert("This tool is under revision. Will be back soon")
#    sys.exit()
#================================================================

print_settings = {}
extra_data = {
        # Read params
        "ini_type": "",
        "qa_revit_version": "",
        "first_user": "",
        "tb_history": [],
        # Write params
        "p_type": "",
        "initials": "",
        "acc_file": None
    }

functions_path = Lib_Path + r"\Codes and Functions"
sys.path.append(functions_path)
import STP_General_Functions
from STP_General_Functions import *

tab_function_path = os.path.join(functions_path,"Document Admin tab")
sys.path.append(tab_function_path)
import STP_DOC_Functions
from STP_DOC_Functions import *

forms_path = os.path.join(functions_path,"Xaml Forms")
sys.path.append(forms_path)
import Form_Classes
from Form_Classes import IssuePrintForm

temp_folder = os.path.join(bin_folder, "Temp_drawings")
clean_up_folder(temp_folder)

if not os.path.exists(temp_folder):
    os.makedirs(temp_folder)

#--------------------------------------------------------------------
#----------- GET PRELIMINARY INFO -----------------------------------
#--------------------------------------------------------------------

# Get formats for combo box
formats_path = os.path.join(Lib_Path, "Data Base","List_Print Naming.txt")
formats = []
with open(formats_path, "r") as f:
    for line in f:
        formats.append(line.strip())

#--------------------------------------------------------------------
#----------- GET PROJECT FOLDER -------------------------------------
#--------------------------------------------------------------------
rvt_Data = get_project_info(doc)
if rvt_Data:
    p_Numb = rvt_Data["Project Number"]
    p_Address = rvt_Data["Project Address"]
    if not p_Numb:
        sys.exit()
    
    if not re.search(r"(STP\d{2}-\d{4})", p_Numb, re.IGNORECASE):
        forms.alert(
            "Project Number for this file doesn't match 'STPYY-0000' standard code",
            exitscript = True
        )
    
    p_Suburb = rvt_Data["Suburb"]
    
    if p_Suburb == "N/F":
        split_addres = p_Address.split(", ")
        if user_name == "Rafael":
            print(len(split_addres))
        rvt_Data["Project Address"] = split_addres[0]
        p_Suburb = rvt_Data["Suburb"] = split_addres[1]
        p_Pcode = rvt_Data["Postcode"] = split_addres[3]

projects = []
selected_project = None
p_Path = None
projects = get_project_folders_from_onedrive(user_name, Lib_Path)

if not projects:
    mssg = "No Project Folders Found. \n\n"
    if local_mode:
        mssg += "Please make sure project folder is inside the designided local folder.\n\n"
    else:
        mssg += "Please make sure OneDrive shortcuts are available on your computer.\n\n"
    mssg += "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
        
# Get current project number folder and location
for project in projects:
    if project[0] == p_Numb:
        selected_project = project
        break

if not selected_project:
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg, exitscript=True)


p_Numb, code_name, p_Path = selected_project
p_Name = code_name.replace(" - Documents", "").upper().replace("MCDON","McDON")


#--------------------------------------------------------------------
#----------- READ QA FILE -------------------------------------------
#--------------------------------------------------------------------
qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb)

if qa_info_exists:
    while confirm_file_is_not_opened(qa_path):
        file_name = os.path.basename(qa_path)

        action = forms.alert(
            "The QA Excel file '{}' is currently open or being used by another process.\n\n"
            "Please close the file and select 'Try Again'.\n\n"
            "If the file is not visibly open, Microsoft Excel may still be running in the background. "
            "Open Task Manager, check for any Microsoft Excel processes, and close them before trying again."
            .format(file_name),
            title="QA File In Use",
            options=[
                "Try Again",
                "Cancel"
            ]
        )

        if action != "Try Again":
            sys.exit()
        
    qa_Data = read_qa_excel_file_V2(qa_path)
    
    if qa_Data["pr_type"] == "[PG]" and p_Suburb == "N/A":
        mssg = "The QA Check List for this project is not compatible with new STP Tools QA Format.\n\n" + \
               "Please execute edit Project parameters to update a compatible Project Address Format"
        forms.alert(mssg)
        sys.exit()

else:
    forms.alert("QA file has not been created for this job yet.", exitscript = True)

#--------------------------------------------------------------------
#----------- COMPARE QA FILE WITH REVIT PARAMETERS ------------------
#--------------------------------------------------------------------

#print(qa_Data)
#print("---------")
#print(rvt_Data)
#print("---------")
unmatch_map = compare_data_maps(qa_Data, rvt_Data, True)

if unmatch_map == "Cancel":
    sys.exit()

client_ref_line = None
qbuild_ref_line = None

if unmatch_map and unmatch_map != "Continue Without Updating":
    parameters_list = [
        "Project Name",
        "Client Name",
        "Project Address", 
        "Suburb",
        "Postcode",
        "Client Reference Number",
        "Qbuild Project Number"
    ]

    for x, param in enumerate(parameters_list):
        if param in unmatch_map:
            parameters_list[x] = ((param, unmatch_map[param][0]))
        else:
            parameters_list[x] = ((param, qa_Data[param]))
            
        if param == "ref_numb":
            client_ref_line = ["Client Reference Number", parameters_list[x][1]]
            qbuild_ref_line = ["Qbuild Project Number", parameters_list[x][1]]

    
    if client_ref_line:
        parameters_list.append(client_ref_line)
    if qbuild_ref_line:
        parameters_list.append(qbuild_ref_line)   
    
    
    result = fill_project_info(doc, parameters_list)


#--------------------------------------------------------------------
#----------- GET DRAWING SHEET COLLECTORS ---------------------------
#--------------------------------------------------------------------
all_sheets = collect_all_drawings(doc)

# Collect printable sheets for discipline
print_base = {"E": "Electrical", "F": "Fire", "M": "Mechanical", "H": "Hydraulic", "S": "Structural"}
pdf_forms = ["RVT", "SID", "SPEC", "F15"]
struct_f15 = ["15a", "15b", "15c", "15d"]
excepted_numbers = ["1", "01"]
printable_sheets = []
F15_sheets = []
SID_sheets = []
SPF_sheets = []

# Fix residential form 15 pages to match all other templates
with revit.Transaction("F15 format"):
    for sheet in all_sheets:
        sheet_numb = sheet.SheetNumber
        if sheet_numb in struct_f15:
            sheet.SheetNumber = "SF" + sheet_numb
            param = sheet.get_Parameter(BuiltInParameter.SHEET_SCHEDULED)
            if param and not param.IsReadOnly:
                param.Set(0)

# Filter not printable PDF forms Rvt, SID, etc
for sheet in all_sheets:
    sheet_numb = sheet.SheetNumber
    if sheet_numb in excepted_numbers:
        continue
        
    if "F15" in sheet_numb:
        F15_sheets.append(sheet)
        continue
    elif "SID" in sheet_numb:
        SID_sheets.append(sheet)
        continue
    elif "SPEC" in sheet_numb:
        SPF_sheets.append(sheet)
        continue
    else:    
        printable_sheets.append(sheet)


# Collect current revision sequences and store them in their respective key map
rev_and_sets = get_revisions_and_sets(doc, all_sheets)

if p_Path:
    # Get job local preferences for print
    file_path = os.path.join(p_Path,"Drawings","xref", "issue_print_preferences.txt")
    read_local_settings(file_path, print_settings)
    
    
#--------------------------------------------------------------------
#----------- SHOW DRAWING SELECTION FORM ---------------------------
#--------------------------------------------------------------------
if not printable_sheets:
    forms.alert("There are no printable sheets in this project")
    sys.exit()

print_Data = {
    "formats": formats,
    "client": rvt_Data["Client Name"],
    "client_ref": rvt_Data["Client Reference Number"],
    "qbuild_ref": rvt_Data["Qbuild Project Number"],
    "purpose_items": ["Preliminary", "Approval", "Tender", "Construction", "Council Sumbmission"],
    "prt_sheets": printable_sheets,
    "prt_type": "I",
    "prt_settings": print_settings,
    "pr_folder": p_Path,
    "pr_status": rvt_Data["Project Status"],
    "bin": bin_folder,
    "def_disc": discipline,
    "building_code": rvt_Data["Building Name"]
}

form = IssuePrintForm(xaml_forms["main_form"], rev_and_sets, print_Data, F15_sheets)
form.ShowDialog()
selected_map = form.rev_map
Debug_zone = True

#--------------------------------------------------------------------
#----------- PRINT GENERAL DRAWINGS ISSUE ---------------------------
#--------------------------------------------------------------------
if selected_map and form.Export:
    
    # Get file names for printing
    set_name, transm_name, other_names = naming_sets(p_Numb, selected_map)
    sheets_to_print = naming_sheets(doc, p_Numb, selected_map)

    selected_rev = selected_map["rev_item"]
    temp_files = []
    target_folder = selected_map["rev_folder"]
    trm_folder = os.path.dirname(target_folder)
    trm_file_name = p_Numb + " - " + selected_map["discipline"] + " - Transmittal.xlsx"
    trm_path = os.path.join(trm_folder, trm_file_name)
    
    go_for_tracking = False
    #Check if the info in the transmittal matches the QA information
    fix_transmittal_map = {}
    if os.path.exists(trm_path):
        trm_Data = read_transmittal_file(trm_path)
        fix_transmittal_map = compare_data_maps(qa_Data, trm_Data, True)

    track_count = 0
    printed_list = []
    actions =["Open Folder", "Close"]
    if Debug_zone == True: 
        ### PRINT DWG FILES ###
        #----------------------
        if "D" in selected_map["formats"]:
            track_count += 1
            temp_files = print_separated_dwg_files(doc, 
                temp_folder, 
                target_folder, 
                sheets_to_print
            )
            if temp_files:
                printed_list.extend(temp_files)
        
        ### PRINT PDF FILES ###
        #----------------------
        if "P" in selected_map["formats"]:
            if selected_map["individ_pdf"] == True:
                track_count += 1
                temp_files = print_separated_pdf_files(doc, 
                    temp_folder, 
                    target_folder, 
                    sheets_to_print,
                    30 #Progress bar initial count XX/100
                )
                if temp_files:
                    printed_list.extend(temp_files)
            
            if selected_map["combined_pdf"] == True:
                track_count += 1
                temp_files = print_combined_pdf_files(doc, 
                    set_name, 
                    temp_folder, 
                    target_folder, 
                    selected_map["rev_sheets"],
                    ["Exporting PDF Combined file.", 70] #Progress bar 70/100
                )
                if temp_files:
                    printed_list.extend(temp_files)

        ### PRINT FORM 15, SID, and SPECS ###
        #------------------------------------
        
        fixed_names = ["FORM 15", "SAFETY IN DESIGN", "SPECIFICATION"]
        included = ["form15", "formSID", "specs"]
        for x, sheets in enumerate([F15_sheets, SID_sheets, SPF_sheets]):
            if selected_map[included[x]] == True and sheets:
                temp_files = print_combined_pdf_files(doc, 
                    other_names + fixed_names[x], # File name
                    temp_folder, 
                    target_folder, 
                    sheets, # Drawing list
                    ["Exporting Other PDF.", 80] #Progress bar 80/100
                )

                if temp_files:
                    printed_list.extend(temp_files)

        ### ADD OTHER PDF PAGES TO TRANSMITTAL ONLY ###
        #---------------------- 
    if Debug_zone == True:
        if selected_map["discipline"] != "Structural":
            sel_disc = selected_map["discipline"].upper()
            if selected_map["form15"] == True:
                F15_sheets = filter_pdf_by_discipline("FORM 15", "F15", F15_sheets, sel_disc)
                selected_map["rev_sheets"].append(F15_sheets[1])
            if selected_map["formSID"] == True:
                SID_sheets = filter_pdf_by_discipline("SAFETY IN DESIGN", "SID", SID_sheets, sel_disc)
                selected_map["rev_sheets"].append(SID_sheets[1])
            if selected_map["specs"] == True:
                SPF_sheets = filter_pdf_by_discipline("SPECIFICATION", "SPEC", SPF_sheets, sel_disc)
                selected_map["rev_sheets"].append(SPF_sheets[1])
            if selected_map["rvt_file"] == True:
                RVT_file = filter_pdf_by_discipline("REVIT MODEL", "RVT", [], sel_disc)
                selected_map["rev_sheets"].append(RVT_file[1])
        
    track_count += 1
    trm_source = os.path.join(Lib_Path, "Data Base", "STPXX-xxxx General Transmittal.xlsx")
    trm_temporal = os.path.join(temp_folder, "temp_transmittal.xlsx")
    
    # Get sequence code to add to the transmittal based on if is multiple revit model or single.
    if print_Data.get("building_code"):
        selected_map["seq_code"] = (str(selected_map["rev_seq"]) + 
                                    print_Data["building_code"])
    else:
        selected_map["seq_code"] = selected_map["rev_seq"]
      
    selected_map["trm_name"] = transm_name   
    trm_target = trm_path
    
    # Check if transmittal already exists or create a new one
    if Debug_zone == True:
        with forms.ProgressBar(title="Creating Transmittal") as pb:
            pb.update_progress(90, 100)
            if trm_target and os.path.exists(trm_target):
                shutil.copy(trm_target, trm_temporal)
            else:
                shutil.copy(trm_source, trm_temporal)
            last_file = [trm_temporal, trm_target]     
            
            if trm_temporal and os.path.exists(trm_temporal):
                temp_files = update_transmittal(
                    rvt_Data,
                    qa_Data,
                    selected_map,
                    temp_folder,
                    target_folder,
                    trm_temporal,
                    fix_transmittal_map)
                if temp_files:
                    printed_list.extend(temp_files)
                    if selected_map["naming_type"] != "STP-Residential":
                        printed_list.append(last_file) 
        
        if printed_list:

            if os.path.exists(target_folder):
                clean_up_folder(target_folder)
            result = move_files_from_temp(printed_list)
            
            if result:
                go_for_tracking = True
                # Mark this revision as issued in Revit
                with revit.Transaction("Rev Issued"):
                    try:
                        selected_rev.Issued = True
                    except:
                        pass
                        
                # if previous sequence issue need to be deleted.
                old_folder = selected_map["rev_to_delete"]
                if old_folder and os.path.exists(old_folder) and old_folder != selected_map["rev_folder"]:
                    remove_folder(old_folder)
                
                actions =["Open Folder", "Close"]
                action = forms.alert(
                    "All done " + user_name + ". Issue folder succesfully saved to\n\n" + selected_map["rev_folder"],
                    options = actions
                )
                
                if action == "Open Folder":
                    os.startfile(target_folder)
            
            else:
                forms.alert(
                    "There was an error while copying files to the folder."
                    "Please contact STP developer for further assistance")
                    
            
            try:
                doc.Save()
            except:
                pass

#--------------------------------------------------------------------
#----------- UPDATE TRACKING DATA -----------------------------------
#--------------------------------------------------------------------

    data = {
        "time": start_time,
        "p_numb": p_Numb,
        "user": user_name,
        "file": "Publish Issue",
        "items": track_count
    }
    track_data(Lib_Path, data, "DOC02")