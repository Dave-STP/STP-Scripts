from pyrevit import forms
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import StructuralType
############IMPORTANT#########
#SCRIPT MUST BE RUN FROM THE WALL FRAMING PLAN , LEVEL OF LINTEL IS TAKEN FROM THERE
doc = __revit__.ActiveUIDocument.Document
active_view=doc.ActiveView
if not isinstance(active_view, ViewPlan):
    forms.alert("Please open a Structural Plan before running this tool", title="Invalid View",exitscript=True)

# Collect all links
links = list(
    FilteredElementCollector(doc)
    .OfClass(RevitLinkInstance)
)

if not links:
    forms.alert("No Revit links found.")
    script.exit()

# Create display names
link_dict = {}
for link in links:
    link_dict[link.Name] = link

selected_name = forms.SelectFromList.show(
    sorted(link_dict.keys()),
    title="Select Linked Model",
    multiselect=False
)
if not selected_name:
    script.exit()

link_inst = link_dict[selected_name]
link_doc = link_inst.GetLinkDocument()
link_transform = link_inst.GetTransform()
#print("Linked document: {}".format(link_doc.Title))

###FUNCTIONS###
#funcion to get window width/height
def get_param_value(elem, param_name):
    p=elem.LookupParameter(param_name)
    if p:
        return p.AsDouble()
    
    elem_type=elem.Document.GetElement(elem.GetTypeId())
    if elem_type:
        p=elem_type.LookupParameter(param_name)
        if p:
            return p.AsDouble()
    return None
##################
#function to project point to wall
def project_to_wall(wall, pt):
    curve=wall.Location.Curve
    proj=curve.Project(pt).XYZPoint
    return proj
#function to find wall at point
def find_wall_at_point(pt, walls, tol=1.0):
    for w in walls:
        bb=w.get_BoundingBox(None)
        if not bb:
            continue
        if(
            bb.Min.X - tol <= pt.X <= bb.Max.X + tol and bb.Min.Y - tol <= pt.Y <= bb.Max.Y + tol):
            return w
    return None
#function to get doors dimensions
def get_opening_size(instance):
    bb=instance.get_BoundingBox(None)
    if not bb:
        print("element {} has no bounding box".format(instance.Id))
        return None, None
    
    host=instance.Host
    if host is None:
        print("element {} has no host".format(instance.Id))
        return None, None

    wall_curve=host.Location.Curve
    wall_dir=(wall_curve.GetEndPoint(1)-wall_curve.GetEndPoint(0)).Normalize()
    corners=[XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z), XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z), XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z), XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z)]
    projections=[]
    for p in corners:
        projections.append(p.DotProduct(wall_dir))
    
    width=max(projections) - min(projections)
    height=bb.Max.Z-bb.Min.Z


    return width, height
#function for creating lintels types:


###FUNCTIONS###

#collect all windows/doors from link
windows =FilteredElementCollector(link_doc).OfCategory(BuiltInCategory.OST_Windows).WhereElementIsNotElementType().ToElements()
doors =FilteredElementCollector(link_doc).OfCategory(BuiltInCategory.OST_Doors).WhereElementIsNotElementType().ToElements()
#get host walls
host_walls=FilteredElementCollector(doc).OfClass(Wall).WhereElementIsNotElementType().ToElements()
#select lintel family symbol
symbols=FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_Windows).ToElements()
level = doc.ActiveView.GenLevel

#print("Found {} windows".format(len(windows)))
    
########

t1=Transaction(doc, "place lintels from link windows and doors")
t1.Start()

####
symbol_dict={}
for s in symbols:
    fam=s.Family
    fam_name=fam.Name if fam else "Unknown"
    type_name=s.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
    display="{} : {}".format(fam_name, type_name)
    symbol_dict[display]=s
selected=forms.SelectFromList.show(sorted(symbol_dict.keys()), title="select lintel base family type", multiselect=False)

#####
if not selected:
    script.exit()
symbol=symbol_dict[selected]
if not symbol.IsActive:
    symbol.Activate()
    doc.Regenerate()

def get_or_create_lintel_types(symbol):
    family=symbol.Family
    BL1=None
    BL2=None
    BL3=None
    all_symbols=FilteredElementCollector(doc).OfClass(FamilySymbol).ToElements()
    
    for s in all_symbols:
        if s.Family.Id!=family.Id:
            continue
        name=s.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
        if "BL1" in name:
            BL1=s
        elif "BL2" in name:
            BL2=s
        elif "BL3" in name:
            BL3=s
    if BL1 is None:
        BL1=symbol.Duplicate("BL1")
    if BL2 is None:
        BL2=symbol.Duplicate("BL2")
    if BL3 is None:
        BL3=symbol.Duplicate("BL3")
    
    return BL1,BL2,BL3
def set_type_mark(symbol,mark):
    p=symbol.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_MARK)
    if p and not p.IsReadOnly:
        p.Set(mark)
def get_lintel_symbol(width):
    width_mm=width*304.8
    if width_mm<=1800:
        return BL1
    elif width_mm<=3000 and width_mm>1800:
        return BL2
    else:
        return BL3
    
#call dunction to create lintel types
BL1, BL2, BL3 = get_or_create_lintel_types(symbol)
#set linel types:
set_type_mark(BL1,"BL1")
set_type_mark(BL2,"BL2")
set_type_mark(BL3,"BL3")

created_lintels=[]
###Windows:
for win in windows:
    if win.Host is None:
        continue
    
    #get linked windows locations
    loc=win.Location
    if not isinstance(loc, LocationPoint):
        continue
    linked_pt=loc.Point
    #tranform linked point to hosted points
    host_pt=link_transform.OfPoint(linked_pt)
    #get linked windows dimensions
    w_width=get_param_value(win,"Width")
    w_height=get_param_value(win,"Height")
    #w_width, w_height = get_opening_size(win)
    #debug
    #print("bounding box Zmax-Zmin={}".format((win.get_BoundingBox(None).Max.Z-win.get_BoundingBox(None).Min.Z)*304.8))
    #print("windows id {} width {}  height {}".format(win.Id,w_width*304.8,w_height*304.8))

    w_sill_height=get_param_value(win,"Sill Height")

    symbol_to_use= get_lintel_symbol(w_width)
    #get hosted walls at those locations
    wall=find_wall_at_point(host_pt,host_walls)
    if not wall:
        continue
    
    pt_on_wall=wall.Location.Curve.Project(host_pt).XYZPoint
    if w_sill_height is None or w_height is None or w_width is None:
        print("Window {} ({}) has no parameter/value, lintel will not be created.".format(win.Id,win.Name))
        continue
    
    instnace=doc.Create.NewFamilyInstance(pt_on_wall,symbol_to_use,wall,level,StructuralType.NonStructural)
    created_lintels.append(instnace)

    #change lintel dimension 
    p=instnace.LookupParameter("STP_Width")
    if p and not p.IsReadOnly:
        p.Set(w_width)

    p=instnace.LookupParameter("STP_Height")
    if p and not p.IsReadOnly:
        p.Set(w_height)

    p=instnace.LookupParameter("Sill Height")
    if p and not p.IsReadOnly:
        p.Set(w_sill_height)
##doors:
for d in doors:
    if d.Host is None :
        #debug
        #print("Skipping door {} - no host".format(d.Id))
        continue
    
    #skip doors that are hosted in curtain walls
    if d.Host.Category.Name =="Curtain Panels":
        #print("door {} skipped host wall is Curtain".format(d.Id)) 
        continue

    #get linked doors locations
    d_loc=d.Location
    if not isinstance(d_loc, LocationPoint):
        continue
    d_linked_pt=d_loc.Point
    #tranform linked point to hosted points
    d_host_pt=link_transform.OfPoint(d_linked_pt)
    #get linked doors dimensions
    d_sill_height=get_param_value(d,"Sill Height")
    d_width, d_height = get_opening_size(d)

    symbol_to_use= get_lintel_symbol(d_width)

    #get hosted walls at those locations
    wall=find_wall_at_point(d_host_pt,host_walls)
    if not wall:
        continue
    
    d_pt_on_wall=wall.Location.Curve.Project(d_host_pt).XYZPoint
    #create lintel instance:
    d_instnace=doc.Create.NewFamilyInstance(d_pt_on_wall,symbol_to_use,wall,level,StructuralType.NonStructural)
    created_lintels.append(d_instnace)

    #change lintel dimension 
    d_p=d_instnace.LookupParameter("STP_Width")
    if d_p and not d_p.IsReadOnly:
        d_p.Set(d_width)

    d_p=d_instnace.LookupParameter("STP_Height")
    if d_p and not d_p.IsReadOnly:
        d_p.Set(d_height)
    
    d_p=d_instnace.LookupParameter("Sill Height")
    if d_p and not d_p.IsReadOnly:
        d_p.Set(d_sill_height)

###Curtain walls
#get linked cutrain walls dimensions
for w in FilteredElementCollector(link_doc).OfClass(Wall):
    w_type=link_doc.GetElement(w.GetTypeId())
    if w_type.Kind==WallKind.Curtain:
        w_loc=w.Location
        w_linked_pt=w_loc.Curve.Evaluate(0.5,True)
        w_host_pt=link_transform.OfPoint(w_linked_pt)
        if not isinstance(w_loc,LocationCurve):
            #print("wall {} has no location Curve".format(w.Id))
            continue
        #get width
        curve=w.Location.Curve
        cw_width=curve.Length
        #get height
        cw_height=w.get_Parameter(BuiltInParameter.WALL_USER_HEIGHT_PARAM).AsDouble()
        #debug
        #print("Curtain wall {} - W={}, H={}".format(w.Id,cw_width*304.8,cw_height*304.8))
        symbol_to_use= get_lintel_symbol(cw_width)
        wall=find_wall_at_point(w_host_pt,host_walls)
        if not wall:
            #print("not wall {}".format(w.Id))
            continue
        w_pt_on_wall=wall.Location.Curve.Project(w_host_pt).XYZPoint
        w_instance=doc.Create.NewFamilyInstance(w_pt_on_wall,symbol_to_use,wall,level,StructuralType.NonStructural)
        created_lintels.append(w_instance)

        #change lintel dimensions:
        w_p=w_instance.LookupParameter("STP_Width")
        if w_p and not w_p.IsReadOnly:
            w_p.Set(cw_width)
        w_p=w_instance.LookupParameter("STP_Height")
        if w_p and not w_p.IsReadOnly:
            w_p.Set(cw_height)
    else:
        continue
doc.Regenerate()

#calculate lintel Height (distance from top of opening to top of wall)
for lintel in created_lintels:
    lintel_wall=lintel.Host
    if not lintel_wall:
        #print("host is not a wall")
        continue
    wall_bb=lintel_wall.get_BoundingBox(None)
    lintel_bb=lintel.get_BoundingBox(None)
    if not wall_bb or not lintel_bb:
        print("no bounding box found")
        continue
    wall_top_z=wall_bb.Max.Z
    lintel_top_z=lintel_bb.Max.Z
    #lintel_top_z=lintel.Location.Point.Z + (get_param_value(lintel,"STP_Height")*0.5)

    dist=wall_top_z-lintel_top_z
    print("lintel {}:  Height = {} ".format(lintel.Id,dist*304.8))

t1.Commit()

###tag lintels:
t2=Transaction(doc,"Tag lintels")
t2.Start()
#select tag type
tag_type=None
window_tags={}
all_tag_symbols=FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_WindowTags)

for fs in all_tag_symbols:
    family_name=fs.Family.Name if fs.Family else "Unknown"
    type_name=fs.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
    display="{} : {}".format(family_name,type_name)
    window_tags[display]=fs

    if family_name=="STP_Block Lintel Tag":
        tag_type=fs
        break
if tag_type is None:
    selected=forms.SelectFromList.show(sorted(window_tags.keys()),title="STP_Block Lintel Tag was not found.\n""Please select tag type",multiselect=False)
    if not selected:
        script.exit()
    tag_type=window_tags[selected]

for lintel in created_lintels:
    lintel_loc=lintel.Location
    tag_pt=lintel_loc.Point
    if not isinstance(lintel_loc, LocationPoint):
        print("lintel has no location point")
        continue

    #tag lintel:
    #print(lintel.Id,tag_pt.X,tag_pt.Y)
    tag=IndependentTag.Create(doc,active_view.Id,Reference(lintel),False,TagMode.TM_ADDBY_CATEGORY,TagOrientation.Horizontal,tag_pt)
    tag.ChangeTypeId(tag_type.Id)
t2.Commit()






