#------------------------------------------------------
#-----ST-03-Import Title Block and Create Sheets.py----
#------------------------------------------------------

# Load Libraries
#------------------------------------------------------
# Import required Dynamo and Revit libraries
import os
import clr
clr.AddReference('RevitAPI')
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import UIApplication

clr.AddReference("RevitServices")
import RevitServices
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
uiapp = DocumentManager.Instance.CurrentUIApplication
uidoc = uiapp.ActiveUIDocument
doc = uidoc.Document
app = doc.Application

from System.Collections.Generic import List
from System.Windows.Forms import MessageBox, MessageBoxButtons, MessageBoxIcon, DialogResult

# Variables
#------------------------------------------------------
Initials = IN[0][0] # 0-Revit Library Path, 1-User, 2-Start time
General_List_Info = IN[0][1]
QA_data = IN[1]

Lib_Path = Initials[0]

next_step = General_List_Info[0]
p_Loc = General_List_Info[1]
note_sheets, cover_sheet, n_levels = General_List_Info[3][0:4]
sheets_list = General_List_Info[4]

p_Info = General_List_Info[2]

# Name of the views to copy from Notes
notesA0 = ["STP_ GEN NOTES SHEET 1", "STP_ALL WHS NOTES", "SAFETY IN DESIGN"]
notesA1 = ["STP_ GEN NOTES SHEET 1", "STP_ GEN NOTES SHEET 2", "STP_ GEN NOTES SHEET 3", "STP_ALL WHS NOTES", "SAFETY IN DESIGN"]
notesA3 = ["STP_ GEN NOTES SHEET 1", "STP_ GEN NOTES SHEET 2", "STP_ GEN NOTES SHEET 3", "STP_ALL WHS NOTES", "SAFETY IN DESIGN SHEET 1", "SAFETY IN DESIGN SHEET 2"]

# Number of the sheets where the notes go
s_numbA0 = ["S001", "S002"]
s_numbA1 = ["S001", "S002", "S003", "S004"]
s_numbA3 = ["S001", "S002", "S003", "S004", "S005"]

# Name of the sheets where the notes go
s_nameA0 = ["STRUCTURAL NOTES SHEET 1", "W&HS AND SAFETY IN DESIGN"]
s_nameA1 = ["STRUCTURAL NOTES SHEET 1", "STRUCTURAL NOTES SHEET 2", "STRUCTURAL NOTES SHEET 3", "SAFETY IN DESIGN"]
s_nameA3 = ["STRUCTURAL NOTES SHEET 1", "STRUCTURAL NOTES SHEET 2", "STRUCTURAL NOTES SHEET 3",  "SAFETY IN DESIGN SHEET 1", "SAFETY IN DESIGN SHEET 2"]

order_A0 = [0, 1, 1]
order_A1 = [0, 1, 2, 2, 3]
order_A3 = [0, 1, 2, 2, 3, 4]

cover_parameters = ["Coversheet Text","Cover Sheet Title","Visibility - Coversheet Stamps"]
off_parameters = ["North Point", "Visibility - North Point", "Project North", "Scale Bar", "NORTH POINT VISIBILITY", "SCALE BAR VISIBILITY", "NorthPoint_OrientedToProjectNorth", "NorthPoint_OrientedToTrueNorth", "Scale_As Indicated"]

test = ""
Test = []
sheets = []
copiedViews = []
aux_list = []
mm_to_feet = 1 / 304.8

# Functions
#------------------------------------------------------
def get_tblock_family(tb_name):
    # Search for the title block in the project.
    titleblock_families = FilteredElementCollector(doc) \
    .OfCategory(BuiltInCategory.OST_TitleBlocks) \
    .OfClass(FamilySymbol) \
    .ToElements()
    
    tb_fam = None
    for tb in titleblock_families:
        if tb.Family.Name == tb_name.replace(".rfa",""):
            tb_fam = tb   
    
    return tb_fam

def flatten_list(List):
    new_list = []
    for sub in List:
        if sub[0]:
            new_list.append(sub[0])
    return new_list

def extract_lines(file_path, search_term):  # Get the coordinates
    with open(file_path, 'r') as file:
        lines = file.readlines()

    line_coords = []
    capture = False

    for line in lines:
        stripped_line = line.strip()

        if search_term in stripped_line:
            capture = True

        if capture:
            if stripped_line == "":  # Stop capturing if we hit a blank line
                break
            coords = stripped_line.split(',')
            if len(coords) == 3:
                # Convert from millimeters to feet
                x = float(coords[0]) * mm_to_feet
                y = float(coords[1]) * mm_to_feet
                z = float(coords[2]) * mm_to_feet
                revit_point = XYZ(x, y, z)
                line_coords.append(revit_point)

    return line_coords
# Code
#------------------------------------------------------

reng = 0
if QA_data and next_step:
    p_Type = "R" if "[R]" in QA_data[0][1] else "G"
    if p_Type != "R":
        for row, line in enumerate(QA_data):  
            if not line[0] and row > 0:
                reng = row - 1
                break

        for item in QA_data[reng]:
            p_Info.append(item)
        p_Info.pop(1); p_Info.pop(-1)
        
        tblock_name = p_Info[6]
        
        General_List_Info[0] = False #

        tb_family = get_tblock_family(tblock_name)
        # If titleblock not existing in the current project, search for it in xrev folder
        if not tb_family:
            tb_path = os.path.join(p_Loc,"Drawings","xref",tblock_name)
            if os.path.exists(tb_path):
                mssg = "The title block : " + tblock_name + " is missing from this file. It may have been deleted or this file is outdated. \n\n Would you like to load the latest version from the 'xrev' folder?"
                result = MessageBox.Show(mssg, "Title Block Missing", MessageBoxButtons.YesNo)
            
                if result == DialogResult.Yes:
                    TransactionManager.Instance.EnsureInTransaction(doc)
                    tb_family = doc.LoadFamily(tb_path)
                    TransactionManager.Instance.TransactionTaskDone()
                    
                    tb_family = get_tblock_family(tblock_name)
                    next_step = True
            else:
                tb_family = get_tblock_family_by_p_Numb(p_Numb)

        if tb_family:
        # Get the existing sheet names to avoid duplicate
            existing_sheets = []
            duplicated_sheets = []
            TransactionManager.Instance.EnsureInTransaction(doc)
            
            sheet_collector = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
            for ex_sheet in sheet_collector:
                existing_sheets.append(ex_sheet.Name)

            #-------------------------------------------------------------------------------
            #---------- COVER SHEET AND NOTE SHEETS ----------------------------------------
            #-------------------------------------------------------------------------------
            
            if cover_sheet:
                if "A0" in tblock_name:
                    sch_x = 3.2
                    sch_y = 2.5
                elif "A1" in tblock_name:
                    sch_x = 2.1
                    sch_y = 1.7
                elif "A3" in tblock_name:
                    sch_x = 0.9 
                    sch_y = 0.9
                else:
                    sch_x = 0 
                    sch_y = 0
                if "COVER SHEET" in existing_sheets:
                    message = f"''COVER SHEET'' Already exists in the project and won't be created"
                    MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                else:
                    sheet = ViewSheet.Create(doc, tb_family.Id)
                    sheet.SheetNumber = "S000"
                    sheet.Name = "COVER SHEET"
                    cover_collector = FilteredElementCollector(doc, sheet.Id).OfCategory(BuiltInCategory.OST_TitleBlocks).ToElements()
                    for tb in cover_collector:
                        for cover_p in cover_parameters:
                            if tb.LookupParameter(cover_p) is not None:
                                tb.LookupParameter(cover_p).Set(True)
                        for off in off_parameters:
                            if tb.LookupParameter(off) is not None:
                                tb.LookupParameter(off).Set(False)            
                    
                    scheduleName = "STRUCTURAL DRAWING LIST"
                    allSchedules = FilteredElementCollector(doc).OfClass(ViewSchedule).ToElements()
                    schedule = [s for s in allSchedules if s.Name == scheduleName][0] # STRUCTURAL DRAWING LIST (Revit Element)
                    scheduleInstance = ScheduleSheetInstance.Create(doc, sheet.Id, schedule.Id, XYZ(sch_x, sch_y, 0))
                    
            if note_sheets:
                
                size_letter = "A1" # If the title block doesn't contain A1, A1, A3 in the name. Consider as A1
                if "A0" in tblock_name:
                    notes = notesA0
                    order = order_A0
                    s_numbs = s_numbA0
                    s_names = s_nameA0
                    size_letter = "A0"
                elif "A3" in tblock_name:
                    notes = notesA3
                    order = order_A3
                    s_numbs = s_numbA3
                    s_names = s_nameA3
                    size_letter = "A3"
                else:
                    notes = notesA1
                    order = order_A1
                    s_numbs = s_numbA1
                    s_names = s_nameA1
                    size_letter = "A1"            
                    
                for j, s in enumerate(s_numbs):
                    if s_names[j] not in existing_sheets:
                        sheet = ViewSheet.Create(doc, tb_family.Id)
                        #Change the name of the sheet based on the 'sheets' list
                        sheet.SheetNumber = s
                        sheet.Name = s_names[j]
                        sheets.append(sheet)
                    else:
                        sheets.append(sheet_collector[existing_sheets.index(s_names[j])])
                    
                    cover_collector = FilteredElementCollector(doc, sheet.Id).OfCategory(BuiltInCategory.OST_TitleBlocks).ToElements()
                    for tb in cover_collector:
                        for cover_p in cover_parameters:
                            if tb.LookupParameter(cover_p) is not None:
                                tb.LookupParameter(cover_p).Set(False)
                        for off in off_parameters:
                            if tb.LookupParameter(off) is not None:
                                tb.LookupParameter(off).Set(False)            

                notesPath = Lib_Path.replace(r"\STP Dynamo",r"\STP Structural\Notes & Legends\STP_General Notes - " + size_letter + ".rvt") # STP Drafting - Revit Library \ .....Notes & Legends\STP_General Notes - A0.rvt
                modelPath = ModelPathUtils.ConvertUserVisiblePathToModelPath(notesPath)
                    
                options = OpenOptions()
                options.DetachFromCentralOption = DetachFromCentralOption.DetachAndPreserveWorksets
                    
                docOnDisk = app.OpenDocumentFile(modelPath, options)
                views = FilteredElementCollector(docOnDisk).OfCategory(BuiltInCategory.OST_Views) 

                #Copy Notes Drafting Views from file (e.g. = "STP_General Notes - A1.rvt")
                view_order = []
                for view in views:
                    if view.Name in notes:
                        view_order.append(notes.index(view.Name))
                        copiedView = ElementTransformUtils.CopyElements(docOnDisk, List[ElementId]([view.Id]), doc, Transform.Identity, CopyPasteOptions())
                        copiedViews.append(copiedView) # 4195921, 419...., 419.....
                        targetView = doc.GetElement(copiedView[0]) # copiedViews as Revit Elements
                        collector = FilteredElementCollector(docOnDisk, view.Id)
                        sourceElements = collector.ToElements()
                        if len(sourceElements) > 0:
                            sourceElements.pop(0)
                        copiedElements = ElementTransformUtils.CopyElements(view, List[ElementId]([elem.Id for elem in sourceElements]), targetView, Transform.Identity, CopyPasteOptions())

                docOnDisk.Close(False)
                
                flat_list = flatten_list(copiedViews)
                copiedViews = [""] * len(view_order)
                for index, detail in enumerate(flat_list):
                    copiedViews[view_order[index]] = detail

                file_path = Lib_Path + r"\STP_Codes\STP_Functions\List_Coordinates.txt"
                code = "STP_"+ size_letter
                    
                # Extract the lines and output them
                points = extract_lines(file_path, code)
                    
                notesViews = []                    
                for i, o in enumerate(order):
                    a = Viewport.Create(doc, sheets[order[i]].Id, copiedViews[i], points[i])
                    notesViews.append(a)
                mssg = "Note Seehts and Cover sheet was created succesfully. However, Creating sheets is not available for the moment. We are working to get this soon"
                result = MessageBox.Show(mssg, "Warning", MessageBoxButtons.OK)
    else:
        result = MessageBox.Show("This tool is not available for Residential Projects", "Warning", MessageBoxButtons.OK)
        General_List_Info[0] = False

OUT = Initials, General_List_Info, notesViews
