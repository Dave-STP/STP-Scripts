from System.Windows.Forms import MessageBox, MessageBoxButtons, MessageBoxIcon, DialogResult

General_List_Info = IN[0][1]
next_step = General_List_Info[0]

if next_step:
    OUT = 1
else:
    OUT = 0