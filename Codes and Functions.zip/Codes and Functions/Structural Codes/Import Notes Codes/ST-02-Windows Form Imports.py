#------------------------------------------------------
#---------ST-02-Windows Form Imports.py----------------
#------------------------------------------------------

# Load Libraries
#------------------------------------------------------
import clr
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

import System
from System import Decimal
from System.Windows.Forms import Form, GroupBox, CheckBox, Button, Label, NumericUpDown, FlowLayoutPanel, DialogResult, ComboBox, TextBox, FlatStyle, RadioButton, MessageBox, FormStartPosition, OpenFileDialog, MessageBoxButtons, MessageBoxIcon
from System.Drawing import Point, Size

import System
from System.Windows.Forms import MessageBox, FormStartPosition, OpenFileDialog, MessageBoxButtons, MessageBoxIcon

# Variables
#------------------------------------------------------
Initials = IN[0][0] # 0-Revit Library Path, 1-User, 2-Start time
General_List_Info = IN[0][1]

next_step = General_List_Info[0]
notes = General_List_Info[3]
sheets = General_List_Info[4]

test = ""
Test = []
aux_list = []

# Functions
#------------------------------------------------------
class CustomForm(Form):
    def __init__(self):
        # Form properties
        self.Text = 'Revit Dynamo - Sheet and Plan Selector'
        # Form Size specified at the end
        
        x1 = 15
        
        self.group = GroupBox()
        self.group.Text = "General Import"
        self.group.Size = Size(400, 55)
        self.group.Location = Point(x1, 20)
        self.gr_General = self.group
        self.Controls.Add(self.gr_General)
        
        # Note Sheets checkboxes
        chb = CheckBox()
        chb.Text = "Note Sheets"
        chb.Checked = True
        chb.TabIndex = 0
        chb.Location = Point(20, 20)
        self.chb_Notes = chb
        self.gr_General.Controls.Add(self.chb_Notes)        
        
        # Cover sheet checkboxes
        chb = CheckBox()
        chb.Text = 'Cover Sheet'
        chb.Checked = True
        chb.TabIndex = 1
        chb.Location = Point(200, 20)
        self.chb_Cover = chb
        self.gr_General.Controls.Add(self.chb_Cover)
        
        self.group = GroupBox()
        self.group.Text = "General Sheets"
        # group size specified at the end
        self.group.Location = Point(x1, self.gr_General.Location.Y + 60)
        self.gr_Sheets = self.group
        self.Controls.Add(self.gr_Sheets)        
        
        gx1 = 20; gx2 = 190; y = 20; index = 0

        # Multiple building checkboxes
        chb = CheckBox()
        chb.Text = 'Multiple Building Typical Details'
        chb.TabIndex = index
        chb.Width = 260
        chb.Location = Point(gx1, y)
        y += 25; index += 1
        self.chb_Mult_bd = chb
        self.gr_Sheets.Controls.Add(self.chb_Mult_bd)        
        
        # Site Work building checkboxes
        chb = CheckBox()
        chb.Text = 'Site Works'
        chb.TabIndex = index
        chb.Width = 80
        chb.Location = Point(gx1, y)
        chb.CheckedChanged += self.on_option_checked
        index += 1
        self.chb_site_works = chb
        self.gr_Sheets.Controls.Add(self.chb_site_works)

        lbl = Label()
        lbl.Text = "---------------------->"
        lbl.Location = Point(80, y + 2)
        lbl.Width = 110
        self.lbl_site = lbl
        self.gr_Sheets.Controls.Add(self.lbl_site)
        
        # Site works detail checkboxes
        chb = CheckBox()
        chb.Text = 'Site Works Details'
        chb.Enabled = False
        chb.TabIndex = index
        chb.Location = Point(gx2, y)
        y += 25; index += 1
        chb.Width = 160
        self.chb_site_details = chb
        self.gr_Sheets.Controls.Add(self.chb_site_details)
        
        # Ground Floor slabs checkboxes
        chb = CheckBox()
        chb.Text = 'Ground Floor Slabs'
        chb.TabIndex = index
        chb.Location = Point(gx1, y)
        index += 1
        chb.Width = 122
        chb.CheckedChanged += self.on_option_checked
        self.chb_slab_footing_plan = chb
        self.gr_Sheets.Controls.Add(self.chb_slab_footing_plan)

        lbl = Label()
        lbl.Text = "--------->"
        lbl.Location = Point(130, y + 4)
        lbl.Width = 55
        self.lbl_ground = lbl
        self.gr_Sheets.Controls.Add(self.lbl_ground)
        
        # Separate Fooing checkboxes
        chb = CheckBox()
        chb.Text = 'Separate Footing and Slab Plans'
        chb.Enabled = False
        chb.TabIndex = index
        chb.Location = Point(gx2, y)
        y += 25; index += 1
        chb.Width = 200
        self.chb_separate_plans = chb
        self.gr_Sheets.Controls.Add(self.chb_separate_plans)
        
        # Base Plate checkboxes
        chb = CheckBox()
        chb.Text = 'Base Plate Plan'
        chb.TabIndex = index
        chb.Location = Point(gx1, y)
        y += 25; index += 1
        chb.Width = 110
        self.chb_base_plates = chb
        self.gr_Sheets.Controls.Add(self.chb_base_plates)

        # Suspended Slabs checkboxes
        chb = CheckBox()
        chb.Text = 'Suspended Slab Plans'
        chb.TabIndex = index
        chb.Location = Point(gx1, y)
        index += 1
        chb.Width = 138
        chb.CheckedChanged += self.on_option_checked
        self.chb_suspended_slabs = chb
        self.gr_Sheets.Controls.Add(self.chb_suspended_slabs)

        lbl = Label()
        lbl.Text = "------->"
        lbl.Location = Point(140, y + 4)
        lbl.Width = 40
        self.lbl__1 = lbl
        self.gr_Sheets.Controls.Add(self.lbl__1)
        
        # Postentioning checkboxes
        chb = CheckBox()
        chb.Text = 'Postensioning Plans'
        chb.Enabled = False
        chb.TabIndex = index
        chb.Location = Point(gx2, y)
        y += 25; index += 1
        chb.Width = 200
        self.chb_post_plans = chb
        self.gr_Sheets.Controls.Add(self.chb_post_plans)

        # Levels label
        lbl = Label()
        lbl.Text = "Levels"
        lbl.Enabled = False
        lbl.Location = Point(gx1, y + 3)
        lbl.Width = 38
        self.lbl_Levels = lbl
        self.gr_Sheets.Controls.Add(self.lbl_Levels)
        
        # Levels Spin Button
        spn = NumericUpDown()
        spn.Minimum = Decimal(1)
        spn.Maximum = Decimal(5)
        spn.Value = Decimal(1)
        spn.Enabled = False
        spn.Width = 50
        spn.TabIndex = index
        index += 1
        spn.Location = Point(75, y)
        self.spn_Levels = spn
        self.gr_Sheets.Controls.Add(self.spn_Levels)
        
        lbl = Label()
        lbl.Text = "------->"
        lbl.Location = Point(140, y + 4)
        lbl.Width = 40
        self.lbl__2 = lbl
        self.gr_Sheets.Controls.Add(self.lbl__2)        

        # RC Beams and columns checkboxes
        chb = CheckBox()
        chb.Text = 'RC Beams and Columns'
        chb.Enabled = False
        chb.TabIndex = index
        chb.Location = Point(gx2, y)
        y += 25; index += 1
        chb.Width = 200
        self.chb_beams = chb
        self.gr_Sheets.Controls.Add(self.chb_beams)
        
        # Wall Framing checkboxes
        chb = CheckBox()
        chb.Text = 'Wall Framing Plans'
        chb.TabIndex = index
        chb.Location = Point(gx1, y)
        y += 25; index += 1
        chb.Width = 200
        self.chb_wall_framing = chb
        self.gr_Sheets.Controls.Add(self.chb_wall_framing)
       
        # Precast Panel checkboxes
        chb = CheckBox()
        chb.Text = 'Precast Panel Plan'
        chb.TabIndex = index
        chb.Location = Point(gx1, y)
        y += 25; index += 1
        chb.Width = 300
        self.chb_precast_panels = chb
        self.gr_Sheets.Controls.Add(self.chb_precast_panels)

        # Roof Framing checkboxes
        chb = CheckBox()
        chb.Text = 'Roof Framing Plans'
        chb.TabIndex = index
        chb.Location = Point(gx1, y)
        index += 1
        chb.Width = 130
        chb.CheckedChanged += self.on_option_checked
        self.chb_roof_framing = chb
        self.gr_Sheets.Controls.Add(self.chb_roof_framing)

        lbl = Label()
        lbl.Text = "--------->"
        lbl.Location = Point(130, y + 4)
        lbl.Width = 55
        self.lbl__3 = lbl
        self.gr_Sheets.Controls.Add(self.lbl__3)  
        
        # Steel Elevations checkboxes
        chb = CheckBox()
        chb.Text = 'Steelwork Elevations'
        chb.Enabled = False
        chb.TabIndex = index
        chb.Location = Point(gx2, y)
        y += 25; index += 1
        chb.Width = 150
        self.chb_steelwork_elevations = chb
        self.gr_Sheets.Controls.Add(self.chb_steelwork_elevations)

        self.group.Size = Size(400, y + 15)
        
        btn = Button()
        btn.Text = "Import"
        btn.Location = Point(200, y + 110)
        btn.TabIndex = index
        index += 1
        btn.Click += self.on_finish
        self.btn_Import = btn
        self.Controls.Add(self.btn_Import)

        btn = Button()
        btn.Text = "Cancel"
        btn.Location = Point(320, y + 110)
        btn.TabIndex = index
        index += 1
        btn.Click += self.on_finish
        self.btn_Cancel = btn
        self.Controls.Add(self.btn_Cancel)
        
        self.Size = Size(450, y + 190)

    def on_option_checked(self, sender, event):
        val = sender.Checked
        if sender.Text == 'Site Works':
            self.chb_site_details.Enabled = val
        elif sender.Text == 'Ground Floor Slabs':
            self.chb_separate_plans.Enabled = val
        elif sender.Text == 'Suspended Slab Plans':
            self.chb_post_plans.Enabled = val
            self.lbl__2.Enabled = val
            self.lbl_Levels.Enabled = val
            self.spn_Levels.Enabled = val
            self.chb_beams.Enabled = val
        elif sender.Text == 'Roof Framing Plans':
            self.chb_steelwork_elevations.Enabled = val

    def on_finish(self, sender, event):
        if sender == self.btn_Import:
            notes[0] = self.chb_Notes.Checked
            notes[1] = self.chb_Cover.Checked
            notes[2] = str(self.spn_Levels.Value)
            
            aux_list = []
            for control in self.gr_Sheets.Controls:
                if isinstance(control, CheckBox) and control.Checked:
                    sheets.append(control.Text)

            sheets.pop(0)
            General_List_Info[0] = True
 
        self.Close()

# Code
#------------------------------------------------------

if next_step:
    General_List_Info[0] = False
    form = CustomForm()
    form.ShowDialog()
    
    
OUT = Initials, General_List_Info


