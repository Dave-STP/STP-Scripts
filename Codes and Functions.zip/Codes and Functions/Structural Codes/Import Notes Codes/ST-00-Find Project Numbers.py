#------------------------------------------------------
#---------ST-00-Find Project Numbers.py----------------
#------------------------------------------------------

# Load Libraries
#------------------------------------------------------
import re  # Regular expressions module
import os

# Variables
#------------------------------------------------------
Initials = IN[0] # 0-Revit Library Path, 1-User, 2-Start time
user_name = Initials[1]

Posible_jobs_path = [r"D:\STP Consultants",
                    r"E:\STP Consultants",
                    r"D:\OneDrive - STP Consultants",
                    r"E:\OneDrive - STP Consultants",
                    fr"C:\Users\{user_name}\STP Consultants",
                    fr"E:\Users\{user_name}\STP Consultants",
                    fr"C:\Users\{user_name}\OneDrive - STP Consultants",
                    fr"E:\Users\{user_name}\OneDrive - STP Consultants",]

stp_folders = []
Projects = []
test = ""
Test = []
aux_list = []

# Functions
#------------------------------------------------------


# Code
#------------------------------------------------------

# Regular expression to match folder names starting with 'STP' followed by two digits
pattern = re.compile(r"^STP\d{2}")

# Find the correct path for the job's shortcuts
for path in Posible_jobs_path:
    if os.path.exists(path):
        for item in os.listdir(path): # List all itemas in the directory
            if os.path.isdir(os.path.join(path, item)): # Check if the item is a folder
                if pattern.match(item): # Check if it matches with the STP format
                    confirm_folder_path = os.path.join(path,item,"QA") # Confirm that is a project folder
                    if os.path.exists(confirm_folder_path):
                        stp_folders.append((item, os.path.join(path, item)))
                    
                    
                # Now check one level down in this folder
                subfolder_path = os.path.join(path, item)
                for sub_item in os.listdir(subfolder_path): # List all items in the sub-folder
                    if os.path.isdir(os.path.join(subfolder_path, sub_item)) and pattern.match(sub_item):
                        confirm_folder_path = os.path.join(subfolder_path, sub_item,"QA") # Confirm that is a project folder
                        if os.path.exists(confirm_folder_path):
                            stp_folders.append((sub_item, os.path.join(subfolder_path, sub_item)))


for folder in stp_folders:
    # Construct the full folder path
    
    code = folder[0][:10]
    p_numb = ""
    p_name = ""
    if code[-3:] == "xxx":
        p_numb = folder[0][13:][:10]
        p_name = folder[0][24:]
    elif code[5] == "-":
        p_numb = folder[0][:10]
        p_name = folder[0][11:]
    elif code[-1] == " ":
        p_numb = folder[0][:5] + "-" + folder[0][5:9]
        p_name = folder[0][10:]
    
    if p_numb != "":
        # Append the tuple with the full folder path
        aux_list.append((p_numb, p_name, folder[1]))

Projects = sorted(aux_list, reverse=True)
OUT = Projects