#------------------------------------------------------
#---------ST-01-Find QA folder information.py----------
#------------------------------------------------------

# Load Libraries
#------------------------------------------------------
import os
import clr
clr.AddReference("RevitServices")
import RevitServices
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
uiapp = DocumentManager.Instance.CurrentUIApplication
uidoc = uiapp.ActiveUIDocument
doc = uidoc.Document

from Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory
from System.Windows.Forms import MessageBox, MessageBoxButtons, MessageBoxIcon, DialogResult

# Variables
#------------------------------------------------------
Jobs_list = IN[1]
Initials = IN[0] # 0-Revit Library Path, 1-User, 2-Start time
test = ""
Test = []
aux_list = []
General_List_Info = []
p_Info = [""]
notes = [""] * 3
sheets = [""]

# Functions
#------------------------------------------------------


# Code
#------------------------------------------------------

project_info = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_ProjectInformation).FirstElement()
project_number = project_info.LookupParameter("Project Number").AsString()


p_Numb = None
for job in Jobs_list:
    if job[0] == project_number:
        p_Numb = project_number
        p_Loc = job[2]        
        break
next_step = False
file_exists = False

if p_Numb:
    QA_path = os.path.join(p_Loc,"QA","Certification and Check Sheets",p_Numb + "_QA_Checklist.xlsx") # Search for QA excel file
    file_exists = os.path.exists(QA_path)
    
    if file_exists:
        p_Info[0] = p_Numb
        next_step = True
    
    else:
        mssg = "There is no project information setup for this project. Please execute 'New Project' Tool before make changes \n \n " + str(project_number) + "_QA_Check list file not founded"
        result = MessageBox.Show(mssg, "Information", MessageBoxButtons.OK)

else:
    mssg = "OneDrive short cut not founded for this project number. Please use STP Tools for project setup. \n \n " + str(project_number) + " Shortcut not founded"
    result = MessageBox.Show(mssg, "Information", MessageBoxButtons.OK)

General_List_Info.append(next_step)
General_List_Info.append(p_Loc)
General_List_Info.append(p_Info)
General_List_Info.append(notes)
General_List_Info.append(sheets)

OUT = Initials, General_List_Info