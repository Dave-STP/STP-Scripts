#-----------------------------------------------------------------------------------
#---------------------------PY-50_Import Notes.py----------------------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import os
import sys
import time
from datetime import datetime
from pyrevit import script, DB, revit, forms
from System.Windows.Controls import CheckBox, Panel, ContentControl
from System.Collections.Generic import List

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
p_Type = project_Type
functions_path = Lib_Path + r"\Codes and Functions\Structural Codes\STP_Functions"
sys.path.append(functions_path)
import Family_load_functions
from Family_load_functions import *

import Import_Notes_functions
from Import_Notes_functions import *

import STP_Tools_Functions
from STP_Tools_Functions import *

# Constants
#----------
doc = __revit__.ActiveUIDocument.Document
app = doc.Application
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
revit_version = revit.doc.Application.VersionNumber[2:]
rvt = int(revit_version)

# General_Variables
#------------------
final_report = ""
script_path = script.get_script_path()
Load_List = []
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()
f15_options = ["STP_Brisbane_A4_Form 15", "STP_Mackay_A4_Form 15", "STP_Mackay_A4_Form 15 (Altern. AS4055)"]

# Local Variables, Lists and Path
#------------------
xaml_file_name = "General Notes Form.axml"
not_created_sheets = []
stp_no_title = None
extra_data = {
        # Read params
        "ini_type": "",
        "qa_revit_version": "",
        "first_user": "",
        "tb_history": [],
        # Write params
        "p_type": "",
        "initials": ""
    }


# Local Functions
#------------------
def get_all_checkboxes(parent):
    checkboxes = []

    # If it's a CheckBox, add it to the list
    if isinstance(parent, CheckBox):
        checkboxes.append(parent)

    # If it�s a panel (like StackPanel, Grid, etc.), iterate its children
    elif isinstance(parent, Panel):
        for child in parent.Children:
            checkboxes.extend(get_all_checkboxes(child))

    # If it�s a ContentControl (like GroupBox), look into its Content
    elif isinstance(parent, ContentControl) and parent.Content:
        checkboxes.extend(get_all_checkboxes(parent.Content))

    return checkboxes

def get_titleblock_type(family_name):
    collector = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).OfCategory(DB.BuiltInCategory.OST_TitleBlocks)
    for tb in collector:
        if tb.Family.Name == family_name.replace(".rfa",""):
            return tb
    return None

def creat_sheet_set(numbs, names, family):
    global not_created_sheets

    for numb, name in zip(numbs, names):
        if numb in existing_numbers or name in existing_sheets:
            name_aux = name + " (copy)"
            not_created_sheets.append(numb + " - " + name_aux)
        else:
            name_aux = name
        try:
            sheet = ViewSheet.Create(doc, family.Id)
            sheet.Name = name_aux
            sheet.SheetNumber = numb

            cover_collector = FilteredElementCollector(doc, sheet.Id).OfCategory(BuiltInCategory.OST_TitleBlocks).ToElements()
            for tb in cover_collector:
                for cover_p in cover_parameters:
                    if tb.LookupParameter(cover_p) is not None:
                        tb.LookupParameter(cover_p).Set(False)
                for off in off_parameters:
                    if tb.LookupParameter(off) is not None:
                        tb.LookupParameter(off).Set(False)
        except Exception as e:
            pass

#------------------------------------------------------------------------------------
#----------- GET PROJECT FOLDER -----------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Read Project Folders"
local_report, projects = get_project_folders_from_onedrive(user_name, Lib_Path, stage)
final_report += local_report

if not projects:
    mssg = "No Project Folders Found. \n\n" + \
           "Please make sure OneDrive shortcuts are available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    aborting_script(final_report, "Project Folders not Found", mssg)

stage = "Get Project Information"
local_report, Info_Data = get_project_info(doc, stage)

final_report += local_report
if Info_Data:
    p_Numb, p_Name, p_Address, p_Suburb, p_Pcode, p_Client = Info_Data[0:6]
    
    pnumb_exists = False
    for project in projects:
        if p_Numb in project[0]:
            pnumb_exists = True
            p_Path = project[2]
            local_report, qa_info_exists, qa_path = get_qa_path(Lib_Path, p_Path, p_Numb, stage, extra_data)
            final_report += local_report
            break
    
if not pnumb_exists:
    
    mssg = "The Project Number from this file was not found. \n\n" + \
           "Project Number:\n" + p_Numb + " [Not Found]\n\n" + \
           "Please check the Job Number or make sure the OneDrive shortcut is available on your computer. " + \
           "If the problem persists, contact the STP Tools Admin for further support."
    forms.alert(mssg)
    sys.exit()
    
# endregion

#------------------------------------------------------------------------------------
#----------- PRE-FORM CHECK AND LOAD ------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Preliminar Checks"

check_all_good = [os.path.exists(Lib_Path), os.path.exists(functions_path)]
if not all (check_all_good):
    forms.alert("Internal error [E00]. Please report it to STP Tools developer", "Error")
    sys.exit()

# Get the viewport types
viewports = DB.FilteredElementCollector(doc).OfClass(DB.Viewport).ToElements()

viewport_types = set()
for vp in viewports:
    type_element = doc.GetElement(vp.GetTypeId())
    if type_element:
        if vp.Name == "STP NO TITLE":
            stp_no_title = type_element
            break

# endregion

#------------------------------------------------------------------------------------
#----------- READ QA FILE -----------------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Read QA File"
tb_name = ""
test = False
if not test:
    if qa_info_exists: 
        local_report, last_qa_line = read_qa_excel_file_V2(qa_path, stage, extra_data)
        final_report += local_report
        tb_name = last_qa_line[6]

    if not tb_name:
        mssg = (
            "No QA Check List file found for this project.\n\n" + \
            "Do you want to continue and select an existing title block from this file?"
            )
        result = forms.alert(mssg, title="TITLE BLOCK NOT FOUND", options=["Yes", "No"])
            
        if result == "Yes":
            current_tblock = []
            xref_tblocks = []
            selected_tb = None

            collector = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).OfCategory(DB.BuiltInCategory.OST_TitleBlocks)
            for tb in collector:
                current_tblock.append("(From Current File) - " + tb.Family.Name)

            xrev_path = os.path.join(p_Path, "Drawings", "xref")
            if os.path.exists(xrev_path):
                rfa_files = [f for f in os.listdir(xrev_path) if f.endswith('.rfa')]
                xref_tblocks = ["(From Xrev Folder ) - " + f.replace(".rfa","") for f in rfa_files] if rfa_files else []
                if xref_tblocks and current_tblock:
                    current_tblock.extend(xref_tblocks)
            
            selected_tb = forms.SelectFromList.show(
                current_tblock,
                title = "Select a title block",
                multiselect = False
                )

            if selected_tb:
                tb_name = selected_tb[22:] + ".rfa"


else:
    tb_name = 'STP25-5555_A0_VERTICAL.rfa' # Delete this one at the end

if not tb_name:
    sys.exit()
# endregion


#-----------------------------------------------------------------------------------
#-------------------------- MAIN WINDOW FORM ---------------------------------------
#-----------------------------------------------------------------------------------

class StructuralTypeForm(forms.WPFWindow):
    def __init__(self, xaml_file_path):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.go_for_import = False

        # Hook triggers
        #---------------------------
        self.chbF15.Click += self.on_enabled_changed
        self.chbSite.Click += self.on_enabled_changed
        self.chbFoot.Click += self.on_enabled_changed
        self.chbSslab.Click += self.on_enabled_changed
        self.chbRoof.Click += self.on_enabled_changed
        self.btnLess.Click += self.on_levels_changed
        self.btnMore.Click += self.on_levels_changed

        self.btnAll.Click += self.on_select_all
        self.btnCancel.Click += self.on_cancel
        self.btnImport.Click += self.on_import

        # Prefill textbox and combos
        #---------------------------
        self.txbLevels.Text = "1"
        self.cmbF15.ItemsSource = f15_options
        self.cmbF15.SelectedIndex = 0

        # Actions
        #---------------------------
        self.on_enabled_changed(self, None)
        
    def on_enabled_changed(self, sender, args):
        self.cmbF15.IsEnabled = self.chbF15.IsChecked
        self.chbSiteDet.IsEnabled = self.chbSite.IsChecked
        self.chbFootSep.IsEnabled = self.chbFoot.IsChecked
        self.chbPost.IsEnabled = self.chbSslab.IsChecked
        self.gpoLevels.IsEnabled = self.chbSslab.IsChecked
        self.chbElev.IsEnabled = self.chbRoof.IsChecked

    def on_levels_changed(self, sender, args):
        if sender == self.btnLess and int(self.txbLevels.Text) > 1:
            self.txbLevels.Text = str(int(self.txbLevels.Text) - 1)
        elif sender == self.btnMore:
            self.txbLevels.Text = str(int(self.txbLevels.Text) + 1)

    def on_select_all(self, sender, args):
        checkboxes = get_all_checkboxes(self.Content)
        if sender.Content == "Select All":
            change = True
            sender.Content = "Deselect All"
        else:
            change = False
            sender.Content = "Select All"
        
        for cb in checkboxes:
            cb.IsChecked = change
        self.on_enabled_changed(self, None)

    def on_cancel(self, sender, args):
        self.Close()

    def on_import(self, sender, args):
        global Load_list
        checkboxes = get_all_checkboxes(self.Content)
        for cb in checkboxes:
            if cb.IsChecked:
                Load_List.append(cb.Name)
                
        if Load_List:
            self.go_for_import = True
            self.Close()
        else:
            forms.alert("Please select at least one option", "Information")

# Show the form
form = StructuralTypeForm(xaml_file_name)
form.ShowDialog()
pb_total = 5
if not form.go_for_import:
    sys.exit()


# Name of the views to copy from Notes
notesA0 = ["STP_ GEN NOTES SHEET 1", "STP_ALL WHS NOTES", "SAFETY IN DESIGN"]
notesA1 = ["STP_ GEN NOTES SHEET 1", "STP_ GEN NOTES SHEET 2", "STP_ GEN NOTES SHEET 3", "STP_ALL WHS NOTES", "SAFETY IN DESIGN"]
notesA3 = ["STP_ GEN NOTES SHEET 1", "STP_ GEN NOTES SHEET 2", "STP_ GEN NOTES SHEET 3", "STP_ALL WHS NOTES", "SAFETY IN DESIGN SHEET 1"]

# Number of the sheets where the notes go
s_numbA0 = ["S001", "S002"]
s_numbA1 = ["S001", "S002", "S003", "S004"]
s_numbA3 = ["S001", "S002", "S003", "S004"]

# Name of the sheets where the notes go
s_nameA0 = ["STRUCTURAL NOTES SHEET 1", "W&HS AND SAFETY IN DESIGN"]
s_nameA1 = ["STRUCTURAL NOTES SHEET 1", "STRUCTURAL NOTES SHEET 2", "STRUCTURAL NOTES SHEET 3", "SAFETY IN DESIGN"]
s_nameA3 = ["STRUCTURAL NOTES SHEET 1", "STRUCTURAL NOTES SHEET 2", "STRUCTURAL NOTES SHEET 3",  "SAFETY IN DESIGN"]

order_A0 = [0, 1, 1]
order_A1 = [0, 1, 2, 2, 3]
order_A3 = [0, 1, 2, 2, 3]

cover_parameters = ["Coversheet Text","Cover Sheet Title","Visibility - Coversheet Stamps"]
off_parameters = ["North Point", "Visibility - North Point", "Project North", "Scale Bar", "NORTH POINT VISIBILITY", 
                  "SCALE BAR VISIBILITY", "NorthPoint_OrientedToProjectNorth", "NorthPoint_OrientedToTrueNorth", "Scale_As Indicated"]


#------------------------------------------------------------------------------------
#----------- GETTING TITLEBLOCKS AND EXISTING SHEET ---------------------------------
# region ----------------------------------------------------------------------------
stage = "Getting Existing Sheets"; pb_number = 0.0; Steps = 4.0

with forms.ProgressBar(title = stage) as pb:
    dx = 1 / Steps; x = 0.0; next_value = (pb_number + x) / pb_total
    pb.update_progress(next_value, 1.0)
    
    existing_sheets = []
    existing_numbers = []
    sheet_collector = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    if sheet_collector:
        dx_local = dx / float(len(sheet_collector))
        for ex_sheet in sheet_collector:
            existing_sheets.append(ex_sheet.Name)
            existing_numbers.append(ex_sheet.SheetNumber)
        x += dx_local; next_value = (pb_number + x) / pb_total#; print("x :", x, "target: ", next_value)
        pb.update_progress(next_value, 1.0)
            
    #------------------------------------------------------------------------------------
    stage = "Getting Service Load and Foundations Notes"
    serv_name = "STP_Service Loads_A3.rfa" if "A3" in tb_name else "STP_Service Loads.rfa"
    foot_name = "STP_Foundation Notes_A3.rfa" if "A3" in tb_name else "STP_Foundation Notes.rfa"
    serv_type = get_titleblock_type(serv_name)
    foot_type = get_titleblock_type(foot_name)
    serv_family = None
    foot_family = None

    if "chbNote" in Load_List:
        if serv_type:
            serv_family = serv_type
        else:
            serv_fam_path = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Notes & Legends", serv_name)
            if os.path.exists(serv_fam_path):
                with revit.Transaction("Load Service Loads Family"):
                    serv_type = doc.LoadFamily(serv_fam_path)
                serv_family = get_titleblock_type(serv_name)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)
        
        if foot_type:
            foot_family = foot_type
        else:
            foot_fam_path = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Notes & Legends", foot_name)
            if os.path.exists(foot_fam_path):
                with revit.Transaction("Load Found. Notes Family"):
                    foot_type = doc.LoadFamily(foot_fam_path)
                foot_family = get_titleblock_type(foot_name)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)

    #------------------------------------------------------------------------------------
    stage = "Getting Form 15 Title Block"

    f15_Bne = [r"STP Structural\Notes & Legends\BNE Form 15\STP_BNE_A4_Form 15 - Page 1 ", 
              r"STP Structural\Notes & Legends\BNE Form 15\STP_BNE_A4_Form 15 - Page 2 "]
    f15_Mck = [r"STP Templates\Mackay Structural Template\Template Extras\STP_A4_Form 15 - Page 1 ", 
              r"STP Templates\Mackay Structural Template\Template Extras\STP_A4_Form 15 - Page 2 "]
    f15_list = [f15_Bne, f15_Mck, f15_Mck]

    if "chbF15" in Load_List:
        f15_index = form.cmbF15.SelectedIndex
        f15_names = []
        f15_paths = []
        f15_families = []
        f15_to_load = []

        if f15_index != -1:
            for f15 in f15_list[f15_index]:
                current_year = datetime.now().year
                for year in range(current_year + 1, current_year -10, -1):
                    rvt_version = str(year)[-2:]
                    lib_path = Lib_Path.replace("STP Tools","")
                    if "4055" in form.cmbF15.SelectedItem and "Page 2" in f15:
                        file_name = f15 + "RVT" + rvt_version + " (Alternative).rfa"
                    else:
                        file_name = f15 + "RVT" + rvt_version + ".rfa"
                    f15_fam_path = lib_path + file_name
                    if os.path.exists(f15_fam_path):
                        f15_names.append(os.path.basename(f15_fam_path))
                        f15_paths.append(f15_fam_path)
                        break
            with revit.Transaction("Load F15 Family"):
                for f15_name, f15_path in zip(f15_names, f15_paths):
                    if os.path.exists(f15_path):
                        f15_type = doc.LoadFamily(f15_path)
                        f15_families.append(get_titleblock_type(f15_name))
    x += dx; next_value = (pb_number + x) / pb_total
    pb.update_progress(next_value, 1.0)


    #------------------------------------------------------------------------------------
    stage = "Getting Title Block Family"
    tb_type = get_titleblock_type(tb_name)
    tb_family = None

    if tb_type:
        tb_family = tb_type
    else:
        tb_qa_path = os.path.join(p_Path,"Drawings", "xref", tb_name)
        if os.path.exists(tb_qa_path):
            with revit.Transaction("Load Title Block"):
                tb_type = doc.LoadFamily(tb_qa_path)
            tb_family = get_titleblock_type(tb_name)
    x += dx; next_value = (pb_number + x) / pb_total
    pb.update_progress(next_value, 1.0)      


# endregion

#------------------------------------------------------------------------------------
#----------- CREATE COVER SHEET AND DRAWING SCHEDULE --------------------------------
# region ----------------------------------------------------------------------------
stage = "Create Cover Sheets"; pb_number += 1.0; Steps = 1.0

with forms.ProgressBar(title = stage) as pb:
    dx = 1 / Steps; x = 0.0; next_value = (pb_number + x) / pb_total
    pb.update_progress(next_value, 1.0)

    if "chbCover" in Load_List and tb_family:
        if "COVER SHEET" in existing_sheets:
            mssg = "'COVER SHEET' Already exists in the current project and won't be created."
            forms.alert (mssg, "Alert")
        else:
            if "A0" in tb_name:
                sch_x = 3.2
                sch_y = 2.5
            elif "A1" in tb_name:
                sch_x = 2.1
                sch_y = 1.7
            elif "A3" in tb_name:
                sch_x = 0.9
                sch_y = 0.9
            else:
                sch_x = 0
                sch_y = 0
        
            with revit.Transaction("Create Cover Sheet"):
                sheet = ViewSheet.Create(doc, tb_family.Id)
                sheet.SheetNumber = "S000"
                sheet.Name = "COVER SHEET"
                cover_collector = DB.FilteredElementCollector(doc, sheet.Id) \
                        .OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
                        .ToElements()
                for tb in cover_collector:
                    for cover_p in cover_parameters:
                        if tb.LookupParameter(cover_p) is not None:
                            tb.LookupParameter(cover_p).Set(True)
                    for off in off_parameters:
                        if tb.LookupParameter(off) is not None:
                            tb.LookupParameter(off).Set(False)            
                    
                scheduleName = "STRUCTURAL DRAWING LIST"
                collector = DB.FilteredElementCollector(doc)
                all_schedules = collector.OfClass(DB.ViewSchedule).ToElements()
                schedule = [s for s in all_schedules if s.Name == scheduleName][0] # STRUCTURAL DRAWING LIST (Revit Element)
                schedule_instance = DB.ScheduleSheetInstance.Create(doc, sheet.Id, schedule.Id, DB.XYZ(sch_x, sch_y, 0))
    
    x += dx_local; next_value = (pb_number + x) / pb_total
    pb.update_progress(next_value, 1.0)
# endregion

#------------------------------------------------------------------------------------
#----------- IMPORT NOTE SHEETS AND ADD AUXILIAR TBLOCKS ----------------------------
# region ----------------------------------------------------------------------------
stage = "Import Note Sheets"; pb_number += 1.0; Steps = 3.0

dx = 1 / Steps; x = 0.0; next_value = (pb_number + x) / pb_total
pb.update_progress(next_value, 1.0)
sheets = []

if "chbNote" in Load_List:
    if tb_family:
        size_letter = "A1" # If the title block doesn't contain A1, A1, A3 in the name. Consider as A1
        if "A0" in tb_name:
            notes = notesA0
            order = order_A0
            s_numbs = s_numbA0
            s_names = s_nameA0
            size_letter = "A0"
            serv_point = DB.XYZ(0.791, 2.700, 0)
            foot_point = DB.XYZ(0.115, 0.817, 0)
        elif "A3" in tb_name:
            notes = notesA3
            order = order_A3
            s_numbs = s_numbA3
            s_names = s_nameA3
            size_letter = "A3"
            serv_point = DB.XYZ(0.404, 0.941, 0)
            foot_point = DB.XYZ(0.404, 0.369, 0)
        else:
            notes = notesA1
            order = order_A1
            s_numbs = s_numbA1
            s_names = s_nameA1
            size_letter = "A1"
            serv_point = DB.XYZ(0.774, 1.886, 0)
            foot_point = DB.XYZ(0.774, 0.775, 0)

        if tb_name:
            with revit.Transaction("Import Note Sheets"):
                serv_included = False
                dx_local = dx / float(len(s_numbs))
                for j, s in enumerate(s_numbs):
                    if s_names[j] not in existing_sheets:
                        sheet = DB.ViewSheet.Create(doc, tb_family.Id)
                        sheet.SheetNumber = s
                        sheet.Name = s_names[j]
                        sheets.append(sheet)
                    else:
                        sheets.append(sheet_collector[existing_sheets.index(s_names[j])])

                    cover_collector = DB.FilteredElementCollector(doc, sheet.Id) \
                        .OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
                        .ToElements()
                    for tb in cover_collector:
                        if tb.Name in serv_name:
                            serv_included = True
                        for cover_p in cover_parameters:
                            if tb.LookupParameter(cover_p) is not None:
                                tb.LookupParameter(cover_p).Set(False)
                        for off in off_parameters:
                            if tb.LookupParameter(off) is not None:
                                tb.LookupParameter(off).Set(False)

                    if sheet.SheetNumber == "S001" and not serv_included:
                        doc.Create.NewFamilyInstance(serv_point, serv_family, sheet)
                        doc.Create.NewFamilyInstance(foot_point, foot_family, sheet)

                    x += dx_local; next_value = (pb_number + x) / pb_total
                    pb.update_progress(next_value, 1.0)

                # STP Drafting - Revit Library \ .....Notes & Legends\STP_General Notes - A0.rvt
                notesPath = Lib_Path.replace(r"\STP Tools",r"\STP Structural\Notes & Legends\STP_General Notes - " + size_letter + ".rvt") 
                modelPath = DB.ModelPathUtils.ConvertUserVisiblePathToModelPath(notesPath)

                options = DB.OpenOptions()
                options.DetachFromCentralOption = DB.DetachFromCentralOption.DetachAndPreserveWorksets

                docOnDisk = app.OpenDocumentFile(modelPath, options)
                views = DB.FilteredElementCollector(docOnDisk).OfCategory(DB.BuiltInCategory.OST_Views)

                #with forms.ProgressBar(title = stage) as pb:
                #Copy Notes Drafting Views from file (e.g. = "STP_General Notes - A1.rvt")
                view_order = []
                copiedViews = []
                aux = list(views)
                dx_local = dx / float(len(aux)) if views else dx
                for view in views:
                    if view.Name in notes:
                        view_order.append(notes.index(view.Name))
                        copiedView = DB.ElementTransformUtils.CopyElements(docOnDisk, List[DB.ElementId]([view.Id]), doc, DB.Transform.Identity, DB.CopyPasteOptions())
                        copiedViews.append(copiedView) # 4195921, 419...., 419.....
                        targetView = doc.GetElement(copiedView[0]) # copiedViews as Revit Elements
                        collector = DB.FilteredElementCollector(docOnDisk, view.Id)
                        sourceElements = list(collector.ToElements())
                        if sourceElements:
                            sourceElements.pop(0)
                        copiedElements = DB.ElementTransformUtils.CopyElements(view, List[DB.ElementId]([elem.Id for elem in sourceElements]), targetView, DB.Transform.Identity, DB.CopyPasteOptions())
                    x += dx_local; next_value = (pb_number + x) / pb_total
                    pb.update_progress(next_value, 1.0)
                docOnDisk.Close(False)

                flat_list = flatten_list(copiedViews)
                copiedViews = [""] * len(view_order)
                for index, detail in enumerate(flat_list):
                    copiedViews[view_order[index]] = detail

                file_path = Lib_Path + r"\Data Base\List_Coordinates.txt"
                code = "STP_"+ size_letter

                # Extract the lines and output them
                points = extract_lines(file_path, code)
                
                # First, collect all available viewport types
                viewport_types = DB.FilteredElementCollector(doc)\
                    .OfClass(DB.ElementType)\
                    .OfCategory(DB.BuiltInCategory.OST_Viewports)\
                    .ToElements()

                dx_local = dx / float(len(order))
                for i, o in enumerate(order):
                    viewport = DB.Viewport.Create(doc, sheets[order[i]].Id, copiedViews[i], points[i])
                    x += dx_local; next_value = (pb_number + x) / pb_total
                    pb.update_progress(next_value, 1.0)

                    # Change the type if "No Title" exists
                    if stp_no_title:
                        viewport.ChangeTypeId(stp_no_title.Id)
        else:
            forms.alert("Choose a title block", "Change")

# endregion

#------------------------------------------------------------------------------------
#----------- IMPORT FORM 15 ---------------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Create F15 page"; pb_number += 1.0; Steps = 2.0

with forms.ProgressBar(title = stage) as pb:
    dx = 1 / Steps; x = 0.0; next_value = (pb_number + x) / pb_total
    pb.update_progress(next_value, 1.0)

    f15_s1 = None
    f15_s2 = None
    f15_point = DB.XYZ(0,0,0)

    if "chbF15" in Load_List:
        with revit.Transaction("Create Form 15 Sheet"):
            for sheet in sheet_collector:
                if sheet.SheetNumber == "SF15":
                    f15_s1 = sheet
                    try:
                        sheet.Name = "STRUCTURAL FORM 15 Page 1"
                    except:
                        pass
                    
                elif sheet.SheetNumber == "SF15a":
                    f15_s2 = sheet
                    try:
                        sheet.Name = "STRUCTURAL FORM 15 Page 2"
                    except:
                        pass
                
            x += dx; next_value = (pb_number + x) / pb_total
            pb.update_progress(next_value, 1.0)

            if f15_s1:
                doc.Create.NewFamilyInstance(f15_point, f15_families[0], f15_s1)
            else:
                sheet = ViewSheet.Create(doc, f15_families[0].Id)
                sheet.SheetNumber = "SF15"
                sheet.Name = "STRUCTURAL FORM 15 Page 1"
            
            if f15_s2:
                doc.Create.NewFamilyInstance(f15_point, f15_families[1], f15_s2)
            else:
                sheet = ViewSheet.Create(doc, f15_families[1].Id)
                sheet.Name = "STRUCTURAL FORM 15 Page 2"
                sheet.SheetNumber = "SF15a"

# endregion

#------------------------------------------------------------------------------------
#----------- CREATE SHEET SETS ------------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Create Sheets"; pb_number += 1.0; Steps = 8.0

with forms.ProgressBar(title = stage) as pb:
    dx = 1 / Steps; x = 0.0; next_value = (pb_number + x) / pb_total
    pb.update_progress(next_value, 1.0)
    
    with revit.Transaction("Ground Level Sheets"):

        s010_numbs = ["S010", "S020", "S030", "S031", "S032"]
        s010_names = ["SITE TYPICAL SLAB & FOOTING DETAILS", "SITE TYPICAL  MASONRY DETAILS SHEET 1", "SITE TYPICAL SUSPENDED SLAB DETAILS", 
                     "SITE TYPICAL CONCRETE COLUMN DETAILS", "SITE TYPICAL STAIR SECTIONS AND DETAILS"]
        if "chbMult" in Load_List:
            creat_sheet_set(s010_numbs, s010_names, tb_family)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)
    #------------------------------------------------------------------------------------
        s050_numbs = ["S050"]
        s050_names = ["SITE PLAN"]
        if "chbSite" in Load_List:
            creat_sheet_set(s050_numbs, s050_names, tb_family)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)
    #------------------------------------------------------------------------------------
        s060_numbs = ["S060", "S061"]
        s060_names = ["SITE SECTIONS", "SITE DETAILS"]
        if "chbSiteDet" in Load_List and "chbSite" in Load_List:
            creat_sheet_set(s060_numbs, s060_names, tb_family)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)
    #------------------------------------------------------------------------------------
        det_numbs = ["S110", "S111", "S112", "S120"]
        det_names = ["TYPICAL SLAB & FOOTING DETAILS SHEET 1", "TYPICAL SLAB & FOOTING DETAILS SHEET 2", "SLAB & FOOTING DETAILS", "SLAB & FOOTING SECTIONS"]
        if "chbFootSep" in Load_List and "chbFoot" in Load_List:
            s100_numbs = ["S090", "S100"]
            s100_names = ["FOUNDATION PLAN", "SLAB ON GROUND PLAN"]
        else:
            s100_numbs = ["S100"]
            s100_names = ["SLAB & FOOTING PLAN"]
        s100_numbs.extend(det_numbs); s100_names.extend(det_names)
        if "chbFoot" in Load_List:
            creat_sheet_set(s100_numbs, s100_names, tb_family)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)
    #------------------------------------------------------------------------------------
        s150_numbs = ["S150","S151"]
        s150_names = ["BASE PLATE PLAN", "BASE PLATE DETAILS"]
        if "chbBplate" in Load_List:
            creat_sheet_set(s150_numbs, s150_names, tb_family)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)
    #------------------------------------------------------------------------------------
    slab_names = ["SLAB PROFILE PLAN", "BOTTOM REINFORCEMENT PLAN", "TOP REINFORCEMENT PLAN"]
    post_names = ["POST TENSIONING PLAN EAST/WEST", "POST TENSIONING PLAN NORTH-SOUTH"]
    rcdt_names = ["R.C BEAM ELEVATIONS & SECTIONS"]
    sdet_names = ["SUPSENDED SLAB DETAILS"]
    strs_names = [""]
    s200_numbs = ["S290"]
    s200_names = ["TYPICAL SUSPENDED SLAB DETAILS"]
    new = True

    def next_numbers(next_list, level):
        global new
        extend_list = []
        last_number = s200_numbs[-1]
        for next in next_list:
            last_digit = last_number[-1]
            next_digit = int(last_digit) + 1
            if new:
                next_number = "S2" + level +"0"
                new = False
            else:
                next_number = last_number[:-1] + str(next_digit)
            extend_list.append(next_number)
            last_number = next_number

        return extend_list

    def adjust_name_with_levels(basic_list, level):
        new_list = []
        for item in basic_list:
            new_list.append("LEVEL " + level + " " + item)
        if new_list:
            return new_list
        else:
            return []

    if "chbSslab" in Load_List:
        with revit.Transaction("Suspended Slab Sheets"):
            n_levels = form.txbLevels.Text
            if n_levels == "1":
                s200_numbs.extend(next_numbers(slab_names, "0"))
                s200_names.extend(slab_names)
                new = False
                if "chbPost" in Load_List:
                    s200_numbs.extend(next_numbers(post_names, "0"))
                    s200_names.extend(post_names)
                if "chbRC" in Load_List:
                    s200_numbs.extend(next_numbers(rcdt_names, "0"))
                    s200_names.extend(rcdt_names)
                s200_numbs.extend(next_numbers(sdet_names, "0"))
                s200_names.extend(sdet_names)
            else:
                s200_numbs = ["S200", "S201", "S295" if "chbRC" in Load_List else "S290"]
                s200_names = ["TYPICAL SUSPENDED SLAB DETAILS", "SUSPENDED SLAB KEY PLAN", "CONCRETE STAIR ELEVATION & DETAILS"]
            
                for n in range(int(n_levels)):
                    level = str(n+1)
                    s200_numbs.extend(next_numbers(slab_names, level))
                    s200_names.extend(adjust_name_with_levels(slab_names, level))
                    if "chbPost" in Load_List:
                        s200_numbs.extend(next_numbers(post_names, level))
                        s200_names.extend(adjust_name_with_levels(post_names, level))
                    if "chbRC" in Load_List:
                        s200_numbs.extend(next_numbers(rcdt_names, level))
                        s200_names.extend(adjust_name_with_levels(rcdt_names, level))
                    s200_numbs.extend(next_numbers(sdet_names, level))
                    s200_names.extend(adjust_name_with_levels(sdet_names, level))
                    new = True
                if "chbRC" in Load_List:
                    s200_numbs.append("S290")
                    s200_names.append("CONCRETE COLUMN ELEVATIONS & DETAILS")


            creat_sheet_set(s200_numbs, s200_names, tb_family)
            x += dx; next_value = (pb_number + x) / pb_total
            pb.update_progress(next_value, 1.0)
        
    with revit.Transaction("Walls and Roof"):

        panl_numbs = ["S300", "S350", "S360"]
        panl_names = ["PRECAST PANEL LAYOUT", "PRECAST PANEL ELEVATIONS SHEET 1", "PRECAST PANEL FIXING DETAILS SHEET 1"]
        wall_numbs = ["S310", "S370", "S380"] if "chbPcast" in Load_List else ["S300", "S350", "S360"]
        wall_names = ["GROUND FLOOR BLOCK WORK WALL FRAMING PLAN", "BLOCK WORK WALL ELEVATIONS", "BLOCK WORK WALL DETAILS"]
        s300_numbs = []
        s300_names = []

        if "chbPcast" in Load_List:
            s300_numbs.extend(panl_numbs)
            s300_names.extend(panl_names)
        if "chbWall" in Load_List:
            s300_numbs.extend(wall_numbs)
            s300_names.extend(wall_names)
            if "chbSslab" in Load_List:
                n_levels = form.txbLevels.Text
                if n_levels != "1":
                    for n in range(int(n_levels)-1):
                        level = str(n+1)
                        numb_to_show = str(n+2) if "chbPcast" in Load_List else level
                        s300_numbs.append("S3" + numb_to_show + "0")
                        s300_names.append("LEVEL " + level + " BLOCKWORK WALL FRAMING PLAN")
        
        creat_sheet_set(s300_numbs, s300_names, tb_family)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)
    #------------------------------------------------------------------------------------
        s400_numbs = ["S400","S420"]
        s400_names = ["ROOF FRAMING PLAN", "STEELWORK DETAILS SHEET 1"]
        if "chbRoof" in Load_List:
            if "chbElev" in Load_List:
                s400_numbs.append("S410")
                s400_names.append("STEELWORK FRAMING SECTIONS AND ELEVATIONS SHEET 1")

            creat_sheet_set(s400_numbs, s400_names, tb_family)
        x += dx; next_value = (pb_number + x) / pb_total
        pb.update_progress(next_value, 1.0)

# endregion
if not not_created_sheets:
    forms.alert("All done " + user_name + ".\n\nNotes and Sheets successfully imported")
else:
    mssg = "The following sheets were renamed because they already exist in the current document::\n\n"
    mssg += "\n".join(not_created_sheets)
    forms.alert(mssg, title="Not all sheets loaded")


#--------------------------------------------------------------------
#----------- REPORT SAVING TIME TO DATA BASE ------------------------
# region ------------------------------------------------------------
stage = "Tracking Data"
new_line = ""
file_path = os.path.join(Lib_Path, "STP Tracking", "Data.txt")
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
cant = int(len(Load_List))

if os.path.exists(qa_path):
    final_report += fill_tracking_data(file_path, p_Numb, user_name, "Import Notes", "3.0", start_time, end_time, str(cant), stage)

# endregion

