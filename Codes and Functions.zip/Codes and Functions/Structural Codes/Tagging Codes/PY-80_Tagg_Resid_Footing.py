import clr
import sys
clr.AddReference("RevitAPI")
from Autodesk.Revit.DB import *
from pyrevit import revit, forms

# Get document and active view
doc = __revit__.ActiveUIDocument.Document
view = doc.ActiveView

# Check if it is the right view by checking the view template
template_id = view.ViewTemplateId
if template_id != ElementId.InvalidElementId:
    view_template = doc.GetElement(template_id)
    if not view_template.Name == "STP SLAB AND FOOTING PLAN":
        msg = (
            "This is not a Slab and Footing Plan View.\n\nPlease run this tool in a view with 'STP SLAB AND FOOTING PLAN' View Template to continue."
        )
        result = forms.alert(msg, title="Confirm Action")
        sys.exit()


def order_points(start, end, points):
    total_length = (start - end).GetLength()

    new_points = [start, end]
    new_lines = []
    values = [0.0, total_length]
    for x, pt in enumerate(points):
        dist = (pt - start).GetLength()
        if dist > 3.28 and total_length - dist > 3.28:
            for y, val in enumerate(values):
                if dist > val:
                    count = y + 1
            new_points.insert(count, pt)
            values.insert(count, dist)
    if len(new_points) > 2:
        for n in range(0, len(new_points)-1):
            distance = new_points[n].DistanceTo(new_points[n+1])
            if distance > 0.1:
                new_lines.append(Line.CreateBound(new_points[n], new_points[n+1]))
        return new_lines
    else:
        return None

# Function to get intersection points
def get_intersection_points(curve1, curve2):
    result_array = clr.Reference[IntersectionResultArray]()
    result = curve1.Intersect(curve2, result_array)

    if result == SetComparisonResult.Overlap:
        intersection_results = result_array.Value
        if intersection_results and intersection_results.Size > 0:
            return [res.XYZPoint for res in intersection_results]

    return []

# ------------------------------------------------------------------
# ------ GET TAGS AND COLLECTORS -----------------------------------
# region -----------------------------------------------------------

beam_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_StructuralFramingTags)\
    .ToElements()

footing_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_StructuralFoundationTags)\
    .ToElements()

selected_beam_tag = None
selected_footing_tag = None
    
for tag_type in beam_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "STANDARD":
        selected_beam_tag = tag_type
        break

for tag_type in footing_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "FOOTING 45":
        selected_footing_tag = tag_type
        break
#endregion

#--------------------------------------------------------------------------
#----------------- TAG BORED PIERS ----------------------------------------
#region--------------------------------------------------------------------

# Collect structural footings elements in active view
footing_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_StructuralFoundation)\
    .WhereElementIsNotElementType()

with revit.Transaction("Footing Tag"):
    for footing in footing_collector:
        type_id = footing.GetTypeId()
        elem_type = doc.GetElement(type_id)

        param = elem_type.LookupParameter("b")
        if param:
            diam = param.AsDouble() * 0.85
        else:
            diam = 0.0

        offset_vector = XYZ(diam, diam, 0)

        loc = footing.Location

        if isinstance(loc, LocationPoint):
            base_point = loc.Point

        elif isinstance(loc, LocationCurve):
            # Get midpoint of the footing
            base_point = loc.Curve.Evaluate(0.5, True)

        else:
            continue

        point = base_point + offset_vector

        IndependentTag.Create(
            doc,
            selected_footing_tag.Id,
            view.Id,
            Reference(footing),
            False,
            TagOrientation.Horizontal,
            point
        )
#endregion


# Collect structural framing elements in active view
framing_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_StructuralFraming)\
    .WhereElementIsNotElementType()

# Filter beams with STP Schedule = "G"
selected_beams = []
for elem in framing_collector:
    type_id = elem.GetTypeId()
    elem_type = doc.GetElement(type_id)
    param = elem_type.LookupParameter("STP Schedule")
    par_b = elem_type.LookupParameter("b")
    if not par_b:
        par_b = elem.LookupParameter("b")
    
    if param and param.AsString() == "G":
        if par_b and par_b.AsDouble() > 0.48:
            loc = elem.Location
            if isinstance(loc, LocationCurve) and loc.Curve:
                selected_beams.append((elem, loc.Curve))

tag_lines = []
tag_beams = []

#--------------------------------------------------------------------------
#----------------- JUST TAG ------------------------------------------
#region--------------------------------------------------------------------
if not split:
    for i in range(len(selected_beams)):
        mark_ = ""
        param = selected_beams[i][0].LookupParameter("Mark")
        if param and param.AsString()!= "":
            mark_ = param.AsString()
        try:
            beam1, curve1 = selected_beams[i]
            level = doc.GetElement(beam1.LevelId)
            s_point = curve1.GetEndPoint(0)
            e_point = curve1.GetEndPoint(1)
            int_points = []
        
            for j in range(len(selected_beams)):
                if i == j:
                    continue    
                beam2, curve2 = selected_beams[j]
                points = get_intersection_points(curve1, curve2)

                for point in points:
                    if point:
                        int_points.append(point)
            if len(int_points) > 0:
                new_lines = order_points(s_point, e_point, int_points)
                if new_lines:
                    for line in new_lines:
                        tag_lines.append(line)
                        tag_beams.append(beam1)
                else:
                    line = Line.CreateBound(s_point, e_point)
                    tag_lines.append(line)
                    tag_beams.append(beam1)
        except Exception as e:
            #print(str(e))
            sys.exit()

    
      

    # 500 mm in feet
    offset = 500 / 304.8 

    with revit.Transaction("Tag Beam Footings"):
        for elem, line in zip(tag_beams, tag_lines):
            if line.Length > 3.28:
                location = elem.Location
                if isinstance(location, LocationCurve):
                    curve = location.Curve
                    point = line.Evaluate(0.5, True)  # midpoint

                    # Beam direction vector
                    direction = (curve.GetEndPoint(1) - curve.GetEndPoint(0)).Normalize()

                    # Perpendicular in XY plane
                    perp_vector = XYZ(-direction.Y, direction.X, 0).Normalize()

                    # Flip the perpendicular vector to always go to positive Y
                    if perp_vector.Y < 0:
                        perp_vector = perp_vector.Negate()

                    # Offset point
                    point = point + perp_vector.Multiply(offset)

                else:
                    continue

                new_tag = IndependentTag.Create(
                    doc,
                    view.Id,
                    Reference(elem),
                    False,
                    TagMode.TM_ADDBY_CATEGORY,
                    TagOrientation.Horizontal,
                    point
                )
#endregion   

#--------------------------------------------------------------------------
#----------------- SPLIT AND TAG -----------------------------------------------
#region--------------------------------------------------------------------

if split:
    # Find and print intersections (avoiding duplicate checks)
    with revit.Transaction("Intersect Beams"):
        delete_beams = []
        for i in range(len(selected_beams)):
            beam1, curve1 = selected_beams[i]
            level = doc.GetElement(beam1.LevelId)
            s_point = curve1.GetEndPoint(0)
            e_point = curve1.GetEndPoint(1)
            int_points = []
        
            for j in range(len(selected_beams)):
                if i == j:
                    continue    
                beam2, curve2 = selected_beams[j]
                points = get_intersection_points(curve1, curve2)

                for point in points:
                    if point:
                        int_points.append(point)

            if len(int_points) > 0:
                new_lines = order_points(s_point, e_point, int_points)
                if new_lines:
                    for line in new_lines:
                        new_beam = doc.Create.NewFamilyInstance(line, beam1.Symbol, level, beam1.StructuralType)
                    delete_beams.append(beam1)
    
        for del_beam in delete_beams:
            id_ = del_beam.Id
            doc.Delete(del_beam.Id)
               
    # Collect structural framing elements in active view
    framing_collector = FilteredElementCollector(doc, view.Id)\
        .OfCategory(BuiltInCategory.OST_StructuralFraming)\
        .WhereElementIsNotElementType()

    # 500 mm in feet
    offset = 500 / 304.8 
    with revit.Transaction("Tag Beam Footings"):
        for elem in framing_collector:
            type_id = elem.GetTypeId()
            elem_type = doc.GetElement(type_id)
            param = elem_type.LookupParameter("STP Schedule")
    
            if param and param.AsString() == "G":
                location = elem.Location
                if isinstance(location, LocationCurve):
                    curve = location.Curve
                    point = curve.Evaluate(0.5, True)  # midpoint

                    # Beam direction vector
                    direction = (curve.GetEndPoint(1) - curve.GetEndPoint(0)).Normalize()

                    # Perpendicular in XY plane
                    perp_vector = XYZ(-direction.Y, direction.X, 0).Normalize()

                    # Flip the perpendicular vector to always go to positive Y
                    if perp_vector.Y < 0:
                        perp_vector = perp_vector.Negate()

                    # Offset point
                    point = point + perp_vector.Multiply(offset)

                elif hasattr(location, 'Point'):
                    point = location.Point
                else:
                    continue

                new_tag = IndependentTag.Create(
                    doc,
                    view.Id,
                    Reference(elem),
                    False,
                    TagMode.TM_ADDBY_CATEGORY,
                    TagOrientation.Horizontal,
                    point
                )
#endregion

