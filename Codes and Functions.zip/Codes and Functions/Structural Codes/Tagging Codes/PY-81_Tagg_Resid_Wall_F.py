#target_wall_type_name = "Stud Timber - 90 LBW + 1/PLY"  # <-- Change this to your desired wall type name

# -*- coding: utf-8 -*-
import math
import os
import sys
from Autodesk.Revit.DB import *
from pyrevit import forms, revit


# Get document and active view
doc = __revit__.ActiveUIDocument.Document
view = doc.ActiveView

# Check if it is the right view by checking the view template
template_id = view.ViewTemplateId
if template_id != ElementId.InvalidElementId:
    view_template = doc.GetElement(template_id)
    if not view_template.Name == "STP WALL FRAMING PLAN":
        msg = (
            "This is not a Wall Framing Plan View.\n\nPlease run this tool in a view with 'STP WALL FRAMING PLAN' View Template to continue."
        )
        result = forms.alert(msg, title="Confirm Action")
        sys.exit()

user = os.getenv("USERNAME")  # works on Windows


#----MAINTENANCE CODE BREAK -------------
#if not user == "Rafael":
#    print("This tool is under maintanance, thanks for waiting")
#    sys.exit()
#else:
#   print("TESTING TESTING")

up = view.UpDirection  # This is "screen up"
right = view.RightDirection  # This is "screen right"

col_b_types = ["b", "Length L"]
col_d_types = ["d", "Width W"]

def column_dimension(elem):
    x1 = 0; x2 = 0
    
    type_id = elem.GetTypeId()
    elem_type = doc.GetElement(type_id)
    
    for b in col_b_types:
        param = elem_type.LookupParameter(b)
        if param:
            x1 = param.AsDouble()
            break
    
    for d in col_d_types:
        param = elem_type.LookupParameter(d)
        if param:
            x2 = param.AsDouble()
            break
    
    return x1 if x1 > x2 else x2

def find_midpoint(point1, point2):
    x1, y1 = point1.X, point1.Y
    x2, y2 = point2.X, point2.Y

    xm = (x1 + x2) / 2
    ym = (y1 + y2) / 2

    return XYZ(xm, ym, point1.Z)

def wall_tag_points(wall):
    segments = []
    openings = wall.FindInserts(True, False, False, False) #Find doors and windows in the wall
    location = wall.Location
    curve = location.Curve
    point_1 = curve.GetEndPoint(0)
    point_2 = curve.GetEndPoint(1)
        
    Max_x = point_1.X if point_1.X > point_2.X else point_2.X
    Min_x = point_1.X if point_1.X < point_2.X else point_2.X
    Max_y = point_1.Y if point_1.Y > point_2.Y else point_2.Y
    Min_y = point_1.Y if point_1.Y < point_2.Y else point_2.Y

    if Max_x - Min_x > Max_y - Min_y:
        c = "x"
        Max = Max_x
        Min = Min_x
    else:
        c = "y"
        Max = Max_y
        Min = Min_y
    
    
    
    if openings:
        gaps = [Min]
        widths = [0]
        centres = []
        for lt in openings:
            lintel = doc.GetElement(lt)
            try:
                param = lintel.LookupParameter("Adjust_width")
            except:
                param = lintel.LookupParameter("Adjust_width")
            
            if param:
                width = param.AsDouble()
            
            offset = width/2

            location = lintel.Location
            if isinstance(location, LocationPoint):
                lintel_centre = location.Point
            elif isinstance(location, LocationCurve):
                lintel_centre = location.Curve.Evaluate(0.5, True)
            else:
                continue

            lintel_c = lintel_centre.X if c == "x" else lintel_centre.Y
            centres.append((lintel_c, offset))
        
        centres.sort()
        for centre in centres:
            gaps.append(centre[0])
            widths.append(centre[1])
        gaps.append(Max)
        widths.append(0)

        #Find mid points
        for x in range(len(gaps)-1):
            gap = abs(gaps[x]-gaps[x+1])-widths[x]-widths[x+1]
            if gap > 0.5:
                if c == "x":
                    m_point = XYZ(gaps[x] + widths[x] + gap/2, lintel_centre.Y, 0)
                else:
                    m_point = XYZ(lintel_centre.X, gaps[x] + widths[x] + gap/2, 0)
                segments.append(m_point)
    
    else:
        segments.append((point_1 + point_2)/2)
    
    return segments


# ------------------------------------------------------------------
# ------ GET TAGS --------------------------------------------------
# region -----------------------------------------------------------

wall_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_WallTags)\
    .ToElements()
    
column_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_StructuralColumnTags)\
    .ToElements()

beam_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_StructuralFramingTags)\
    .ToElements()

window_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_WindowTags)\
    .ToElements()

reo_2d_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_DetailComponentTags)\
    .ToElements()

general_details_collector = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_DetailComponents)


selected_wall_tag = None
selected_col_tag = None
selected_beam_tag = None
selected_window_tag = None
selected_reo_2d_tag = None
selected_det_item = None

for tag_type in wall_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Wall Tag":
        selected_wall_tag = tag_type
        break
    elif param and param.AsString() == "Mark":
        selected_wall_tag = tag_type

for tag_type in column_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Col Tag":
        selected_col_tag = tag_type
        break
    elif param and param.AsString() == "COLUMN OVER AND UNDER (45)":
        selected_col_tag = tag_type

for tag_type in beam_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Beam Tag":
        selected_beam_tag = tag_type
        break
    elif param and param.AsString() == "STANDARD":
        selected_beam_tag = tag_type

for tag_type in beam_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Window Tag":
        selected_beam_tag = tag_type
        break
    else:
        selected_beam_tag == None

for tag_type in reo_2d_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Reinf Tag":
        selected_reo_2d_tag = tag_type
        break
    elif param and param.AsString() == "1-100 TEXT":
        selected_reo_2d_tag = tag_type

all_tags = [selected_wall_tag, selected_col_tag, selected_beam_tag, selected_window_tag, selected_reo_2d_tag]
auto_tags = True
for tag in all_tags:
    try:
        param = tag.LookupParameter("Type Name")
        if param and not "Auto" in param.AsString():
            auto_tags = False
            break
    except:
        pass

if not auto_tags:
    msg = (
        "This template does not contain the required 'Auto Tag' families.\n\n"
        "As a result, some tags may not be placed correctly in the plan.\n\n"
        "Do you want to continue?"
    )
    result = forms.alert(msg, title="Confirm Action", options=["Yes", "No"])

    if result == "No":
        sys.exit()


for s in general_details_collector:
    if s.Family.Name == "STP_Plan_Extent Arrow":
        selected_detail = s



# endregion

# ------------------------------------------------------------------
# ------ GET COLLECTORS --------------------------------------------
# region -----------------------------------------------------------
walls_collector = FilteredElementCollector(doc, view.Id).OfCategory(BuiltInCategory.OST_Walls).WhereElementIsNotElementType()

framing_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_StructuralFraming)\
    .WhereElementIsNotElementType()

columns_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_StructuralColumns)\
    .WhereElementIsNotElementType()

windows_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_Windows)\
    .WhereElementIsNotElementType()

doors_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_Doors)\
    .WhereElementIsNotElementType()

det_items_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_DetailComponents)\
    .WhereElementIsNotElementType()


skip = True
# endregion


# ------------------------------------------------------------------
# ------ TAG WALLS -------------------------------------------------
# region -----------------------------------------------------------
walls_to_tag = []
double_tag = []
for wall in walls_collector:
    if "PLY" in wall.Name:
        walls_to_tag.append(wall)
    if "2/PLY" in wall.Name:
        double_tag.append(wall)

if walls_to_tag and selected_wall_tag and skip:
    with revit.Transaction("Tag Ply Braced Walls"):
        for wall in walls_to_tag:
            
            location = wall.Location
            if not hasattr(location, 'Curve'):
                continue
            curve = location.Curve
            
            direction = curve.GetEndPoint(1) - curve.GetEndPoint(0)
            direction = direction.Normalize()

            perpendicular = XYZ(-direction.Y, direction.X, 0)
            delta_offset = -1 if wall.Flipped else 1
            perpendicular = perpendicular.Negate()
            tag_points = wall_tag_points(wall)
            #print(tag_points)
            if tag_points:
                for point in tag_points:
                    tag_point = point.Add(perpendicular.Multiply(delta_offset))
                    IndependentTag.Create(
                        doc,
                        selected_wall_tag.Id,
                        view.Id,
                        Reference(wall),
                        False,  # no leader
                        TagOrientation.Horizontal,
                        tag_point
                    )
                    
                    if wall in double_tag:
                        delta_offset = -delta_offset
                
                        tag_point = point.Add(perpendicular.Multiply(delta_offset))
                
                        IndependentTag.Create(
                            doc,
                            selected_wall_tag.Id,
                            view.Id,
                            Reference(wall),
                            False,  # no leader
                            TagOrientation.Horizontal,
                            tag_point
                        )

#sys.exit()

# endregion

# ------------------------------------------------------------------
# ------ TAG FRAMING BEAMS -----------------------------------------
# region ----------------------------------------------------------- 
elements_to_tag = []
bearers_to_text = []
elements_for_symbol = []

for elem in framing_collector:
    type_id = elem.GetTypeId()
    elem_type = doc.GetElement(type_id)
    param = elem_type.LookupParameter("Type Comments")
    if param and not "BEARER" in param.AsString():
        elements_to_tag.append(elem)
        if param.AsString() == "TRUSS" or "RAFTER" in param.AsString():
            elements_for_symbol.append(elem)
    else:
        bearers_to_text.append(elem)


if elements_to_tag and selected_beam_tag and skip:
    with revit.Transaction("Tag Structural Framing Elements"):
        for elem in elements_to_tag:
            location = elem.Location
            if isinstance(location, LocationCurve):
                point = location.Curve.Evaluate(0.5, True)  # midpoint
            elif hasattr(location, 'Point'):
                point = location.Point
            else:
                continue
                
            new_tag = IndependentTag.Create(
                doc,
                selected_beam_tag.Id,
                view.Id,
                Reference(elem),
                False,  # no leader
                TagOrientation.Horizontal,
                point
            )


if elements_for_symbol and selected_detail and skip:
    with revit.Transaction("Place Detail Item in Beam Midpoint"):
        # Ensure symbol is active
        if not selected_detail.IsActive:
            selected_detail.Activate()
            doc.Regenerate()

        for elem in elements_for_symbol:
            location = elem.Location
            if isinstance(location, LocationCurve):
                curve = location.Curve
                mid_point = curve.Evaluate(0.6, True)

                # Place detail item at midpoint in current view
                inst = doc.Create.NewFamilyInstance(
                    mid_point,
                    selected_detail,
                    view
                )

                # Get beam direction vector
                beam_dir = (curve.GetEndPoint(1) - curve.GetEndPoint(0)).Normalize()

                # Perpendicular direction (rotate 90� around Z axis)
                perp_dir = XYZ(-beam_dir.Y, beam_dir.X, 0).Normalize()

                # Current instance right direction is X axis (1,0,0)
                # Need rotation angle from X-axis to perp_dir
                angle = math.atan2(perp_dir.Y, perp_dir.X)

                # Rotation axis (Z axis through midpoint)
                axis = Line.CreateBound(mid_point, mid_point + XYZ(0, 0, 1))

                # Apply rotation
                ElementTransformUtils.RotateElement(doc, inst.Id, axis, angle)



from Autodesk.Revit.DB import LocationCurve, TextNote, XYZ, ElementTransformUtils, Line, ElementTypeGroup
import math

if bearers_to_text and selected_beam_tag and skip:
    with revit.Transaction("Add FB Text Notes to Bearers"):
        for bearer in bearers_to_text:
            location = bearer.Location
            if isinstance(location, LocationCurve):
                curve = location.Curve
                mid_point = curve.Evaluate(0.5, True)

                # Beam direction (normalized)
                direction = (curve.GetEndPoint(1) - curve.GetEndPoint(0)).Normalize()

                # Reference axis for angle (X axis)
                x_axis = XYZ(1, 0, 0)
                dot = direction.DotProduct(x_axis)
                cross = direction.CrossProduct(x_axis)
                angle = math.acos(max(min(dot, 1.0), -1.0))
                if cross.Z < 0:
                    angle = -angle

                # Offset so text doesn�t overlap the beam
                offset_vector = XYZ(0.2, 0.2, 0)
                text_point = mid_point + offset_vector

                # Create text note (normal, no rotation yet)
                text_note_type_id = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType)
                text = "FB"
                note = TextNote.Create(doc, view.Id, text_point, text, text_note_type_id)

                # Rotate the text note around Z axis through its insertion point
                axis = Line.CreateBound(text_point, text_point + XYZ(0,0,1))
                ElementTransformUtils.RotateElement(doc, note.Id, axis, angle)


#endregion

# ------------------------------------------------------------------
# ------ TAG COLUMNS -----------------------------------------------
# region -----------------------------------------------------------

if columns_collector and selected_col_tag and skip:
    with revit.Transaction("Tag All Structural Columns"):
        for column in columns_collector:
            location = column.Location
            delta = column_dimension(column)

            offset_tag = XYZ(delta/2 + 0.25, delta/2 + 0.25, 0)
            if isinstance(location, LocationPoint):
                point = location.Point
            elif isinstance(location, LocationCurve):
                point = location.Curve.Evaluate(0.5, True)
            else:
                continue
            
            tag_point = point.Add(offset_tag)
            
            IndependentTag.Create(
                doc,
                selected_col_tag.Id,
                view.Id,
                Reference(column),
                False,  # no leader
                TagOrientation.Horizontal,
                tag_point
            )
            
#endregion

# ------------------------------------------------------------------
# ------ TAG DETAIL RC LINTELS -------------------------------------
# region -----------------------------------------------------------

lintels_to_tag = []
bars_to_text = []

for elem in windows_collector:
    type_id = elem.GetTypeId()
    elem_type = doc.GetElement(type_id)
    param = elem_type.LookupParameter("Type Name")
    if param and param.ToString() == "STP Lintels":
        lintels_to_tag.append(elem)
    else:
        lintels_to_tag.append(elem)

if lintels_to_tag and selected_beam_tag and skip:
    with revit.Transaction("Tag RC Lintels"):
        for lintel in lintels_to_tag:
            location = lintel.Location
            if isinstance(location, LocationPoint):
                 point = location.Point
            else:
                continue
            
            # Filter those that have bars
            bar_left = lintel.LookupParameter("No. bars left")
            bar_right = lintel.LookupParameter("No. bars right")
            try:
                bar_size_parameter = lintel.LookupParameter("Bar Size")
                bar_size = bar_size_parameter.AsInteger()
            except:
                bar_size = 16
            try:
                width = lintel.LookupParameter("Adjust_width")
            except:
                width = lintel.LookupParameter("STP_Width")
            if (bar_left and bar_left.AsInteger() > 0) or (bar_right and bar_right.AsInteger() > 0):
                if width:
                    w_val = width.AsDouble() if width.AsDouble() and width.AsDouble() > 0 else 0
                                    
                    aux = ((lintel, bar_left.AsInteger(), bar_right.AsInteger(), w_val, point, bar_size))
                    bars_to_text.append(aux)

            new_tag = IndependentTag.Create(
                doc,
                view.Id,
                Reference(lintel),
                False,
                TagMode.TM_ADDBY_CATEGORY,
                TagOrientation.Horizontal,
                point
            )

if bars_to_text:
    angle_rad = math.radians(45)
    text_note_type_id = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType)

    with revit.Transaction("Tag Bar Number"):
        for bars in bars_to_text:
            lintel = bars[0]
            direction = lintel.FacingOrientation
            left_text = str(bars[1]) + "/N" + str(bars[5])
            rght_text = str(bars[2]) + "/N" + str(bars[5])
            left_width_half = bars[3] / 2 + (0.65 if abs(direction.Y)==1 else -0.65)
            rght_width_half = bars[3] / 2 - (0.65 if abs(direction.Y)==1 else -0.65)
            text_point = bars[4]
            
            mark = lintel.LookupParameter("Mark")
            aux = mark.AsString() if mark else "N/F"

            dx1 = - ((left_width_half + (bars[1])*0.328) * direction.Y) + (0.13 if abs(direction.Y) < 0.1 else 0)
            dx2 = ((rght_width_half + (bars[1])*0.328) * direction.Y) + (0.13 if abs(direction.Y) < 0.1 else 0)
            dy1 = ((left_width_half + (bars[1])*0.328) * direction.X) + (1.47 if abs(direction.X) < 0.1 else 0)
            dy2 = - ((rght_width_half + (bars[2])*0.328) * direction.X) + (1.47 if abs(direction.X) < 0.1 else 0)
            left_offset_vector = XYZ(dx1, dy1, 0)
            rght_offset_vector = XYZ(dx2, dy2, 0)

            left_text_point = text_point + left_offset_vector
            rght_text_point = text_point + rght_offset_vector

            if bars[1] > 0:
                text_note = TextNote.Create(doc, view.Id, left_text_point, left_text, text_note_type_id)
                axis = Line.CreateBound(left_text_point, left_text_point + XYZ(0, 0, 1))
                ElementTransformUtils.RotateElement(doc, text_note.Id, axis, angle_rad)
            
            if bars[2] > 0:
                text_note = TextNote.Create(doc, view.Id, rght_text_point, rght_text, text_note_type_id)
                axis = Line.CreateBound(rght_text_point, rght_text_point + XYZ(0, 0, 1))
                ElementTransformUtils.RotateElement(doc, text_note.Id, axis, angle_rad)
            



# endregion


# ------------------------------------------------------------------
# ------ TAG DETAIL ITEMS ------------------------------------------
# region -----------------------------------------------------------
details_to_tag = []

for elem in det_items_collector:
    type_id = elem.GetTypeId()
    elem_type = doc.GetElement(type_id)
    param = elem_type.LookupParameter("Type Name")
    if param and param.AsString() != "DIM":
        details_to_tag.append(elem)


if details_to_tag and selected_reo_2d_tag and skip:
    with revit.Transaction("Tag 2d Wall Reinf"):
        for det in details_to_tag:
            location = det.Location
            if isinstance(location, LocationPoint):
                point = location.Point
            elif isinstance(location, LocationCurve):
                point = location.Curve.Evaluate(0.0, True)
            else:
                continue
            
            tag = IndependentTag.Create(
                doc,
                selected_reo_2d_tag.Id,
                view.Id,
                Reference(det),
                False,  # no leader
                TagOrientation.Horizontal,
                point
            )

            translation = XYZ(1.2, 1, 0)
            ElementTransformUtils.MoveElement(doc, tag.Id, translation)

# endregion