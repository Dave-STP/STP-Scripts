#target_wall_type_name = "Stud Timber - 90 LBW + 1/PLY"  # <-- Change this to your desired wall type name

# -*- coding: utf-8 -*-
import math
import os
import sys
from Autodesk.Revit.DB import *
from pyrevit import forms, revit


# Get document and active view
doc = __revit__.ActiveUIDocument.Document
view = doc.ActiveView

# Check if it is the right view by checking the view template
template_id = view.ViewTemplateId
if template_id != ElementId.InvalidElementId:
    view_template = doc.GetElement(template_id)
    if not view_template.Name == "STP FLOOR FRAMING PLAN":
        msg = (
            "This is not a Floor Framing Plan View.\n\nPlease run this tool in a view with 'STP FLOOR FRAMING PLAN' View Template to continue."
        )
        result = forms.alert(msg, title="Confirm Action")
        sys.exit()

user = os.getenv("USERNAME")  # works on Windows


#----MAINTENANCE CODE BREAK -------------
#if not user == "Rafael":
#    print("This tool is under maintanance, thanks for waiting")
#    sys.exit()
#else:
#   print("TESTING TESTING")

up = view.UpDirection  # This is "screen up"
right = view.RightDirection  # This is "screen right"

col_b_types = ["b", "Length L"]
col_d_types = ["d", "Width W"]

def column_dimension(elem):
    x1 = 0; x2 = 0
    
    type_id = elem.GetTypeId()
    elem_type = doc.GetElement(type_id)
    
    for b in col_b_types:
        param = elem_type.LookupParameter(b)
        if param:
            x1 = param.AsDouble()
            break
    
    for d in col_d_types:
        param = elem_type.LookupParameter(d)
        if param:
            x2 = param.AsDouble()
            break
    
    return x1 if x1 > x2 else x2

def find_midpoint(point1, point2):
    x1, y1 = point1.X, point1.Y
    x2, y2 = point2.X, point2.Y

    xm = (x1 + x2) / 2
    ym = (y1 + y2) / 2

    return XYZ(xm, ym, point1.Z)

def wall_tag_points(wall, m_point):
    
    m_points = []
    # - Get wall properties and location
    bbox_wall = wall.get_BoundingBox(None)
    wall_min = bbox_wall.Min
    wall_max = bbox_wall.Max
    points = [wall_min, wall_max]

    if wall_max.X - wall_min.X > wall_max.Y - wall_min.Y:
        c = "x"
        Max = wall_max.X
        Min = wall_min.X
    else:
        c = "y"
        Max = wall_max.Y
        Min = wall_min.Y 
    
    gaps = [Min, Max]

    doors_ids = wall.FindInserts(True, False, False, False)
    if doors_ids:
        for dr in doors_ids:
            door = doc.GetElement(dr)
            if door.Name == "STP_Studwall doors":
                param = door.LookupParameter("Adjust_width")
                door_length = param.AsDouble()
                offset = door_length/2
                door_centre = door.Location.Point
                door_c = door_centre.X if c == "x" else door_centre.Y
                
                if c == "x":
                    point_a = door_centre + XYZ(-offset, 0, 0)
                    point_b = door_centre + XYZ(offset, 0, 0)
                else:
                    point_a = door_centre + XYZ(0, -offset, 0)
                    point_b = door_centre + XYZ(0, -offset, 0)
                
                if door_c - offset - 1.3 < gaps[0]:
                    points[0] = point_b
                    gaps[0] = door_c + offset
                elif door_c + offset + 1.3 > gaps[-1]:
                    points[-1] = point_a
                    gaps[-1] = door_c - offset
                else:
                    for x, gap in enumerate(gaps):
                        if door_c + offset < gap and x > 0:
                            gaps.insert(x, door_c + offset)
                            gaps.insert(x, door_c - offset)
                            points.insert(x, point_b)
                            points.insert(x, point_a)
                            break

        idx = 1
        while idx < len(points):
            m_points.append(find_midpoint(points[idx-1],points[idx]))
            idx = idx + 2
        
    else:
        m_points.append(m_point)
    
    return m_points

# ------------------------------------------------------------------
# ------ GET TAGS --------------------------------------------------
# region -----------------------------------------------------------

column_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_StructuralColumnTags)\
    .ToElements()

beam_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_StructuralFramingTags)\
    .ToElements()

reo_2d_tag_types = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_DetailComponentTags)\
    .ToElements()

general_details_collector = FilteredElementCollector(doc)\
    .OfClass(FamilySymbol)\
    .OfCategory(BuiltInCategory.OST_DetailComponents)

selected_col_tag = None
selected_beam_tag = None
selected_reo_2d_tag = None

for tag_type in column_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Col Tag":
        selected_col_tag = tag_type
        break
    elif param and param.AsString() == "COLUMN OVER AND UNDER (45)":
        selected_col_tag = tag_type

for tag_type in beam_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Beam Tag":
        selected_beam_tag = tag_type
        break
    elif param and param.AsString() == "STANDARD":
        selected_beam_tag = tag_type

for tag_type in reo_2d_tag_types:
    param = tag_type.LookupParameter("Type Name")
    if param and param.AsString() == "Auto Reinf Tag":
        selected_reo_2d_tag = tag_type
        break
    elif param and param.AsString() == "1-100 TEXT":
        selected_reo_2d_tag = tag_type

all_tags = [selected_col_tag, selected_beam_tag, selected_reo_2d_tag]
auto_tags = True
for tag in all_tags:
    try:
        param = tag.LookupParameter("Type Name")
        if param and not "Auto" in param.AsString():
            auto_tags = False
            break
    except:
        pass

if not auto_tags:
    msg = (
        "This template does not contain the required 'Auto Tag' families.\n\n"
        "As a result, some tags may not be placed correctly in the plan.\n\n"
        "Do you want to continue?"
    )
    result = forms.alert(msg, title="Confirm Action", options=["Yes", "No"])

    if result == "No":
        sys.exit()


for s in general_details_collector:
    if s.Family.Name == "STP_Plan_Extent Arrow":
        selected_detail = s



# endregion

# ------------------------------------------------------------------
# ------ GET COLLECTORS --------------------------------------------
# region -----------------------------------------------------------
walls_collector = FilteredElementCollector(doc, view.Id).OfCategory(BuiltInCategory.OST_Walls).WhereElementIsNotElementType()

framing_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_StructuralFraming)\
    .WhereElementIsNotElementType()

columns_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_StructuralColumns)\
    .WhereElementIsNotElementType()

det_items_collector = FilteredElementCollector(doc, view.Id)\
    .OfCategory(BuiltInCategory.OST_DetailComponents)\
    .WhereElementIsNotElementType()


skip = True
# endregion

# ------------------------------------------------------------------
# ------ TAG FRAMING BEAMS -----------------------------------------
# region ----------------------------------------------------------- 
elements_to_tag = []
elements_to_hide = []
elements_to_text = []
elements_for_symbol = []

for elem in framing_collector:
    type_id = elem.GetTypeId()
    elem_type = doc.GetElement(type_id)
    param = elem_type.LookupParameter("Type Comments")
    if param:
        p_type = param.AsString()
        if "BEARER" in p_type or "POLE" in p_type:
            elements_to_tag.append(elem)
        elif "JOIST" in p_type:
            double1 = elem.LookupParameter("Alt View 1")
            double2 = elem.LookupParameter("Alt View 2")
            t_mark = elem_type.LookupParameter("Type Mark")
            qnt = double1.AsInteger() + double2.AsInteger()
            if qnt > 0:
                elements_to_text.append((elem, str(qnt+1) + "/" + t_mark.AsString()))
            else:
                elements_to_tag.append(elem)
                elements_for_symbol.append(elem)
        elif "LINTEL" in p_type:
            elements_to_text.append((elem, "L"))
        else:
            elements_to_hide.append(elem)

if elements_to_tag and selected_beam_tag and skip:
    with revit.Transaction("Tag Structural Framing Elements"):
        for elem in elements_to_tag:
            location = elem.Location
            if isinstance(location, LocationCurve):
                point = location.Curve.Evaluate(0.5, True)  # midpoint
            elif hasattr(location, 'Point'):
                point = location.Point
            else:
                continue
                
            new_tag = IndependentTag.Create(
                doc,
                selected_beam_tag.Id,
                view.Id,
                Reference(elem),
                False,  # no leader
                TagOrientation.Horizontal,
                point
            )

if elements_for_symbol and selected_detail and skip:
    with revit.Transaction("Place Detail Item in Beam Midpoint"):
        # Ensure symbol is active
        if not selected_detail.IsActive:
            selected_detail.Activate()
            doc.Regenerate()

        for elem in elements_for_symbol:
            location = elem.Location
            if isinstance(location, LocationCurve):
                curve = location.Curve
                mid_point = curve.Evaluate(0.6, True)

                # Place detail item at midpoint in current view
                inst = doc.Create.NewFamilyInstance(
                    mid_point,
                    selected_detail,
                    view
                )

                # Get beam direction vector
                beam_dir = (curve.GetEndPoint(1) - curve.GetEndPoint(0)).Normalize()

                # Perpendicular direction (rotate 90� around Z axis)
                perp_dir = XYZ(-beam_dir.Y, beam_dir.X, 0).Normalize()

                # Current instance right direction is X axis (1,0,0)
                # Need rotation angle from X-axis to perp_dir
                angle = math.atan2(perp_dir.Y, perp_dir.X)

                # Rotation axis (Z axis through midpoint)
                axis = Line.CreateBound(mid_point, mid_point + XYZ(0, 0, 1))

                # Apply rotation
                ElementTransformUtils.RotateElement(doc, inst.Id, axis, angle)

if elements_to_text and skip:
    with revit.Transaction("Add X/ Text Notes to Joists"):
        for joists in elements_to_text:
            joist = joists[0]
            location = joist.Location
            if isinstance(location, LocationCurve):
                curve = location.Curve
                mid_point = curve.Evaluate(0.5, True)

                # Beam direction (normalized)
                direction = (curve.GetEndPoint(1) - curve.GetEndPoint(0)).Normalize()

                # Reference axis for angle (X axis)
                x_axis = XYZ(1, 0, 0)
                dot = direction.DotProduct(x_axis)
                cross = direction.CrossProduct(x_axis)
                angle = math.acos(max(min(dot, 1.0), -1.0))
                if cross.Z < 0:
                    angle = -angle

                # Offset so text doesn�t overlap the beam
                offset_vector = XYZ(-0.75, 0.1, 0)
                text_point = mid_point + offset_vector

                # Create text note (normal, no rotation yet)
                text_note_type_id = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType)
                text = joists[1]
                note = TextNote.Create(doc, view.Id, text_point, text, text_note_type_id)

                # Rotate the text note around Z axis through its insertion point
                axis = Line.CreateBound(text_point, text_point + XYZ(0,0,1))
                ElementTransformUtils.RotateElement(doc, note.Id, axis, angle)
# endregion
                
# ------------------------------------------------------------------
# ------ TAG COLUMNS -----------------------------------------------
# region -----------------------------------------------------------

if columns_collector and selected_col_tag and skip:
    with revit.Transaction("Tag All Structural Columns"):
        for column in columns_collector:
            location = column.Location
            delta = column_dimension(column)

            offset_tag = XYZ(delta/2 + 0.25, delta/2 + 0.25, 0)
            if isinstance(location, LocationPoint):
                point = location.Point
            elif isinstance(location, LocationCurve):
                point = location.Curve.Evaluate(0.5, True)
            else:
                continue
            
            tag_point = point.Add(offset_tag)
            
            IndependentTag.Create(
                doc,
                selected_col_tag.Id,
                view.Id,
                Reference(column),
                False,  # no leader
                TagOrientation.Horizontal,
                tag_point
            )
            
#endregion

# ------------------------------------------------------------------
# ------ HIDE NO USED BEAMS -----------------------------------------------
# region -----------------------------------------------------------
if elements_to_hide and skip:
    from System.Collections.Generic import List
    with revit.Transaction("Hide non needed elements"):
        ids = List[ElementId]([e.Id for e in elements_to_hide])
        view.HideElements(ids)
        msg = "Some elements like lintels were hidden. Check for missing elements"
    result = forms.alert(msg, title="ALERT, hidden elements")