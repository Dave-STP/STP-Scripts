# -*- coding: utf-8 -*-
import sys
import os
import re
import traceback
from pyrevit import forms
from Autodesk.Revit.DB import BuiltInParameter

def test_function(test):
    return("This is a test: " + test)

def aborting_script(report, title, mssg):
    forms.alert(mssg, title, options=["OK"])
    if "Fail" in report:
        print(report)
    else: # Delete this one at the end
        print("testing " + title)
    sys.exit()

def usage_categ_famtype_list(lib_path, Revit_Category, stage):
    file_path = os.path.join(lib_path,"Codes and Functions", "Structural Codes", "STP_Functions",
        "Structural Member Types.txt")
    revit_cat = Revit_Category + " Types"
    structural_usages = Revit_Category + " Usages"
    framing_types = []
    usages_type = []
    usage_List = []
    categ_List = []
    local_report = ""
    
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
            if lines:
                local_report += u"\u2705 Stage: " + stage + " Success: Usages file found. \n"
            else:
                local_report += u"\u274C Stage: " + stage + " Fail. No lines found.\n"

            # Find the indices of the markers
            start_framing_index = next((i for i, line in enumerate(lines) if line.strip() == revit_cat), -1)
            end_framing_index = next((i for i, line in enumerate(lines) if line.strip() == revit_cat + " End"), -1)
            start_usages_index = next((i for i, line in enumerate(lines) if line.strip() == structural_usages), -1)
            end_usages_index = next((i for i, line in enumerate(lines) if line.strip() == structural_usages + " End"), -1)

            # Check if indices are valid before slicing
            if start_framing_index != -1 and end_framing_index != -1:
                framing_types = [line.strip() for line in lines[start_framing_index + 1:end_framing_index]]
            
            if start_usages_index != -1 and end_usages_index != -1:
                usages_type = [line.strip() for line in lines[start_usages_index + 1:end_usages_index]]
                'BEAM-BEAMS-#STP_Steel_UB'
                'EDGE THICKENING-FOOTINGS'

            def_index = []
            for k, sect in enumerate(usages_type):
                n = sect.find("-#")
                if n >= 0:
                    default_family = sect[n+2:]
                    index = framing_types.index(default_family)
                    def_index.append(index)
                    sect = sect[:n]

                else:
                    def_index.append(0)
                
                n = sect.find("-")
                if n > 0:
                    usage_List.append(sect[:n])
                    categ_List.append(sect[n + 1:])
                else:
                    usage_List.append(sect)
                    categ_List.append(sect)
        
        local_report += u"\u2705 Stage: "+ stage + "Success. List created: \n"
    except Exception as e:
        local_report += u"\u274C Stage: " + stage + "Fail.\n"
        local_report += traceback.format_exc() + " \n"
        local_report += ">>> PROGRAM ABORTED. PLEASE CONTACT STP TOOLS ADMIN FOR SUPPORT <<<"
        aborting_script(local_report, "Usage List Error", "Usage and Category List not found. \n\nPlease contact STP Tools developer.")
        
    return local_report, usage_List, categ_List, def_index, framing_types

def profile_sizes(file_path):
    mylines = []
    if os.path.exists(file_path):
        mylines = []
        with open(file_path, 'r') as file:
            mylines = [line.strip() for line in file]
        mylines[0] = "Select Size" + mylines[0]
        
        size_list = []
        aux = []
        all_data_list = []
        for line in mylines:
            params = line.split(",")
            size_list.append(params[0][:-1] if params[0].endswith(' ') else params[0]) # Add sizes to the list
            aux.append(params)
        
        for x, line in enumerate(aux[0]):
            try:
                n = line.index("##")
                aux[0][x] = line[:n]
            except:
                pass
            all_data_list = aux
    else:
        size_list, all_data_list = [["No Info available","for this family","Please Report this","issue to STP Tools","admin. Thanks"], ["No Info"]]
    return size_list, all_data_list

def get_next_available_type_mark(tag_list, prefix):
    numbers = []
    pattern = r"{}(\d+)$".format(re.escape(prefix))  # <-- build the pattern safely
    for tag in tag_list:
        match = re.match(pattern, tag)
        if match:
            numbers.append(int(match.group(1)))

    if not numbers:
        return "{}1".format(prefix)

    current = 1
    while current in numbers:
        current += 1

    return "{}{}".format(prefix, current)

def addapt_value_storage_type(item, params):
    from Autodesk.Revit.DB import StorageType, ElementId
    
    # Obtener todos los parámetros del elemento
    param_set = item.Parameters
    
    for param in param_set:
        param_name = param.Definition.Name
        if param_name == "STP_Reinforcement" and param.IsReadOnly: 
            param.DissociateFromGlobalParameter() # <<<< Unlink this parameter from Global parameters
        
        # Verificamos si el parámetro tiene el nombre que buscamos
        if param_name == params[0] and not param.IsReadOnly:
            #print(params)
                
            storage_type = param.StorageType
            if storage_type == StorageType.Double:
                if params[0] == "A":
                    convert_units = 1 / 92903.04
                elif params[0] == "W":
                    convert_units = 1 / 3.281
                else:
                    convert_units = 1 / 304.8
                param.Set(float(params[1]) * convert_units)
            elif storage_type == StorageType.String:
                param.Set(str(params[1]))
            else:
                param.Set(params[1])
    
    return True

def load_families_and_parameters(doc, Load_List):
    import os
    import traceback
    from Autodesk.Revit.DB import FilteredElementCollector, FamilySymbol, Family
    from pyrevit import forms, revit
    
    #user_name = os.environ.get("USERNAME")
    #if user_name != "Rafael":
    #    forms.alert("This tool is under review. Thanks for your patience")
    #    sys.exit()

    symbols = FilteredElementCollector(doc).OfClass(FamilySymbol).ToElements()
    families = FilteredElementCollector(doc).OfClass(Family).ToElements()
    not_loaded = []
    loaded = []
    state = False
    func_report = ""
    user_name = ""

    for new_type in Load_List:
        try:
            with revit.Transaction("STP Tools Load Families"):
                fam_name = new_type[0][0]
                new_type_name = new_type[0][1]
                family_path = new_type[0][2]
                type_to_load = new_type[0][3]

                go_for_parameters = True
                # First check if the family is in the document (regardless of symbols)
                family_in_doc = next((f for f in families if f.Name == fam_name), None)
                search_fams = []
                
                if not family_in_doc:
                    # Load family from path
                    if os.path.exists(family_path):
                        fam_name = os.path.basename(family_path).replace(".rfa","")
                        if type_to_load:
                            loaded_ok = doc.LoadFamilySymbol(family_path, type_to_load)
                        else:
                            loaded_ok = doc.LoadFamily(family_path)
                        
                        # Refresh both collectors
                        symbols = FilteredElementCollector(doc).OfClass(FamilySymbol).ToElements()
                        families = FilteredElementCollector(doc).OfClass(Family).ToElements()
                        
                        # Find new symbol to rename
                        new_symbol = next((s for s in symbols if s.Family.Name == fam_name), None)
                        if new_symbol:
                            new_symbol.Name = new_type_name
                            func_report += u"\u2705 Stage: " + new_type_name + " Family loaded from Revit Library: Success \n"
                            loaded.append(new_type_name)
                        else:
                            go_for_parameters = False
                            func_report += u"\u26A0 Stage: " + new_type_name + " Warning: Family loaded but type not found \n"
                            not_loaded.append(fam_name + "  [TYPE NOT FOUND AFTER LOADING]")
                            continue
                    else:
                        go_for_parameters = False
                        func_report += u"\u26A0 Stage: " + new_type_name + " Family not found in library: Warning \n"
                        if not fam_name + "  [FAMILY NOT FOUND]" in not_loaded:
                            not_loaded.append(fam_name + "  [FAMILY NOT FOUND]")
                        continue
                else:
                    # Family exists, try to duplicate a symbol
                    symbol_to_copy = next((s for s in symbols if s.Family.Name == fam_name), None)
                    if symbol_to_copy:
                        new_symbol = symbol_to_copy.Duplicate(new_type_name)
                        func_report += u"\u2705 Stage: " + new_type_name + " Family copied from existing: Success \n"
                        loaded.append(new_type_name)
                    else:
                        go_for_parameters = False
                        func_report += u"\u26A0 Stage: " + new_type_name + " Family exists but has no symbols: Warning \n"
                        not_loaded.append(fam_name + "  [NO SYMBOLS FOUND]")
                        continue

                # Set parameters
                if go_for_parameters:
                    for gen_par in new_type[1]:
                        addapt_value_storage_type(new_symbol, gen_par)
                    for dim_par in new_type[2]:
                        addapt_value_storage_type(new_symbol, dim_par)
                    func_report += u"\u2705 Stage: Family Parameters set: Success \n"

        except Exception as e:
            state = True
            func_report += u"\u274C Stage: Load " + new_type[0][0] + " Family: Fail.\n"
            func_report += traceback.format_exc() + " \n"
            func_report += ">>> SOME FAMILIES MAY NOT HAVE LOADED PROPERLY, PLEASE CHECK THE FAMILIES <<<"

    # Final report
    user_name = os.environ.get("USERNAME")
    if not user_name == "DavidH":
        if not_loaded:
            msg = "The following families are missing or incomplete:\n\n" + "\n".join(not_loaded)
            if loaded:
                msg += "\n\nThe following families were loaded successfully:\n\n" + "\n".join(loaded)
            forms.alert(msg, title="Family Load Warning", warn_icon=True)
        else:
            msg = "All member types were loaded successfully:\n\n" + "\n".join(loaded)
            forms.alert(msg, title="Family Load Report", warn_icon=False)

    return state, func_report

def create_Type_Mark_List(collector, stage):
    local_report = ""
    type_marks_list = []
    type_marks_grey = []
    
    for ftype in collector:
        type_mark_param = ftype.LookupParameter('Type Mark')
        type_mark = type_mark_param.AsString() if type_mark_param and type_mark_param.HasValue else "<None>"
        type_name = ftype.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
        
        if type_mark != "<None>" and type_mark not in type_marks_list:
            type_marks_list.append((type_mark, type_mark + " - " + type_name))
            type_marks_grey.append(type_mark)
  
    if type_marks_list:
        local_report += u"\u2705 Stage: " + stage + " Success \n"
    else:
        local_report += u"\u26A0 Stage: " + stage + " Warning. No Type Marks found \n"

    return local_report, type_marks_list, type_marks_grey

def find_family_type(collector, fam_list, stage):
    local_report = ""
    
    for ftype in collector:
        if ftype.Family.Name in fam_list:
            return ftype.Family.Name
            
    return "N/F"

def filter_type_mark(usage, suffix, tm_list, tm_grey):
    from System.Windows.Controls import ListBoxItem
    from System.Windows.Media import Brushes
    def natural_sort_key(text):
        return [int(text_part) if text_part.isdigit() else text_part.lower() for text_part in re.split('(\d+)', text)]

    # Filter the type mark list
    filtered_type_marks_list = [] 
    n = len(suffix)
            
    for x, pair in enumerate(tm_list):
        new_pair = (pair[0], pair[0] + " - " + pair[1].replace(pair[0] + " - ","").replace(" - " + pair[0],"").replace(pair[0] + "-","").replace("-" + pair[0],""))
        #print((new_pair[0], len(new_pair[0]) > 1))
        long = len(new_pair[0])
        if long > n and new_pair[0][:n] == suffix:
            if new_pair[0][n].isdigit():
                filtered_type_marks_list.append(new_pair)
   
    if filtered_type_marks_list:
        filtered = sorted([x[1] for x in filtered_type_marks_list], key=natural_sort_key)
        filtered_color = []
        next_type_mark = get_next_available_type_mark([x[0] for x in filtered_type_marks_list], suffix)
        
        for mark in filtered:
            n = mark.find(" - ")
            item = ListBoxItem()
            item.Content = mark
            if mark[:n] in tm_grey:
                item.Foreground = Brushes.DarkGray
            else:
                item.Foreground = Brushes.Blue
            filtered_color.append(item)
    else:
        filtered_color = ["No type mark found for: ", usage + " [" + suffix + "]"]
        next_type_mark = suffix + "1"
        
    return filtered_color, next_type_mark

def fill_tracking_data(file_path, raw_line, stage):
    local_report = ""
    new_line = ""
    titles_line = ["Project Number:", "User:", "File:", "Version:", "Start Time:", "End Time:", "Loaded Items:"]
    if len(raw_line) != len(titles_line):
        forms.alert("Lines doesn't match", "Warning", options=["OK"])
        return local_report
    
    for title, item in zip(titles_line, raw_line):
        new_line += title + ", " + item + ", "
    final_line = new_line[:-2] + "\n"

    if file_path:
        with open(file_path, "a") as file:
            file.write(final_line)
            local_report += u"\u2705 Stage: " + stage + ": [Add New Line to Track File] Success \n"
    #except Exception as e:
    else:
        local_report += u"\u274C Stage: " + stage + ": [Fail] \n" + str(e) + "\n"
        return local_report
    return local_report

def exceptions():
    e = ["PURLIN","BRACING","OUTRIGGER", "RIDGE BEAM","TRANSOM","BAYONET", "STUB", "ISOLATED BEAM", "BATTEN", "STUB COLUMN", "BEAM FOOTING", "PIER", "STEEL POST", "POST", "SLAB THICKENING"]
    f = ["P","BR","OR", "RD","TR","ByN","ST","SB", "BA", "ST", "B", "P", "C", "C", "TH"]
    
    return e, f