import os
import sys

def test(qa_path):
    print("test file")