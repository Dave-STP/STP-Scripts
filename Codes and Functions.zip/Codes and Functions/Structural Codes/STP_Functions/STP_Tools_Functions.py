#--------------------------------------------------------------------
#----- FUNCTIONS FOR STP GENERAL TOOLS ------------------------------
#--------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import System
import os
import re
import clr
clr.AddReference("System")
clr.AddReference("System.Windows.Forms")
import System.Windows.Forms as WinForms
import ctypes
import traceback
import shutil
import time
import gc
from pyrevit import forms, revit
from pyrevit.coreutils import ribbon
from Autodesk.Revit.DB import FilteredElementCollector, ViewSheet, FamilyInstance, BuiltInCategory, Transaction, XYZ, ElementTransformUtils, FamilySymbol


# Excel Libraries
from System import Type, Activator, Array, Object
from System.Reflection import BindingFlags
import System.Windows.Forms as WinForms
import System.Threading as Threading
import System.Diagnostics as diag

support_mssg = "\n PROGRAM ABORTED \n\n *Please contact STP Tools Admin for Further Support"


def aborting_script(report, title, mssg):
    forms.alert(mssg, title, options=["OK"])
    if "Fail" in report:
        print(report)

    sys.exit()

def bring_excel_to_front(excel_app):
    local_report = ""
    
    try:
        # Wait briefly to let Excel render
        time.sleep(0.5)
        
        # Get Excel main window handle
        hwnd = excel_app.Hwnd

        # Bring to foreground
        ctypes.windll.user32.ShowWindow(hwnd, 5)  # SW_SHOW
        ctypes.windll.user32.SetForegroundWindow(hwnd)
    except Exception as e:
        local_report += str(e)
        pass

def check_correct_qa_path(p_path, p_numb, rvt, stage):
    local_report = ""
    qa_exist = False
    qa_path = ""
    mssg = ""
    
    qa_path_24 = move_qa_to_drawings(p_path, p_numb + "_QA_Checklist.xlsx")
    qa_path_25 = move_qa_to_drawings(p_path, p_numb + "_QA_Checklist.xlsm")
    qa_auxp_25 = move_qa_to_drawings(p_path, "r25_support_temp_file.txt")

    if rvt < 25:
        qa_path = qa_path_24
        qa_exist = os.path.exists(qa_path)
        if qa_exist:
            local_report += u"\u2705 Stage: " + stage + ": [Correct QA version found] \n"
        else:
            local_report += u"\U0001F4CC Stage: " + stage + ": [No QA file found] \n"
        if os.path.exists(qa_path_25) and os.path.exists(qa_auxp_25):
            mssg = (
                "This project was originally created in Revit 2025 or a newer version.\n\n" + 
                "Please open it using the appropriate version of Revit."
                )
            local_report += u"\u274C Stage: " + stage + ": [Worng Revit Version]\n"
    else:
        qa_path = qa_path_25
        qa_exist = all([os.path.exists(qa_path), os.path.exists(qa_auxp_25)])
        if qa_exist:
            local_report += u"\u2705 Stage: " + stage + ": [Correct QA version found] \n"
        else:
            local_report += u"\U0001F4CC Stage: " + stage + ": [No QA file found] /n"
        if os.path.exists(qa_path_24):
            mssg = (
                "This project was originally created in Revit 2024 or an older version.\n\n" + 
                "Please open it using the appropriate version of Revit."
                )
            local_report += u"\u274C Stage: " + stage + ": [Worng Revit Version]\n"
            
    if mssg:
        aborting_script("", "Wrong Revit Version", mssg)

    return local_report, qa_exist, qa_path

def check_last_version(lib_path, tab, user_name):
    return

def check_last_version_backup(lib_path, tab, user_name):
    report = ""
    mssg = ""
    bin_dir = os.path.join(
        "C:\\Users", user_name,
        "AppData", "Roaming", "pyRevit-Master", "extensions", "STP.extension", "bin"
    )
    version_file = os.path.join(bin_dir, tab + " version.txt")
    latest_ver_file = os.path.join(lib_path, "STP_Codes", "Latest versions.txt")
    
    if os.path.exists(version_file):
        with open(version_file, 'r') as f:
            version = float(f.read().strip())
        
        latest_version = None
        with open(latest_ver_file, 'r') as f:
            for line in f:
                # Remove spaces and newline
                line = line.strip()
                if line.startswith(tab):
                    try:
                        # Split at "=" and convert the second part to float
                        latest_version = float(line.split('=')[1].strip())
                    except:
                        latest_version = None
                    break
                    
        if version < latest_version:
            mssg = "There is a new " + tab + " version.\n\nDo you want to update it now?"
    
    else:
        mssg = "There is a new " + tab + " version.\n\nDo you want to update it now?"
        
    if mssg:
        if user_name == "Rafael":
            response = forms.alert("{}, Tu folder extensions se va a borrar, ya hiciste backup?".format(user_name), options = ["Si ya hice backup", "No todavia"])
            if not response or "No" in response:
                sys.exit()
        else:
            response = forms.alert(mssg, title="Update available", options=["Yes", "No"])
        
        if response == "Yes" or "Si" in response:
            bat_path = os.path.join(lib_path,"STP Tools Installer","STP Tools Installer (Full install).bat")
    
            if os.path.exists(bat_path):
                proc = System.Diagnostics.Process()
                proc.StartInfo.FileName = bat_path
                proc.StartInfo.UseShellExecute = True
                
                #started = True
                started = proc.Start()
                if started:
                    report = (
                           "Update Success.\n\n"
                           "Please restart Revit or Reload Pyrevit and add tabs from 'Manage Tabs' button"
                           )
                    
                else:
                    msg = (
                        "Failed to start the batch file.\n\n"
                        "Please try again. If the issue persists, contact STP developer support."
                    )
            else:
                report = ("Failed to found the batch file.\n\n"
                          "Please try again or contact STP developer support")
            forms.alert(report, exitscript=True)
        
        elif response == False:
            sys.exit()
        
    return report

def copy_hookers(lib_path, pyrevit_path):
    source_chain = os.path.join(lib_path, "STP Tools Installer", "STP.extension")
    target_chain = pyrevit_path.replace(r"\STP Tools.tab\QA Management.Panel\newProject.pulldown","")
    
    #Copy enable or disable STP Tools hook.
    file_name = "view-activated.py"
    file_route = os.path.join("hooks")
    source_file = os.path.join(source_chain, file_route, file_name)
    target_path = os.path.join(target_chain, file_route)
    target_file = os.path.join(target_chain, file_route, file_name)
    
    #print(source_file)
    #print(target_path)
    #print(target_file)
    if not os.path.exists(target_file):
        try:
            if os.path.exists(source_file):
                if not os.path.exists(target_path):
                    os.makedirs(target_path)
                    
                shutil.copy2(source_file, target_file)
                
        except:
            return

def copy_QA_excel_file_to_folder(lib_path, folder_path, p_numb):
    qa_source_path = os.path.join(lib_path,"STP_Data base","QA_Check List - V2.xlsx")
    qa_target_path = os.path.join(folder_path, p_numb + "_QA_Checklist.xlsx")

    shutil.copyfile(qa_source_path, qa_target_path)
    time.sleep(0.5)
    
    if os.path.exists(qa_target_path):
        return qa_target_path
    else:
        return None

def create_folders_in_project(pr_path):
    all_disciplines = ["Civil", "Elec", "Fire", "Hyd", "Mech", "Struct"]
    new_folders = {
        "Current Drawings": all_disciplines,
        "Issued Drawings": all_disciplines,
        "xref": ["superseded"]
    }
    
    with forms.ProgressBar(title='Creating project folders for STP Tools...') as pb:
        pb.update_progress(1, 20)
        drawings_folder_path = os.path.join(pr_path, "Drawings")
        if not os.path.exists(drawings_folder_path):
            os.makedirs(drawings_folder_path)
        
        if os.path.exists(drawings_folder_path):
            x = 1
            for folder, sub_folders in new_folders.items():
                x += 1
                pb.update_progress(x, 20)
                new_folder = os.path.join(drawings_folder_path, folder)
                if not os.path.exists(new_folder):
                    os.makedirs(new_folder)
                
                if sub_folders and os.path.exists(new_folder):
                    for item in sub_folders:
                        x += 1
                        pb.update_progress(x, 20)
                        new_subfolder = os.path.join(new_folder, item)
                        if not os.path.exists(new_subfolder):
                            os.makedirs(new_subfolder)
                            
        pb.update_progress(19, 20)
        with open(os.path.join(drawings_folder_path, "local_config.txt"), "w") as f:
            pass

def delete_or_supersede_titleblock(doc, action, new_fam, old_list, stage):
    local_report = "All title blocks deleted or superseded correctly"
    old_fam_list = [item.replace(".rfa","") for item in old_list if item is not None]
    
    # Collect all title block types
    titleblock_types = FilteredElementCollector(doc)\
        .OfCategory(BuiltInCategory.OST_TitleBlocks)\
        .WhereElementIsElementType()\
        .ToElements()
    with Transaction(doc, "Delete or supersed Family") as t:
        t.Start()
        for tb in titleblock_types:
            fam_name = tb.Family.Name
            if not fam_name == new_fam:
                if action:
                    if fam_name in old_fam_list or fam_name.endswith("_SS"):
                        try:
                            doc.Delete(tb.Family.Id)
                        except:
                            local_report += "Delete title block " + fam_name + " Failed.\n"
                else:
                    if fam_name in old_fam_list:
                        try:
                            tb.Family.Name = fam_name + "_SS"
                        except:
                            local_report += "Supersed title block " + fam_name + " Failed.\n"

        t.Commit()
    return local_report

def enable_disable_buttons(tab_name, panel_name, item_name,
                        enabled=True,
                        is_pulldown=False,   # "button" or "pulldown"
                        affect_children=False,
                        debug=False):
    """
    Enable/disable a ribbon UI item (button or pulldown).

    Args:
        tab_name (str): Tab name (as shown in Revit UI)
        panel_name (str): Panel name
        item_name (str): Button or pulldown name
        enabled (bool): True = enable, False = disable
        item_type (str): "button" or "pulldown"
        affect_children (bool): If True, also apply to children (recommended for pulldowns)
        debug (bool): Print debug info

    Returns:
        bool: True if successful, False otherwise
    """

    try:
        ui = ribbon.get_current_ui()

        tab = ui.find_child(tab_name)
        if not tab:
            if debug: print("Tab not found:", tab_name)
            return False

        panel = tab.find_child(panel_name)
        if not panel:
            if debug: print("Panel not found:", panel_name)
            return False

        item = panel.find_child(item_name)
        if not item:
            if debug: print("Item not found:", item_name)
            return False

        # Set main item state
        item.enabled = enabled

        # If pulldown, optionally affect children
        if is_pulldown == True and affect_children:
            try:
                for child in item.get_children():
                    child.enabled = enabled
            except:
                if debug: print("Could not access children of:", item_name)

        if debug:
            print("[{}] '{}' -> {}".format(
                "Pulldown" if is_pulldown else "Button",
                item_name,
                "ENABLED" if enabled else "DISABLED"
            ))

        return True

    except Exception as e:
        if debug:
            print("Error:", str(e))
        return False

def extract_lines(file_path, search_term):  # Get the coordinates for title blocks
    mm_to_feet = 1 / 304.8
    with open(file_path, 'r') as file:
        lines = file.readlines()

    line_coords = []
    capture = False

    for line in lines:
        stripped_line = line.strip()

        if search_term in stripped_line:
            capture = True

        if capture:
            if stripped_line == "":  # Stop capturing if we hit a blank line
                break
            coords = stripped_line.split(',')
            if len(coords) == 3:
                # Convert from millimeters to feet
                x = float(coords[0]) * mm_to_feet
                y = float(coords[1]) * mm_to_feet
                z = float(coords[2]) * mm_to_feet
                revit_point = XYZ(x, y, z)
                line_coords.append(revit_point)

    return line_coords

def extract_number(project_code):
    match = re.search(r"STP(\d+)-(\d+)", project_code)
    if match:
        year = int(match.group(1))
        number = int(match.group(2))
        return (year, number)
    return (0, 0)  # fallback if format is wrong

def fill_design_drafter(file_path):
    drafter_list = []  
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            drafter_list = [line.strip() for line in file.readlines()]
    else:
        drafter_list.append("File not found")
    
    if not "Design" in file_path:
        return sorted(drafter_list)
    else:
        return drafter_list

def fill_design_info(doc, List, stage):
    drafter = get_initials(List[0] if List[0] != "Other" else "")
    designer = get_initials(List[1] if List[1] != "Other" else "")
    approver_name = List[2]
    approver = get_initials(approver_name if approver_name != "Other" else "")
    signature = "Signature " + approver_name.replace(" Florence", "").replace(" Graham","")
    
    f15 = List[3]
    f15_sign = "Signature - " + f15
    f15_cred = "Cridentials - " + f15
    p_client = List[4]
    
    design_parameters = ["Drawn By", "Designed By", "Approved By"]
    design_parameters.extend((approver_name, signature))
    design_values = [drafter, designer, approver, int(1), int(1)]
    
    sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    
    # Filter only sheets whose number starts with "S"
    filtered_sheets = [sheet for sheet in sheets if sheet.SheetNumber.startswith("S")]
    
    #if os.environ.get("USERNAME") != "Rafael":
    with revit.Transaction("Update Design Info"):
    # For each filtered sheet, collect its title block instances
        with forms.ProgressBar(title='Update Design Info') as pb:
            lim = len(filtered_sheets)
            for x, sheet in enumerate(filtered_sheets):
                title_blocks = FilteredElementCollector(doc, sheet.Id)\
                    .OfClass(FamilyInstance)\
                    .OfCategory(BuiltInCategory.OST_TitleBlocks)\
                    .ToElements()

                for tb in title_blocks:
                    if not "Brian" in approver_name:
                        param = tb.LookupParameter("Brian Mayer"); param and param.Set(int(0))
                        param = tb.LookupParameter("Signature Brian Mayer"); param and param.Set(int(0))
                
                    for par, val in zip(design_parameters, design_values):
                        param = tb.LookupParameter(par); param and param.Set(val)
                
                pb.update_progress(x, lim + 1)
                
            filtered_sheets = [sheet for sheet in sheets if sheet.SheetNumber.startswith("1")]

            for sheet in filtered_sheets:
                title_blocks = FilteredElementCollector(doc, sheet.Id).OfCategory(BuiltInCategory.OST_TitleBlocks).WhereElementIsNotElementType()
                for tb in title_blocks:
                    if tb.Name == "STP_A4_Transmittal-Vertical":
                        param = tb.LookupParameter("Distribution 1"); param and param.Set(p_client)
                    tb_type = doc.GetElement(tb.GetTypeId())
                    if not "Brian" in f15:
                        type_param = tb_type.LookupParameter("Cridentials - Brian"); type_param and type_param.Set(int(0))
                        type_param = tb_type.LookupParameter(f15_cred); type_param and type_param.Set(int(1))
                        param = tb.LookupParameter("Signature - Brian"); param and param.Set(int(0))
                        param = tb.LookupParameter(f15_sign); param and param.Set(int(1))
    
    if drafter:
        return drafter
    else:
        return ""

def fill_titleblock_list(path, stage):
    local_report = ""
    
    tb_names = []
    tb_pahts = []
    tb_version = []
    tb_side = []
    tb_size = []
    tb_Info = []
    
    # Open the file and read it line by line
    try:
        with open(path, 'r') as file:
            for line in file:
                # Look for lines starting with 'tb_path ='
                if line.strip().startswith('tb_path'):
                    tb_pahts.append(line.strip()[10:])
                if line.strip().startswith('name'):
                    tb_names.append(line.strip()[7:])
                if line.strip().startswith('version'):
                    tb_version.append(line.strip()[7:])
                if line.strip().startswith('side'):
                    tb_side.append(line.strip()[7:])
                if line.strip().startswith('size'):
                    tb_size.append(line.strip()[7:])
            
            tb_Info = ((tb_names, tb_pahts, tb_version, tb_side, tb_size))
            local_report += u"\u2705 Stage: " + stage + " [Read Title Block List] Success \n"
            
    except Exception as e:
        local_report += u"\u26A0 Stage: " + stage + ": Fail: \n" + str(e) + "\n"
        local_report += traceback.format_exc()

    return local_report, tb_Info

def fill_tracking_data(path, p_numb, user, file, version, start_time, end_time, items, stage):
    testing = False #Make true when testing the function only
    
    if ("XXXX" in p_numb or "TEST" in p_numb) and not testing:
        return ""
    else:
        local_report = ""
        new_line = "Project Number:, " + p_numb
        new_line += ", User:, " + user
        new_line += ", File:, " + file
        new_line += ", Version:, " + version
        new_line += ", Start Time:, " + start_time
        new_line += ", End Time:, " + end_time
        new_line += ", Loaded Items:, " + items

        try:
            with open(path, "a") as f:
                f.write(new_line + "\n")
            local_report += u"\u2705 Stage: " + stage + ": [Update Tracking data] Success. \n"
        except Exception as e:
            local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
            
        return local_report

def find_post_code(lib_path, suburb):
    postcode = "" # No Code
    council = ""
    codes_path = os.path.join(lib_path, "STP_Data base", "postcode list.txt")
    suburb_line = ""
    sl = len(suburb)
    n = 0
    
    try:
        with open(codes_path, 'r+') as file:
            lines = file.readlines()
            # Find if the suburb exists in the list
            for line in lines:
                if "#" in line:
                    suburb_in_line = line.split("#")[0].strip()
                    if suburb.upper() == suburb_in_line.upper():
                        suburb_line = line
                        break
            
            # Depends on action, read the suburb or record new entry
            if suburb_line:
                n = line.find("#")
                if n > 0:
                    postcode = line[n+1:n+5]
                    if len(line) > n + 7:
                        council = line[n+6:].replace("\n","")
    except:
        pass
    
    return postcode, council

def fill_project_info(doc, params, stage):
    local_report = ""
    aux_Address = ""

    try:
        project_info = doc.ProjectInformation
        if not project_info.LookupParameter("Suburb"):
            aux_Address = params[2][1] + ", " + params[3][1] + ", QLD, " + params[4][1]
        with revit.Transaction("STP Tools-parameters"):
            for x, param in enumerate(params):
                param_name = ""
                for info_param in project_info.Parameters:
                    if info_param.Definition.Name == param[0]:
                        param_name = info_param
                        break
                if param_name:
                    try:
                        info_param.Set(params[x][1])
                        if param_name.Definition.Name == "Project Address" and aux_Address:
                            info_param.Set(aux_Address)
                        local_report += u"\u2705 Stage: " + stage + ": '" + params[x][0] + "' Load Success \n"
                    except:
                        local_report += u"\u26A0 Stage: " + stage + ": '" + params[x][0] + "' not Loaded Warning \n"
                else:
                    local_report += u"\u26A0 Stage:  " + stage + ": '" + params[x][0] + "' not Found Warning \n"
    except Exception as e:
        local_report += u"\u274C " + stage + ": Fail: " + str(e) + "\n"
        mssg = "Error while Setting Project Information\n\n Please contact STP Tools development"
        title = "Project info Error"
        aborting_script(local_report, title, mssg)

    return local_report

def flatten_list(List):
    new_list = []
    for sub in List:
        if sub[0]:
            new_list.append(sub[0])
    return new_list

def get_initials(name):
    val = "".join(word[0].upper() for word in name.split() if word)
    return val if val != "BM" else "BRM"

def get_project_folders_from_onedrive(user_name, lib_path, stage = "N/A"):
    local_report = ""
    
    if "bin" in lib_path: # This is for drafters who work in a local machine not connected to share point
        forms.alert("Select the folder for new project")
        selected_folder = forms.pick_folder(
            title="Select STP Tools Folder"
        )   

        if selected_folder and os.path.exists(selected_folder):
            local_report += u"\u2705 Stage: " + stage + ": [STP folders Loaded to List] Success:\n"
            return local_report, [selected_folder]
        else:
            sys.exit()

    else: #And this is for everyone else
        possible_jobs_path = [
            r"D:\OneDrive - STP Consultants",
            r"E:\OneDrive - STP Consultants",
            r"C:\STP Consultants\OneDrive - STP Consultants",
            r"D:\STP Consultants\OneDrive - STP Consultants",
            r"C:\Users\STP Consultants",
            r"C:\Users\{}\STP Consultants".format(user_name),
            r"E:\Users\{}\STP Consultants".format(user_name),
            r"C:\Users\{}\OneDrive - STP Consultants".format(user_name),
            r"E:\Users\{}\OneDrive - STP Consultants".format(user_name),
            r"C:\Users\{}\STP Consultants".format(user_name + ".STPTSV"),
            r"E:\Users\{}\STP Consultants".format(user_name + ".STPTSV"),
            r"C:\Users\{}\OneDrive - STP Consultants".format(user_name + ".STPTSV"),
            r"E:\Users\{}\OneDrive - STP Consultants".format(user_name + ".STPTSV"),]
        
        stp_folders = []
        projects = []
        aux_list = []

        # Regular expression to match folder names starting with 'STP' followed by two digits
        pattern = re.compile(r"^STP\d{2}")
        for path in possible_jobs_path:
            if os.path.exists(path) and os.path.exists(os.path.join(path, 'desktop.ini')):
                try:
                    for item in os.listdir(path):  # List all items in the directory
                        if os.path.isdir(os.path.join(path, item)):  # Check if the item is a folder
                            if pattern.match(item):  # Check if it matches the STP format
                                confirm_folder_path = os.path.join(path, item, "QA")  # Confirm project folder
                                if os.path.exists(confirm_folder_path):
                                    stp_folders.append((item, os.path.join(path, item)))
                                
                            # Now check one level down in this folder
                            subfolder_path = os.path.join(path, item)
                            for sub_item in os.listdir(subfolder_path):  # List all items in the sub-folder
                                if os.path.isdir(os.path.join(subfolder_path, sub_item)) and pattern.match(sub_item):
                                    confirm_folder_path = os.path.join(subfolder_path, sub_item, "QA")  # Confirm project folder
                                    if os.path.exists(confirm_folder_path):
                                        stp_folders.append((sub_item, os.path.join(subfolder_path, sub_item)))

                        # Check if desktop_ini exists to monitore not synced onedrive folder
                        try:
                            if not os.path.exists(os.path.join(path, 'desktop.ini')):
                                file_path = os.path.join(lib_path, "STP_Data base", "no sync onedrive report.txt")
                                #with open(file_path, 'a') as file:
                                #    file.write("\n[" + user_name + "] " + path + " / No desktop_ini")
                        except:
                            pass
                except:
                    pass
        if stp_folders:
            for folder in stp_folders:
                code = folder[0][:10]
                p_numbs = ""
                p_names = ""
                
                # Check the project code and name based on different patterns
                try:
                    if code[-3:] == "xxx":
                        p_numbs = folder[0][13:][:10]
                        p_names = folder[0][24:]
                    elif code[5] == "-":
                        p_numbs = folder[0][:10]
                        p_names = folder[0][11:]
                    elif code[-1] == " ":
                        p_numbs = folder[0][:5] + "-" + folder[0][5:9]
                        p_names = folder[0][10:]
                    
                    if p_numbs != "":
                        # Append the tuple with project number, name, and folder path
                        aux_list.append((p_numbs, p_names, folder[1]))
                except:
                    pass
            
            if aux_list:
                # Sort the projects by project number
                projects = sorted(aux_list, reverse=True)
                local_report += u"\u2705 Stage: " + stage + ": [STP folders Loaded to List] Success:\n"


        return local_report, projects

def get_project_info(doc, stage = "N/A"):
    List = []
    local_report = ""
    
    project_info = doc.ProjectInformation
    params = ["Project Number", "Project Name", "Project Address",
              "Suburb", "Postcode", "Client Name"]
    
    for param in params:
        par_name = project_info.LookupParameter(param)
        if par_name:
            List.append(par_name.AsString())
        else:
            List.append("N/F")

    if not "N/F" in List:
        local_report += u"\u2705 Stage: " + stage + ": [Find Parameters] Sucess\n"
    else:
        local_report += u"\u26A0 Stage: " + stage + ": [Missing Parameters] Warning\n"
    
    return local_report, List

def get_qa_path(lib_path, p_path, p_numb, stage, eData = {}):
    local_report = "QA file not found"
    qa_exist = False
    
    qa_folder = os.path.join(p_path, "Drawings")
    qa_path = os.path.join(qa_folder, p_numb + "_QA_Checklist.xlsx")
    txt_path = os.path.join(qa_folder, "r25_support_temp_file.txt") #Check if the previous version exists to change
    ss_path = os.path.join(qa_folder, "SS_support_temp_file_SS.txt")
    
    if os.path.exists(txt_path):
        stage = "Update V2 Files"
        local_report = ""
        #Check if old macro excel file exists and delete it
        macro_path = qa_path.replace("xlsx", "xlsm")
        if os.path.exists(macro_path):
            os.remove(macro_path)
            local_report += u"\u2705 Stage: " + stage + ": [Excel Macro old version delete] Success \n"
        
        #Copy the V2 file excel into folder
        qa_path = copy_QA_excel_file_to_folder(lib_path, qa_folder, p_numb)
        local_report += u"\u2705 Stage: " + stage + ": [Excel file V2 update] Success \n"
        
        with open(txt_path, "r") as f:
            copied_lines = f.readlines()
        
        first_line = True
        qa_copied_lines = []
        
        for line in copied_lines:
            items = [x.strip() for x in line.strip().split(",")]
            if first_line:
                eData["p_type"] = items[1][-4:]
                eData["ini_type"] = eData["p_type"]
            else:
                qa_copied_lines.append(items)
            first_line = False
        write_qa_excel_file_V2(qa_path, stage, qa_copied_lines, eData)
        qa_exist = True
        local_report += u"\u2705 Stage: " + stage + ": [History copied to new Excel file] Success \n"
        os.rename(txt_path, ss_path)
        qa_exist = True
    
    elif os.path.exists(qa_path):
        local_report = u"\u2705 Stage: " + stage + ": [QA File V2 found] \n"
        qa_exist = True
        
    return local_report, qa_exist, qa_path

def is_file_open(filepath):
    if not os.path.exists(filepath):
        return False
    try:
        # Try opening the file with exclusive access
        with open(filepath, 'r+') as f:
            return False  # File is accessible, so not open elsewhere
    except IOError:
        return True  # File is in use

def load_title_block(tb_source, tb_target, doc, stage):
    local_report = ""
    if os.path.exists(tb_source):
        if tb_source != tb_target and tb_source != "QA_path":
            try:
                shutil.copy2(tb_source, tb_target)
            except Exception as e:
                local_report += u"\u274C " + stage + ": Fail: " + str(e) + "\n"
                local_report += traceback.format_exc()
    else:
        if not tb_source == "QA_data":
            local_report += u"\u26A0 Stage: " + stage + ": [Title Block Source not exist. Check with STP Tool admin.] \n"
            return local_report, False
    
    if os.path.exists(tb_target):
        local_report += u"\u2705 Stage: " + stage + ": Success: New TitleBlock Copied to xref folder \n"
        with revit.Transaction("STP Tools-Load TB"):
            try:
                family = doc.LoadFamily(tb_target)
                local_report += u"\u2705 Stage: " + stage + ": Success: Title Block Family Loaded \n"
            except Exception as e:
                local_report += u"\u274C " + stage + ": Fail: " + str(e) + "\n"
                local_report += traceback.format_exc()
                return local_report, False
    else:
        local_report += u"\u26A0 Stage: " + stage + ": Fail: [Target Family not Found] \n"
        forms.alert(
                os.path.basename(tb_target) + 
                " was expected in the 'Xref' folder but was not found." + 
                " It may have been deleted. \n\nTitle block could not be loaded.",
                title = "Title Block not found"
                    )
        return local_report, False

    return local_report, True

def move_qa_to_drawings(path, file_type):
    stage = "QA Check List Migration"
    mssg = ""
    local_report = ""
    
    source_path = os.path.join(path, "QA", "Certification and Check Sheets", file_type) #p_numb + "_QA_Checklist.xlsx")
    destination_path = source_path.replace("QA\Certification and Check Sheets","Drawings")
    
    if os.path.exists(destination_path):
        return destination_path
    
    elif os.path.exists(source_path):
        shutil.move(source_path, destination_path) #Change this to move at the end
        if os.path.exists(destination_path):
            mssg = "The existing QA checklist has been moved from 'Certification and Check Sheets' to 'Drawings' folder.\n\nPlease note: this is a one-time action."
            if not "support" in destination_path:
                forms.alert(mssg, title="File Moved", ok=True)
            return destination_path
    else:
        return destination_path

def open_qa_excel_file(qa_path, dwg , tb_name, stage):
    clr.AddReference('Microsoft.Office.Interop.Excel')
    from Microsoft.Office.Interop import Excel
    
    excel = Excel.ApplicationClass()
    workbook = None
    local_report = ""
    funct_report = ""
    try:
        workbook = excel.Workbooks.Open(qa_path)
        if dwg and workbook.Sheets["Changes_Record"].Cells(2, 12).Value2 == "DWG":
            workbook.Sheets["Changes_Record"].Cells(2, 12).Value2 = dwg
            workbook.Sheets["Changes_Record"].Cells(2, 7).Value2 = tb_name
        if workbook:
            local_report += u"\u2705 Stage: " + stage + ": [Existing QA file Found] Success \n"
    except Exception as e:
        local_report += u"\u274C Stage: " + stage + ": [FAIL]\n" + str(e) + "\n"
        local_report += traceback.format_exc()
        local_report += safely_close_excel(locals(), excel, workbook, stage)
        pass
    
    if wait_for_excel_ready(excel):
        excel.Visible = True
        funct_report = bring_excel_to_front(excel)
        if funct_report:
            local_report += funct_report
    
    if 'workbook' in locals():
        del workbook
    if 'excel' in locals():
        del excel
        gc.collect()

    return True, local_report, False

def read_qa_excel_file(qa_path, project_path, stage):
    clr.AddReference('Microsoft.Office.Interop.Excel')
    from Microsoft.Office.Interop import Excel
    
    local_report = ""
    next_reng = 0
    last_record = []
    extra_data = []
    mssg = ""

    with forms.ProgressBar(title='Reading QA Check List') as pb:
        pb.update_progress(0.1, 1)
        excel = Excel.ApplicationClass()
        excel.Visible = False
        workbook = None
        tb_Hist = []

        if is_file_open(qa_path):
            mssg = "QA file: " + os.path.basename(qa_path) + " is currently open. \n\nPlease close it before continuing and then try again."
            title = "Excel File Open"
            try:
                del excel
            except:
                pass
            aborting_script("", title, mssg)
        else:
            try:
                workbook = excel.Workbooks.Open(qa_path)
                data = workbook.Sheets('Changes_Record')
                local_report += u"\u2705 Stage: " + stage + ": Success [Open Excel File Success] \n"
            except Exception as e:
                try:
                    del data
                except:
                    pass
                local_report += u"\u274C Stage: " + stage + ": [Fail Reading Excel Info]\n"
                local_report += safely_close_excel(locals(), excel, workbook, stage)
                local_report += "\n" + str(e) + "\n" + support_mssg
                mssg = "Internal error [E01] while reading QA file\n\n please contact STP Tool developer."; title = "Excel File Readig Error"
                aborting_script(local_report, title, mssg)
            max_rows = 20
            next_reng = 1
            try:
                while next_reng <= max_rows:
                    value = data.Cells(next_reng, 1).Value2
                    tb_temp = data.Cells(next_reng,7).Value2
                    if not tb_temp in tb_Hist and tb_temp != "TITLE BLOCK NAME":
                        tb_Hist.append(tb_temp)
                    if not value or str(value).strip() == "":
                        break
                    next_reng += 1
                local_report += u"\u2705 Stage: " + stage + ": [Read Info Success] \n"
            except Exception as e:
                local_report += u"\u274C Stage: " + stage + ": [Fail Reading Excel Lines]\n"
                local_report += safely_close_excel(locals(), excel, workbook, stage)
                local_report += "\n" + str(e) + "\n" + support_mssg
                mssg = "Internal error [E02] while reading QA file\n\n please contact STP Tool developer."; title = "Excel File Readig Error"
                aborting_script(local_report, title, mssg)

            next_reng = next_reng - 1
            pb.update_progress(0.5, 1)
            pb.title = "Extracting Values..."

            try:
                # Main Line
                p_Name = data.Cells(next_reng,2).Value2
                p_Client = data.Cells(next_reng,3).Value2
                p_Address = data.Cells(next_reng,4).Value2
                p_Suburb = data.Cells(next_reng,5).Value2
                p_Pcode = data.Cells(next_reng,6).Value2
                tb_Name = data.Cells(next_reng,7).Value2
                tb_Type = data.Cells(next_reng,8).Value2
                tb_Side = data.Cells(next_reng,9).Value2
                tb_Size = data.Cells(next_reng,10).Value2
                last_user = data.Cells(next_reng,11).Value2
                
                pb.update_progress(0.6, 1)
                # Extra Data
                p_Type = data.cells(1,2).Value2
                qa_revit_version = data.Cells(2,12).Value2
                qa_revit_version = str(qa_revit_version).replace(".0","")
                first_user = data.Cells(2,11).Value2
                tb_target_path = os.path.join(project_path,"Drawings","xref",tb_Name)
                
                pb.update_progress(0.7, 1)
                pb.title = "Importing List..."
                
                last_record = [next_reng, p_Name, p_Client, p_Address, p_Suburb, p_Pcode, tb_Name, tb_Type, tb_Side, tb_Size, last_user]
                extra_data = [p_Type, qa_revit_version, first_user, tb_Hist, tb_target_path]
                local_report += u"\u2705 Stage: " + stage + ": [Project Info List created] Success \n"
                
                pb.update_progress(0.8, 1)
                try:
                    workbook.Close()
                    del workbook
                    excel.Quit()
                    del excel
                    gc.collect()
                except:
                    local_report += u"\u26A0 Stage: " + stage + ": [Excel file did not close properly] \n"
                    pass
                pb.update_progress(0.9, 1)
                return local_report, last_record, extra_data
                
            except Exception as e:
                local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
                local_report += traceback.format_exc()
                mssg = "Internal error [E03] while reading QA file\n\n please contact STP Tool developer."; title = "Excel File Readig Error"
                aborting_script(local_report, title, mssg)
                
    return "", last_record, extra_data

def get_excel_pids():
    pids = set()
    for p in diag.Process.GetProcessesByName("EXCEL"):
        try:
            pids.add(p.Id)
        except:
            pass
    return pids

def kill_excel_pids(pid_set):
    for p in diag.Process.GetProcessesByName("EXCEL"):
        try:
            if p.Id in pid_set:
                p.Kill()
        except:
            pass

def read_qa_excel_file_V2(qa_path, stage, eData = {}):
    excel = None
    workbook = None
    workbooks = None
    sheets = None
    sheet = None
    cells = None
    local_report = ""
    
    try:
        f = open(qa_path, "a")
        f.close()
    except:
        forms.alert(
            "STP Tools found a problem while reading the QA Excel file.\n\n"
            "This usually happens when the file is open or Excel is still running in the background.\n\n"
            "Please close all Excel windows (including background processes directly from 'Task Manager') and try again.\n\n"
            "If the issue continues, contact the STP Tools developer.",
            title="Error Reading QA File"
        )
        sys.exit()

    try:
        excel_type = Type.GetTypeFromProgID("Excel.Application")
        if excel_type is None:
            raise Exception("Excel COM ProgID not found")

        excel = Activator.CreateInstance(excel_type)
        #print("TRY IS RUNNING")
        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)

        workbooks = com_get(excel, "Workbooks")
        workbook = com_call(workbooks, "Open", qa_path)

        sheets = com_get(workbook, "Worksheets")
        sheet = com_get(sheets, "Item", "Changes_Record")
        cells = com_get(sheet, "Cells")

        # -------- find last row --------

        max_excel_rows = 1048576
        last_cell_col_a = com_get(cells, "Item", max_excel_rows, 1)
        end_up = com_get(last_cell_col_a, "End", -4162)   # xlUp
        last_row = com_get(end_up, "Row")

        # -------- find last column --------

        max_excel_cols = 16384
        last_cell_in_row = com_get(cells, "Item", last_row, max_excel_cols)
        end_left = com_get(last_cell_in_row, "End", -4159)   # xlToLeft
        last_col = com_get(end_left, "Column")

        # -------- read last row --------

        main_data = []

        for c in range(1, last_col + 1):
            cell = com_get(cells, "Item", last_row, c)
            value = com_get(cell, "Value2")
            main_data.append(value)

        # -------- extra fixed values --------

        p_Type = com_get(com_get(cells, "Item", 1, 2), "Value2")

        qa_revit_version = com_get(com_get(cells, "Item", 2, 12), "Value2")
        qa_revit_version = str(qa_revit_version).replace(".0", "")

        first_user = com_get(com_get(cells, "Item", 2, 11), "Value2")

        # -------- collect unique values from column G --------

        type_list = []
        seen = set()

        for r in range(2, last_row + 1):  # skip header row
            cell = com_get(cells, "Item", r, 7)
            value = com_get(cell, "Value2")

            if value not in [None, ""]:
                value = str(value)

                if value not in seen:
                    seen.add(value)
                    type_list.append(value)

        # -------- combine extra data --------
        eData["ini_type"] = p_Type[-4:]
        eData["qa_revit_version"] = qa_revit_version
        eData["first_user"] = first_user
        eData["tb_history"] = type_list
        
        local_report += u"\u2705 Stage: " + stage + ": [Reading QA File data] Success \n"
        return local_report, main_data

    except Exception as e:
        #print("EXCEPT IS RUNNING")
        local_report += u"\u274C Stage: " + stage + ": [FAIL]\n" + str(e) + "\n"
        local_report += traceback.format_exc()

        # kill any new Excel processes created during this run
        title = "Error while reading excel file"
        mssg = "STP Tools found a problem while reading QA existing file for this project.\n\nPlease contact STP Tool developer for further support."
        aborting_script(local_report, title, mssg)
        

    finally:
        #print("FINALLY IS RUNNING")
        try:
            if workbook:
                com_call(workbook, "Close", False)
        except:
            pass

        try:
            if excel:
                com_call(excel, "Quit")
        except:
            pass
            
        cells = None
        sheet = None
        sheets = None
        workbook = None
        workbooks = None
        excel = None

def read_r25_support_file(project_path, stage):
    local_report = ""
    List = []
    tb_Hist = []
    txt_path = os.path.join(project_path, "Drawings", 
        "r25_support_temp_file.txt")
    try:
        with open(txt_path, 'r') as file:
            lines = file.readlines()
    except Exception as e:
        local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
        local_report += support_mssg
        mssg = "Internal error [E05] while reading QA file\n\n please contact STP Tool developer."; title = "Excel File Readig Error"
        aborting_script(local_report, title, mssg)
        
    if lines and len(lines) > 1:
        first_user = lines[1].split(', ')[10]
        last_line = lines[-1].split(', ')
        p_Name = last_line[1]
        p_Client = last_line[2]
        p_Address = last_line[3]
        p_Suburb = last_line[4]
        p_Pcode = last_line[5]
        tb_Name = last_line[6]
        tb_Type = last_line[7]
        tb_Side = last_line[8]
        tb_Size = last_line[9]
        tb_target_path = os.path.join(project_path,"Drawings","xref",tb_Name)
        last_user = last_line[10]
        qa_revit_version = last_line[11]
        p_Type = lines[0].split(', ')[1]
        n_lines = len(lines)
        for line in lines:
            tb_temp = line.split(', ')[6]
            if not tb_temp in tb_Hist and tb_temp != "TITLE BLOCK NAME":
                tb_Hist.append(tb_temp)
        
        last_record = [n_lines, p_Name, p_Client, p_Address, p_Suburb, p_Pcode, tb_Name, tb_Type, tb_Side, tb_Size, last_user]
        extra_data = [p_Type, qa_revit_version, first_user, tb_Hist, tb_target_path]
        
        local_report += u"\u2705 Stage: " + stage + ": [Project Info List created] Success \n"
    else:
        local_report += u"\u274C Stage: " + stage + ": [No lines to read in txt file]\n"
        local_report += support_mssg
        mssg = "Internal error [E06] while reading QA file\n\n please contact STP Tool developer."; title = "Excel File Readig Error"
        aborting_script(local_report, title, mssg)
    
    return local_report, last_record, extra_data

def remove_non_ascii(text):
    res = ""
    for c in text:
        if c == u'\u2019':
            c = "'"
        res = res + c
    return res

def remove_spaces_and_points(val):
    text = str(val)
    Symbols = [".", " ", "."]
    n = len(text)
    if n > 0:
        for n in range(n):
            if text[n] not in Symbols:
                break
    
    return text[n:]

def replace_title_block(doc, sheet_list, source_tblock, new_tb, dx, dy):
    local_report = ""

    # Collect all title block types
    titleblock_types = FilteredElementCollector(doc)\
        .OfCategory(BuiltInCategory.OST_TitleBlocks)\
        .WhereElementIsElementType()\
        .ToElements()

    current_tb_names = {tb.Family.Name: tb for tb in titleblock_types}
    
    if source_tblock in current_tb_names and new_tb in current_tb_names:
        source_type = current_tb_names[source_tblock]
        new_type = current_tb_names[new_tb]

        # First: collect all replacements
        to_replace = []

        sheets = FilteredElementCollector(doc)\
            .OfCategory(BuiltInCategory.OST_Sheets)\
            .WhereElementIsNotElementType()\
            .ToElements()
        
        with forms.ProgressBar(title='Finding Sheets to replace') as pb:
            dt = 0.5 / len(sheets)
            x = 0
            n_item = 0

            for sheet in sheets:
                pb.update_progress(x + dt, 1)
                x = x + dt
                n_item += 1
                pb.title = 'Finding Sheets to replace ' + str(n_item) + ' of ' + str(len(sheets))
                
                if sheet.SheetNumber in sheet_list or sheet_list == "ALL":
                    tblocks = FilteredElementCollector(doc, sheet.Id)\
                        .OfCategory(BuiltInCategory.OST_TitleBlocks)\
                        .WhereElementIsNotElementType()\
                        .ToElements()
                
                    for tb in tblocks:
                        tb_type = doc.GetElement(tb.GetTypeId())
                        if tb_type.Family.Name == source_tblock:
                            location = tb.Location
                            if hasattr(location, 'Point'):
                                to_replace.append((sheet.Id, tb.Id, location.Point))

            transaction = Transaction(doc, "Replace Title Blocks")
            if to_replace:
                dt = 0.5 / len(to_replace)
                x = 0.5
                try:
                    with revit.Transaction("Replace Title Blocks"):
                        for sheet_id, old_tb_id, point in to_replace:
                            pb.update_progress(x + dt, 1)
                            x = x + dt
                            pb.title = "Replacing sheet " + sheet.SheetNumber
                            # Delete old title block
                            doc.Delete(old_tb_id)

                            # Add new one
                            sheet = doc.GetElement(sheet_id)
                            titleblock = doc.Create.NewFamilyInstance(point, new_type, sheet)
                            if dx > 0 or dy > 0:
                                move_vector = XYZ(dx, dy, 0)
                                ElementTransformUtils.MoveElement(doc, titleblock.Id, move_vector)

                    local_report += u"\u2705 Stage: Replace Title Block Success \n"
                
                except Exception as e:
                    if transaction.HasStarted():
                        transaction.RollBack()
                    local_report += u"\u274C Stage: Replace Title Block Fail: " + str(e) + ".\n"
                    return local_report, False
    else:
        local_report += u"\u274C Stage: Replace Title Block Fail: One or both title block types not found.\n"
        return local_report, False
    
    return local_report, True

def safely_close_excel(local_vars, excel, workbook, stage):
    local_report = u"\u26A0 Stage: " + stage + ": [Excel Forced to Close in Safe Mode]\n"
    if 'workbook' in local_vars and workbook is not None:
        try:
            workbook.Close(SaveChanges=False)
        except Exception as e:
            local_report = "Error closing workbook: " + str(e)
    
    if 'excel' in local_vars and excel is not None:
        if wait_for_excel_ready(excel):
            try:
                excel.Quit()
            except Exception as e:
                local_report = "Error closing excel: " + str(e)
            finally:
                try:
                    del excel
                    gc.collect()
                except:
                    pass
    
    return local_report

def split_address(lib_path, address):
    p_address = ""
    p_suburb = ""
    p_pcode = ""
    p_region = ""
    abrevations = [" ST", " RD", " DR"]
    roads = ["ROAD", "STREET", "AVENUE", "BOULEVARD", "DRIVE", "LANE", "CRESCENT", "TERRACE", "CIRCUIT", "COURT", "WAY", "CLOSE"]
    found_road = None
    #roads.extend(abrevations)
    len_word = 0
    p_address = "N/F"; p_suburb = ""; p_pcode = ""
    
    for road in roads:
        if road in address:
            found_road = road
            break
            
    if not found_road:
        for road in abrevations:
            if road in address:
                found_road = road
                break
        
    if found_road:
        position = address.find(road)
        if position > 0:
            len_word = len(road)
            p_address = address[:(position + len_word)]
            p_suburb = remove_spaces_and_points(address[(position + len_word) + 1:])

    if p_suburb:
        p_pcode, p_region = find_post_code(lib_path, p_suburb)
    
    return p_address, p_suburb, p_pcode, p_region

def supersed_tblock_family(tb_names):
    symbols = (
        FilteredElementCollector(revit.doc)
        .OfClass(FamilySymbol)
        .OfCategory(BuiltInCategory.OST_TitleBlocks)
    )
    
    with revit.Transaction("Rename Annotation Family"):
        for symbol in symbols:
            family = symbol.Family
            
            for item in tb_names:
                tb_name = item.replace(".rfa","")
                if family.Name in tb_name:
                    family.Name = family.Name + "_SS"
                    break
        
def wait_for_excel_ready(excel_app, timeout=10):
    import System

    start = time.time()
    while time.time() - start < timeout:
        try:
            # Try a harmless call to see if Excel is ready
            _ = excel_app.Visible
            return True  # If no error, Excel is ready
        except System.Runtime.InteropServices.COMException:
            time.sleep(0.1)  # Wait a little and try again
    
    return False  # Timed out

def write_r25_support_file(project_path, new_line, stage):
    local_report = ""
    txt_path = os.path.join(project_path, "QA", "Certification and Check Sheets", 
        "r25_support_temp_file.txt")
    if txt_path:
        with open(txt_path, "a") as file:
            file.write(new_line)
            local_report += u"\u2705 Stage: " + stage + ": [Add New Line to r25support] Success \n"
    
    else:
        local_report += u"\u274C Stage: " + stage + ": [Fail] \n" + str(e) + "\n"
        return False, local_report
    return True, local_report

def write_qa_excel_file(qa_path, stage, qa_new_line, eData):
    clr.AddReference('Microsoft.Office.Interop.Excel')
    from Microsoft.Office.Interop import Excel
    from Microsoft.Office.Interop.Excel import XlDirection
    
    workbook = None
    local_report = ""
    funct_report = ""
    if stage == "Modify QA Check List file":
        mssg = "Project Information Updated. \n\nPlease fill out your initials if required."
    else:
        mssg = "New Project Created. \n\nPlease fill out your initials if required."
    data = None
    
    if os.path.exists(qa_path):
        excel = Excel.ApplicationClass()
        excel.Visible = False
        
        try:
            workbook = excel.Workbooks.Open(qa_path)
        except Exception as e:
            local_report += u"\u274C Stage: " + stage + "[Fail to open Excel]\n" + str(e) + "\n"
            local_report += safely_close_excel(locals(), excel, workbook, stage)
            mssg = "Internal error [E07] while writting QA file\n\n please contact STP Tool developer."; title = "Excel File writting Error"
            return local_report, mssg, True
        # Find the latest occupied row
        if workbook:
            if wait_for_excel_ready(excel):
                data = workbook.Sheets('Changes_Record')
            else:
                local_report += u"\u274C Stage:" + stage + ": [Excel App did not answer and should close] /n"
                local_report += safely_close_excel(locals(), excel, workbook, stage)
                mssg = "Internal error [E08] while writting QA file\n\n please contact STP Tool developer."; title = "Excel File writting Error"
                return local_report, mssg, True
            
            # Fill out optimal cells
        if data:
            if wait_for_excel_ready(excel):
                try:
                    last_row = data.Cells(data.Rows.Count, 1).End(XlDirection.xlUp).Row
                    for x, item in enumerate(qa_new_line):
                        if item == "#":
                            data.Cells(last_row + 1, x + 1).Value2 = last_row
                        else:
                            data.Cells(last_row + 1, x + 1).Value2 = item
                    local_report += u"\u2705 Stage: " + stage + ": [Write New Line] Success. \n"
                except Exception as e:
                    local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
                    local_report += safely_close_excel(locals(), excel, workbook, stage)
                    mssg = "Internal error [E09] while writting QA file\n\n please contact STP Tool developer."; title = "Excel File writting Error"
                    return local_report, mssg, True
            else:
                local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
                local_report += safely_close_excel(locals(), excel, workbook, stage)
                mssg = "Internal error [E09.5] while writting QA file\n\n please contact STP Tool developer."; title = "Excel File writting Error"
                return local_report, mssg, True
            #--Extra Data---
            if stage == "Create QA Check List file":
                p_Type, Acc, Initials = eData
                try:
                    if p_Type:
                        data.Cells(1, 2).Value2 = "PROJECT NAME [P" + p_Type + "]"
                    if Acc == "Y":
                        workbook.Sheets(1).Cells(12, 2).Value2 = True
                    if Initials != "":
                        for n in range(3, 16, 1):
                            workbook.Sheets(1).Cells(n, 4).Value2 = Initials
                except Exception as e:
                    local_report += u"\u274C Stage: " + stage + ": Fail\n" + str(e) + "\n"
                    local_report += safely_close_excel(locals(), excel, workbook, stage)
                    mssg = "Internal error [E09] while writting QA file\n\n please contact STP Tool developer."; title = "Excel File writting Error"
                    return local_report, mssg, True
    
    forms.alert(mssg, title="Success", options=["OK"])
    mssg = ""
    if wait_for_excel_ready(excel):
        excel.Visible = True
        funct_report = bring_excel_to_front(excel)
        if funct_report:
            local_report += funct_report
    else:
        mssg = "Excel is not responding. \n\nPlease open Excel file manually and fill out your initials if required."
    return local_report, mssg, False
    
def write_qa_excel_file_V2(qa_path, stage, qa_new_lines, eData):
    excel = None
    workbook = None
    success = False
    local_report = ""
    s_type = eData["p_type"]
    if stage == "Modify QA Check List file":
        s_type = eData["ini_type"]
    
    try:
        excel_type = Type.GetTypeFromProgID("Excel.Application")
        excel = Activator.CreateInstance(excel_type)

        com_set(excel, "Visible", False)
        com_set(excel, "DisplayAlerts", False)

        workbooks = com_get(excel, "Workbooks")
        workbook = com_call(workbooks, "Open", qa_path)

        sheets = com_get(workbook, "Worksheets")
        sheet = com_get(sheets, "Item", "Changes_Record")
        cells = com_get(sheet, "Cells")

        max_cols_to_check = max(len(qa_new_lines[0]), 13, 1)
        target_row = get_next_empty_row(sheet, max_cols_to_check)

        # Change header B1 only when s_type is not "G"
        if stage == "Create QA Check List file" or stage == "Update V2 Files":
            if s_type != "":
                header_cell = com_get(cells, "Item", 1, 2)
                com_set(header_cell, "Value2", "PROJECT NAME {}".format(s_type))

        # Write new row
        for qa_new_line in qa_new_lines:
            write_row(cells, target_row, qa_new_line)

            # Set automatic row number in first column
            no_cell = com_get(cells, "Item", target_row, 1)
            com_set(no_cell, "Value2", target_row - 1)
            target_row += 1
        

        if s_type == "[PR]" and stage == "Create QA Check List file":
            try:
                checklist_sheet = com_get(sheets, "Item", "Project Checklist")
                
                if "initials" in eData:
                    checklist_cells = ["D3", "D4", "D5", "D7", "D8", "D9", "D10"]

                    for addr in checklist_cells:
                        cell = com_get(checklist_sheet, "Range", addr)
                        com_set(cell, "Value2", eData["initials"])

            except:
                pass

        com_call(workbook, "Save")
        local_report += u"\u2705 Stage: " + stage + ": [New Escel File save] Success \n"

        WinForms.Application.DoEvents()
        Threading.Thread.CurrentThread.Join(150)
        WinForms.Application.DoEvents()
        
        if s_type != "[PR]" or stage != "Create QA Check List file":
            user_name = os.environ.get("USERNAME")
            forms.alert("All done {}. \n\nPlease add your initials to Excel QA file.".format(user_name), "QA Record")
            com_set(excel, "Visible", True)

            try:
                com_set(excel, "WindowState", -4137)  # xlMaximized
            except:
                pass

            # maximize workbook window
            try:
                active_window = com_get(excel, "ActiveWindow")
                com_set(active_window, "WindowState", -4137)
            except:
                pass

            try:
                com_set(excel, "UserControl", True)
            except:
                pass

            try:
                com_set(excel, "Interactive", True)
            except:
                pass

            try:
                com_call(workbook, "Activate")
            except:
                pass

            try:
                com_call(sheet, "Activate")
            except:
                pass

            try:
                first_written_cell = com_get(cells, "Item", target_row, 1)
                com_call(first_written_cell, "Select")
            except:
                pass

            WinForms.Application.DoEvents()
            Threading.Thread.CurrentThread.Join(300)
            WinForms.Application.DoEvents()

            try:
                hwnd = com_get(excel, "Hwnd")
                user32 = ctypes.windll.user32
                user32.ShowWindow(hwnd, 3)  
                user32.SetForegroundWindow(hwnd)
                user32.BringWindowToTop(hwnd)
                user32.SetActiveWindow(hwnd)
            except:
                pass

        else:
            try:
                if workbook:
                    com_call(workbook, "Close", False)
            except:
                pass

            try:
                if excel:
                    com_call(excel, "Quit")
            except:
                pass
        
        success = True
        return local_report, True

    except Exception as e:
        local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
        local_report += traceback.format_exc()
        return local_report, False

    finally:
        if not success:
            try:
                if workbook:
                    com_call(workbook, "Close", False)
            except:
                pass

            try:
                if excel:
                    com_call(excel, "Quit")
            except:
                pass

def net_array(*args):
    return Array[Object](list(args))

def com_get(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.GetProperty,
        None,
        obj,
        net_array(*args) if args else None
    )

def com_set(obj, name, value):
    obj.GetType().InvokeMember(
        name,
        BindingFlags.SetProperty,
        None,
        obj,
        net_array(value)
    )

def com_call(obj, name, *args):
    return obj.GetType().InvokeMember(
        name,
        BindingFlags.InvokeMethod,
        None,
        obj,
        net_array(*args) if args else None
    )

def is_row_empty(cells, row_number, max_cols_to_check):
    for c in range(1, max_cols_to_check + 1):
        cell = com_get(cells, "Item", row_number, c)
        value = com_get(cell, "Value2")
        if value not in [None, ""]:
            return False
    return True

def get_next_empty_row(sheet, max_cols_to_check):
    cells = com_get(sheet, "Cells")
    max_excel_rows = 1048576

    last_cell_col_a = com_get(cells, "Item", max_excel_rows, 1)
    end_up = com_get(last_cell_col_a, "End", -4162)   # xlUp
    last_row = com_get(end_up, "Row")

    if last_row == 1 and is_row_empty(cells, 1, max_cols_to_check):
        return 1

    row = last_row
    while not is_row_empty(cells, row, max_cols_to_check):
        row += 1

    return row

def write_row(cells, row_number, data):
    for c, value in enumerate(data, start=1):
        current_cell = com_get(cells, "Item", row_number, c)
        if value is None:
            com_set(current_cell, "Value2", "")
        else:
            com_set(current_cell, "Value2", str(value))


#def ():
    #local_report = ""
    #Out_Data = []

#local_report += u"\u2705 Stage: " + stage + ":  \n"
#local_report += u"\u26A0 Stage: " + stage + ":  \n"
#local_report += u"\U0001F4CC Stage:" + stage + ":  /n"

#except Exception as e:
    #local_report += u"\u274C Stage: " + stage + "\n" + str(e) + "\n"
    #local_report += traceback.format_exc()

#    return continue_task, local_report, Out_Data
