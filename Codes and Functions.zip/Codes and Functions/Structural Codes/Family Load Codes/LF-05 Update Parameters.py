# Load the Python Standard and DesignScript Libraries
import clr
clr.AddReference('RevitAPI')
from Autodesk.Revit.DB import *
clr.AddReference('RevitServices')
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

clr.AddReference('System.Windows.Forms')
from System.Windows.Forms import MessageBox, MessageBoxButtons, MessageBoxIcon
doc = DocumentManager.Instance.CurrentDBDocument

bar_sizes = ["N10", "N12", "N16", "N20", "N22", "N24", "R6", "R8", "R10"]

test = []
fail = []

# 0 - Integer
# 1 - Double
# 2 - String

def filter_parameter_value(Fam, Pair):
    # Lookup the parameter in the family element
    param = Fam.LookupParameter(Pair[0])
    par_type = param.StorageType
    value = Pair[1]

    
    if par_type == 2:
        value = value
    if value in bar_sizes:
        value = float(value[1:])/304.8
    elif value == True or value == False:
        value = value
    elif par_type == StorageType.Integer:
        value = int(float(str(value)))
    elif par_type == StorageType.Double:
        value = float(value)/304.8
    else:
        value = value
        
    if Pair[0] == "A":
        test.append(value)
        value = value / 304.8
    
    return ((Pair[0], value))
    
# The inputs to this node will be stored as a list in the IN variables.
instances = UnwrapElement(IN[0])
input_data = IN[1]
category_data = input_data[0]
family_data = input_data[1]
Revit_category = input_data[2]
# Place your code below this line

TransactionManager.Instance.EnsureInTransaction(doc)



if Revit_category == "Structural Framing":
    for x, instance in enumerate(instances):
        for parameter_pair in family_data[x]:
            if parameter_pair[0] == "Purlin notes":
                need_purlin_notes = parameter_pair[1]
            if parameter_pair[0] == "Spacing":
                spacing = parameter_pair[1]
            if parameter_pair[0] == "Rows":
                rows = parameter_pair[1]
            if parameter_pair[0] == "HD_Galv":
                HDG = parameter_pair[1]
            if parameter_pair[0] == "On_Flat":
                on_flat = parameter_pair[1]
        
        purlin_comments = ""
        rows_comment = ""
        if need_purlin_notes and spacing != "" and spacing != "0":
            purlin_comments = "S @" + spacing + "Crs"
            number = float(str(rows))
            rows_number = str(rows) + " ROWS OF BRIDGING" if number > 1 else str(rows) + " ROW OF BRIDGING"
            if number > 0:
                purlin_comments = purlin_comments + ", " + rows_number
            instances[x].LookupParameter("STP_Comment").Set(category_data[x][5] + purlin_comments)
        
        hdg_flat_comment = category_data[x][1]
        hdg_flat_comment = hdg_flat_comment + ". (ON FLAT)" if on_flat else hdg_flat_comment
        hdg_flat_comment = hdg_flat_comment + ". H.D. GALV" if HDG else hdg_flat_comment
        
        if HDG or on_flat:
            instances[x].LookupParameter("STP_Size").Set(hdg_flat_comment + ".")

elif Revit_category == "Timber Beams" or Revit_category == "Timber Columns":
    for x, instance in enumerate(instances):
        timber_size = category_data[x][1]
        for parameter_pair in family_data[x]:
            if parameter_pair[0] == "H3T":
                if parameter_pair[1] and parameter_pair[1] != 0 and parameter_pair[1] != "":
                    timber_size = timber_size + " (H3 TREATED)"
            if parameter_pair[0] == "Spacing":
                spacing = parameter_pair[1]
                sufix = ""
                if spacing != "0" and spacing != "":
                    sufix = "S @" + parameter_pair[1] + " Crs"
        
        instances[x].LookupParameter("STP_Size").Set(timber_size)
        instances[x].LookupParameter("Type Comments").Set(category_data[x][5] + sufix)
        
elif Revit_category == "Structural Columns":
    pass

for x, instance in enumerate(instances):
    for Pair in family_data[x]:
        try:
            new_Pair = filter_parameter_value(instance, Pair)
            k = 92.903030 if Pair[0] == "W" else 1
            instance.LookupParameter(new_Pair[0]).Set(new_Pair[1] * k)
        except:
            fail.append(Pair)



TransactionManager.Instance.TransactionTaskDone()

# Assign your output to the OUT variable.
OUT = instances
