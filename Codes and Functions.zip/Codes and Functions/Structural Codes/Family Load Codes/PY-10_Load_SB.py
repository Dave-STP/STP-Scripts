#-----------------------------------------------------------------------------------
#---------------------------PY-10_Load_SB.py----------------------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import os
import time
import traceback
from datetime import datetime
from pyrevit import forms, DB, script

from System import Action
from System.Windows import Visibility
from System.Windows.Controls import ListBoxItem
from System.Windows.Media import Brushes

from System.Windows.Threading import DispatcherPriority
from Autodesk.Revit.DB import BuiltInParameter
from System.IO import Path, FileStream, FileMode, FileAccess, FileShare
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions\Structural Codes\STP_Functions"
sys.path.append(functions_path)
import Family_load_functions
from Family_load_functions import *

import STP_Tools_Functions
from STP_Tools_Functions import *

# Constants
#----------
doc = __revit__.ActiveUIDocument.Document
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
#if user_name != "Rafael":
#    forms.alert("This tool is under review. Will be back soon")
#    sys.exit()
exceptions, fixed_code = exceptions()

# General_Variables
#------------------
final_report = ""
script_path = script.get_script_path()
Load_List = []
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()

# Local Variables, Lists and Path
#------------------
family_types = "Structural Framing"
xaml_file_name = "Steel Beams Form.axml"
schedules = ["R", "F", "M"]

# Check for last version
local_report = check_last_version(Lib_Path, "STP Structural", user_name)
res_param = proj_info.LookupParameter("Suburb")
res_type = True if res_param and res_param.HasValue else False

#------------------------------------------------------------------------------------
#----------- PRE-FORM CHECK AND LOAD ------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Preliminar Checks"

check_all_good = [os.path.exists(Lib_Path), os.path.exists(functions_path)]
if not all (check_all_good):
    forms.alert("Internal error [E00]. Please report it to STP Tools developer", "Error")
    sys.exit()

# Get Usage and Category List for Form
local_report, usage_List, categ_List, index_List, type_List = usage_categ_famtype_list(Lib_Path, family_types, stage)
final_report += local_report

# endregion

#-----------------------------------------------------------------------------------
#----------- GET EXISTING MEMBERS AND TYPE MARKS -----------------------------------
# region ---------------------------------------------------------------------------
stage = "Get Existing Type Mark List: "

collector = DB.FilteredElementCollector(doc)
instance_types = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

try:
    local_report, type_Marks_List, type_Marks_Grey = create_Type_Mark_List(instance_types, stage)
    final_report += local_report
except Exception as e:
    final_report += u"\u274C Stage: " + stage + " Fail.\n" + str(e)

# endregion

#-----------------------------------------------------------------------------------
#-------------------------- MAIN WINDOW FORM ---------------------------------------
#-----------------------------------------------------------------------------------

class StructuralTypeForm(forms.WPFWindow):
    def __init__(self, xaml_file_path):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.next_type_mark = ""
        self.usage_type = ""
        self.usage_sufix = ""
        self.path_txt_file = ""
        self.path_rfa_file = ""
        self.check_string = ""
        self.all_family_data_list = []
        global Load_List
        self.go_for_load = False

        # Hook up buttons
        self.btnAdd.Click += self.add_item
        self.btnRemove.Click += self.remove_item
        self.btnCancel.Click += self.close_form
        self.btnLoad.Click += self.load_families
        
        self.cmbUsage.SelectionChanged += self.on_usage_changed
        self.cmbType.SelectionChanged += self.on_type_changed
        self.txbComments.TextChanged += self.on_comment_changed
        self.txbComments.GotFocus += self.on_text_box_focus
        self.txbCategory.GotFocus += self.on_text_box_focus
        self.chbPurlins.Click += self.on_purlin_changed
        self.sldRows.ValueChanged += self.on_bridging_number_changed

        # Populate dropdowns and listboxes
        self.populate_controls()
        
        # Activate Initial Conditions
        
        if res_type:
            self.cmbUsage.SelectedItem = "FLOOR BEARER"
            self.cmbSched.SelectedIndex = 2
        else:
            self.cmbUsage.SelectedItem = "RAFTER"
            self.cmbSched.SelectedIndex = 0
    
    def populate_controls(self):
        self.cmbUsage.ItemsSource = usage_List
        self.cmbSched.ItemsSource = ["Roof Framing", "Floor Framing", "Wall & Bracing Framing"]
        self.cmbType.ItemsSource = type_List
        self.lblAlignment.Visibility = self.txbSpacing.Visibility = self.lblBridging.Visibility = self.sldRows.Visibility = self.txbRows.Visibility = Visibility.Collapsed
        
    def check_is_last_item(self):
        check = self.cmbUsage.SelectedItem + self.cmbType.SelectedItem + self.txbMark.Text + self.txbCategory.Text + self.txbComments.Text + self.lsbSizes.SelectedItem
        check += "y" if self.chbGalv.IsChecked else "n"
        check += "y" if self.chbFlat.IsChecked else "n"
        check += "y" if self.chbPurlins.IsChecked else "n"
        check += self.txbSpacing.Text + self.txbRows.Text
        return check
        

    def on_usage_changed(self, sender, args):
        if self.cmbUsage.SelectedIndex >= 0:
            self.cmbType.SelectedIndex = index_List[self.cmbUsage.SelectedIndex]
            self.txbCategory.Text = categ_List[self.cmbUsage.SelectedIndex]
            self.txbComments.Text = "ADD COMMENT HERE"
            
            self.usage_type = self.cmbUsage.SelectedItem
            if self.usage_type in exceptions:
                self.usage_sufix = fixed_code[exceptions.index(self.usage_type)]
            else:
                self.usage_sufix = ''.join([word[0] for word in self.usage_type.split()])
            
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks
            self.chbPurlins.IsChecked = False
            self.on_purlin_changed(self.chbPurlins, None)
            self.chbFlat.IsChecked = False
            
    def on_type_changed(self, sender, args):
        profile = self.cmbType.SelectedItem
        self.path_txt_file = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Structural_Framing",profile + ".txt")
        self.path_rfa_file = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Structural_Framing",profile + ".rfa")
        size_list, self.all_family_data_list = profile_sizes(self.path_txt_file) # size_list, all_data_list
        self.lsbSizes.ItemsSource = size_list[1:] if size_list[0] == "Select Size" else size_list

    def on_comment_changed(self, sender, args):
        if self.txbComments.Text == "ADD COMMENT HERE":
            self.txbComments.Foreground = Brushes.LightGray
        else:
            self.txbComments.Foreground = Brushes.Black
    
    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)

    def on_purlin_changed(self, sender, args):
        if sender.IsChecked:
            self.lblAlignment.Visibility = self.lblMm.Visibility = self.txbSpacing.Visibility = self.lblBridging.Visibility = self.sldRows.Visibility = self.txbRows.Visibility = Visibility.Visible
        else:
            self.lblAlignment.Visibility = self.lblMm.Visibility = self.txbSpacing.Visibility = self.lblBridging.Visibility = self.sldRows.Visibility = self.txbRows.Visibility = Visibility.Collapsed
    
    def on_bridging_number_changed(self, sender, arg):
        self.txbRows.Text = str(int(sender.Value))
            
    def add_item(self, sender, args):
        global Load_List
        selected_index = self.lsbSizes.SelectedIndex
        if selected_index >= 0:
            selected_size = self.lsbSizes.SelectedItem
            selected_type_mark = self.txbMark.Text
            load_list_name = selected_type_mark + " - " + selected_size
            new_line = []
            
            hdg_flat_name = ""
            if self.chbGalv.IsChecked:
                if res_type:
                    hdg_flat_name = " GALV"
                else:
                    hdg_flat_name = " (H.D.G)"
            spacing_name = ""
            
            if self.chbFlat.IsChecked:
                hdg_flat_name += " - ON FLAT"
            if self.chbPurlins.IsChecked:
                spacing_name += " @" + self.txbSpacing.Text + " CRS"
                if self.sldRows.Value > 0:
                    spacing_name += " " + self.txbRows.Text + "-BR"
            
            self.lsbNewItems.Items.Add(load_list_name + hdg_flat_name + spacing_name)

            fam_name = self.cmbType.SelectedItem
            new_name = selected_size + " - " + selected_type_mark + (" (F)" if self.chbFlat.IsChecked else "")
            fam_path = self.path_rfa_file
            fam_type = selected_size
            
            family_block = [fam_name, new_name, fam_path, fam_type]
            new_line.append(family_block)

            
            stp_comment = self.cmbUsage.SelectedItem + ("S @" + self.txbSpacing.Text + " CRS, " if self.chbPurlins.IsChecked else "")
            aux_txt = ""
            if spacing_name[-3:] == "-BR":
                aux_txt = self.txbRows.Text + " ROWS OF BRIDGING"
                if spacing_name[-4] == "1":
                    aux_txt = aux_txt.replace("ROWS","ROW")
            stp_comment += aux_txt + (". " + self.txbComments.Text.upper() if self.txbComments.Text != "ADD COMMENT HERE" else "")
            

            par_schedule = (("STP Schedule", schedules[self.cmbSched.SelectedIndex]))
            par_category = (("STP Category", self.txbCategory.Text))
            par_stp_size = (("STP_Size", selected_size + hdg_flat_name.replace(" - ON FLAT","-ON FLAT")))
            par_stp_com1 = (("STP_Comment", stp_comment))
            par_typ_mark = (("Type Mark",selected_type_mark))
            par_stp_com2 = (("Type Comments", stp_comment))
            
            general_block = [par_schedule, par_category, par_stp_size, par_stp_com1, par_typ_mark, par_stp_com2]
            new_line.append(general_block)

            params = []
            if "RHS" in self.all_family_data_list[selected_index + 1][0] and self.chbFlat.IsChecked:
                aux = []
                ix_d = self.all_family_data_list[0].index('d')
                ix_b = self.all_family_data_list[0].index('b')
                new_d = self.all_family_data_list[selected_index + 1][ix_b]
                new_b = self.all_family_data_list[selected_index + 1][ix_d]

                for x, item in enumerate(self.all_family_data_list[selected_index + 1]):
                    if x == ix_d:
                        params.append((self.all_family_data_list[0][x],new_d))
                    elif x == ix_b:
                        params.append((self.all_family_data_list[0][x],new_b))
                    else:
                        params.append((self.all_family_data_list[0][x],item))
            else:
                for par, val in zip(self.all_family_data_list[0], self.all_family_data_list[selected_index + 1]):
                    if par not in [p[0] for p in general_block] and par != "Select Size":
                        params.append((par, val))

            new_line.append(params)

            Load_List.append(new_line)
                    
            # Update Type Mark List Box
            type_mark_list_name = selected_type_mark + " - " + selected_size
            type_Marks_List.append((selected_type_mark, type_mark_list_name))
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks
            self.check_string = self.check_is_last_item()
            
        else:
            forms.alert(
                "Please select an element size.",
                title="Warning",
                warn_icon=True  # This shows the warning (exclamation) icon
            )          
    def remove_item(self, sender, args):
        global Load_List
        selected_index = self.lsbNewItems.SelectedIndex
        if selected_index >= 0:
            self.lsbNewItems.Items.RemoveAt(selected_index)
            del Load_List[selected_index]
            del type_Marks_List[selected_index + len(type_Marks_Grey)]

        # Update Type Mark List Box
        filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
        self.txbMark.Text = self.next_type_mark
        self.lsbMarks.ItemsSource = filtered_type_marks

    def close_form(self, sender, args):
        self.Close()

    def load_families(self, sender, args):
        selected_index = self.lsbSizes.SelectedIndex
        if selected_index >= 0:
            final_check = self.check_is_last_item()
            if final_check == self.check_string: # Check if there are modifications in elements before load
                self.go_for_load = True
                self.Close()
            else:
                result = forms.alert(
                    "The last item hasn't been added to the list. Do you want to continue loading without it?",
                    title="Confirm Add",
                    yes=True,
                    no=True
                )
                if result:
                    self.go_for_load = True
                    self.Close()
        else:
            forms.alert(
                "Please select an element size.",
                title="Warning",
                warn_icon=True  # This shows the warning (exclamation) icon
            )

# Show the form
form = StructuralTypeForm(xaml_file_name)
form.ShowDialog()

#-----------------------------------------------------------------------------------
#-------------COPY FAMILY INSTANCE AND ADD PARAMETERS-------------------------------
# region ---------------------------------------------------------------------------
stage = "Load Family and Parameters"
if form.go_for_load and Load_List:
    try:
        local_state, local_report = load_families_and_parameters(doc, Load_List)
    except Exception as e:
        local_report = str(e)
    final_report += local_report
else:
    sys.exit()

# endregion

#--------------------------------------------------------------------
#----------- REPORT SAVING TIME TO DATA BASE ------------------------
# region ------------------------------------------------------------
stage = "Tracking Data"
file_path = os.path.join(Lib_Path, "STP Tracking", "Data.txt")
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if os.path.exists(file_path):
    final_report += fill_tracking_data(file_path, p_Numb, user_name, "Load Steel Beams", "4", start_time, end_time, str(len(Load_List)), stage)

# endregion


#print(final_report)