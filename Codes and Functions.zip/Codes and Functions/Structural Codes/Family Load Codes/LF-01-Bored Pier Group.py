import sys
import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *

clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from System.Drawing import Point, Size
from System.Windows.Forms import Application, Form, Label, TextBox, NumericUpDown, CheckBox, GroupBox, ComboBox, RadioButton

from System import Decimal

def stp_reinforcement():
    if chbMass.Checked:
        txbStpReinf.Text = "MASS CONCRETE"
    else:
        txbStpReinf.Text = str(spnBbn.Value) + "/" + cmbBbs.SelectedItem + ". " + cmbLigs.SelectedItem + " LIGS @" + txbSpac.Text + "Crs."

        
def on_control_update(sender, event):
    
#---------------- LONGITUDINAL REINF.----------------------
        
    if sender.Name == "Mass Concrete":
        gboxLigs.Enabled = not sender.Checked
        for control in gboxLongR.Controls:
            if control != sender:
                control.Enabled = not sender.Checked
        stp_reinforcement()

#---------------- TRANSVERSAL REINF.----------------------

    elif sender.Name == "N" or sender.Name == "R":
        list = N_list if sender.Name == "N" else R_list
        cmbLigs.Items.Clear()
        for nr in list:
            cmbLigs.Items.Add(nr)
        cmbLigs.SelectedIndex = 1
        stp_reinforcement()

#---------------- AUTOMATIC REINF. TEXT.----------------------

    elif sender.Name == "AutoReinf":
        txbStpReinf.ReadOnly = sender.Checked
        if sender.Checked == True:
            stp_reinforcement()
            
#----------------  OTHERS  ----------------------    
    else:
        stp_reinforcement()



N_list = ["N10", "N12", "N16", "N20", "N22", "N24"]
R_list = ["R6", "R8", "R10"]

# Create a group box
groupBox = GroupBox()
groupBox.Text = "BORED PIER INFORMATION"
groupBox.Size = Size(730, 250)

#---------------------------------------------------
#       DIMENSIONS GROUP
#--------------------------------------------------- 


gbox = GroupBox()
gbox.Text = "Pier Dimensions (mm)"
gbox.Location = Point(25, 25)
gbox.Size = Size(125, 120)
gboxDims = gbox

label = Label()
label.Text = "Diameter:"
label.Location = Point(10, 27)
label.Height = 15
label.Width = 50
lblDiam = label

txb = TextBox()
txb.Name = "Diameter"
txb.Location = Point(70, 25)
txb.Width = 40
txb.Text = "400"
txbDiam = txb
       
label = Label()
label.Text = "Length:"
label.Location = Point(10, 57)
label.Height = 15
label.Width = 50
lblLength = label

txb = TextBox()
txb.Name = "Length"
txb.Location = Point(70, 55)
txb.Width = 40
txb.Text = "1500"
txbLength = txb

label = Label()
label.Text = "Cover:"
label.Location = Point(10, 87)
label.Height = 15
label.Width = 40
lblCover = label

txb = TextBox()
txb.Name = "STP_Cover"
txb.Location = Point(70, 85)
txb.Width = 40
txb.Text = "65"
txbCover = txb

gboxDims.Controls.Add(lblDiam)
gboxDims.Controls.Add(txbDiam)
gboxDims.Controls.Add(lblLength)
gboxDims.Controls.Add(txbLength)
gboxDims.Controls.Add(lblCover)
gboxDims.Controls.Add(txbCover)

#---------------------------------------------------
#       EMNEDMENT GROUP
#--------------------------------------------------- 

gbox = GroupBox()
gbox.Text = "Pier Embedment Conditions"
gbox.Location = Point(165, 25)
gbox.Size = Size(200, 120)
gboxEmbed = gbox

label = Label()
label.Text = "Borehole:"
label.Location = Point(10, 27)
label.Height = 15
label.Width = 60
lblBhole = label

txb = TextBox()
txb.Name = "STP_Borehole_Reference"
txb.Location = Point(70, 25)
txb.Width = 120
txbBhole = txb

label = Label()
label.Text = "Clay Emb.:"
label.Location = Point(10, 57)
label.Height = 15
label.Width = 60
lblClay = label

txb = TextBox()
txb.Name = "STP_Clay_Embedment"
txb.Location = Point(70, 55)
txb.Width = 120
txbClay = txb

label = Label()
label.Text = "Rock Emb.:"
label.Location = Point(10, 87)
label.Height = 15
label.Width = 60
lblRock = label

txb = TextBox()
txb.Name = "STP_Rock_Embedment"
txb.Location = Point(70, 85)
txb.Width = 120
txbRock = txb

gboxEmbed.Controls.Add(lblBhole)
gboxEmbed.Controls.Add(txbBhole)
gboxEmbed.Controls.Add(lblClay)
gboxEmbed.Controls.Add(txbClay)
gboxEmbed.Controls.Add(lblRock)
gboxEmbed.Controls.Add(txbRock)

#---------------------------------------------------
#       LONGITUDINAL REO GROUP
#---------------------------------------------------

gbox = GroupBox()
gbox.Text = "Long. Reinforcement"
gbox.Location = Point(385, 25)
gbox.Size = Size(150, 120)
gboxLongR = gbox

chbox = CheckBox()
chbox.Text = "Mass Concrete"
chbox.Name = "Mass Concrete"
chbox.Checked = True
chbox.Location = Point(10, 20)   
chbMass = chbox
chbMass.CheckedChanged += on_control_update

label = Label()
label.Text = "Bar Size:"
label.Location = Point(10, 57)
label.Height = 15
label.Width = 60
lblBbs = label 

cmbox = ComboBox()
cmbox.Name = "Bars Size"
cmbox.Location = Point(85, 55)
cmbox.Width = 50
for n in N_list:
	cmbox.Items.Add(n)
cmbox.SelectedItem = "N16"       
cmbBbs = cmbox
cmbBbs.SelectedIndexChanged += on_control_update

label = Label()
label.Text = "Bar Number:"
label.Location = Point(10, 87)
label.Height = 15
label.Width = 69
lblBbn = label

nupdwn = NumericUpDown()
nupdwn.Name = "No Bars"
nupdwn.Location = Point(85, 85)
nupdwn.Width = 50
nupdwn.Minimum = Decimal(4)
spnBbn = nupdwn
spnBbn.ValueChanged += on_control_update

gboxLongR.Controls.Add(chbMass)
gboxLongR.Controls.Add(lblBbs)
gboxLongR.Controls.Add(cmbBbs)
gboxLongR.Controls.Add(lblBbn)
gboxLongR.Controls.Add(spnBbn)

#---------------------------------------------------
#       LIGATURES GROUP
#---------------------------------------------------  

gbox = GroupBox()
gbox.Text = "Transveral Reinf."
gbox.Location = Point(550, 25)
gbox.Size = Size(160, 120)
gboxLigs = gbox
 
radbtn = RadioButton()
radbtn.Text = "N"
radbtn.Name = "N"
radbtn.Location = Point(10, 20)
radbtn.Width = 40
rbtN = radbtn
rbtN.CheckedChanged += on_control_update

radbtn = RadioButton()
radbtn.Text = "R"
radbtn.Name = "R"
radbtn.Location = Point(75, 20)
radbtn.Width = 40
radbtn.Checked = True
rbtR = radbtn
rbtR.CheckedChanged += on_control_update

label = Label()
label.Text = "Bar Size:"
label.Location = Point(10, 57)
label.Height = 15
label.Width = 60
lblLigs = label

cmbox = ComboBox()
cmbox.Name = "Ligs Size"
for r in R_list:
    cmbox.Items.Add(r)
cmbox.SelectedItem = "R10"
cmbox.Location = Point(75, 55)
cmbox.Width = 50
cmbLigs = cmbox
cmbLigs.SelectedIndexChanged += on_control_update

label = Label()
label.Text = "Spacing:"
label.Location = Point(10, 87)
label.Height = 15
label.Width = 60
lblSpac = label 

txb = TextBox()
txb.Name = "Ligs Pitch"
txb.Text = "200"
txb.Location = Point(75, 85)
txb.Width = 50
txbSpac = txb
txbSpac.Leave += on_control_update

label = Label()
label.Text = "mm"
label.Location = Point(130, 87)
label.Height = 15
label.Width = 25
lblSmm = label

gboxLigs.Controls.Add(rbtN)
gboxLigs.Controls.Add(rbtR)
gboxLigs.Controls.Add(lblLigs)
gboxLigs.Controls.Add(cmbLigs)
gboxLigs.Controls.Add(lblSpac)
gboxLigs.Controls.Add(txbSpac)
gboxLigs.Controls.Add(lblSmm)

#---------------------------------------------------
#       REINFORCING TEXT GROUP
#---------------------------------------------------  

gbox = GroupBox()
gbox.Text = "STP_Reinforcement."
gbox.Size = Size(680, 70)
gbox.Location = Point(25, 160)
gboxStpReinf = gbox

chb = CheckBox()
chb.Text = "Automatic"
chb.Name = "AutoReinf"
chb.Width = 80
chb.Checked = True
chb.Location = Point(25,25)
chbAutoReinf = chb
chbAutoReinf.CheckedChanged += on_control_update

txb = TextBox()
txb.Name = "STP_Reinforcement"
txb.Width = 350
txb.ReadOnly = True
txb.Location = Point(110,25)
txbStpReinf = txb


gboxStpReinf.Controls.Add(chbAutoReinf)
gboxStpReinf.Controls.Add(txbStpReinf)
groupBox.Controls.Add(gboxStpReinf)

#----------------------------------------------------

groupBox.Controls.Add(gboxDims)
groupBox.Controls.Add(gboxLongR)
groupBox.Controls.Add(gboxLigs)
groupBox.Controls.Add(gboxEmbed)

chbMass.Checked = False

control_names = [] # Get parameters and index to use
control_index = [] # in the next control

# Loop through the controls in the GroupBox and get their names
for Groups in groupBox.Controls:
    for control in Groups.Controls:	
        if control.Name:
            control_names.append(control.Name)
        
# Output the GroupBox
OUT = groupBox, control_names, "Bored Piers"
