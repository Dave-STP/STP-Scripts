import sys
import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *

clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from System.Drawing import Point, Size, Color
from System.Windows.Forms import Application, Form, Label, TextBox, NumericUpDown, CheckBox, GroupBox, ComboBox, RadioButton

from System import Decimal

N_list = ["N10", "N12", "N16", "N20", "N22", "N24"]
R_list = ["R6", "R8", "R10"]
T_list = ["L11TM", "L12TM", "L14TM"]
Final_Reo_text = ""

def on_focus(sender, event):
    sender.Focus()
    sender.SelectAll()

# Create a group box
groupBox = GroupBox()
groupBox.Text = "TIMBER BEAM INFORMATION"
groupBox.Size = Size(500, 160)

#--------------------------------------------
#DIMENSIONS GROUP
#-------------------------------------------- 

gbox = GroupBox()
gbox.Name = "Dimensions"
gbox.Text = "Beam Dimensions (mm)"
gbox.Location = Point(10, 25)
gbox.Size = Size(140, 110)
gboxDims = gbox

label = Label()
label.Text = "Depth:"
label.Location = Point(10, 25)
label.Height = 15
label.Width = 50
lblDepth = label

txb = TextBox()
txb.Location = Point(60, 25)
txb.Width = 50
txb.Text = "150"
txb.Name = "d"
txb.TabIndex = 0
txb.GotFocus += on_focus
txb.Click += on_focus
txbDepth = txb

label = Label()
label.Text = "Width:"
label.Location = Point(10, 52)
label.Height = 15
label.Width = 50
lblWidth = label

txb = TextBox()
txb.Location = Point(60, 50)
txb.Width = 50
txb.Text = "65"
txb.Name = "b"
txb.TabIndex = 1
txb.GotFocus += on_focus
txb.Click += on_focus
txbWidth = txb

chbox = CheckBox()
chbox.Location = Point(13, 75)
chbox.Text = "H3 Treated"
chbox.Name = "H3T"
chbox.Checked = False
chbox.TabIndex = 2
chbH3T = chbox

gboxDims.Controls.Add(lblDepth)
gboxDims.Controls.Add(txbDepth)
gboxDims.Controls.Add(lblWidth)
gboxDims.Controls.Add(txbWidth)
gboxDims.Controls.Add(chbH3T)

#---------------------------------------------------
#       OTHER CONSIDERATIONS
#---------------------------------------------------

gbox = GroupBox()
gbox.Name = "Joists"
gbox.Text = "Spacing at multiple elements"
gbox.Location = Point(160, 25)
gbox.Size = Size(250, 110)
gboxJoists = gbox

label = Label()
label.Text = "Specify spacing if applicable; otherwise,"
label.Location = Point(10, 20)
label.Height = 15
label.Width = 230
lblRequired1 = label

label = Label()
label.Text = "leave it as 0."
label.Location = Point(10, 40)
label.Height = 15
label.Width = 230
lblRequired2 = label

label = Label()
label.Text = "SPACING:"
label.Location = Point(10, 73)
label.Height = 15
label.Width = 60
lblSpc1 = label

label = Label()
label.Text = "@ "
label.Location = Point(70, 73)
label.Height = 15
label.Width = 20
lblSpc2 = label

txb = TextBox()
txb.Location = Point(90, 70)
txb.Width = 60
txb.Text = ""
txb.Name = "Spacing"
txb.TabIndex = 3
txb.GotFocus += on_focus
txb.Click += on_focus
txbSpac = txb

label = Label()
label.Text = "mm"
label.Location = Point(155, 73)
label.Height = 15
label.Width = 30
lblSpc3 = label

txb = TextBox()
txb.Name = "STP Schedule"
txb.Location = Point(40, 90)
txb.Width = 60
txb.Visible = False
txbCateg = txb

gboxJoists.Controls.Add(lblRequired1)
gboxJoists.Controls.Add(lblRequired2)
gboxJoists.Controls.Add(lblSpc1)
gboxJoists.Controls.Add(lblSpc2)
gboxJoists.Controls.Add(txbSpac)
gboxJoists.Controls.Add(lblSpc3)
gboxJoists.Controls.Add(txbCateg)

#----------------------------------------------------
#---INITIALISING THE CODE



groupBox.Controls.Add(gboxDims)
groupBox.Controls.Add(gboxJoists)

   
control_names = [] # Get parameters and index to use
control_index = [] # in the next control

# Loop through the controls in the GroupBox and get their names
for Groups in groupBox.Controls:
    for control in Groups.Controls:    
        if control.Name:
            control_names.append(control.Name)
        
# Output the GroupBox
OUT = groupBox, control_names, "Timber Beams"
