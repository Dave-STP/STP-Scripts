#-----------------------------------------------------------------------------------
#---------------------------PY-20_Load_BF.py----------------------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import os
import time
import traceback
from datetime import datetime
from Autodesk.Revit.DB import FilteredElementCollector, Family
from pyrevit import forms, DB, script

from System import Action
from System.Windows import Visibility
from System.Windows.Controls import ListBoxItem
from System.Windows.Media import Brushes

from System.Windows.Threading import DispatcherPriority
from Autodesk.Revit.DB import BuiltInParameter
from System.IO import Path, FileStream, FileMode, FileAccess, FileShare
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions\Structural Codes\STP_Functions"
sys.path.append(functions_path)
import Family_load_functions
from Family_load_functions import *

import STP_Tools_Functions
from STP_Tools_Functions import *

# Constants
#----------
doc = __revit__.ActiveUIDocument.Document
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
exceptions, fixed_code = exceptions()

# General_Variables
#------------------
final_report = ""
script_path = script.get_script_path()
Load_List = []
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()
aux_reo = ""

# Local Variables (General, Resid, McDonalds)
#------------------
family_types = "Beam Footings"
xaml_file_name = "Beam Footings Form.axml"
BF_list = ["STP_Beam Footing", "Rectangular Concrete Beam"]
N_list = ["N10", "N12", "N16", "N20", "N22", "N24"]
R_list = ["R6", "R8", "R10"]
T_list = ["L11TM", "L12TM", "L14TM"]
res_param = proj_info.LookupParameter("Suburb")
res_type = True if res_param and res_param.HasValue else False
fam_type = ""
fam_name = "STP_Beam Footing"

families = (FilteredElementCollector(doc).OfClass(Family))
if res_type:
    for fam in families:
        if fam.Name == "Rectangular Concrete Beam":
            fam_name = "Rectangular Concrete Beam"
            break

#------------------------------------------------------------------------------------
#----------- PRE-FORM CHECK AND LOAD ------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Preliminar Checks"

check_all_good = [os.path.exists(Lib_Path), os.path.exists(functions_path)]
if not all (check_all_good):
    forms.alert("Internal error [E00]. Please report it to STP Tools developer", "Error")
    sys.exit()

# Get Usage and Category List for Form
local_report, usage_List, categ_List, index_List, type_List = usage_categ_famtype_list(Lib_Path, family_types, stage)
final_report += local_report

# endregion

#-----------------------------------------------------------------------------------
#----------- GET EXISTING MEMBERS AND TYPE MARKS -----------------------------------
# region ---------------------------------------------------------------------------
stage = "Get Existing Type Mark List: "

collector = DB.FilteredElementCollector(doc)
instance_types_1 = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

collector = DB.FilteredElementCollector(doc)
instance_types_2 = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFoundation)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

instance_types = []
instance_types.extend(instance_types_1)
instance_types.extend(instance_types_2)

try:
    local_report, type_Marks_List, type_Marks_Grey = create_Type_Mark_List(instance_types, stage)
    final_report += local_report
except Exception as e:
    final_report += u"\u274C Stage: " + stage + " Fail.\n" + str(e)


# endregion

#-----------------------------------------------------------------------------------
#-------------------------- MAIN WINDOW FORM ---------------------------------------
#-----------------------------------------------------------------------------------
class BeamFootingsForm(forms.WPFWindow):
    def __init__(self, xaml_file_path):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.initialize_ui()
        self.next_type_mark = ""
        self.usage_type = ""
        self.usage_sufix = ""
        self.path_txt_file = ""
        self.path_rfa_file = ""
        self.check_string = ""
        self.go_for_load = False
        global Load_List
 
        # Hook up buttons
        #--------------------- General ----------------------------
        self.cmbUsage.SelectionChanged += self.on_usage_changed
        self.txbComments.GotFocus += self.on_text_box_focus
        self.txbComments.TextChanged += self.on_comment_changed
        self.txbMark.GotFocus += self.on_text_box_focus
        self.txbCategory.GotFocus += self.on_text_box_focus
        #-------------------- Geometry ----------------------------
        self.txbWidth.LostFocus += self.on_width_changed
        self.txbWidth.GotFocus += self.on_text_box_focus
        self.txbWidth.LostFocus += self.on_text_box_leave
        self.txbDepth.GotFocus += self.on_text_box_focus
        self.txbDepth.LostFocus += self.on_text_box_leave
        self.txbCover.GotFocus += self.on_text_box_focus
        self.chbMassConc.Click += self.on_reo_conditions_changed
        self.chbSameTopBtm.Click += self.on_reo_conditions_changed
        #-------------------- Bottom ------------------------------
        self.chbBtmReo.Click += self.on_reo_conditions_changed
        self.rdoBtmBars.Click += self.on_reo_conditions_changed
        self.rdoBtmMesh.Click += self.on_reo_conditions_changed
        self.spnBtm1.Click += self.on_reo_type_changed
        self.spnBtm2.Click += self.on_reo_type_changed
        self.cmbBtmMesh.SelectionChanged += self.on_reo_type_changed
        self.cmbBtmReo.SelectionChanged += self.on_reo_type_changed
        #---------------------- Top -------------------------------
        self.chbTopReo.Click += self.on_reo_conditions_changed
        self.rdoTopBars.Click += self.on_reo_conditions_changed
        self.rdoTopMesh.Click += self.on_reo_conditions_changed
        self.spnTop1.Click += self.on_reo_type_changed
        self.spnTop2.Click += self.on_reo_type_changed
        self.cmbTopMesh.SelectionChanged += self.on_reo_type_changed
        self.cmbTopReo.SelectionChanged += self.on_reo_type_changed
        #-------------------- Ligatures ---------------------------
        self.chbSide.Content = "Side Reinf."
        self.chbLigs.Click += self.on_reo_conditions_changed
        self.rdoLigR.Click += self.on_reo_type_changed
        self.rdoLigN.Click += self.on_reo_type_changed
        self.cmbLigSize.SelectionChanged += self.on_reo_type_changed
        self.txbLigSpacing.TextChanged += self.on_reo_type_changed
        #-------------------- Auto-Reinf --------------------------
        self.chbAutoReo.Click += self.on_auto_reinf_changed
        #-------------------- Buttons -----------------------------
        self.btnAdd.Click += self.on_add_item
        self.btnRemove.Click += self.remove_item
        self.btnLoad.Click += self.load_families
        self.btnCancel.Click += self.close_form

        # Populate dropdowns and listboxes
        self.cmbUsage.ItemsSource = usage_List
        self.cmbConc.ItemsSource = ["N20", "N25", "N32", "N40"]
        self.txbWidth.Text = "300"
        self.txbDepth.Text = "400"
        self.txbCover.Text = "50"
        
        self.cmbBtmReo.ItemsSource = N_list
        self.cmbBtmReo.SelectedIndex = 1
        self.txbBtm.Text = "3"
        self.cmbBtmMesh.ItemsSource = ["3-" + type for type in T_list]
        self.cmbBtmMesh.SelectedIndex = 0
        
        self.cmbTopReo.ItemsSource = N_list
        self.cmbTopReo.SelectedIndex = 1
        self.txbTop.Text = "3"
        self.cmbTopMesh.ItemsSource = ["3-" + type for type in T_list]
        self.cmbTopMesh.SelectedIndex = 0
        
        self.cmbLigSize.ItemsSource = R_list
        self.cmbLigSize.SelectedIndex = 0
        

        # Activate Initial Conditions
        if res_type:
            self.cmbUsage.SelectedItem = "BEAM FOOTING"
        else:
            self.cmbUsage.SelectedItem = "STRIP FOOTING"
        self.rdoLigR.IsChecked = True
        self.chbAutoReo.IsChecked = True
        self.cmbConc.SelectedIndex = 0
        self.chbMassConc.IsChecked = True
        self.on_reo_conditions_changed(self, None)

    def initialize_ui(self):
        # Path to the image
        img_path = Path.Combine(script_path, "Beam Footing.png")

        # Load the image WITHOUT locking the file
        stream = FileStream(img_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
        bitmap = BitmapImage()
        bitmap.BeginInit()
        bitmap.CacheOption = BitmapCacheOption.OnLoad  # load into memory to release file lock
        bitmap.StreamSource = stream
        bitmap.EndInit()
        bitmap.Freeze()  # Makes it usable across threads (recommended)
        stream.Close()   # Close to release the file lock

        # Set image source (make sure x:Name="imgBeam" in your XAML)
        self.imgBeam.Source = bitmap

    def check_is_last_item(self):
        check = (
            self.cmbUsage.SelectedItem + self.cmbConc.SelectedItem + self.txbMark.Text + 
            self.txbCategory.Text + self.txbComments.Text + 
            self.txbWidth.Text + self.txbDepth.Text + self.txbCover.Text +
            self.txbBtm.Text + self.cmbBtmReo.SelectedItem + self.cmbBtmMesh.SelectedItem +
            self.txbTop.Text + self.cmbTopReo.SelectedItem + self.cmbTopMesh.SelectedItem +
            self.txbLigSpacing.Text + self.cmbLigSize.SelectedItem)
        check += ("y" if self.chbMassConc.IsChecked else "n") + ("y" if self.chbSameTopBtm.IsChecked else "n")
        check += ("y" if self.chbBtmReo.IsChecked else "n") + ("y" if self.rdoBtmBars.IsChecked else "n") + ("y" if self.rdoBtmMesh.IsChecked else "n")
        check += ("y" if self.chbTopReo.IsChecked else "n") + ("y" if self.rdoTopBars.IsChecked else "n") + ("y" if self.rdoTopMesh.IsChecked else "n")
        check += ("y" if self.chbLigs.IsChecked else "n") + ("y" if self.chbSide.IsChecked else "n") + ("y" if self.rdoLigR.IsChecked else "n")
        return check

    def on_usage_changed(self, sender, args):
        if self.cmbUsage.SelectedIndex >= 0:
            if categ_List[self.cmbUsage.SelectedIndex] != "EXISTING" and res_type:
                self.txbCategory.Text = "FOOTING BEAMS"
            else:
                self.txbCategory.Text = categ_List[self.cmbUsage.SelectedIndex]
            self.txbComments.Text = "ADD COMMENT HERE"
            
            self.usage_type = self.cmbUsage.SelectedItem
            if self.usage_type in exceptions:
                self.usage_sufix = fixed_code[exceptions.index(self.usage_type)]
            else:
                self.usage_sufix = ''.join([word[0] for word in self.usage_type.split()])
            
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks

    def on_reo_conditions_changed(self, sender, args):
        if self.chbMassConc.IsChecked:
            self.btmGruop.IsEnabled = self.topGroup.IsEnabled = self.ligsGroup.IsEnabled = self.chbSameTopBtm.IsEnabled = False
            self.chbBtmReo.IsChecked = False
            self.chbTopReo.IsChecked = False
            if self.chbAutoReo.IsChecked == True:
                self.txbReoSummary.Text = "MASS CONCRETE"
        else:
            if self.chbSameTopBtm.IsChecked:
                self.topGroup.Visibility = Visibility.Collapsed
                self.chbTopReo.IsChecked = self.chbBtmReo.IsChecked
            else:
                self.topGroup.Visibility = Visibility.Visible
            
            self.btmGruop.Header = "Top & Btm Reinforcement" if self.chbSameTopBtm.IsChecked else "Bottom Reinforcement"
            
            self.btmGruop.IsEnabled = self.topGroup.IsEnabled = self.ligsGroup.IsEnabled = self.chbSameTopBtm.IsEnabled = True
            self.barsBtm.IsEnabled = self.chbBtmReo.IsChecked and self.rdoBtmBars.IsChecked
            self.optionsBtm.IsEnabled = self.chbBtmReo.IsChecked
            self.cmbBtmMesh.IsEnabled = self.chbBtmReo.IsChecked and self.rdoBtmMesh.IsChecked
            self.rdoBtmMesh.IsEnabled = self.chbBtmReo.IsChecked
            
            self.barsTop.IsEnabled = self.chbTopReo.IsChecked and self.rdoTopBars.IsChecked
            self.optionsTop.IsEnabled = self.chbTopReo.IsChecked
            self.cmbTopMesh.IsEnabled = self.chbTopReo.IsChecked and self.rdoTopMesh.IsChecked
            self.rdoTopMesh.IsEnabled = self.chbTopReo.IsChecked

            self.groupLig1.IsEnabled = self.chbLigs.IsChecked
            self.groupLig2.IsEnabled = self.chbLigs.IsChecked
            
            if self.chbBtmReo.IsChecked and self.rdoBtmBars.IsChecked:
                self.barsBtm.Visibility = Visibility.Visible
                self.cmbBtmMesh.Visibility = Visibility.Collapsed
            elif self.chbBtmReo.IsChecked and self.rdoBtmMesh.IsChecked:
                self.barsBtm.Visibility = Visibility.Collapsed
                self.cmbBtmMesh.Visibility = Visibility.Visible
            else:
                self.barsBtm.Visibility = self.cmbBtmMesh.Visibility = Visibility.Collapsed

            if self.chbTopReo.IsChecked and self.rdoTopBars.IsChecked:
                self.barsTop.Visibility = Visibility.Visible
                self.cmbTopMesh.Visibility = Visibility.Collapsed
            elif self.chbTopReo.IsChecked and self.rdoTopMesh.IsChecked:
                self.barsTop.Visibility = Visibility.Collapsed
                self.cmbTopMesh.Visibility = Visibility.Visible
            else:
                self.barsTop.Visibility = self.cmbTopMesh.Visibility = Visibility.Collapsed
                
            if self.chbLigs.IsChecked:
                self.chbSide.Visibility = Visibility.Visible
                self.groupLig1.Visibility = Visibility.Visible
                self.groupLig2.Visibility = Visibility.Visible
            else:
                self.groupLig1.Visibility = Visibility.Collapsed
                self.groupLig2.Visibility = Visibility.Collapsed
                self.chbSide.Visibility = Visibility.Collapsed
            
            self.reinf_text(self, None)
            
    def on_reo_type_changed(self, sender, args):
        if sender == self.spnBtm1:
            val = int(self.txbBtm.Text)
            self.txbBtm.Text = str(val - 1) if val - 1 > 1 else str(val)
        elif sender == self.spnBtm2:
            self.txbBtm.Text = str(int(self.txbBtm.Text) + 1)

        if sender == self.spnTop1:
            val = int(self.txbTop.Text)
            self.txbTop.Text = str(val - 1) if val - 1 > 1 else str(val)
        elif sender == self.spnTop2:
            self.txbTop.Text = str(int(self.txbTop.Text) + 1)

        if sender == self.rdoLigR:
            self.cmbLigSize.ItemsSource = R_list
            self.cmbLigSize.SelectedIndex = 0
        elif sender == self.rdoLigN:
            self.cmbLigSize.ItemsSource = N_list
            self.cmbLigSize.SelectedIndex = 0
            
        if self.chbAutoReo.IsChecked == True:
            self.reinf_text(self, None)
        
    def on_width_changed(self, sender, args):
        if sender.Text != "":
            ww = self.txbWidth.Text[0] + "-"
            if self.cmbBtmMesh.SelectedIndex >= 0:
                aux = self.cmbBtmMesh.SelectedIndex
                self.cmbBtmMesh.ItemsSource = [ww + type for type in T_list]
                self.cmbBtmMesh.SelectedIndex = aux
            
            if self.cmbTopMesh.SelectedIndex >= 0:
                aux = self.cmbTopMesh.SelectedIndex
                self.cmbTopMesh.ItemsSource = [ww + type for type in T_list]
                self.cmbTopMesh.SelectedIndex = aux
            
            if self.chbAutoReo.IsChecked:
                self.reinf_text(self, None)
    
    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)

    def on_text_box_leave(self, sender, args):
        if sender.Text == "":
            sender.Text = "100"

    def on_comment_changed(self, sender, args):
        if self.txbComments.Text == "ADD COMMENT HERE":
            self.txbComments.Foreground = Brushes.LightGray
        else:
            self.txbComments.Foreground = Brushes.Black
    
    def on_auto_reinf_changed(self, sender, args):
        global aux_reo
        if self.chbAutoReo.IsChecked == False:
            self.txbReoSummary.Text = aux_reo
            self.txbReoSummary.IsEnabled = True
        else:
            aux_reo = self.txbReoSummary.Text
            self.reinf_text(self, None)
        
    def reinf_text(self, sender, args):
        Reinf = ""
        btm_reo = ""
        top_reo = ""
        lig_reo = ""
        
        # Conditions
        #-----------
        btm_cond = self.chbBtmReo.IsChecked
        top_cond = self.chbTopReo.IsChecked
        top_btm_cond = all([btm_cond, self.chbSameTopBtm.IsChecked])
        lig_cond = self.chbLigs.IsChecked
        
        # Texts
        #-------
        if self.cmbBtmMesh.SelectedIndex >= 0 and self.rdoBtmMesh.IsChecked:
            btm_reo = self.cmbBtmMesh.SelectedItem
        if self.cmbTopMesh.SelectedIndex >= 0 and self.rdoTopMesh.IsChecked:
            top_reo = self.cmbTopMesh.SelectedItem
        if self.cmbBtmReo.SelectedIndex >= 0 and self.rdoBtmBars.IsChecked:
            btm_reo = self.txbBtm.Text + "/" + self.cmbBtmReo.SelectedItem
        if self.cmbTopReo.SelectedIndex >= 0 and self.rdoTopBars.IsChecked:
            top_reo = self.txbTop.Text + "/" + self.cmbTopReo.SelectedItem

        if self.cmbLigSize.SelectedIndex >= 0 and self.chbLigs.IsChecked:
            lig_reo = (self.cmbLigSize.SelectedItem + " LIGS @" + 
                self.txbLigSpacing.Text + "CRS.")
        
        # Combinations
        #-------------
        
        if top_btm_cond:
            Reinf = btm_reo + " TOP & BTM. " + lig_reo
        else:
            if btm_cond and top_cond:
                if btm_reo == top_reo:
                    Reinf = btm_reo + " TOP & BTM. " + lig_reo
                else:
                    Reinf = top_reo + " TOP. " + btm_reo + " BTM. " + lig_reo
            elif btm_cond and not top_cond:
                Reinf = btm_reo + " BTM. " + lig_reo
            elif top_cond and not btm_cond:
                Reinf = top_reo + " TOP. " + lig_reo
        
        if self.chbAutoReo.IsChecked:
            self.txbReoSummary.Text = Reinf
            #self.txbReoSummary.Text = str(self.chbLigs.IsChecked)


    def on_add_item(self, sender, args):
        global Load_List
        if all([float(self.txbWidth.Text) > 100, float(self.txbDepth.Text) > 100]):
            selected_size_gral = self.txbWidth.Text + "w x " + self.txbDepth.Text + "d"
            selected_size_resd = self.txbWidth.Text + " WIDE x " + self.txbDepth.Text + " DEEP"
            selected_type_mark = self.txbMark.Text
            new_name = (selected_type_mark + " - " + selected_size_gral)
            if res_type:
                new_name = ("STP_" + selected_type_mark + " Footing")
            self.lsbNewItems.Items.Add(new_name)

            new_line = []

            fam_path = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Foundations", fam_name + ".rfa")

            family_block = [fam_name, new_name, fam_path, fam_type]
            new_line.append(family_block)
            
            # General Parameters
            stp_comment = ". " + self.txbComments.Text.upper() if self.txbComments.Text != "ADD COMMENT HERE" else ""
            par_schedule = (("STP Schedule", "G"))
            par_category = (("STP Category", self.txbCategory.Text))
            par_stp_size = (("STP_Size", selected_size_gral))
            par_stp_comm = (("STP_Comment", self.cmbUsage.SelectedItem + stp_comment))
            par_res_comm = (("Type Comments", self.cmbUsage.SelectedItem + stp_comment))
            par_typ_mark = (("Type Mark",selected_type_mark))
            par_concrete = (("STP_Concrete Grade/Fill", self.cmbConc.SelectedItem))
            par_reinforc = (("STP_Reinforcement", self.txbReoSummary.Text))
            par_cover = (("STP_Cover", self.txbCover.Text))
            # For residential
            if res_type:
                par_stp_size = (("STP_Size", selected_size_resd))
                par_reinforc = (("STP_Reinforcement", self.txbReoSummary.Text.replace("11TM", "11 TM").replace("12TM", "12 TM").replace("14TM", "14 TM")))
                #par_cover = (("STP_Cover", self.txbCover.Text + "mm")) #Removed, put back if needed

            general_block = [par_schedule, par_category, par_stp_size, par_stp_comm, par_res_comm, par_typ_mark, par_concrete, par_reinforc, par_cover]
            new_line.append(general_block)

            params = []
            # Local Parameters
            par_w = (("Footing_Width", self.txbWidth.Text))
            par_d = (("Footing_Depth", self.txbDepth.Text))
            par_b = (("b", self.txbWidth.Text))
            par_h = (("h", self.txbDepth.Text))
            par_abr = (("Add Btm Reo", 1 if self.chbBtmReo.IsChecked and self.rdoBtmBars.IsChecked else 0))
            par_atr = (("Add Top Reo", 1 if self.chbTopReo.IsChecked and self.rdoTopBars.IsChecked else 0))
            par_bbn = (("Btm Bars No.", int(self.txbBtm.Text)))
            par_tbn = (("Top Bars No.", int(self.txbTop.Text)))
            par_bbs = (("Btm Bars Size", float(self.cmbBtmReo.SelectedItem.replace("N",""))))
            par_tbs = (("Top Bars Size", float(self.cmbTopReo.SelectedItem.replace("N",""))))
            par_asr = (("Add Side Reo", 1 if self.chbSide.IsChecked else 0))
            par_alg = (("Add Ligatures", 1 if self.chbLigs.IsChecked else 0))
            par_lgs = (("Ligature Size", float(self.cmbLigSize.SelectedItem.replace("N","").replace("R",""))))
            par_lsp = (("Ligature Spacing", float(self.txbLigSpacing.Text)))
            par_btm = (("Btm Trench", 1 if self.chbBtmReo.IsChecked and self.rdoBtmMesh.IsChecked else 0))
            par_ttm = (("Top Trench", 1 if self.chbTopReo.IsChecked and self.rdoTopMesh.IsChecked else 0))
            par_tsz = (("Trench Size", self.cmbTopMesh.SelectedItem))
            # for Residential
            #par_ = (("", ))

            params = [par_w, par_d, par_b, par_h, par_abr, par_atr, par_bbn, par_tbn, par_bbs, par_tbs,
                par_asr, par_alg, par_lgs, par_lsp, par_btm, par_ttm, par_tsz]
            new_line.append(params)
            
            Load_List.append(new_line)
            
            # Update Type Mark List Box
            type_mark_list_name = selected_type_mark + " - " + selected_size_gral
            type_Marks_List.append((selected_type_mark, type_mark_list_name))
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks
            self.check_string = self.check_is_last_item()
        else:
            forms.alert(
                "Error: Check Width and Depth Parameter.",
                title="Warning",
                warn_icon=True  # This shows the warning (exclamation) icon
            )

    def remove_item(self, sender, args):
        global Load_List
        selected_index = self.lsbNewItems.SelectedIndex
        if selected_index >= 0:
            self.lsbNewItems.Items.RemoveAt(selected_index)
            del Load_List[selected_index]
            del type_Marks_List[selected_index + len(type_Marks_Grey)]

        # Update Type Mark List Box
        filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
        self.txbMark.Text = self.next_type_mark
        self.lsbMarks.ItemsSource = filtered_type_marks
        self.check_string = self.check_is_last_item()
        
    def close_form(self, sender, args):
        self.Close()

    def load_families(self, sender, args):
        final_check = self.check_is_last_item()
        if final_check == self.check_string: # Check if there are modifications in elements before load
            self.go_for_load = True
            self.Close()
        else:
            result = forms.alert(
                "The last item hasn't been added to the list. Do you want to continue loading without it?",
                title="Confirm Add",
                yes=True,
                no=True
            )
            if result:
                self.go_for_load = True
                self.Close()


# Show the form
form = BeamFootingsForm(xaml_file_name)
form.ShowDialog()


#-----------------------------------------------------------------------------------
#-------------COPY FAMILY INSTANCE AND ADD PARAMETERS-------------------------------
# region ---------------------------------------------------------------------------
stage = "Load Family and Parameters"
if form.go_for_load and Load_List:
    try:
        local_state, local_report = load_families_and_parameters(doc, Load_List)
    except Exception as e:
        local_report = str(e)
    final_report += local_report
else:
    sys.exit()

# endregion


#--------------------------------------------------------------------
#----------- REPORT SAVING TIME TO DATA BASE ------------------------
# region ------------------------------------------------------------
stage = "Tracking Data"
file_path = os.path.join(Lib_Path, "STP Tracking", "Data.txt")
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if os.path.exists(file_path):
    final_report += fill_tracking_data(file_path, p_Numb, user_name, "Load Beam Footing", "4", start_time, end_time, str(len(Load_List)), stage)

# endregion


#print(final_report)