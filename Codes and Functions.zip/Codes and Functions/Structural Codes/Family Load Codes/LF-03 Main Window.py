# Load the Python Standard and DesignScript Libraries
import sys
import os
import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *

clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from System.Drawing import Point, Size, ContentAlignment, Color, Image, Icon, Font, FontStyle
from System.Windows.Forms import Application, Button, Form, Label, ListBox, TextBox, ComboBox, RadioButton, CheckBox, GroupBox, FormStartPosition, NumericUpDown, BorderStyle, ListBox, SelectionMode, ScrollBars, MessageBox, MessageBoxButtons, MessageBoxIcon

from System import Environment, Decimal
Test = []
#-----------------------------------------------------------------
#       FUNCTIONS TO EXPORT ONE IS FINISHED
#-----------------------------------------------------------------

def is_number_greater_than(val, limit):
    try:
        # Convert the value to a float once
        num = float(val)
        # Check if the number is greater than or equal to the limit
        if num >= limit:
            return True
        else:
            return False
    except ValueError:
        return False
        

def Available_type_mark(categ_code, exist_member_list):
    lrg = len(categ_code)
    used_list = []
    used_tp = []
    used_numbers = []
    for x, type in enumerate(exist_member_list[0]):
        if type[:lrg] == categ_code and type[lrg:].isdigit():
            used_numbers.append(int(type[lrg:]))
            if exist_member_list[1][x] != "##":
                used_list.append(exist_member_list[1][x])
            used_tp.append(exist_member_list[0][x])
    k = 1
    while k in used_numbers:
        k = k + 1
    
    next_availabe_type_mark = categ_code + str(k)
    
    # Create a list of tuples, each containing corresponding elements from all three lists
    combined_lists = list(zip(used_numbers, used_tp, used_list))
    if combined_lists:
	    sorted_combined = sorted(combined_lists, key=lambda x: x[0])
	    
	    # After sorting, unpack the sorted lists
	    sorted_numbers, sorted_tp, sorted_list = zip(*sorted_combined)
	    
	    sorted_list = list(sorted_list)
	    sorted_tp = list(sorted_tp)
    else:
        sorted_list = []
        sorted_tp = []

    return sorted_list, sorted_tp, next_availabe_type_mark

# The inputs to this node will be stored as a list in the IN variables.
exceptions = ["BRACING","OUTRIGGER","TRANSOM","BAYONET",
              "STUB", "ISOLATED BEAM", "BATTEN", "STUB COLUMN"]
fixed_code = ["BR","OR","TR","ByN","ST","SB", "BA", "ST"]
purlins_and_girts_list = ["PURLIN","GIRT","CEILING JOIST","ROOF JOIST", "CEILING JOIST", "FLOOR JOIST"]
names_to_show = ["Footing_Width","Footing_Depth","Footing_Length","Diameter","Length","d", "b", "H3T"]
foundation_list = ["Beam Footings","Pad Footings","Bored Piers"]
steel_list = ["Structural Framing", "Structural Columns"]
timber_list = ["Timber Beams", "Timber Columns"]
timber_functions = ["M", "F", "R"]
timber_spacings = ["JOIST", "RAFTER", "POLE"]
excepted_parameters = ["Select Size", "STP_Size", "STP_Comment", "STP Schedule", "STP Category"]
Load_list = []
Parm_list = []
#------------------------------------------
Lib_Path = IN[0][0]
#------------------------------------------
FamilyData = IN[1]
particular_group = FamilyData[0][0]
control_names = FamilyData[0][1]
Revit_Category = FamilyData[0][2]
#------------------------------------------

family_names = FamilyData[1]
family_usages = FamilyData[2]
Usage_list = []
Codes_list = []
Categ_list = []
for item in family_usages:
    us = item.split('-')[0]
    Usage_list.append(us)
    Categ_list.append(item.split('-')[1])
    code = us.split()
    suffix = ""
    for word in code:
        suffix = suffix + word[0]
    if us in exceptions:
        n = exceptions.index(us)
        suffix = fixed_code[n]
    Codes_list.append(suffix)
default_index = FamilyData[3]

#------------------------------------------
Type_Marks_Data = IN[2]
Current_Type_Marks = Type_Marks_Data[0]
Current_Type_marks_names = Type_Marks_Data[1]
size_of_TM_Data = len(Current_Type_Marks)
    
# Check if the file "Structural\Structural Framing (or Columns)\ Exists
aux_path = os.path.join(Lib_Path.replace("STP Dynamo","STP Structural"), Revit_Category.replace(" ","_"))
if os.path.isdir(aux_path):
    types_source_path = aux_path
else:
    types_source_path = "N/A"

class Load_Family_Form(Form):
    def __init__(self):
        self.Text = Revit_Category.upper()
        self.Width = 600
        self.Height = 670
        self.StartPosition = FormStartPosition.CenterScreen
        
        self.type_mark_suffix = ""
        self.P_Category = ""
        self.prov_comment = ""
        self.Test = []
        
        self.List_A = [""] * 6
        self.purlin_comments = []
        self.Finalised = False
#-----------------------------------------------------------------
#       GENERAL ELEMENTS CONTROL
#-----------------------------------------------------------------
        w1 = 150
        x1 = 20
        y1 = 20        # Location.X for the first group of elements.

        lbl = Label()
        lbl.Text = "Structural Usage"
        lbl.Location = Point(x1, y1)
        lbl.Width = w1
        lbl.Height = 15
        self.lblUsage = lbl
        
        cmb = ComboBox()
        cmb.Location = Point(x1, lbl.Location.Y + 20)
        cmb.Width = w1
        for usage in Usage_list:
            cmb.Items.Add(usage)
        cmb.SelectedIndexChanged += self.on_usage_change
        self.cmbUsage = cmb
        
        lbl = Label()
        lbl.Text = "Family Type"
        lbl.Location = Point(x1, cmb.Location.Y + 30)
        lbl.Width = w1
        lbl.Height = 15
        self.lblType = lbl
        
        cmb = ComboBox()
        cmb.Location = Point(x1, lbl.Location.Y + 20)
        cmb.Width = w1
        for fam_name in family_names:
            cmb.Items.Add(fam_name)
        cmb.SelectedIndexChanged += self.on_type_change
        self.cmbType = cmb
        
        lbl = Label()
        lbl.Text = "Element Size" #---For steel elements only
        lbl.Location = Point(x1, cmb.Location.Y + 30)
        lbl.Width = w1
        lbl.Height = 15
        self.lblSize = lbl
        
        cmb = ComboBox()
        cmb.Location = Point(x1, lbl.Location.Y + 20)
        cmb.Width = w1
        cmb.SelectedIndexChanged += self.fill_List_A
        self.cmbSize = cmb
        
        lbl = Label()
        lbl.Text = "Concrete Grade" # --- For concrete elements only
        lbl.Location = self.lblSize.Location
        lbl.Width = w1
        lbl.Height = 15
        self.lblConc = lbl
        
        concrete_list = ["N25", "N32", "N40"]
        
        cmb = ComboBox()
        cmb.Location = self.cmbSize.Location
        cmb.Width = w1
        for conc in concrete_list:
            cmb.Items.Add(conc)
        cmb.SelectedIndexChanged += self.fill_List_A
        self.cmbConc = cmb
        
        lbl = Label()
        lbl.Text = "Element Function" # --- For timber beams only
        lbl.Location = self.lblSize.Location
        lbl.Width = w1
        lbl.Height = 15
        self.lblFunction = lbl
        
        function_list = ["Wall Framing", "Floor Framing", "Roof Framing"]
        
        cmb = ComboBox()
        cmb.Location = self.cmbSize.Location
        cmb.Width = w1
        for func in function_list:
            cmb.Items.Add(func)
        cmb.SelectedIndexChanged += self.fill_List_A
        cmb.SelectedIndexChanged += self.on_function_change
        self.cmbFunction = cmb
        
        lbl = Label()
        lbl.Text = "Next Available Type Mark" 
        lbl.Location = Point(x1, cmb.Location.Y + 30)
        lbl.Width = w1
        lbl.Height = 15
        self.lblTmark = lbl
        
        txb = TextBox()
        txb.Location = Point(x1, lbl.Location.Y + 20)
        txb.Width = w1
        txb.LostFocus += self.fill_List_A
        self.txbTmark = txb
                     
        lbl = Label()
        lbl.Text = "STP Category" 
        lbl.Location = Point(x1, txb.Location.Y + 30)
        lbl.Height = 15
        self.lblCateg = lbl
        
        txb = TextBox()
        txb.Location = Point(x1, lbl.Location.Y + 20)
        txb.Width = w1
        txb.LostFocus += self.fill_List_A
        self.txbCateg = txb
        
        lbl = Label()
        lbl.Text = "STP Comment" 
        lbl.Location = Point(x1, txb.Location.Y + 30)
        lbl.Height = 15
        self.lblComment = lbl
        
        txb = TextBox()
        txb.Location = Point(x1, lbl.Location.Y + 20)
        txb.Width = w1
        txb.LostFocus += self.fill_List_A
        self.txbComment = txb

        self.Controls.Add(self.lblUsage)
        self.Controls.Add(self.cmbUsage)
        self.Controls.Add(self.lblType)
        self.Controls.Add(self.cmbType)
        if Revit_Category in foundation_list:
            self.Controls.Add(self.lblConc)
            self.Controls.Add(self.cmbConc)
        elif Revit_Category in timber_list:
            self.Controls.Add(self.lblFunction)
            self.Controls.Add(self.cmbFunction)
            if Revit_Category == "Timber Columns":
                self.lblFunction.Visible = False
                self.cmbFunction.Visible = False
        else:
            self.Controls.Add(self.lblSize)
            self.Controls.Add(self.cmbSize)
        self.Controls.Add(self.lblTmark)
        self.Controls.Add(self.txbTmark)
        self.Controls.Add(self.lblComment)
        self.Controls.Add(self.txbComment)
        self.Controls.Add(self.lblCateg)
        self.Controls.Add(self.txbCateg)
        
#-----------------------------------------------------------------
#       TYPE MARKS AND NEW ELEMENT LISTS
#-----------------------------------------------------------------
        x2 = x1 + w1 + 25
        
        lbl = Label()
        lbl.Text = "Current Type Marks"
        lbl.Location = Point(x2, 20)
        lbl.Width = 10
        lbl.Height = 15
        self.lbTMlist = lbl
        
        txb_ml = TextBox()
        txb_ml.Location = Point(x2, lbl.Location.Y + 20)
        txb_ml.Width = 10
        txb_ml.Height = self.txbComment.Location.Y - 50
        txb_ml.Multiline = True
        txb_ml.ReadOnly = True
        txb_ml.BackColor = Color.White
        txb_ml.BorderStyle = BorderStyle.FixedSingle
        txb_ml.ScrollBars = ScrollBars.Vertical
        self.txbUsedTMarks = txb_ml
        
        lbl = Label()
        lbl.Text = "New Elements' List"
        lbl.Width = 10
        lbl.Height = 15
        self.lblNewList = lbl
        
        lsb = ListBox()
        lsb.Name = "Lista"
        lsb.Width = 10
        lsb.Height = txb_ml.Height + 40
        self.lstNewList = lsb
        
        self.Controls.Add(self.lbTMlist)
        self.Controls.Add(self.txbUsedTMarks)
        self.Controls.Add(self.lblNewList)
        self.Controls.Add(self.lstNewList)

#-----------------------------------------------------------------
#       PARTICULAR FOR EACH ELEMENT GROUP
#-----------------------------------------------------------------
        
        y2 = self.txbComment.Location.Y + 40
        x3 = x1 + particular_group.Width + 25
        y3 = y2 + particular_group.Height + 20
        
        particular_group.Location = Point(x1, y2)
        self.Controls.Add(particular_group)
        
#---------------------------------------------------
#       COMMAND BUTTONS
#---------------------------------------------------        
        
        btn = Button()
        btn.Text = '+ADD+'
        btn.Name = "Add"
        btn.Width = 80
        btn.Height = 50
        #btn.Font = Font("Arial", 14, FontStyle.Bold)
        #image = Image.FromFile(r"D:\LABORAL\STP CONSULTANTS\test2.png")
        #btn.Image = image
        #btn.ImageAlign = ContentAlignment.MiddleCenter 
        btn.Location = Point(x3, y2)
        btn.BackColor = Color.Green
        self.btmAdd = btn
        self.btmAdd.Click += self.on_add_remove_element
        
        btn = Button()
        btn.Name = "Remove"
        btn.Text = 'REMOVE'
        btn.Width = 80
        btn.Height = 50
        #btn.Font = Font("Arial", 10, FontStyle.Bold)
        #image = Image.FromFile(r"D:\LABORAL\STP CONSULTANTS\test3.png")
        #btn.Image = image
        #btn.ImageAlign = ContentAlignment.MiddleCenter 
        btn.Location = Point(x3, self.btmAdd.Location.Y + 50)
        self.btmRemove = btn
        self.btmRemove.Click += self.on_add_remove_element
        
        btn = Button()
        btn.Text = 'FINALISE'
        btn.Name = "Finalise"
        btn.Width = 250
        btn.Location = Point(300, y3)
        self.btmFinish = btn
        self.btmFinish.Click += self.on_finish

        btn = Button()
        btn.Text = 'CANCEL'
        btn.Name = "Cancel"
        btn.Width = 250
        btn.Location = Point(25, y3)
        self.btnCancel = btn
        self.btnCancel.Click += self.on_finish
        
        self.Controls.Add(self.btmAdd)
        self.Controls.Add(self.btmRemove)
        self.Controls.Add(self.btmFinish)
        self.Controls.Add(self.btnCancel)

        # Adjust final windows Width
        L = x3 + 25 + self.btmAdd.Width + 15
        H = y3 + btn.Height + 65
        self.Width = L
        self.Height = H
        
        d = L -x2 - 30
        w2 = (d - 40) / 2
        x4 = x2 + d / 2
        
        self.lbTMlist.Width = w2
        self.txbUsedTMarks.Width = w2               
        self.lblNewList.Width = w2                
        self.lblNewList.Location = Point(x4, self.lbTMlist.Location.Y)
        self.lstNewList.Width = self.lblNewList.Width
        self.lstNewList.Location = Point(x4, self.txbUsedTMarks.Location.Y)
        self.txbComment.Width = w1 + w2 + 10

#---------------------------------------------------
#       INITIALISING THE CODE
#---------------------------------------------------  

        if Revit_Category == "Structural Framing":
            initial_index = 23
        elif Revit_Category == "Structural Columns":
            initial_index = 8
        elif Revit_Category == "Beam Footings":
            initial_index = 7
        elif Revit_Category == "Timber Beams":
            initial_index = 11
        else:
            initial_index = 0
        try:
            self.cmbUsage.SelectedIndex = initial_index
        except:
            self.cmbUsage.SelectedIndex = 0
        
        self.cmbConc.SelectedIndex = 0
        self.cmbFunction.SelectedIndex = 0

#---------------------------------------------------
#       MAIN WINDOW FUNCTIONS
#---------------------------------------------------

    def on_usage_change(self, sender, event):
        index_Usage = self.cmbUsage.SelectedIndex
        self.type_mark_suffix = Codes_list[index_Usage]
        self.prov_comment = Usage_list[index_Usage]
        
        # Get next available Type Mark
        self.type_marks()
            
        # Check if the steel framing family requires open the external group
        # Exclusively when need Spacing and Bridging rows
              
        if Revit_Category in steel_list:
            ctrl1 = self.find_particular_group_control("Spacing", "Usage")
            ctrl2 = self.find_particular_group_control("Rows", "Usage")
            ctrl3 = self.find_particular_group_control("Purlin notes", "Usage")
            if self.prov_comment in purlins_and_girts_list:
                ctrl1.Enabled = ctrl2.Enabled = ctrl3.Checked = True
            else:
                ctrl1.Enabled = ctrl2.Enabled = ctrl3.Checked = False

        try:
            self.cmbType.SelectedIndex = default_index[index_Usage]
        except:
            self.cmbType.SelectedIndex = 0
            
    def on_type_change(self, sender, event):
        if Revit_Category not in foundation_list:
            family_name = self.cmbType.SelectedItem
            family_txt_file = family_name + ".txt"
            family_rvt_file = family_name + ".rfa"
            family_txt_path = os.path.join(types_source_path, family_txt_file)
            self.cmbSize.Items.Clear()
                
            if os.path.isfile(family_txt_path):
                mylines = []
                with open(family_txt_path, 'r') as file:
                    mylines = [line.strip() for line in file]
                
                # Prevent from load excesive elements in structural shs columns
                if family_name == "STP_Steel Col_SHS" and Revit_Category == "Structural Columns":
                    mylines = mylines[:1] + mylines[27:]
                    
                mylines[0] = "Select Size" + mylines[0]
                aux = []
                for line in mylines:
                    params = line.split(",")
                    self.cmbSize.Items.Add(params[0][:-1] if params[0].endswith(' ') else params[0]) # Add sizes to the list
                    self.cmbSize.SelectedIndex = 0
                    aux.append(params)
                
                # Remove all the "##" from the file to get only parameter names
                for x, line in enumerate(aux[0]):
                    try:
                        n = line.index("##")
                        aux[0][x] = line[:n]
                    except:
                        pass
    
                self.All_families_data_list = aux
                
    def on_function_change(self, sender, event):
        if Revit_Category in timber_list:
            ctrl1 = self.find_particular_group_control("STP Schedule", "Usage")
            ctrl1.Text = "C" if Revit_Category == "Timber Columns" else timber_functions[self.cmbFunction.SelectedIndex]
                
#---------------------------------------------------
#       GENERAL FUNCTIONS
#---------------------------------------------------
    def create_Footings_name(self, list_b):
        if Revit_Category == "Bored Piers":
            return list_b[3] + " Dia x " + list_b[4] + "lg"
        elif Revit_Category == "Pad Footings":
            size_sqr = list_b[0] + "Sqr x " + list_b[1] + "d"
            size_rec = list_b[0] + "w x " + list_b[2] + "lg x " + list_b[1] + "d"
            return size_sqr if list_b[0] == list_b[2] else size_rec
        else:
            return list_b[0] + "w x " + list_b[1] + "d"
    
    def create_Timber_name(self, list_b):
        size = list_b[5] + "x" + list_b[6]
        return size
    
    def type_marks(self):
        # Get next available Type Mark
        matrix_tm = Available_type_mark(self.type_mark_suffix, Type_Marks_Data)
        UsedTMarks = matrix_tm[0]
        next_type_mark = matrix_tm[2]
        if UsedTMarks:
            self.txbUsedTMarks.Text = Environment.NewLine.join(UsedTMarks)
        else:
            self.txbUsedTMarks.Text = "No current type marks in the model"
        # Fill text boxes that depend on Usage only
        self.txbComment.Text = Usage_list[self.cmbUsage.SelectedIndex]
        self.txbTmark.Text = next_type_mark
        self.txbCateg.Text = Categ_list[self.cmbUsage.SelectedIndex]
    
    def fill_List_A(self, sender, event):
        if Revit_Category in foundation_list:
       	    P_Conc = self.cmbConc.SelectedItem    	        
       	    P_Name = "#name#"
       	if Revit_Category in timber_list:
       	    P_Conc = "N/A"
       	    P_Name = self.cmbFunction.SelectedItem
        else:
            P_Conc = "N/A"
            P_Name = self.cmbSize.SelectedItem
        
        self.List_A[0] = self.cmbType.SelectedItem
        self.List_A[1] = P_Name
        self.List_A[2] = self.txbTmark.Text
        self.List_A[3] = self.txbCateg.Text
        self.List_A[4] = P_Conc
        self.List_A[5] = self.txbComment.Text

    def find_particular_group_control(self, name, stage):
        if name in control_names:
            found = False
            control = None
            if Revit_Category in foundation_list or Revit_Category in timber_list:
                for Groups in particular_group.Controls:
                    for control_p in Groups.Controls:
                        if control_p.Name == name:
                            control = control_p
                            found = True
                            break
            else:
                for control_p in particular_group.Controls:
                    if control_p.Name == name:
                        control = control_p
                        found = True
                        break            
            
            if found and stage != "Usage":
                control_type = ""
                control_type = type(control).__name__
                control_value = None

                if control_type == "TextBox":
                    control_value = control.Text
                elif control_type == "ComboBox":
                    control_value = control.SelectedItem
                elif control_type == "CheckBox":
                    control_value = control.Checked
                elif control_type == "RadioButton":
                    control_value = control.Checked
                elif control_type == "Label":
                    control_value = control.Text
                elif control_type == "NumericUpDown":
                    control_value = int(str(control.Value))
                else:
                    control_type = "Not found"
                
                return [name, control_value]
            else:
                return control
        else:
            return None
        
#---------------------------------------------------
#       BUTTON's FUNCTIONS
#---------------------------------------------------

    def on_add_remove_element(self, sender, event):
        self.mssg = ""
        element_approved = False
        if sender.Name == "Add":
            element_approved = True
            if Revit_Category in steel_list:
                if self.cmbSize.SelectedItem == "Select Size" or self.cmbSize.SelectedIndex < 0:
                    self.mssg = "PLEASE SELECT THE SIZE OF THE " + self.cmbUsage.SelectedItem + "!"
                    element_approved = False
                    
            elif Revit_Category in foundation_list:
                if Revit_Category == "Bored Piers":
                    check_list = ["Diameter", "Length"]
                elif Revit_Category == "Pad Footings":
                    check_list = ["Footing_Width", "Footing_Length", "Footing_Depth"]
                elif Revit_Category == "Beam Footings":
                    check_list = ["Footing_Width", "Footing_Depth"]
                    
                fail_spaces = []
                for check in check_list:
                    match = self.find_particular_group_control(check, "Add")
                    if not is_number_greater_than(match[1], 100):
                        fail_spaces.append(match[0] + " = " + match[1])
                failed_text_box_list = "\n".join(fail_spaces)
                if failed_text_box_list != "":
                    element_approved = False
                    self.mssg = "ONE OF THE FOLLOWING TEXT BOX ARE NOT CORRECT OR LESS THAN 100mm :" + "\n" + "\n" + failed_text_box_list
                    
                self.All_families_data_list = []
            
            elif Revit_Category in timber_list:
                check_list = ["d", "b"]
                fail_spaces = []
                for check in check_list:
                    match = self.find_particular_group_control(check, "Add")
                    if not is_number_greater_than(match[1], 20):
                        fail_spaces.append(match[0] + " = " + match[1])
                failed_text_box_list = "\n".join(fail_spaces)
                if failed_text_box_list != "":
                    element_approved = False
                    self.mssg = "ONE OF THE FOLLOWING TEXT BOX ARE NOT CORRECT :" + "\n" + "\n" + failed_text_box_list
                
                self.All_families_data_list = []

        elif sender.Name == "Remove":
            selected_index = self.lstNewList.SelectedIndex
            if selected_index >= 0:
                self.lstNewList.Items.RemoveAt(selected_index)
                remove_index = size_of_TM_Data + selected_index
                Load_list.pop(selected_index)
                Type_Marks_Data[0].pop(remove_index)
                Type_Marks_Data[1].pop(remove_index)
                self.type_marks()
                self.fill_List_A(self, None)
             
        if element_approved == True:
            # Get the particular group data:
            aux = []
            self.fill_List_A(self, None)
            self.List_B = [""] * 10
            for name in control_names:
                control_info = self.find_particular_group_control(name, "Add")
                if name in names_to_show:
                    try:
                        idx = names_to_show.IndexOf(name)
                    except:
                        idx = names_to_show.index(name)
                    self.List_B[idx] = control_info[1]
                aux.append(control_info)

            if Revit_Category in foundation_list:
                self.List_A[1] = self.create_Footings_name(self.List_B)
            if Revit_Category in timber_list:
                self.List_A[1] = self.create_Timber_name(self.List_B) + " " + self.List_A[0]
                if Revit_Category == "Timber Columns":
                    self.List_A[0] = "PSL-Parallel Strand Lumber-Column"
                else:
                    self.List_A[0] = "STP_Timber_HW_UNSEASONED"
            
            new_entry = self.List_A[2] + " - " + self.List_A[1]
            if self.List_B[7]:
                new_entry = new_entry + " [H3]"
            
            self.lstNewList.Items.Add(new_entry)
            
            # Add element to the Load_list
            Load_list.append(self.List_A)
            if self.All_families_data_list:
                aux_list = zip(self.All_families_data_list[0], self.All_families_data_list[self.cmbSize.SelectedIndex])
                for ax in aux_list:
                    if ax[0] not in excepted_parameters:
                        a = float(ax[1]) if is_number_greater_than(ax[1],0) else ax[1]
                        aux.append((ax[0], a))
            
            # Check if ON-FLAT is activated for RHS to exchange b and d value
            if self.List_A[0][:13] == "STP_Steel_RHS" and aux[3][1]:
                for x, ax in enumerate(aux):
                    # Convert tuple to a list to allow modification
                    pair_list = list(ax)
                    
                    # Check if the first element is "b" or "d" and swap accordingly
                    if pair_list[0] == "b":
                        pair_list[0] = "d"
                    elif pair_list[0] == "d":
                        pair_list[0] = "b"
        
                    # Convert the modified list back to a tuple and update the aux list
                    aux[x] = tuple(pair_list)
            
            Parm_list.append(aux)
            Type_Marks_Data[0].append(self.List_A[2])
            Type_Marks_Data[1].append("##")
            self.List_A = [""] * 6
            self.type_marks()
            if Revit_Category == "Timber Beams": #Return Spacing textbox to 0
                spacing_txb = self.find_particular_group_control("Spacing", "Usage")
                spacing_txb.Text = "0"
        
        # Show message if element is not approved:
        else:
            if sender.Name != "Remove":
                MessageBox.Show(self.mssg, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            
            
    def on_finish(self, sender, event):
        if sender.Name == "Finalise":
            self.Finalised = True
        
        self.Close()
                   
form = Load_Family_Form()
form.ShowDialog()


#OUT = form.Test #Parm_list

if form.Finalised:
    OUT = Load_list, Parm_list, Revit_Category
else:
    OUT = [], [], ""
    