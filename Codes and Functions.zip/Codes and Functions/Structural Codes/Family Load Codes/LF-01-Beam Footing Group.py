import sys
import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *

clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from System.Drawing import Point, Size, Color
from System.Windows.Forms import Application, Form, Label, TextBox, NumericUpDown, CheckBox, GroupBox, ComboBox, RadioButton

from System import Decimal

def stp_reinforcement():
    
    if chbAutoReinf.Checked:
        tmesh_text = ""
        if chbTmesh.Checked and chbBmesh.Checked:
            tmesh_text = cmbTmesh.SelectedItem + " TOP & BTM. "
        elif chbTmesh.Checked and not chbBmesh.Checked:
            tmesh_text = cmbTmesh.SelectedItem + " TOP. "
        elif not chbTmesh.Checked and chbBmesh.Checked:
            tmesh_text = cmbTmesh.SelectedItem + " BOTTOM. "
            
        #Forming Top and Btm Reo Text
        top_btm_reo = ""
        top_reo_text = str(spnTopNumber.Value) + "/" + cmbTbs.SelectedItem
        btm_reo_text = str(spnBtmNumber.Value) + "/" + cmbBbs.SelectedItem

        if int(str(spnTopNumber.Value)) > 1 and int(str(spnBtmNumber.Value)) > 1:
            if top_reo_text == btm_reo_text:
                top_btm_reo = top_reo_text + " TOP & BTM. "
            else:
                top_btm_reo = top_reo_text + " TOP, " + btm_reo_text + " BOTTOM. "
        elif int(str(spnTopNumber.Value)) > 1 and int(str(spnBtmNumber.Value)) < 2:
            top_btm_reo = top_reo_text + " TOP. "
        elif int(str(spnBtmNumber.Value)) > 1 and int(str(spnTopNumber.Value)) < 2:
            top_btm_reo = btm_reo_text + " BOTTOM. "

        ligs_text = cmbLigs.SelectedItem + " LIGS @" + txbSpac.Text + "Crs." if not rbtNone.Checked else ""
        

        Final_Reo_text = top_btm_reo + tmesh_text + ligs_text
        txbStpReinf.Text = Final_Reo_text if Final_Reo_text != "" else "MASS CONCRETE"

def on_control_update(sender, event):

    # Hide Combo box if number of bars is less than 2 TOP and BOTTOM
    #---------------------------------------------------------------
    if sender.Name == "Top Bars No.":
        cmbTbs.Enabled = int(str(sender.Value)) > 1
        chbAddTop.Checked = int(str(sender.Value)) > 1
        stp_reinforcement()
    elif sender.Name == "Btm Bars No.":
        cmbBbs.Enabled = int(str(sender.Value)) > 1 
        chbAddBtm.Checked = int(str(sender.Value)) > 1
        stp_reinforcement()

    # Take the width of the beam to get the trench mesh size
    #---------------------------------------------------------------
    elif sender.Name == "Footing_Width":
        prov_index = cmbTmesh.SelectedIndex
        w = sender.Text[0]
        w = w if int(w) < 6 else str(5)
        cmbTmesh.Items.Clear()
        for item in T_list:
            item = w + "-" + item
            cmbTmesh.Items.Add(item)
        try:
            cmbTmesh.SelectedIndex = prov_index
        except:
            cmbTmesh.SelectedIndex = 0
        stp_reinforcement()
        
    # Check if Trench Mesh is needed to show the Type Combo
    #---------------------------------------------------------------
    elif sender.Name == "Top Trench" or sender.Name == "Btm Trench":
        cmbTmesh.Enabled = chbTmesh.Checked or chbBmesh.Checked
        stp_reinforcement()

    # Check Ligatures visibility
    #---------------------------------------------------------------
    elif sender.Name == "No Ligs" or sender.Name == "N" or sender.Name == "R":
        chbAddLigs.Checked = not rbtNone.Checked
        if sender.Name == "No Ligs":
            cmbLigs.Enabled = False
            txbSpac.Enabled = False
        else:
            cmbLigs.Enabled = True
            txbSpac.Enabled = True
        
            list = N_list if sender.Name == "N" else R_list
            cmbLigs.Items.Clear()
            for item in list:
                item = item
                cmbLigs.Items.Add(item)
            cmbLigs.SelectedIndex = 1
        stp_reinforcement()
    
#---------------- AUTOMATIC REINF. TEXT.----------------------

    elif sender.Name == "AutoReinf":
        txbStpReinf.ReadOnly = sender.Checked
        if sender.Checked == True:
            stp_reinforcement()
    
    else:
        stp_reinforcement()
            


N_list = ["N10", "N12", "N16", "N20", "N22", "N24"]
R_list = ["R6", "R8", "R10"]
T_list = ["L11TM", "L12TM", "L14TM"]
Final_Reo_text = ""

# Create a group box
groupBox = GroupBox()
groupBox.Text = "BEAM FOOTING INFORMATION"
groupBox.Size = Size(500, 350)

#--------------------------------------------
#DIMENSIONS GROUP
#-------------------------------------------- 

gbox = GroupBox()
gbox.Text = "Footing Dimensions (mm)"
gbox.Location = Point(10, 25)
gbox.Size = Size(140, 110)
gboxDims = gbox

label = Label()
label.Text = "Width:"
label.Location = Point(10, 25)
label.Height = 15
label.Width = 50
lblWidth = label

txb = TextBox()
txb.Location = Point(60, 25)
txb.Width = 50
txb.Text = "300"
txb.Name = "Footing_Width"
txb.Leave += on_control_update
txbWidth = txb

label = Label()
label.Text = "Depth:"
label.Location = Point(10, 52)
label.Height = 15
label.Width = 50
lblDepth = label

txb = TextBox()
txb.Location = Point(60, 50)
txb.Width = 50
txb.Text = "500"
txb.Name = "Footing_Depth"
txbDepth = txb

label = Label()
label.Text = "Cover:"
label.Location = Point(10, 77)
label.Height = 15
label.Width = 50
lblCover = label

txb = TextBox()
txb.Location = Point(60, 75)
txb.Width = 50
txb.Text = "65"
txb.Name = "STP_Cover"
txbCover = txb


gboxDims.Controls.Add(lblWidth)
gboxDims.Controls.Add(txbWidth)
gboxDims.Controls.Add(lblDepth)
gboxDims.Controls.Add(txbDepth)
gboxDims.Controls.Add(lblCover)
gboxDims.Controls.Add(txbCover)

#---------------------------------------------------
#       TOP REO GROUP
#---------------------------------------------------

gbox = GroupBox()
gbox.Text = "Top Reinforcement"
gbox.Location = Point(10, 145)
gbox.Size = Size(130, 130)
gboxTopR = gbox

label = Label()
label.Text = "Bars Number:"
label.Location = Point(10, 25)
label.Height = 15
label.Width = 100
lblTbn = label

num_updown = NumericUpDown()
num_updown.Location = Point(10, 45)
num_updown.Width = 100
num_updown.Name = "Top Bars No."
spnTopNumber = num_updown
spnTopNumber.ValueChanged += on_control_update

label = Label()
label.Text = "Bar Size:"
label.Location = Point(10, 75)
label.Height = 15
label.Width = 100
lblTbs = label

cmbox = ComboBox()
cmbox.Location = Point(10, 95)
cmbox.Width = 100
cmbox.Name = "Top Bars Size" 
cmbTbs = cmbox
cmbTbs.Enabled =  False

chbox = CheckBox()
chbox.Text = "."
chbox.Name = "Add Top Reo"
chbox.Checked = False
chbox.Visible = False
chbAddTop = chbox

gboxTopR.Controls.Add(lblTbn)
gboxTopR.Controls.Add(spnTopNumber)
gboxTopR.Controls.Add(lblTbs)
gboxTopR.Controls.Add(cmbTbs)
gboxTopR.Controls.Add(chbAddTop)

#---------------------------------------------------
#       BOTTOM REO GROUP
#---------------------------------------------------
       
gbox = GroupBox()
gbox.Text = "Bottom Reinforcement"
gbox.Location = Point(170, 145)
gbox.Size = Size(130, 130)
gboxBtmR = gbox

label = Label()
label.Text = "Bars Number:"
label.Location = Point(10, 25)
label.Height = 15
label.Width = 100
lblBbn = label

num_updown = NumericUpDown()
num_updown.Location = Point(10, 45)
num_updown.Width = 100
num_updown.Name = "Btm Bars No."
spnBtmNumber = num_updown
spnBtmNumber.ValueChanged += on_control_update

label = Label()
label.Text = "Bar Size:"
label.Location = Point(10, 75)
label.Height = 15
label.Width = 100
lblBbs = label

cmbox = ComboBox()
cmbox.Location = Point(10, 95)
cmbox.Width = 100
cmbox.Name = "Btm Bars Size"
cmbox.SelectedItem = "N12"
cmbBbs = cmbox
cmbBbs.Enabled =  False

chbox = CheckBox()
chbox.Text = "."
chbox.Name = "Add Btm Reo"
chbox.Checked = False
chbox.Visible = False
chbAddBtm = chbox

gboxBtmR.Controls.Add(lblBbn)
gboxBtmR.Controls.Add(spnBtmNumber)
gboxBtmR.Controls.Add(lblBbs)
gboxBtmR.Controls.Add(cmbBbs)
gboxBtmR.Controls.Add(chbAddBtm)

for bar in N_list:
    cmbTbs.Items.Add(bar)
    cmbBbs.Items.Add(bar)
cmbTbs.SelectedItem = "N16"  
cmbBbs.SelectedItem = "N16"   

#---------------------------------------------------
#       TRENCH MESH GROUP
#---------------------------------------------------
       
gbox = GroupBox()
gbox.Text = "Trench Mesh"
gbox.Location = Point(330, 145)
gbox.Size = Size(130, 130)
gboxTmesh = gbox

chbox = CheckBox()
chbox.Text = "TOP Mesh"
chbox.Location = Point(25, 25)
chbox.Name = "Top Trench"
chbox.CheckedChanged += on_control_update
chbTmesh = chbox

chbox = CheckBox()
chbox.Text = "BTM Mesh"
chbox.Location = Point(25, 60)
chbox.Name = "Btm Trench"
chbox.CheckedChanged += on_control_update
chbBmesh = chbox

cmbox = ComboBox()
cmbox.Location = Point(10, 95)
cmbox.Width = 100
cmbox.Name = "Trench Size"
for item in T_list:
    cmbox.Items.Add("3-" + item)
cmbox.SelectedIndex = 0
cmbTmesh = cmbox
cmbTmesh.Enabled = False

gboxTmesh.Controls.Add(chbTmesh)
gboxTmesh.Controls.Add(chbBmesh)
gboxTmesh.Controls.Add(cmbTmesh)

#---------------------------------------------------
#       LIGATURES MESH GROUP
#---------------------------------------------------  

gbox = GroupBox()
gbox.Text = "Ligatures"
gbox.Location = Point(160, 35)
gbox.Size = Size(300, 100)
gboxLigs = gbox

radbtn = RadioButton()
radbtn.Text = "None"
radbtn.Location = Point(25, 20)
radbtn.Width = 70
radbtn.Name = "No Ligs"
radbtn.CheckedChanged += on_control_update
rbtNone = radbtn

radbtn = RadioButton()
radbtn.Text = "N type"
radbtn.Name = "N"
radbtn.Location = Point(25, 45)
radbtn.Width = 70
radbtn.CheckedChanged += on_control_update
rbtN = radbtn

radbtn = RadioButton()
radbtn.Text = "R type"
radbtn.Name = "R"
radbtn.Location = Point(25, 70)
radbtn.Width = 70
radbtn.CheckedChanged += on_control_update
rbtR = radbtn

label = Label()
label.Text = "Lig Size:"
label.Location = Point(100, 24)
label.Height = 15
label.Width = 60
lblLigs = label

cmbox = ComboBox()
cmbox.Location = Point(165, 20)
cmbox.Width = 100
cmbox.Name = "Ligature Size"
for r in R_list:
    cmbox.Items.Add(r)
cmbox.SelectedIndex = 1
cmbLigs = cmbox
cmbLigs.Enabled = False

label = Label()
label.Text = "Spacing:"
label.Location = Point(100, 62)
label.Height = 15
label.Width = 60
lblSpac = label

txb = TextBox()
txb.Text = "200"
txb.Location = Point(165, 60)
txb.Width = 100
txb.Name = "Ligature Spacing"
txbSpac = txb
txbSpac.Enabled = False
txbSpac.TextChanged += on_control_update

chbox = CheckBox()
chbox.Text = "."
chbox.Name = "Add Ligatures"
chbox.Checked = False
chbox.Visible = False
chbAddLigs = chbox

#---------------------------------------------------
#       REINFORCING TEXT GROUP
#---------------------------------------------------  

gbox = GroupBox()
gbox.Text = "STP_Reinforcement."
gbox.Size = Size(450, 70)
gbox.Location = Point(10, 280)
gboxStpReinf = gbox

chb = CheckBox()
chb.Text = "Automatic"
chb.Name = "AutoReinf"
chb.Width = 80
chb.Checked = False
chb.Location = Point(25,25)
chbAutoReinf = chb
chbAutoReinf.CheckedChanged += on_control_update

txb = TextBox()
txb.Name = "STP_Reinforcement"
txb.Width = 320
txb.ReadOnly = True
txb.Location = Point(110,25)
txbStpReinf = txb


gboxStpReinf.Controls.Add(chbAutoReinf)
gboxStpReinf.Controls.Add(txbStpReinf)
groupBox.Controls.Add(gboxStpReinf)

#----------------------------------------------------

rbtNone.Checked = True
chbAutoReinf.Checked = True

gboxLigs.Controls.Add(rbtNone)
gboxLigs.Controls.Add(rbtN)
gboxLigs.Controls.Add(rbtR)
gboxLigs.Controls.Add(lblLigs)
gboxLigs.Controls.Add(cmbLigs)
gboxLigs.Controls.Add(lblSpac)
gboxLigs.Controls.Add(txbSpac)
gboxLigs.Controls.Add(chbAddLigs)

groupBox.Controls.Add(gboxDims)
groupBox.Controls.Add(gboxTopR)
groupBox.Controls.Add(gboxBtmR)
groupBox.Controls.Add(gboxTmesh)
groupBox.Controls.Add(gboxLigs)
groupBox.Controls.Add(gboxStpReinf)

   
control_names = [] # Get parameters and index to use
control_index = [] # in the next control

# Loop through the controls in the GroupBox and get their names
for Groups in groupBox.Controls:
    for control in Groups.Controls:    
        if control.Name:
            control_names.append(control.Name)
        
# Output the GroupBox
OUT = groupBox, control_names, "Beam Footings"
