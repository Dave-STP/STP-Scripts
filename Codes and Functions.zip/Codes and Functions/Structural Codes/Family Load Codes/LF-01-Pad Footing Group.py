import sys
import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *

clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from System.Drawing import Point, Size
from System.Windows.Forms import Application, Form, Label, TextBox, NumericUpDown, CheckBox, GroupBox, ComboBox, RadioButton
 
from System import Decimal

def stp_reinforcement():
    if chbAutoReinf.Checked:
        final_text = ""
        ligatures_text = ""
        if chbMass.Checked:
            final_text = "MASS CONCRETE"
        else:
            as_spacing_btm = cmbBbs.SelectedItem + "-" + txbBspc.Text
            as_number_btm = str(spnBbn.Value) + "/" + cmbBbs.SelectedItem
            as_spacing_top = cmbTbs.SelectedItem + "-" + txbTspc.Text
            as_number_top = str(spnTbn.Value) + "/" + cmbTbs.SelectedItem
            if chbSameL.Checked:
                ligatures_text = " E/W."
            else:
                if rbtUbars.Checked:
                    ligatures_text = cmbLigs.SelectedItem + " 'U' TRANSVERSAL BARS @" + txbSpac.Text + "Crs."
                else:
                    ligatures_text = cmbLigs.SelectedItem + " LIGS @" + txbSpac.Text + "Crs."
                   
            if rbtBmesh.Checked:
                final_text = cmbBmsh.SelectedItem
                final_text = final_text + " MESH TOP & BTM. " if chbTop.Checked else final_text + " MESH BOTTOM. "
            elif rbtBbss.Checked:
                if chbTop.Checked and as_spacing_top == as_spacing_btm:
                    final_text = as_spacing_btm + " TOP & BTM. "
                elif chbTop.Checked and as_spacing_top != as_spacing_btm:
                    final_text = as_spacing_top + " TOP. " + as_spacing_btm + " BOTTOM. "
                else:
                    final_text = as_spacing_btm + " BOTTOM. "
            elif rbtBnbs.Checked:
                if chbTop.Checked and as_number_top == as_number_btm:
                    final_text = as_number_btm + " TOP & BTM. "
                elif chbTop.Checked and as_number_top != as_number_btm:
                    final_text = as_number_top + " TOP. " + as_number_btm + " BOTTOM. "
                else:
                    final_text = as_number_btm + " BOTTOM. "
            
            if not rbtBmesh.Checked:
                final_text = final_text + ligatures_text
                


        txbStpReinf.Text = final_text
    
def bottom_reo_conditions():
    
    chbAddBtm.Checked = not chbMass.Checked
    for control in gboxBtmR.Controls:
        if control != chbMass:
            control.Enabled = not chbMass.Checked 
    gboxTtmR.Enabled = not chbMass.Checked
    gboxLigs.Enabled = not chbMass.Checked
        
    if not chbMass.Checked:
        lblBbs.Visible = cmbBbs.Visible = lblTbs.Visible = cmbTbs.Visible = not rbtBmesh.Checked
        lblBmsh.Visible = cmbBmsh.Visible = lblTmsh.Visible = cmbTmsh.Visible = rbtBmesh.Checked
        chbSame.Enabled = chbTop.Checked and not rbtBmesh.Checked
        txbBspc.Enabled = spnBbn.Enabled = txbTspc.Enabled = spnTbn.Enabled = not rbtBmesh.Checked
        if rbtBmesh.Checked:
            chbSame.Checked = True
        
        txbBspc.Enabled = rbtBbss.Checked
        spnBbn.Enabled = rbtBnbs.Checked
        
        txbTspc.Enabled = (rbtBbss.Checked and chbTop.Checked and not chbSame.Checked)
        spnTbn.Enabled = (rbtBnbs.Checked and chbTop.Checked  and not chbSame.Checked)
        cmbTbs.Enabled = (chbTop.Checked and not rbtBmesh.Checked  and not chbSame.Checked)
        cmbTmsh.Enabled = (chbTop.Checked and rbtBmesh.Checked  and not chbSame.Checked)
        
        gboxLigs.Enabled = (chbTop.Checked and not rbtBmesh.Checked)
        
        if rbtBnbs.Checked:
            rounded_spacing = str(round((int(txbWidth.Text) - 2 * int(txbCover.Text)) / (spnBbn.Value - 1),0))
            txbBspc.Text = rounded_spacing
            if chbTop.Checked and not chbSame.Checked:
                rounded_spacing = str(round((int(txbWidth.Text) - 2 * int(txbCover.Text))/(spnTbn.Value - 1),0))
                txbTspc.Text = rounded_spacing
        
        if chbSame.Checked:
            cmbTbs.SelectedIndex = cmbBbs.SelectedIndex
            cmbTmsh.SelectedIndex = cmbBmsh.SelectedIndex
            txbTspc.Text = txbBspc.Text
            spnTbn.Value = spnBbn.Value
        
        chbTmesh.Checked = (chbTop.Checked and rbtBmesh.Checked)
            


def on_control_update(sender, event):

#---------------- DIMENSIONS GROUP----------------------

    if sender.Name == "Sqr":
        test = sender.Name
        if chbSquare.Checked:
            txbLength.Text = txbWidth.Text
        txbLength.Enabled = not chbSquare.Checked
    
    if sender.Name == "Footing_Width" and chbSquare.Checked:
        txbLength.Text = txbWidth.Text
        
#---------------- TOP REO GROUP---------------------- 

    elif sender.Name == "Add Top":
        test = sender.Name
        for control in gboxTtmR.Controls:
            if control != sender:
                control.Visible = sender.Checked
        rbtUbars.Checked = True
        rbtLigs.Enabled = sender.Checked


#---------------- TLIGATURES GROUP-------------------

    elif sender.Name == "Same as Long":
        gboxULbars.Enabled = rbtUbars.Enabled = rbtLigs.Enabled = not chbSameL.Checked
            
    elif sender.Name == "Add Ligatures":
        if not rbtR.Checked:
            rbtR.Checked = True
        cmbLigs.Items.Clear()
        for r in R_list:
            cmbLigs.Items.Add(r)
        cmbLigs.SelectedIndex = 1
        rbtN.Enabled = not sender.Checked
       
    elif sender.Name == "Transv U bars":
        rbtN.Checked = True
        cmbLigs.Items.Clear()
        for n in N_list:
            cmbLigs.Items.Add(n)
        cmbLigs.SelectedIndex = 1
    
    elif sender.Name == "R":
        cmbLigs.Items.Clear()
        for r in R_list:
            cmbLigs.Items.Add(r)
        cmbLigs.SelectedIndex = 1
     

        
#---------------- AUTOMATIC REINF. TEXT.----------------------

    elif sender.Name == "AutoReinf":
        txbStpReinf.ReadOnly = sender.Checked
        if sender.Checked == True:
            stp_reinforcement()
            
#----------------  OTHERS  ----------------------    
    bottom_reo_conditions()
    stp_reinforcement()        
        
N_list = ["N10", "N12", "N16", "N20", "N22", "N24"]
R_list = ["R6", "R8", "R10"]
T_list = ["LT-11", "LT-12", "LT-14"]
M_list = ["SL72", "SL82", "SL92", "SL102"]

# Create a group box
groupBox = GroupBox()
groupBox.Text = "PAD FOOTING INFORMATION"
groupBox.Size = Size(650, 420)

#---------------------------------------------------
#       DIMENSIONS GROUP
#--------------------------------------------------- 

gbox = GroupBox()
gbox.Text = "Footing Dimensions (mm)"
gbox.Location = Point(10, 25)
gbox.Size = Size(180, 160)
gboxDims = gbox

chbox = CheckBox()
chbox.Text = "Square"
chbox.Location = Point(10, 25)
chbox.Name = "Sqr"
chbSquare = chbox
chbSquare.CheckedChanged += on_control_update

label = Label()
label.Text = "Width:"
label.Location = Point(10, 52)
label.Height = 15
label.Width = 50
lblWidth = label

txb = TextBox()
txb.Location = Point(60, 50)
txb.Width = 50
txb.Text = "1000"
txb.Name = "Footing_Width"
txbWidth = txb
txbWidth.Leave += on_control_update

label = Label()
label.Text = "Length:"
label.Location = Point(10, 77)
label.Height = 15
label.Width = 50
lblLength = label

txb = TextBox()
txb.Location = Point(60, 75)
txb.Width = 50
txb.Text = "1000"
txb.Name = "Footing_Length"
txbLength = txb

label = Label()
label.Text = "Depth:"
label.Location = Point(10, 102)
label.Height = 15
label.Width = 50
lblDepth = label

txb = TextBox()
txb.Location = Point(60, 100)
txb.Width = 50
txb.Text = "400"
txb.Name = "Footing_Depth"
txbDepth = txb

label = Label()
label.Text = "Cover:"
label.Location = Point(10, 127)
label.Height = 15
label.Width = 50
lblCover = label

txb = TextBox()
txb.Location = Point(60, 125)
txb.Width = 50
txb.Text = "65"
txb.Name = "STP_Cover"
txbCover = txb

gboxDims.Controls.Add(chbSquare)
gboxDims.Controls.Add(lblWidth)
gboxDims.Controls.Add(txbWidth)
gboxDims.Controls.Add(lblLength)
gboxDims.Controls.Add(txbLength)
gboxDims.Controls.Add(lblDepth)
gboxDims.Controls.Add(txbDepth)
gboxDims.Controls.Add(lblCover)
gboxDims.Controls.Add(txbCover)

#---------------------------------------------------
#       BOTTOM REO GROUP
#---------------------------------------------------

gbox = GroupBox()
gbox.Text = "BOTTOM Reinforcement"
gbox.Location = Point(10, 195)
gbox.Size = Size(300, 140)
gboxBtmR = gbox

chbox = CheckBox()
chbox.Text = "Mass Concrete"
chbox.Location = Point(10, 20)
chbox.Name = "Mass Conc"
chbMass = chbox
chbMass.CheckedChanged += on_control_update

radbtn = RadioButton()
radbtn.Text = "Slab Mesh"
radbtn.Location = Point(10, 50)
radbtn.Width = 100
radbtn.Name = "Bottom Slab Mesh"
rbtBmesh = radbtn
rbtBmesh.CheckedChanged += on_control_update

radbtn = RadioButton()
radbtn.Text = "Bar Size + Spacing"
radbtn.Width = 130
radbtn.Location = Point(10, 80)
radbtn.Name = "Btm Size + Spacing"
rbtBbss = radbtn
rbtBbss.CheckedChanged += on_control_update

radbtn = RadioButton()
radbtn.Text = "Number + Bars Size"
radbtn.Location = Point(10, 110)
radbtn.Name = "Btm Size + Qty"
radbtn.Width = 130
rbtBnbs = radbtn
rbtBnbs.CheckedChanged += on_control_update

label = Label()
label.Text = "Bar Size:"
label.Location = Point(150, 22)
label.Height = 15
label.Width = 60
lblBbs = label 

cmbox = ComboBox()
cmbox.Location = Point(220, 20)
cmbox.Width = 60
for n in N_list:
    cmbox.Items.Add(n)
cmbox.Name = "Btm Bar Size"
cmbBbs = cmbox
cmbBbs.SelectedIndexChanged += on_control_update

label = Label()
label.Text = "Mesh Type:"
label.Location = Point(150, 22)
label.Height = 15
label.Width = 60
lblBmsh = label

cmbox = ComboBox()
cmbox.Location = Point(220, 20)
cmbox.Width = 60
cmbox.Name = "Mesh Type"
for mesh in M_list:
    cmbox.Items.Add(mesh)
cmbBmsh = cmbox
cmbBmsh.SelectedIndexChanged += on_control_update

label = Label()
label.Text = "Spacing:"
label.Location = Point(150, 52)
label.Height = 15
label.Width = 60
lblBspc = label

txb = TextBox()
txb.Location = Point(220, 50)
txb.Width = 40
txb.Text = "300"
txb.Name = "Btm Bars Max Spacing"
txbBspc = txb
txbBspc.TextChanged += on_control_update 

label = Label()
label.Text = "mm"
label.Location = Point(260, 52)
label.Height = 15
label.Width = 30
lblBmm = label

label = Label()
label.Text = "Bar Number:"
label.Location = Point(150, 82)
label.Height = 15
label.Width = 69
lblBbn = label

nupdwn = NumericUpDown()
nupdwn.Location = Point(220, 80)
nupdwn.Width = 60
nupdwn.Minimum = Decimal(2)
nupdwn.Name = "Btm Bars Qty"
spnBbn = nupdwn
spnBbn.ValueChanged += on_control_update

chbox = CheckBox()
chbox.Text = "."
chbox.Name = "Add Btm Reo"
chbox.Checked = False
chbox.Visible = False
chbAddBtm = chbox


gboxBtmR.Controls.Add(chbMass)
gboxBtmR.Controls.Add(rbtBmesh)
gboxBtmR.Controls.Add(rbtBbss)
gboxBtmR.Controls.Add(rbtBnbs)
gboxBtmR.Controls.Add(lblBbs)
gboxBtmR.Controls.Add(cmbBbs)
gboxBtmR.Controls.Add(lblBmm)
gboxBtmR.Controls.Add(lblBmsh)
gboxBtmR.Controls.Add(cmbBmsh)
gboxBtmR.Controls.Add(lblBspc)
gboxBtmR.Controls.Add(txbBspc)
gboxBtmR.Controls.Add(lblBbn)
gboxBtmR.Controls.Add(spnBbn)
gboxBtmR.Controls.Add(chbAddBtm)

#---------------------------------------------------
#       TOP REO GROUP
#---------------------------------------------------
       
gbox = GroupBox()
gbox.Text = "TOP Reinforcement"
gbox.Location = Point(320, 195)
gbox.Size = Size(300, 140)
gboxTtmR = gbox

chbox = CheckBox()
chbox.Text = "Add Top Reinf."
chbox.Width = 120
chbox.Location = Point(25, 20)
chbox.Name = "Add Top Reo"
chbox.Checked = True
chbTop = chbox 
chbTop.CheckedChanged += on_control_update

chbox = CheckBox()
chbox.Text = "Same as BTM Reo"
chbox.Width = 120
chbox.Location = Point(25, 50)
chbox.Name = "Same as Btm"
chbSame = chbox
chbSame.CheckedChanged += on_control_update

label = Label()
label.Text = "Bar Size:"
label.Location = Point(150, 22)
label.Height = 15
label.Width = 60
lblTbs = label 

cmbox = ComboBox()
cmbox.Location = Point(220, 20)
cmbox.Width = 60
for n in N_list:
    cmbox.Items.Add(n)
cmbox.Name = "Top Bar Size"
cmbTbs = cmbox
cmbTbs.SelectedIndexChanged += on_control_update

label = Label()
label.Text = "Mesh Type:"
label.Location = Point(150, 22)
label.Height = 15
label.Width = 60
lblTmsh = label

cmbox = ComboBox()
cmbox.Location = Point(220, 20)
cmbox.Width = 60
for mesh in M_list:
    cmbox.Items.Add(mesh)
cmbox.Name = "Mesh Type Top"
cmbTmsh = cmbox
cmbTmsh.SelectedIndexChanged += on_control_update

label = Label()
label.Text = "Spacing:"
label.Location = Point(150, 52)
label.Height = 15
label.Width = 60
lblTspc = label

txb = TextBox()
txb.Location = Point(220, 50)
txb.Width = 40
txb.Text = "300"
txb.Name = "Top Bars Max Spacing"
txbTspc = txb
txbTspc.TextChanged += on_control_update 

label = Label()
label.Text = "mm"
label.Location = Point(260, 52)
label.Height = 15
label.Width = 30
lblTmm = label

label = Label()
label.Text = "Bar Number:"
label.Location = Point(150, 82)
label.Height = 15
label.Width = 69
lblTbn = label

nupdwn = NumericUpDown()
nupdwn.Location = Point(220, 80)
nupdwn.Width = 60
nupdwn.Minimum = Decimal(2)
nupdwn.Name = "Top Bars Qty"
spnTbn = nupdwn
spnTbn.ValueChanged += on_control_update

chbox = CheckBox()
chbox.Text = "."
chbox.Name = "Top Slab Mesh"
chbox.Checked = False
chbox.Visible = False
chbTmesh = chbox

gboxTtmR.Controls.Add(chbTop)
gboxTtmR.Controls.Add(chbSame)
gboxTtmR.Controls.Add(lblTbs)
gboxTtmR.Controls.Add(cmbTbs)
gboxTtmR.Controls.Add(lblTmm)
gboxTtmR.Controls.Add(lblTmsh)
gboxTtmR.Controls.Add(cmbTmsh)
gboxTtmR.Controls.Add(lblTspc)
gboxTtmR.Controls.Add(txbTspc)
gboxTtmR.Controls.Add(lblTbn)
gboxTtmR.Controls.Add(spnTbn)
gboxTtmR.Controls.Add(chbTmesh)

#---------------------------------------------------
#       LIGATURES GROUP
#---------------------------------------------------  

gbox = GroupBox()
gbox.Text = "Transveral Reinf."
gbox.Location = Point(240, 25)
gbox.Size = Size(380, 160)
gboxLigs = gbox

chbox = CheckBox()
chbox.Text = "Each Way (E/W)"
chbox.Width = 140
chbox.Location = Point(25, 25)
chbox.Name = "Same as Long"
chbSameL = chbox
chbSameL.CheckedChanged += on_control_update

radbtn = RadioButton()
radbtn.Text = "'U' Bars"
radbtn.Location = Point(25, 50)
radbtn.Width = 70
radbtn.Name = "Transv U bars"
rbtUbars = radbtn
rbtUbars.CheckedChanged += on_control_update

radbtn = RadioButton()
radbtn.Text = "Ligatures"
radbtn.Location = Point(25, 75)
radbtn.Width = 70
radbtn.Name = "Add Ligatures"
rbtLigs = radbtn
rbtLigs.CheckedChanged += on_control_update

gbox = GroupBox()
gbox.Text = "'U' Bars."
gbox.Location = Point(200, 15)
gbox.Size = Size(170, 130)
gboxULbars = gbox

radbtn = RadioButton()
radbtn.Text = "N"
radbtn.Location = Point(15, 25)
radbtn.Width = 40
radbtn.Name = "N"
rbtN = radbtn
rbtN.CheckedChanged += on_control_update

radbtn = RadioButton()
radbtn.Text = "R"
radbtn.Location = Point(80, 25)
radbtn.Width = 40
radbtn.Name = "R"
rbtR = radbtn
rbtN.CheckedChanged += on_control_update

label = Label()
label.Text = "Bar Size:"
label.Location = Point(15, 62)
label.Height = 15
label.Width = 60
lblLigs = label

cmbox = ComboBox()
cmbox.Location = Point(80, 60)
cmbox.Width = 60
cmbox.Name = "Lig Size"
cmbLigs = cmbox
cmbLigs.SelectedIndexChanged += on_control_update

label = Label()
label.Text = "Spacing:"
label.Location = Point(15, 92)
label.Height = 15
label.Width = 60
lblSpac = label

txb = TextBox()
txb.Text = "200"
txb.Location = Point(80, 90)
txb.Width = 50
txb.Name = "Lig Spacing"
txbSpac = txb
txbSpac.TextChanged += on_control_update

label = Label()
label.Text = "mm"
label.Location = Point(135, 92)
label.Height = 15
label.Width = 30
lblSmm = label

gboxULbars.Controls.Add(rbtN)
gboxULbars.Controls.Add(rbtR)
gboxULbars.Controls.Add(lblLigs)
gboxULbars.Controls.Add(cmbLigs)
gboxULbars.Controls.Add(lblSpac)
gboxULbars.Controls.Add(txbSpac)
gboxULbars.Controls.Add(lblSmm)

#---------------------------------------------------
#       REINFORCING TEXT GROUP
#---------------------------------------------------  

gbox = GroupBox()
gbox.Text = "STP_Reinforcement."
gbox.Size = Size(610, 60)
gbox.Location = Point(10, 350)
gboxStpReinf = gbox

chb = CheckBox()
chb.Text = "Automatic"
chb.Name = "AutoReinf"
chb.Width = 80
chb.Checked = False
chb.Location = Point(25,25)
chbAutoReinf = chb
chbAutoReinf.CheckedChanged += on_control_update

txb = TextBox()
txb.Name = "STP_Reinforcement"
txb.Width = 480
txb.ReadOnly = True
txb.Location = Point(110,25)
txbStpReinf = txb


gboxStpReinf.Controls.Add(chbAutoReinf)
gboxStpReinf.Controls.Add(txbStpReinf)
groupBox.Controls.Add(gboxStpReinf)

#----------------------------------------------------


gboxLigs.Controls.Add(gboxULbars)
gboxLigs.Controls.Add(chbSameL)
gboxLigs.Controls.Add(rbtUbars)
gboxLigs.Controls.Add(rbtLigs)

# Initialise the form control
cmbBbs.SelectedIndex = 2
cmbTbs.SelectedIndex = 2
cmbBmsh.SelectedIndex = 1
cmbTmsh.SelectedIndex = 1
chbSquare.Checked = True
rbtBbss.Checked = True
chbSame.Checked = True
chbTop.Checked = False
rbtN.Checked = True
chbSameL.Checked = True
chbAutoReinf.Checked = True
rbtUbars.Checked = True

groupBox.Controls.Add(gboxDims)
groupBox.Controls.Add(gboxBtmR)
groupBox.Controls.Add(gboxTtmR)
groupBox.Controls.Add(gboxLigs)

control_names = [] # Get parameters and index to use
control_index = [] # in the next control

# Loop through the controls in the GroupBox and get their names
for Groups in groupBox.Controls:
    for control in Groups.Controls:	
        if control.Name:
            control_names.append(control.Name)
        
# Output the GroupBox
OUT = groupBox, control_names, "Pad Footings"
