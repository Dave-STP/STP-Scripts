# Load the Python Standard and DesignScript Libraries
import clr
clr.AddReference('RevitAPI')
from Autodesk.Revit.DB import *
clr.AddReference('RevitServices')
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

clr.AddReference('System.Windows.Forms')
from System.Windows.Forms import MessageBox, MessageBoxButtons, MessageBoxIcon
doc = DocumentManager.Instance.CurrentDBDocument

# The inputs to this node will be stored as a list in the IN variables.
dataEnteringNode = IN
input_data = IN[0]
category_data = input_data[0]
family_data = input_data[1]
Revit_category = input_data[2]
# Place your code below this line

if Revit_category == "Structural Framing" or Revit_category == "Timber Beams":
	collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFraming)
	cat = "R"
elif Revit_category == "Structural Columns" or Revit_category == "Timber Columns":
	collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralColumns)
	cat = "R"
elif Revit_category == "Beam Footings":
    collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFraming)
    cat = "G"
else:
	collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFoundation)
	cat = "G"



Sched_params = ["STP Schedule", "STP_Size", "Type Mark", "STP Category", "STP_Concrete Grade/Fill","STP_Comment"]

newTypes = []
test = []
errors = []
fail = []

TransactionManager.Instance.EnsureInTransaction(doc)

for newNames in category_data:
    if Revit_category != "Timber Beams" or Revit_category != "Timber Columns":
        newName = newNames[2] + " - " + newNames[1]
    else:
        newName = newNames[1] + " - " + newNames[2]
    Fam = None
    not_found_families = []
    for item in collector:
        if isinstance(item, FamilySymbol) and item.Family.Name.replace("_C450L0","").replace("_C350L0","") == newNames[0]:
            Fam = item
            try:
                # Attempt to duplicate the type
                newType = Fam.Duplicate(newName)
                newTypes.append(newType)
            except Exception as e:
                # Append error message to the newTypes list if duplicate error occurs
                if "The name is already in use" in str(e):
                    errors.append(newName)
                    newTypes.append(None)
                    mssg  = "The following elements already exist in the project and will be ommited:"
                else:
                    errors.append(newName + "#failed")
                    newTypes.append(None)
            break
    if Fam == None:
        errors.append("- " + newNames[0])
        mssg  = "The following families were not found in the project. Please load at least one family in order to create new instances:"

instances = UnwrapElement(newTypes)

for x, instance in enumerate(instances):
    if instance:
        for j, parameter in enumerate(Sched_params):
            par = category_data[x][j] if j > 0 else cat
            try:
                instance.LookupParameter(parameter).Set(par)
                test.append(par + " - " + category_data[x][j])
            except:
                fail.append((parameter, category_data[x][j]))
                test.append(par + " X " + category_data[x][j])

if errors:
    mssg  = mssg + " \n \n" + "\n".join(errors)
    MessageBox.Show(mssg, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)

TransactionManager.Instance.TransactionTaskDone()

# Assign your output to the OUT variable.
OUT = instances