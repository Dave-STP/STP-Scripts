#-----------------------------------------------------------------------------------
#---------------------------PY-12_Load_ST.py----------------------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import os
import time
import math
import traceback
from datetime import datetime
from pyrevit import revit, forms, DB, script
from Autodesk.Revit.DB.Structure import TrussMemberType

from System import Action
from System.Windows import Visibility
from System.Windows.Controls import ListBoxItem
from System.Windows.Media import Brushes, SolidColorBrush, Colors

from System.Windows.Threading import DispatcherPriority
from Autodesk.Revit.DB import BuiltInParameter
from System.IO import Path, FileStream, FileMode, FileAccess, FileShare
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions\Structural Codes\STP_Functions"
sys.path.append(functions_path)
import Family_load_functions
from Family_load_functions import *

import STP_Tools_Functions
from STP_Tools_Functions import *

# Constants
#----------
doc = __revit__.ActiveUIDocument.Document
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
exceptions, fixed_code = exceptions()

# General_Variables
#------------------
final_report = ""
script_path = script.get_script_path()
form_1_path = os.path.join(script_path, "Select Truss Form.axml")
form_2_path = os.path.join(script_path, "Steel Trusses Form.axml")
Load_List = []
frames_to_search = []
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()
truss_type = 0
true_ = Visibility.Visible
false_ = Visibility.Collapsed
go_for_load = False

# Local Variables, Lists and Path
#------------------
family_types = "Truss"
form_1_name = "Select Truss Form.axml"
form_2_name = "Steel Trusses Form.axml"
schedules = ["R", "F", "M"]
res_param = proj_info.LookupParameter("Suburb")
res_type = True if res_param and res_param.HasValue else False

#------------------------------------------------------------------------------------
#----------- PRE-FORM CHECK AND LOAD ------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Preliminar Checks"

check_all_good = [os.path.exists(Lib_Path), os.path.exists(functions_path)]
if not all (check_all_good):
    forms.alert("Internal error [E00]. Please report it to STP Tools developer", "Error")
    sys.exit()

# Get Usage and Category List for Form
local_report, usage_List, categ_List, index_List, type_List = usage_categ_famtype_list(Lib_Path, family_types, stage)

final_report += local_report
# endregion

#-----------------------------------------------------------------------------------
#----------- GET EXISTING MEMBERS AND TYPE MARKS -----------------------------------
# region ---------------------------------------------------------------------------
stage = "Get Existing Type Mark List: "

collector = DB.FilteredElementCollector(doc)
instance_types = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

collector = DB.FilteredElementCollector(doc)
instance_types_truss = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_Truss)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

truss_families = []
for truss in instance_types_truss:
    truss_families.append(truss.Family.Name)

try:
    local_report, type_Marks_List, type_Marks_Grey = create_Type_Mark_List(instance_types_truss, stage)
    final_report += local_report
except Exception as e:
    final_report += u"\u274C Stage: " + stage + " Fail.\n" + str(e)

# endregion

#-----------------------------------------------------------------------------------
#-------------------------- SELECT WINDOW FORM -------------------------------------
#-----------------------------------------------------------------------------------

class TrussSelectForm(forms.WPFWindow):
    def __init__(self, form_1_name):
        forms.WPFWindow.__init__(self, form_1_name)
        self.initialize_ui()

        self.btnOp1.Click += self.selected_option
        self.btnOp2.Click += self.selected_option
        self.btnOp3.Click += self.selected_option
        self.btnOp4.Click += self.selected_option

    def initialize_ui(self):
        # Path to the image
        img_names = ["Opt1.jpg", "Opt2.jpg", "Opt3.jpg", "Opt4.jpg"]
        img_controls = [self.imgOp1, self.imgOp2, self.imgOp3, self.imgOp4]

        # Load the image WITHOUT locking the file
        for img_name, img_control in zip(img_names, img_controls):
            img_path = Path.Combine(script_path, img_name)
            stream = FileStream(img_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
            bitmap = BitmapImage()
            bitmap.BeginInit()
            bitmap.CacheOption = BitmapCacheOption.OnLoad
            bitmap.StreamSource = stream
            bitmap.EndInit()
            bitmap.Freeze()
            stream.Close()
            img_control.Source = bitmap

    def selected_option(self, sender, args):
        global truss_type
        n = sender.Name[-1]
        truss_type = int(n)
        
        if truss_type > 0:
            self.Hide()
            truss_form = TrussMainForm(form_2_path, self)
            truss_form.ShowDialog()

#-----------------------------------------------------------------------------------
#-------------------------- MAIN WINDOW FORM ---------------------------------------
#-----------------------------------------------------------------------------------
class TrussMainForm(forms.WPFWindow):
    def __init__(self, form_1_name, parent_form):
        forms.WPFWindow.__init__(self, form_1_name)
        self.initialize_ui()
        self.parent_form = parent_form
        self.btnBack.Click += self.go_back
        self.suffix = [""] * 4
        self.file_paths = [""] * 4
        self.fam_paths = [""] * 4
        self.all_family_data_list = [None] * 4
        self.new_items = []
        
        self.cmbSize2.Background = SolidColorBrush(Colors.LightBlue)

        self.all_groups = [self.gpo1, self.gpo2, self.gpo3, self.gpo4]
        self.all_famtyp = [self.cmbType1, self.cmbType2, self.cmbType3, self.cmbType4]
        self.all_sizes = [self.cmbSize1, self.cmbSize2, self.cmbSize3, self.cmbSize4]
        for gpo in self.all_groups:
            gpo.Visibility = false_

        # Hook up buttons
        #--------------------- General ----------------------------
        self.cmbUsage.SelectionChanged += self.on_usage_changed
        self.txbComments.GotFocus += self.on_text_box_focus
        self.txbComments.LostFocus += self.on_text_box_leave
        self.txbComments.TextChanged += self.on_comment_changed
        self.txbMark.GotFocus += self.on_text_box_focus
        #--------------------- Trusses ----------------------------
        self.cmbType1.SelectionChanged += self.on_type_changed
        self.cmbType2.SelectionChanged += self.on_type_changed
        self.cmbType3.SelectionChanged += self.on_type_changed
        self.cmbType4.SelectionChanged += self.on_type_changed
        self.cmbSize1.SelectionChanged += self.on_size_changed
        self.cmbSize2.SelectionChanged += self.on_size_changed
        self.cmbSize3.SelectionChanged += self.on_size_changed
        self.cmbSize4.SelectionChanged += self.on_size_changed
        #--------------------- Buttons ----------------------------
        self.btnImport.Click += self.on_add_item
        self.btnCancel.Click += self.close_form
        
        for n in range(truss_type):
            self.all_groups[n].Visibility = true_
            self.all_famtyp[n].ItemsSource = type_List
            self.all_famtyp[n].SelectedIndex = 0
        
        # Populate dropdowns and listboxes
        if truss_type > 0:
            self.gpo1.Header = "All Element Types"
        if truss_type > 1:
            self.gpo1.Header = "Top & Btm Chord Types"
            self.gpo2.Header = "End & Web Types"
        if truss_type > 2:
            self.gpo1.Header = "Top & Btm Chord Types"
            self.gpo2.Header = "End Types"
            self.gpo3.Header = "Web Types"
        if truss_type > 3:
            self.gpo1.Header = "Top & Btm Chord Types"
            self.gpo2.Header = "End Types"
            self.gpo3.Header = "Diagonal Types"
            self.gpo4.Header = "Vertical Types"

        self.cmbUsage.ItemsSource = usage_List
        self.cmbFamType.ItemsSource = truss_families


        # Activate Initial Conditions
        self.cmbUsage.SelectedItem = "FASCIA TRUSS"
        

    def initialize_ui(self):
        # Path to the image
        img_path = Path.Combine(script_path, "Opt" + str(truss_type) + ".jpg")

        # Load the image WITHOUT locking the file
        stream = FileStream(img_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
        bitmap = BitmapImage()
        bitmap.BeginInit()
        bitmap.CacheOption = BitmapCacheOption.OnLoad  # load into memory to release file lock
        bitmap.StreamSource = stream
        bitmap.EndInit()
        bitmap.Freeze()  # Makes it usable across threads (recommended)
        stream.Close()   # Close to release the file lock
 
        # Set image source (make sure x:Name="imgPier" in your XAML)
        self.ImgTruss.Source = bitmap        

    def on_usage_changed(self, sender, args):
        if self.cmbUsage.SelectedIndex >= 0:
            self.txbComments.Text = "ADD COMMENT HERE"
            
            self.usage_type = self.cmbUsage.SelectedItem
            if self.usage_type in exceptions:
                self.usage_sufix = fixed_code[exceptions.index(self.usage_type)]
            else:
                self.usage_sufix = ''.join([word[0] for word in self.usage_type.split()])
            
            # Change family type according to Usage
            if self.cmbUsage.SelectedItem == "WIND TRUSS":
                self.cmbFamType.SelectedIndex = 1
            else:
                self.cmbFamType.SelectedIndex = 0
                        
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks

    def on_type_changed(self, sender, args):
        index = int(sender.Name[-1]) - 1
        profile = self.all_famtyp[index].SelectedItem
        path_txt_file = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Structural_Framing", profile + ".txt")
        path_rfa_file = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Structural_Framing", profile + ".rfa")
        size_list, family_data_list = profile_sizes(path_txt_file) # size_list, all_data_list
        self.all_sizes[index].ItemsSource = size_list if size_list[-1] != "" else size_list[:-1]
        self.all_sizes[index].SelectedIndex = 0
        self.file_paths[index] = path_txt_file
        self.fam_paths[index] = path_rfa_file
        self.all_family_data_list[index] = family_data_list
 
    def on_size_changed(self, sender, args):
        size1 = self.all_sizes[0].SelectedItem
        size2 = self.all_sizes[1].SelectedItem
        size3 = self.all_sizes[2].SelectedItem
        size4 = self.all_sizes[3].SelectedItem

        self.lblTopChord.Text = size1 if size1 != "Select Size" else "TOP CHORD"
        self.lblBtmChord.Text = size1 if size1 != "Select Size" else "BTM CHORD"
        if truss_type == 1:
            self.lblVert.Text = size1 if size1 != "Select Size" else "VERTICAL"
            self.lblDiag1.Text = size1 if size1 != "Select Size" else "DIAGONAL"
            self.lblDiag2.Text = size1 if size1 != "Select Size" else "DIAGONAL"
            self.lblEnd1.Text = size1 if size1 != "Select Size" else "END"
            self.lblEnd2.Text = size1 if size1 != "Select Size" else "END"
            self.suffix[0] = "ALL"
        elif truss_type == 2:
            self.lblVert.Text = size2 if size2 != "Select Size" else "VERTICAL"
            self.lblDiag1.Text = size2 if size2 != "Select Size" else "DIAGONAL"
            self.lblDiag2.Text = size2 if size2 != "Select Size" else "DIAGONAL"
            self.lblEnd1.Text = size2 if size2 != "Select Size" else "END"
            self.lblEnd2.Text = size2 if size2 != "Select Size" else "END"
            self.suffix[0] = "CHORDS"; self.suffix[1] = "LACINGS"
        elif truss_type == 3:
            self.lblVert.Text = size3 if size3 != "Select Size" else "VERTICAL"
            self.lblDiag1.Text = size3 if size3 != "Select Size" else "DIAGONAL"
            self.lblDiag2.Text = size3 if size3 != "Select Size" else "DIAGONAL"
            self.lblEnd1.Text = size2 if size2 != "Select Size" else "END"
            self.lblEnd2.Text = size2 if size2 != "Select Size" else "END"
            self.suffix[0] = "CHORDS"; self.suffix[1] = "ENDS"; self.suffix[2] = "LACINGS"
        elif truss_type == 4:
            self.lblVert.Text = size4 if size4 != "Select Size" else "VERTICAL"
            self.lblDiag1.Text = size3 if size3 != "Select Size" else "DIAGONAL"
            self.lblDiag2.Text = size3 if size3 != "Select Size" else "DIAGONAL"
            self.lblEnd1.Text = size2 if size2 != "Select Size" else "END"
            self.lblEnd2.Text = size2 if size2 != "Select Size" else "END"
            self.suffix[0] = "CHORDS"; self.suffix[1] = "ENDS"; self.suffix[2] = "DIAG"; self.suffix[3] = "VERT"
        
    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)

    def on_text_box_leave(self, sender, args):
        sender.Text = sender.Text.upper()
        if sender == self.txbComments and sender.Text == "":
            sender.Text = "ADD COMMENT HERE"

    def on_comment_changed(self, sender, args):
        if self.txbComments.Text == "ADD COMMENT HERE":
            self.txbComments.Foreground = Brushes.LightGray
        else:
            self.txbComments.Foreground = Brushes.Black

    def go_back(self, sender, args):
        self.Close()
        self.parent_form.ShowDialog()

    def close_form(self, sender, args):
        self.Close()

    def on_add_item(self, sender, args):
        global Load_List
        global truss_type
        global go_for_load
        global frames_to_search
        all_selected = True
        no_selected = []
        self.new_items = []
        
        for i in range(truss_type):
            selected_index = self.all_sizes[i].SelectedIndex
            if selected_index > 0:
                selected_size = self.all_sizes[i].SelectedItem
                selected_type_mark = self.txbMark.Text
                new_line = []
                fam_name = self.all_famtyp[i].SelectedItem
                new_name = selected_size + "_" + selected_type_mark + " (" + self.suffix[i] + ")"
                self.new_items.append(new_name)
                fam_path = self.fam_paths[i]
                fam_type = selected_size
                family_block = [fam_name, new_name, fam_path, fam_type]
                new_line.append(family_block)

                general_block = []
                par_schedule = (("STP Schedule", "T"))
                par_category = (("STP Category", selected_type_mark))
                par_stp_size = (("STP_Size", selected_size))
                par_stp_com1 = (("STP_Comment", self.suffix[i]))
                par_stp_com2 = (("Type Comments", self.suffix[i]))
            
                general_block = [par_schedule, par_category, par_stp_size, par_stp_com1, par_stp_com2]
                new_line.append(general_block)

                params = []
                for par, val in zip(self.all_family_data_list[i][0], self.all_family_data_list[i][selected_index + 1]):
                    if par not in [p[0] for p in general_block] and par != "Select Size":
                        params.append((par, val))

                new_line.append(params)
                Load_List.append(new_line)
            else:
                no_selected.append(self.all_groups[i].Header)
                all_selected = False
            
        if all_selected == False:
            mssg = "One of the following Types have not been selected. Please select element size.\n\n"
            for miss in no_selected:
                mssg += "- " + miss + "\n"
            forms.alert(mssg, "Error")
        else:
            truss_line = []
            fam_name = self.cmbFamType.SelectedItem
            items_in_truss = "VARIES"
            if truss_type == 1:
                items_in_truss = self.cmbSize1.SelectedItem
            elif truss_type == 2:
                items_in_truss = self.cmbSize1.SelectedItem + "/" + self.cmbSize2.SelectedItem
            new_name = selected_type_mark + "_" + items_in_truss
            self.new_items.insert(0, new_name)
            fam_path = ""
            fam_type = ""
            family_block = [fam_name, new_name, fam_path, fam_type]
            truss_line.append(family_block)

            general_block = []
            par_typ_mark = (("Type Mark",selected_type_mark))
            general_block = [par_typ_mark]
            truss_line.append(general_block)

            params = []
            truss_line.append(params)
            Load_List.append(truss_line)
            frames_to_search = self.new_items
            go_for_load = True
            self.Close()
            

# Show the form
select_form = TrussSelectForm(form_1_path)
select_form.ShowDialog()

#-----------------------------------------------------------------------------------
#-------------COPY FAMILY INSTANCE AND ADD PARAMETERS-------------------------------
# region ---------------------------------------------------------------------------
stage = "Load Family and Parameters"
if go_for_load and Load_List:
    try:
        local_state, local_report = load_families_and_parameters(doc, Load_List)
    except Exception as e:
        local_report = str(e)
    final_report += local_report

else:
    sys.exit()

# endregion

#-----------------------------------------------------------------------------------
#-------------MODIFY TRUSS ATTRIBUTES ----------------------------------------------
# region ---------------------------------------------------------------------------
stage = "Modify Truss"
collector = DB.FilteredElementCollector(doc)
instance_types = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^


collector = DB.FilteredElementCollector(doc)
instance_types_truss = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_Truss)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

target_frames = [None] * 4
for item in instance_types:
    param = item.LookupParameter("Type Name")
    if param and param.AsString() in frames_to_search:
        n = frames_to_search.index(param.AsString())
        target_frames[n-1] = item

truss = None
for item in instance_types_truss:
    param = item.LookupParameter("Type Name")
    if param and param.AsString() in frames_to_search:
        truss = item


if truss:
    top_chord = BuiltInParameter.TRUSS_FAMILY_TOP_CHORD_STRUCTURAL_TYPES_PARAM
    btm_chord = BuiltInParameter.TRUSS_FAMILY_BOTTOM_CHORD_STRUCTURAL_TYPES_PARAM
    dia_chord = BuiltInParameter.TRUSS_FAMILY_DIAG_WEB_STRUCTURAL_TYPES_PARAM
    ver_chord = BuiltInParameter.TRUSS_FAMILY_VERT_WEB_STRUCTURAL_TYPES_PARAM

    top_rotation = BuiltInParameter.TRUSS_FAMILY_TOP_CHORD_ANGLE_PARAM
    btm_rotation = BuiltInParameter.TRUSS_FAMILY_BOTTOM_CHORD_ANGLE_PARAM
    dia_rotation = BuiltInParameter.TRUSS_FAMILY_DIAG_WEB_ANGLE_PARAM
    ver_rotation = BuiltInParameter.TRUSS_FAMILY_VERT_WEB_ANGLE_PARAM

    with revit.Transaction("Set Truss Members"):
        if target_frames[0]:
            new_type_id = target_frames[0].Id
            param = truss.get_Parameter(top_chord)
            if param:
                param.Set(new_type_id)
            param = truss.get_Parameter(btm_chord)
            if param:
                param.Set(new_type_id)
            param = truss.get_Parameter(top_rotation)
            if param:
                param.Set(math.radians(-90))
            param = truss.get_Parameter(btm_rotation)
            if param:
                param.Set(math.radians(90))
            param = truss.get_Parameter(dia_rotation)
            if param:
                param.Set(math.radians(90))
            param = truss.get_Parameter(ver_rotation)
            if param:
                param.Set(math.radians(90))
        

        if truss_type == 1 and target_frames[0]:
            new_type_id = target_frames[0].Id
            param = truss.get_Parameter(dia_chord)
            if param:
                param.Set(new_type_id)
            param = truss.get_Parameter(ver_chord)
            if param:
                param.Set(new_type_id)

        elif truss_type == 2 and target_frames[0] and target_frames[1]:
            new_type_id = target_frames[1].Id
            param = truss.get_Parameter(dia_chord)
            if param:
                param.Set(new_type_id)
            param = truss.get_Parameter(ver_chord)
            if param:
                param.Set(new_type_id)
        
        elif truss_type == 3 and target_frames[0] and target_frames[1] and target_frames[2]:
            new_type_id = target_frames[2].Id
            param = truss.get_Parameter(dia_chord)
            if param:
                param.Set(new_type_id)
            param = truss.get_Parameter(ver_chord)
            if param:
                param.Set(new_type_id)

        elif truss_type == 4 and target_frames[0] and target_frames[1] and target_frames[2] and target_frames[3]:
            new_type_id = target_frames[2].Id
            param = truss.get_Parameter(dia_chord)
            if param:
                param.Set(new_type_id)
            
            new_type_id = target_frames[3].Id
            param = truss.get_Parameter(ver_chord)
            if param:
                param.Set(new_type_id)

        if truss_type > 2:
            message = (
                "End lacing members were not modeled.\n\n"
                "Revit does not allow independent modeling of end lacing elements.\n"
                "To include them in the schedule, please ensure that at least one end element "
                "is modeled properly."
            )

            forms.alert(message, title="Warning")

# endregion
#print(final_report)

#--------------------------------------------------------------------
#----------- REPORT SAVING TIME TO DATA BASE ------------------------
# region ------------------------------------------------------------
stage = "Tracking Data"
file_path = os.path.join(Lib_Path, "STP Tracking", "Data.txt")
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if os.path.exists(file_path):
    final_report += fill_tracking_data(file_path, p_Numb, user_name, "Load Truss Members", "4", start_time, end_time, "1", stage)

# endregion


#print(final_report)