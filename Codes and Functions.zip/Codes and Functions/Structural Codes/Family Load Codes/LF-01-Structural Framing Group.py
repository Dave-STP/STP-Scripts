import sys
import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *

clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from System.Drawing import Point, Size
from System.Windows.Forms import Application, Form, Label, TextBox, NumericUpDown, CheckBox, GroupBox

from System import Decimal

# Create a group box
groupBox = GroupBox()
groupBox.Text = "PURLIN, GIRTS AND JOISTS ADDITIONAL INFO."
groupBox.Size = Size(400, 130)

#---------------------------------------------------
#       ADDITIONAL WINDOW FOR PURLIN PARAMETERS
#---------------------------------------------------

label = Label()
label.Text = "SPACING:"
label.Location = Point(150, 20)
label.Height = 15
label.Width = 150
lblSpc1 = label

label = Label()
label.Text = "@ "
label.Location = Point(150, 43)
label.Height = 15
label.Width = 20
lblSpc2 = label

txb = TextBox()
txb.Location = Point(180, 40)
txb.Width = 60
txb.Text = "900"
txb.Name = "Spacing"
txbSpac = txb

label = Label()
label.Text = "mm"
label.Location = Point(240, 43)
label.Height = 15
label.Width = 30
lblSpc3 = label

label = Label()
label.Text = "BRIDGING ROWS:"
label.Location = Point(150, 70)
label.Height = 15
label.Width = 150
lblRow = label

nmr = NumericUpDown()
nmr.Location = Point(150, 90)
nmr.Width = 100
nmr.TextAlign = 0
nmr.Minimum = Decimal(0)  # Set the minimum value
nmr.Maximum = Decimal(6)
nmr.Value = Decimal(2)
nmr.Name = "Rows"
UpDown = nmr

chb = CheckBox()
chb.Text = "(H.D. GALV.)"
chb.Location = Point(10, 20)
chb.Name = "HD_Galv"
chbMat = chb

chb = CheckBox()
chb.Text = "ON FLAT"
chb.Location = Point(10, 50)
chb.Name = "On_Flat"
chbSide = chb

chb = CheckBox()
chb.Text = "."
chb.Name = "Purlin notes"
chb.Location = Point (10,10)
chb.Visible = False
chb.Checked = False
chbPurlinNotes = chb

groupBox.Controls.Add(lblSpc1)
groupBox.Controls.Add(lblSpc2)
groupBox.Controls.Add(lblSpc3)
groupBox.Controls.Add(txbSpac)
groupBox.Controls.Add(lblRow)
groupBox.Controls.Add(UpDown)
groupBox.Controls.Add(chbMat)
groupBox.Controls.Add(chbSide)
groupBox.Controls.Add(chbPurlinNotes)

control_names = [] # Get parameters and index to use
control_index = [] # in the next control

# Loop through the controls in the GroupBox and get their names
for control in groupBox.Controls:
    if control.Name:
        control_names.append(control.Name)
        
# Output the GroupBox
OUT = groupBox, control_names, "Structural Framing"
