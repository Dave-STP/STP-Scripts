# Load the Python Standard and DesignScript Libraries
import sys
import clr

clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *

# The inputs to this node will be stored as a list in the IN variables.
Lib_Path = IN[0][0]
file_path = Lib_Path + r"\STP_Codes\STP_Functions\Structural Member Types.txt"

particular_gruop_pass_only = IN[1]
Revit_Category = particular_gruop_pass_only[2]

revit_cat = Revit_Category + " Types"
structural_usages = Revit_Category + " Usages"

# Initialize a dictionary to hold the sections
sections = {
    'framing_types': [],
    'structural_usages': []
}

# ----------------------------------------------------------
# ----Open the txt file to bring types and usages-----------
# ----------------------------------------------------------

try:
    with open(file_path, 'r') as file:
        lines = file.readlines()

        # Find the indices of the markers
        start_framing_index = next((i for i, line in enumerate(lines) if line.strip() == revit_cat), -1)
        end_framing_index = next((i for i, line in enumerate(lines) if line.strip() == revit_cat + " End"), -1)
        start_usages_index = next((i for i, line in enumerate(lines) if line.strip() == structural_usages), -1)
        end_usages_index = next((i for i, line in enumerate(lines) if line.strip() == structural_usages + " End"), -1)

        # Check if indices are valid before slicing
        if start_framing_index != -1 and end_framing_index != -1:
            sections['framing_types'] = [line.strip() for line in lines[start_framing_index + 1:end_framing_index]]
        
        if start_usages_index != -1 and end_usages_index != -1:
            sections['structural_usages'] = [line.strip() for line in lines[start_usages_index + 1:end_usages_index]]


except:
    pass


test = []
default_index = []
for k, sect in enumerate(sections['structural_usages']):
    n = sect.find("-#")
    if n > 0:
        fam_name = sect[n+2:]
        index = sections['framing_types'].index(fam_name)
        default_index.append(index)
        sections['structural_usages'][k] = sect[:n]
    else:
        default_index.append(0)
    
# Assign your output to the OUT variable.
OUT = particular_gruop_pass_only, sections['framing_types'], sections['structural_usages'], default_index
