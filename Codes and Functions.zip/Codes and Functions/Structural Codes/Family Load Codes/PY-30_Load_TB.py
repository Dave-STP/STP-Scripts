#-----------------------------------------------------------------------------------
#---------------------------PY-30_Load_TB.py----------------------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import os
import time
import traceback
from datetime import datetime
from pyrevit import forms, DB, script

from System import Action
from System.Windows import Visibility
from System.Windows.Controls import ListBoxItem
from System.Windows.Media import Brushes

from System.Windows.Threading import DispatcherPriority
from Autodesk.Revit.DB import BuiltInParameter
from System.IO import Path, FileStream, FileMode, FileAccess, FileShare
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions\Structural Codes\STP_Functions"
sys.path.append(functions_path)
import Family_load_functions
from Family_load_functions import *

import STP_Tools_Functions
from STP_Tools_Functions import *

# Constants
#----------
doc = __revit__.ActiveUIDocument.Document
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
exceptions, fixed_code = exceptions()

# General_Variables
#------------------
final_report = ""
script_path = script.get_script_path()
Load_List = []
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()

# Local Variables, Lists and Path
#------------------
family_types = "Timber Beams"
xaml_file_name = "Timber Beams Form.axml"
schedules = ["R", "F", "M"]
res_param = proj_info.LookupParameter("Suburb")
res_type = True if res_param and res_param.HasValue else False

if res_type:
    fam_name = "STP_Timber_HW_UNSEASONED"
    fam_type = "100x50 F11"
else:
    fam_name = "STP_Timber_MGP12"
    fam_type = "90x35 MGP12"



sched_types = ["WALL FRAMING", "FLOOR BEAM", "ROOF BEAM"]
roof_exceptions = ["PURLIN", "OUTRIGGER"]
floor_exceptions = ["RAFTER", "BEAM", "BATTEN", "JOIST"]
aux_reo = ""



#------------------------------------------------------------------------------------
#----------- PRE-FORM CHECK AND LOAD ------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Preliminar Checks"

# Check for last version
local_report = check_last_version(Lib_Path, "STP Structural", user_name)

check_all_good = [os.path.exists(Lib_Path), os.path.exists(functions_path)]
if not all (check_all_good):
    forms.alert("Internal error [E00]. Please report it to STP Tools developer", "Error")
    sys.exit()

# Get Usage and Category List for Form
local_report, usage_List, categ_List, index_List, type_List = usage_categ_famtype_list(Lib_Path, family_types, stage)
final_report += local_report

# endregion

#-----------------------------------------------------------------------------------
#----------- GET EXISTING MEMBERS AND TYPE MARKS -----------------------------------
# region ---------------------------------------------------------------------------
stage = "Get Existing Type Mark List: "

collector = DB.FilteredElementCollector(doc)
instance_types = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

try:
    local_report, type_Marks_List, type_Marks_Grey = create_Type_Mark_List(instance_types, stage)
    final_report += local_report
except Exception as e:
    final_report += u"\u274C Stage: " + stage + " Fail.\n" + str(e)

# endregion


#-----------------------------------------------------------------------------------
#-------------------------- MAIN WINDOW FORM ---------------------------------------
#-----------------------------------------------------------------------------------

class TimberBeamsForm(forms.WPFWindow):
    def __init__(self, xaml_file_path):
        super(TimberBeamsForm, self).__init__(xaml_file_path)
        #self.initialize_ui()
        self.next_type_mark = ""
        self.usage_type = ""
        self.usage_sufix = ""
        self.path_txt_file = ""
        self.path_rfa_file = ""
        self.check_string = ""
        global Load_List
        self.go_for_load = False

        # Hook up buttons
        #--------------------- General ----------------------------
        self.cmbUsage.SelectionChanged += self.on_usage_changed
        self.txbComments.GotFocus += self.on_text_box_focus
        self.txbComments.TextChanged += self.on_comment_changed
        self.txbCategory.GotFocus += self.on_text_box_focus        
        #-------------------- Geometry ----------------------------
        self.txbWidth.GotFocus += self.on_text_box_focus
        self.txbWidth.LostFocus += self.on_text_box_leave
        self.txbDepth.GotFocus += self.on_text_box_focus
        self.txbDepth.LostFocus += self.on_text_box_leave
        self.txbSpacing.LostFocus += self.on_text_box_leave
         #-------------------- Buttons -----------------------------
        self.btnAdd.Click += self.on_add_item
        self.btnRemove.Click += self.remove_item
        self.btnLoad.Click += self.load_families
        self.btnCancel.Click += self.close_form       

        # Populate dropdowns and listboxes
        self.cmbUsage.ItemsSource = usage_List
        self.cmbType.ItemsSource = type_List
        self.cmbSched.ItemsSource = sched_types

        # Activate Initial Conditions
        self.cmbUsage.SelectedItem = "LINTEL"
        self.txbWidth.Text = "50"
        self.txbDepth.Text = "200"
        self.rdoSing.IsChecked = True
        self.txbSpacing.Text = "0"

    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)

    def on_text_box_leave(self, sender, args):
        if sender.Text == "":
            sender.Text = "10"
            if sender == self.txbSpacing:
                sender.Text = "0"

    def on_comment_changed(self, sender, args):
        if self.txbComments.Text == "ADD COMMENT HERE":
            self.txbComments.Foreground = Brushes.LightGray
        else:
            self.txbComments.Foreground = Brushes.Black

    def check_is_last_item(self):
        check = (
            self.cmbUsage.SelectedItem + self.cmbType.SelectedItem + self.cmbSched.SelectedItem + 
            self.txbMark.Text + self.txbCategory.Text + self.txbComments.Text + 
            self.txbWidth.Text + self.txbDepth.Text + self.txbSpacing.Text)
        check += ("y" if self.chbH3.IsChecked else "n") + ("y" if self.rdoSing.IsChecked else "n")
        check += ("y" if self.rdoDble.IsChecked else "n") + ("y" if self.rdoTple.IsChecked else "n")
        return check

    def on_usage_changed(self, sender, args):
        if self.cmbUsage.SelectedIndex >= 0:
            self.cmbType.SelectedIndex = index_List[self.cmbUsage.SelectedIndex]
            if "ROOF" in self.cmbUsage.SelectedItem or self.cmbUsage.SelectedItem in roof_exceptions:
                self.cmbSched.SelectedIndex = 2
            elif "FLOOR" in self.cmbUsage.SelectedItem or self.cmbUsage.SelectedItem in floor_exceptions:
                self.cmbSched.SelectedIndex = 1
            elif self.cmbSched.SelectedIndex < 0:
                self.cmbSched.SelectedIndex = 0

            self.txbCategory.Text = categ_List[self.cmbUsage.SelectedIndex]
            self.txbComments.Text = "ADD COMMENT HERE"
            
            self.usage_type = self.cmbUsage.SelectedItem
            if self.usage_type in exceptions:
                self.usage_sufix = fixed_code[exceptions.index(self.usage_type)]
            else:
                self.usage_sufix = ''.join([word[0] for word in self.usage_type.split()])
            
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks

    def on_add_item(self, sender, args):
        global Load_List
        family_block = []
        general_block = []
        params_block = []
        if all([float(self.txbWidth.Text) > 20, float(self.txbDepth.Text) > 20]):

            cant = ""
            if self.rdoDble.IsChecked:
                cant = "2/"
            elif self.rdoTple.IsChecked:
                cant = "3/"

            selected_size = cant + self.txbDepth.Text + "x" + self.txbWidth.Text
            selected_type_mark = self.txbMark.Text
            selected_timber = self.cmbType.SelectedItem

            new_name = (selected_type_mark + " - " + selected_size + " " + selected_timber)
            spacing = self.txbSpacing.Text
            new_name += (" @" + spacing) if spacing != "0" else ""
            new_name += " (H3)" if self.chbH3.IsChecked else ""
            
            self.lsbNewItems.Items.Add(new_name)

            new_line = []

            fam_path = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Structural_Framing", fam_name + ".rfa")
            family_block = [fam_name, new_name, fam_path, fam_type]
            new_line.append(family_block)

            stp_comment = self.cmbUsage.SelectedItem
            stp_comment += ("S @" + spacing + "CRS.") if spacing != "0" else "."
            stp_comment += " " + self.txbComments.Text if self.txbComments.Text != "ADD COMMENT HERE" else ""
            
            stp_size = (selected_size + " " + selected_timber)
            stp_size += " (H3 TREATED)" if self.chbH3.IsChecked else ""
            
            if "ROOF" in self.cmbSched.SelectedItem:
                par_schedule = (("STP Schedule", "R"))
            elif "FLOOR" in self.cmbSched.SelectedItem:
                par_schedule = (("STP Schedule", "F"))
            else:
                par_schedule = (("STP Schedule", "M"))
            par_category = (("STP Category", self.txbCategory.Text))
            par_stp_size = (("STP_Size", stp_size))
            par_stp_comm = (("STP_Comment", stp_comment))
            par_res_comm = (("Type Comments", stp_comment))
            par_typ_mark = (("Type Mark",selected_type_mark))

            general_block = [par_schedule, par_category, par_stp_size, par_stp_comm, par_res_comm,par_typ_mark]
            new_line.append(general_block)

            par_w = (("b", self.txbWidth.Text))
            par_d = (("d", self.txbDepth.Text))

            params_block = [par_w, par_d]
            new_line.append(params_block)
            
            Load_List.append(new_line)

            # Update Type Mark List Box
            type_mark_list_name = selected_type_mark + " - " + selected_size + " " + selected_timber
            type_Marks_List.append((selected_type_mark, type_mark_list_name))
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks
            self.check_string = self.check_is_last_item()

        else:
            forms.alert(
                "Error: Check Width and Depth Parameter.",
                title="Warning",
                warn_icon=True
            )

    def remove_item(self, sender, args):
        global Load_List
        selected_index = self.lsbNewItems.SelectedIndex
        if selected_index >= 0:
            self.lsbNewItems.Items.RemoveAt(selected_index)
            del Load_List[selected_index]
            del type_Marks_List[selected_index + len(type_Marks_Grey)]

        # Update Type Mark List Box
        filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
        self.txbMark.Text = self.next_type_mark
        self.lsbMarks.ItemsSource = filtered_type_marks
        
    def close_form(self, sender, args):
        self.Close()

    def load_families(self, sender, args):
        final_check = self.check_is_last_item()
        if final_check == self.check_string: # Check if there are modifications in elements before load
            self.go_for_load = True
            self.Close()
        else:
            result = forms.alert(
                "The last item hasn't been added to the list. Do you want to continue loading without it?",
                title="Confirm Add",
                yes=True,
                no=True
            )
            if result:
                self.go_for_load = True
                self.Close()

# Show the form
form = TimberBeamsForm(xaml_file_name)
form.ShowDialog()
    
#-----------------------------------------------------------------------------------
#-------------COPY FAMILY INSTANCE AND ADD PARAMETERS-------------------------------
# region ---------------------------------------------------------------------------
stage = "Load Family and Parameters"
if form.go_for_load and Load_List:
    try:
        local_state, local_report = load_families_and_parameters(doc, Load_List)
    except Exception as e:
        local_report = str(e)
    final_report += local_report
else:
    sys.exit()

# endregion

#--------------------------------------------------------------------
#----------- REPORT SAVING TIME TO DATA BASE ------------------------
# region ------------------------------------------------------------
stage = "Tracking Data"
file_path = os.path.join(Lib_Path, "STP Tracking", "Data.txt")
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if os.path.exists(file_path):
    final_report += fill_tracking_data(file_path, p_Numb, user_name, "Load Timber Beams", "4", start_time, end_time, str(len(Load_List)), stage)

# endregion


#print(final_report)