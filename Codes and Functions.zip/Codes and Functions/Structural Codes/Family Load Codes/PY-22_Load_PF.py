#-----------------------------------------------------------------------------------
#-------------------------- PY-22_Load_Pad Footings.py -----------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import os
import time
import traceback
from datetime import datetime
from pyrevit import forms, DB, script

from System import Action
from System.Windows import Visibility
from System.Windows.Controls import ListBoxItem
from System.Windows.Media import Brushes

from System.Windows.Threading import DispatcherPriority
from Autodesk.Revit.DB import BuiltInParameter
from System.IO import Path, FileStream, FileMode, FileAccess, FileShare
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions\Structural Codes\STP_Functions"
sys.path.append(functions_path)
import Family_load_functions
from Family_load_functions import *

import STP_Tools_Functions
from STP_Tools_Functions import *

# Constants
#----------
doc = __revit__.ActiveUIDocument.Document
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
exceptions, fixed_code = exceptions()

# General_Variables
#------------------
final_report = ""
script_path = script.get_script_path()
Load_List = []
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()
aux_reo = ""

# Local Variables (General, Resid, McDonalds)
#------------------
family_types = "Pad Footings"
xaml_file_name = "Pad Footings Form.axml"
BP_list = ["Pad Footings", "STP_Pad Footing"]
N_list = ["N10", "N12", "N16", "N20", "N22", "N24"]
R_list = ["R6", "R8", "R10"]
M_list = ["SL72", "SL82", "SL92", "SL102"]

fam_type = ""
fam_name = "STP_Pad Footing"

res_param = proj_info.LookupParameter("Suburb")
res_type = True if res_param and res_param.HasValue else False

#------------------------------------------------------------------------------------
#----------- PRE-FORM CHECK AND LOAD ------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Preliminar Checks"

# Check for last version
local_report = check_last_version(Lib_Path, "STP Structural", user_name)

check_all_good = [os.path.exists(Lib_Path), os.path.exists(functions_path)]
if not all (check_all_good):
    forms.alert("Internal error [E00]. Please report it to STP Tools developer", "Error")
    sys.exit()

# Get Usage and Category List for Form
local_report, usage_List, categ_List, index_List, type_List = usage_categ_famtype_list(Lib_Path, family_types, stage)
final_report += local_report

# endregion

#-----------------------------------------------------------------------------------
#----------- GET EXISTING MEMBERS AND TYPE MARKS -----------------------------------
# region ---------------------------------------------------------------------------
stage = "Get Existing Type Mark List: "

collector = DB.FilteredElementCollector(doc)
instance_types = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFoundation)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^


try:
    local_report, type_Marks_List, type_Marks_Grey = create_Type_Mark_List(instance_types, stage)
    final_report += local_report
except Exception as e:
    final_report += u"\u274C Stage: " + stage + " Fail.\n" + str(e)


# endregion

#-----------------------------------------------------------------------------------
#-------------------------- MAIN WINDOW FORM ---------------------------------------
#-----------------------------------------------------------------------------------
class PadFootinForm(forms.WPFWindow):
    def __init__(self, xaml_file_path):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.initialize_ui()
        self.next_type_mark = ""
        self.usage_type = ""
        self.usage_sufix = ""
        self.path_txt_file = ""
        self.path_rfa_file = ""
        self.check_string = ""
        self.go_for_load = False
        global Load_List
        
# Hook up buttons
        #--------------------- General ----------------------------
        self.cmbUsage.SelectionChanged += self.on_usage_changed
        self.txbComments.GotFocus += self.on_text_box_focus
        self.txbComments.TextChanged += self.on_comment_changed
        self.txbMark.GotFocus += self.on_text_box_focus
        self.txbCategory.GotFocus += self.on_text_box_focus
        #-------------------- Geometry ----------------------------
        self.txbWidth.GotFocus += self.on_text_box_focus
        self.txbWidth.LostFocus += self.on_text_box_leave
        self.chbSqr.Click += self.on_square_changed
        self.txbLength.GotFocus += self.on_text_box_focus
        self.txbLength.LostFocus += self.on_text_box_leave
        self.txbDepth.GotFocus += self.on_text_box_focus
        self.txbDepth.LostFocus += self.on_text_box_leave
        self.txbCover.GotFocus += self.on_text_box_focus
        self.txbCover.LostFocus += self.on_text_box_leave
        self.chbMassConc.Click += self.on_reo_conditions_changed
        #-------------------- Bottom ------------------------------
        self.chbBtmReo.Click += self.on_reo_conditions_changed
        self.chbBtmReo.Click += self.on_reo_type_changed
        self.rdoBtmBarsN.Click += self.on_reo_conditions_changed
        self.rdoBtmBarsS.Click += self.on_reo_conditions_changed
        self.rdoBtmMesh.Click += self.on_reo_conditions_changed
        self.cmbBtmReo.SelectionChanged += self.on_reo_type_changed
        self.spnBtm1.Click += self.on_reo_type_changed
        self.spnBtm2.Click += self.on_reo_type_changed
        self.txbBtmSpacing.TextChanged += self.on_reo_type_changed
        self.cmbBtmMesh.SelectionChanged += self.on_reo_type_changed
        #---------------------- Top -------------------------------
        self.chbTopReo.Click += self.on_reo_conditions_changed
        self.chbTopReo.Click += self.on_reo_type_changed
        self.rdoTopBarsN.Click += self.on_reo_conditions_changed
        self.rdoTopBarsS.Click += self.on_reo_conditions_changed
        self.rdoTopMesh.Click += self.on_reo_conditions_changed
        self.cmbTopReo.SelectionChanged += self.on_reo_type_changed
        self.spnTop1.Click += self.on_reo_type_changed
        self.spnTop2.Click += self.on_reo_type_changed
        self.txbTopSpacing.TextChanged += self.on_reo_type_changed
        self.cmbTopMesh.SelectionChanged += self.on_reo_type_changed
        #-------------------- Transversl --------------------------
        self.chbLigs.Click += self.on_reo_conditions_changed
        self.chbLigs.Click += self.on_lig_type_changed
        self.chbEw.Click += self.on_reo_conditions_changed
        self.rdoUbar.Click += self.on_reo_type_changed
        self.rdoLigs.Click += self.on_reo_type_changed
        self.rdoLigR.Click += self.on_lig_type_changed
        self.rdoLigN.Click += self.on_lig_type_changed
        self.cmbLigSize.SelectionChanged += self.on_reo_type_changed
        self.txbLigSpacing.TextChanged += self.on_reo_conditions_changed
        #-------------------- Auto-Reinf --------------------------
        self.chbAutoReo.Click += self.on_auto_reinf_changed
        #-------------------- Buttons -----------------------------
        self.btnAdd.Click += self.on_add_item
        self.btnRemove.Click += self.remove_item
        self.btnLoad.Click += self.load_families
        self.btnCancel.Click += self.close_form

        # Populate dropdowns and listboxes
        self.cmbUsage.ItemsSource = usage_List
        self.cmbConc.ItemsSource = ["N20", "N25", "N32", "N40"]

        self.cmbBtmReo.ItemsSource = N_list
        self.cmbTopReo.ItemsSource = N_list
        
        self.cmbBtmMesh.ItemsSource = M_list
        self.cmbTopMesh.ItemsSource = M_list
        self.cmbLigSize.ItemsSource = N_list
        self.chbAutoReo.IsChecked = True
        
        # Activate Initial Conditions
        self.txbWidth.Text = self.txbLength.Text = "1000"
        self.txbDepth.Text = "500"
        self.txbCover.Text = "50"
        self.cmbBtmReo.SelectedIndex = self.cmbTopReo.SelectedIndex = 1
        self.cmbBtmMesh.SelectedIndex = self.cmbTopMesh.SelectedIndex = 1
        self.rdoBtmBarsN.IsChecked = self.rdoTopBarsN.IsChecked = True
        self.txbBtmSpacing.Text = self.txbTopSpacing.Text = "250"
        self.txbBtm.Text = self.txbTop.Text = "3"
        
        self.cmbUsage.SelectedIndex = 0
        self.cmbConc.SelectedIndex = 1

        self.rdoUbar.IsChecked = self.rdoLigN.IsChecked = True
        self.cmbLigSize.SelectedIndex = 1
        self.on_reo_conditions_changed(self, None)
        self.on_reo_type_changed(self, None)

    def initialize_ui(self):
        # Path to the image
        img_path = Path.Combine(script_path, "Pad Footing.png")

        # Load the image WITHOUT locking the file
        stream = FileStream(img_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
        bitmap = BitmapImage()
        bitmap.BeginInit()
        bitmap.CacheOption = BitmapCacheOption.OnLoad  # load into memory to release file lock
        bitmap.StreamSource = stream
        bitmap.EndInit()
        bitmap.Freeze()  # Makes it usable across threads (recommended)
        stream.Close()   # Close to release the file lock

        # Set image source (make sure x:Name="imgBeam" in your XAML)
        self.imgPier.Source = bitmap

    def on_usage_changed(self, sender, args):
        if self.cmbUsage.SelectedIndex >= 0:
            self.txbCategory.Text = categ_List[self.cmbUsage.SelectedIndex]
            self.txbComments.Text = "ADD COMMENT HERE"
            
            self.usage_type = self.cmbUsage.SelectedItem
            if self.usage_type in exceptions:
                self.usage_sufix = fixed_code[exceptions.index(self.usage_type)]
            else:
                self.usage_sufix = ''.join([word[0] for word in self.usage_type.split()])

            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks

    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)

    def on_comment_changed(self, sender, args):
        if self.txbComments.Text == "ADD COMMENT HERE":
            self.txbComments.Foreground = Brushes.LightGray
        else:
            self.txbComments.Foreground = Brushes.Black

    def on_text_box_leave(self, sender, args):
        if sender.Text == "":
            if sender == self.txbCover:
                sender.Text = "50"
            else:
                sender.Text = "500"
 
    def on_square_changed(self, sender, args):
        if self.chbSqr.IsChecked:
            self.txbLength.Text = self.txbWidth.Text
        self.txbLength.IsEnabled = not self.chbSqr.IsChecked

    def on_reo_conditions_changed(self, sender, args):
        _true = Visibility.Visible
        _false = Visibility.Collapsed
        if self.chbMassConc.IsChecked:
            self.btmGroup.IsEnabled = self.topGroup.IsEnabled = self.ligsGroup.IsEnabled = False
            self.chbBtmReo.IsChecked = False
            self.chbTopReo.IsChecked = False
            if self.chbAutoReo.IsChecked:
                self.txbReoSummary.Text = "MASS CONCRETE"
        
        else:
            self.btmGroup.IsEnabled = self.topGroup.IsEnabled = self.ligsGroup.IsEnabled = True
            
            self.optionsBtm.IsEnabled = self.layoutBtm.IsEnabled = self.chbBtmReo.IsChecked
            self.optionsTop.IsEnabled = self.layoutTop.IsEnabled = self.chbTopReo.IsChecked
            
            # Bottom Reo conditions
            self.cmbBtmReo.Visibility = self.barsNumberBtm.Visibility = self.btmSpacing.Visibility = self.cmbBtmMesh.Visibility = _false
            if self.rdoBtmBarsN.IsChecked:
                self.cmbBtmReo.Visibility = self.barsNumberBtm.Visibility = _true
            elif self.rdoBtmBarsS.IsChecked:
                self.cmbBtmReo.Visibility = self.btmSpacing.Visibility = _true
            elif self.rdoBtmMesh.IsChecked:
                self.cmbBtmMesh.Visibility = _true

            # Top Reo conditions
            self.cmbTopReo.Visibility = self.barsNumberTop.Visibility = self.topSpacing.Visibility = self.cmbTopMesh.Visibility = _false
            if self.rdoTopBarsN.IsChecked:
                self.cmbTopReo.Visibility = self.barsNumberTop.Visibility = _true
            elif self.rdoTopBarsS.IsChecked:
                self.cmbTopReo.Visibility = self.topSpacing.Visibility = _true
            elif self.rdoTopMesh.IsChecked:
                self.cmbTopMesh.Visibility = _true

            # Ligatures conditions
            if not self.chbLigs.IsChecked:
                self.chbEw.IsChecked = self.chbEw.IsEnabled = self.groupLig1.IsEnabled = False
                self.groupLig2.Visibility = self.groupLig3.Visibility = _false
            elif self.chbLigs.IsChecked and not self.chbEw.IsChecked:
                self.groupLig1.IsEnabled = self.chbEw.IsEnabled = True
                self.groupLig2.Visibility = self.groupLig3.Visibility = _true
            elif self.chbLigs.IsChecked and self.chbEw.IsChecked:
                self.groupLig1.IsEnabled = False
                self.groupLig2.Visibility = self.groupLig3.Visibility = _false

            if self.chbAutoReo.IsChecked:
                self.reinf_text(self, None)

    def on_lig_type_changed(self, sender, args):
        if self.rdoLigR.IsChecked:
            self.cmbLigSize.ItemsSource = R_list
            self.cmbLigSize.SelectedIndex = 1
        elif self.rdoLigN.IsChecked:
            self.cmbLigSize.ItemsSource = N_list
            self.cmbLigSize.SelectedIndex = 1

    def on_reo_type_changed(self, sender, args):
        if sender == self.spnBtm1:
            val = int(self.txbBtm.Text)
            self.txbBtm.Text = str(val - 1) if val - 1 > 1 else str(val)
        elif sender == self.spnBtm2:
            self.txbBtm.Text = str(int(self.txbBtm.Text) + 1)

        if sender == self.spnTop1:
            val = int(self.txbTop.Text)
            self.txbTop.Text = str(val - 1) if val - 1 > 1 else str(val)
        elif sender == self.spnTop2:
            self.txbTop.Text = str(int(self.txbTop.Text) + 1)

        if self.chbAutoReo.IsChecked:
            self.reinf_text(self, None)

    def on_auto_reinf_changed(self, sender, args):
        global aux_reo
        if self.chbAutoReo.IsChecked == False:
            self.txbReoSummary.Text = aux_reo
            self.txbReoSummary.IsEnabled = True
        else:
            aux_reo = self.txbReoSummary.Text
            self.reinf_text(self, None)

    def reinf_text(self, sender, args):
        Reinf = ""
        btm_reo = ""
        top_reo = ""
        lig_reo = ""
        top_ew = ""
        btm_ew = ""

        if self.chbLigs.IsChecked and self.chbEw.IsChecked and not self.rdoBtmMesh.IsChecked:
            btm_ew = " E/W."
        else:
            btm_ew = "."

        if self.chbLigs.IsChecked and self.chbEw.IsChecked and not self.rdoTopMesh.IsChecked:
            top_ew = " E/W."
        else:
            top_ew = "."

        no_bars_btm = self.txbBtm.Text
        bartype_btm = self.cmbBtmReo.SelectedItem
        spacing_btm = self.txbBtmSpacing.Text
        slbmesh_btm = self.cmbBtmMesh.SelectedItem

        if self.chbBtmReo.IsChecked:
            if self.rdoBtmBarsN.IsChecked:
                btm_reo = no_bars_btm + "/" + bartype_btm
            elif self.rdoBtmBarsS.IsChecked:
                btm_reo = bartype_btm + "-" + spacing_btm
            elif self.rdoBtmMesh.IsChecked:
                btm_reo = slbmesh_btm

        no_bars_top = self.txbTop.Text
        bartype_top = self.cmbTopReo.SelectedItem
        spacing_top = self.txbTopSpacing.Text
        slbmesh_top = self.cmbTopMesh.SelectedItem

        if self.chbTopReo.IsChecked:
            if self.rdoTopBarsN.IsChecked:
                top_reo = no_bars_top + "/" + bartype_top
            elif self.rdoTopBarsS.IsChecked:
                top_reo = bartype_top + "-" + spacing_top
            elif self.rdoTopMesh.IsChecked:
                top_reo = slbmesh_top
        
        
        if btm_reo and btm_reo == top_reo:
            Reinf = btm_reo + " TOP & BTM" + btm_ew
            
        else:
            if top_reo and btm_reo:
                Reinf = top_reo + " TOP" + top_ew + ", " + btm_reo + " BTM" + btm_ew
            elif top_reo and not btm_reo:
                Reinf = top_reo + " TOP" + top_ew
            elif not top_reo and btm_reo:
                Reinf = btm_reo + " BTM" + btm_ew
        
        if self.chbLigs.IsChecked and not self.chbEw.IsChecked and self.cmbLigSize.SelectedIndex >= 0:
            if self.rdoUbar.IsChecked:
                lig_reo = " " + self.cmbLigSize.SelectedItem + " 'U' BARS @" + self.txbLigSpacing.Text + "CRS."
            elif self.rdoLigs.IsChecked:
                lig_reo = " " + self.cmbLigSize.SelectedItem + " LIGS @" + self.txbLigSpacing.Text + "CRS."

            
        if self.chbAutoReo.IsChecked:        
            self.txbReoSummary.Text = Reinf + lig_reo if Reinf + lig_reo != "" else "MASS CONCRETE"

    def float_numb(self, control):
        if control:
            return float(control.replace("N","").replace("R",""))
        else:
            return ""

    def max_spacing(self, dst, nmb, cvr):
        d = float(dst); n = int(nmb); c = float(cvr)
        if n > 2:
            return (d - 2*c) / (n - 1)
        else:
            return d - 2*c

    def check_is_last_item(self):
        check = (
            self.cmbUsage.SelectedItem + self.cmbConc.SelectedItem + self.txbMark.Text +
            self.txbCategory.Text + self.txbComments.Text +
            self.txbWidth.Text + self.txbLength.Text + self.txbDepth.Text + self.txbCover.Text +
            self.cmbBtmReo.SelectedItem + self.txbBtm.Text + self.txbBtmSpacing.Text + self.cmbBtmMesh.SelectedItem +
            self.cmbTopReo.SelectedItem + self.txbTop.Text + self.txbTopSpacing.Text + self.cmbTopMesh.SelectedItem +
            self.cmbLigSize.SelectedItem + self.txbLigSpacing.Text
            )
        check += ("y" if self.chbMassConc.IsChecked else "n")
        check += ("y" if self.chbBtmReo.IsChecked else "n") + ("y" if self.rdoBtmBarsN.IsChecked else "n") + ("y" if self.rdoBtmBarsS.IsChecked else "n") + ("y" if self.rdoBtmMesh.IsChecked else "n")
        check += ("y" if self.chbTopReo.IsChecked else "n") + ("y" if self.rdoTopBarsN.IsChecked else "n") + ("y" if self.rdoTopBarsS.IsChecked else "n") + ("y" if self.rdoTopMesh.IsChecked else "n")
        check += ("y" if self.chbLigs.IsChecked else "n") + ("y" if self.chbEw.IsChecked else "n") + ("y" if self.rdoUbar.IsChecked else "n") + ("y" if self.rdoLigs.IsChecked else "n")
        check += ("y" if self.rdoLigN.IsChecked else "n") + ("y" if self.rdoLigR.IsChecked else "n") + ("y" if self.chbAutoReo.IsChecked else "n")

        return check

    def on_add_item(self, sender, args):
        global Load_List

        if all([float(self.txbWidth.Text) > 100, float(self.txbDepth.Text) > 100, float(self.txbLength.Text) > 100]):
            if self.chbSqr.IsChecked:
                selected_size_gral = self.txbWidth.Text + "Sqr x " + self.txbDepth.Text + "d"
                selected_size_resd = self.txbWidth.Text + " SQR x " + self.txbDepth.Text + " DEEP"
            else:
                selected_size_gral = self.txbWidth.Text + "w x " + self.txbLength.Text + "lg x " + self.txbDepth.Text + "d"
                selected_size_resd = self.txbWidth.Text + " WIDE x " + self.txbLength.Text + " LONG x " + self.txbDepth.Text + " DEEP"

            selected_type_mark = self.txbMark.Text
            new_name = (selected_type_mark + " - " + selected_size_gral)
            self.lsbNewItems.Items.Add(new_name)
            
            new_line = []
            fam_path = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Foundations", "STP_Pad Footing.rfa")
            fam_type = "PF base" # Fix these two when doing in the office

            family_block = [fam_name, new_name, fam_path, fam_type]
            new_line.append(family_block)

            stp_comment = ". " + self.txbComments.Text if self.txbComments.Text != "ADD COMMENT HERE" else ""
            par_schedule = (("STP Schedule", "G"))
            par_category = (("STP Category", self.txbCategory.Text))
            par_stp_size = (("STP_Size", selected_size_gral))
            par_stp_comm = (("STP_Comment", self.cmbUsage.SelectedItem + stp_comment))
            par_res_comm = (("Type Comments", self.cmbUsage.SelectedItem + stp_comment))
            par_typ_mark = (("Type Mark",selected_type_mark))
            par_concrete = (("STP_Concrete Grade/Fill", self.cmbConc.SelectedItem))
            par_reinforc = (("STP_Reinforcement", self.txbReoSummary.Text))
            par_cover = (("STP_Cover", self.txbCover.Text))

            # For residential
            if res_type:
                par_stp_size = (("STP_Size", selected_size_resd))
                #par_cover = (("STP_Cover", self.txbCover.Text + "mm")) #Removed, put it back if needed
            general_block = [par_schedule, par_category, par_stp_size, par_stp_comm, par_res_comm, par_typ_mark, par_concrete, par_reinforc, par_cover]
            new_line.append(general_block)

            top_r = (self.chbTopReo.IsChecked and not self.chbMassConc.IsChecked and not self.rdoTopMesh.IsChecked)
            btm_r = (self.chbBtmReo.IsChecked and not self.chbMassConc.IsChecked and not self.rdoBtmMesh.IsChecked)
            lig_r = (self.chbLigs.IsChecked and not self.chbEw.IsChecked and not self.chbMassConc.IsChecked)
            top_m = (self.chbTopReo.IsChecked and not self.chbMassConc.IsChecked and self.rdoTopMesh.IsChecked)
            btm_m = (self.chbBtmReo.IsChecked and not self.chbMassConc.IsChecked and self.rdoBtmMesh.IsChecked)
            mesh = ""
            if self.rdoBtmMesh.IsChecked:
                mesh = self.cmbBtmMesh.SelectedItem
            if self.rdoTopMesh.IsChecked and not self.rdoBtmMesh.IsChecked:
                mesh = self.cmbTopMesh.SelectedItem

            top_s = self.txbTopSpacing.Text if self.rdoTopBarsS.IsChecked else self.max_spacing(self.txbWidth.Text, self.txbTop.Text, self.txbCover.Text)
            btm_s = self.txbBtmSpacing.Text if self.rdoBtmBarsS.IsChecked else self.max_spacing(self.txbWidth.Text, self.txbBtm.Text, self.txbCover.Text)

            params_block = []
            par_1 = (("Include Top Reo", 1 if top_r else 0))
            par_2 = (("Top Bar Size", self.float_numb(self.cmbTopReo.SelectedItem)))
            par_3 = (("Top Bars Max Spacing", top_s))
            par_4 = (("Include Btm Reo", 1 if btm_r else 0))
            par_5 = (("Btm Bar Size", self.float_numb(self.cmbBtmReo.SelectedItem)))
            par_6 = (("Btm Bars Max Spacing", btm_s))
            par_7 = (("Add Ligatures", 1 if lig_r else 0 ))
            par_8 = (("Lig Type", "N" if self.rdoLigN.IsChecked else "R"))
            par_9 = (("Lig Size", self.float_numb(self.cmbLigSize.SelectedItem)))
            par_10 = (("Lig Spacing", self.txbLigSpacing.Text))
            par_11 = (("Top Slab Mesh", 1 if top_m else 0))
            par_12 = (("Bottom Slab Mesh", 1 if btm_m else 0))
            par_13 = (("Mesh Type", mesh))
            par_14 = (("Length", self.txbWidth.Text if self.chbSqr.IsChecked else self.txbLength.Text))
            par_15 = (("Width", self.txbWidth.Text))
            par_16 = (("Pad Depth", self.txbDepth.Text))
            par_17 = (("TB Cover", self.txbCover.Text))
            par_18 = (("Footing_Width", self.txbWidth.Text))
            par_19 = (("Footing_Depth", self.txbDepth.Text))
            par_20 = (("Footing_Length", self.txbWidth.Text if self.chbSqr.IsChecked else self.txbLength.Text))

            params_block = [par_1 , par_2 , par_3 , par_4 , par_5 , par_6 , par_7 , par_8 , par_9 , par_10 , par_11 , par_12 , par_13, par_14 , par_15 , par_16, par_17, par_18 , par_19, par_20]
            new_line.append(params_block)

            Load_List.append(new_line)

            # Update Type Mark List Box
            type_mark_list_name = selected_type_mark + " - " + selected_size_gral
            type_Marks_List.append((selected_type_mark, type_mark_list_name))
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks
            self.check_string = self.check_is_last_item()
        else:
            forms.alert(
                "Error: Check Dimension Values.",
                title="Warning",
                warn_icon=True  # This shows the warning (exclamation) icon
            )

    def remove_item(self, sender, args):
        global Load_List
        selected_index = self.lsbNewItems.SelectedIndex
        if selected_index >= 0:
            self.lsbNewItems.Items.RemoveAt(selected_index)
            del Load_List[selected_index]
            del type_Marks_List[selected_index + len(type_Marks_Grey)]

        # Update Type Mark List Box
        filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
        self.txbMark.Text = self.next_type_mark
        self.lsbMarks.ItemsSource = filtered_type_marks

    def close_form(self, sender, args):
        self.Close()

    def load_families(self, sender, args):
        final_check = self.check_is_last_item()
        if final_check == self.check_string: # Check if there are modifications in elements before load
            self.go_for_load = True
            self.Close()
        else:
            result = forms.alert(
                "The last item hasn't been added to the list. Do you want to continue loading without it?",
                title="Confirm Add",
                yes=True,
                no=True
            )
            if result:
                go_for_load = True
                self.Close()


# Show the form
form = PadFootinForm(xaml_file_name)
form.ShowDialog()

#-----------------------------------------------------------------------------------
#-------------COPY FAMILY INSTANCE AND ADD PARAMETERS-------------------------------
# region ---------------------------------------------------------------------------
stage = "Load Family and Parameters"
if form.go_for_load and Load_List:
    try:
        local_state, local_report = load_families_and_parameters(doc, Load_List)
    except Exception as e:
        local_report = str(e)
    final_report += local_report
else:
    sys.exit()

# endregion

#--------------------------------------------------------------------
#----------- REPORT SAVING TIME TO DATA BASE ------------------------
# region ------------------------------------------------------------
stage = "Tracking Data"
file_path = os.path.join(Lib_Path, "STP Tracking", "Data.txt")
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if os.path.exists(file_path):
    final_report += fill_tracking_data(file_path, p_Numb, user_name, "Load Pad Footings", "4", start_time, end_time, str(len(Load_List)), stage)

# endregion


#print(final_report)




