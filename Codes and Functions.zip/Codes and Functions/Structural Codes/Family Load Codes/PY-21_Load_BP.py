#-----------------------------------------------------------------------------------
#-------------------------- PY-11_Load_Bored_Piers.py ------------------------------
#-----------------------------------------------------------------------------------

# Load Libraries
#---------------
import sys
import os
import time
import traceback
from datetime import datetime
from pyrevit import forms, DB, script

from System import Action
from System.Windows import Visibility
from System.Windows.Controls import ListBoxItem
from System.Windows.Media import Brushes

from System.Windows.Threading import DispatcherPriority
from Autodesk.Revit.DB import BuiltInParameter
from System.IO import Path, FileStream, FileMode, FileAccess, FileShare
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption

Lib_Path = revit_library_path # This path comes from the script.py file in the push button folder
functions_path = Lib_Path + r"\Codes and Functions\Structural Codes\STP_Functions"
sys.path.append(functions_path)
import Family_load_functions
from Family_load_functions import *

import STP_Tools_Functions
from STP_Tools_Functions import *

# Constants
#----------
doc = __revit__.ActiveUIDocument.Document
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
user_name = os.environ.get("USERNAME")
exceptions, fixed_code = exceptions()

# General_Variables
#------------------
final_report = ""
script_path = script.get_script_path()
Load_List = []
proj_info = doc.ProjectInformation
p_Numb = proj_info.get_Parameter(DB.BuiltInParameter.PROJECT_NUMBER).AsString()
aux_reo = ""

# Local Variables (General, Resid, McDonalds)
#------------------
family_types = "Bored Piers"
xaml_file_name = "Bored Pier Form.axml"
N_list = ["N10", "N12", "N16", "N20", "N22", "N24"]
R_list = ["R6", "R8", "R10"]
T_list = ["L11TM", "L12TM", "L14TM"]
res_param = proj_info.LookupParameter("Suburb")
res_type = True if res_param and res_param.HasValue else False

if res_type:
    fam_name = "Bored Pier-Footing"
    fam_type = "BP Base"
else:
    fam_name = "STP_Bored Pier"
    fam_type = "BP Base"

def update_this_form(form_path):
    local_path = os.path.join(form_path, "Bored Pier Form.axml")
    share_path = Lib_Path + r"\STP Tools Installer\STP.extension\STP Structural\Load Concrete Families.Panel\BoredPier.pushbutton\Bored Pier Form.axml"
    shutil.copy2(share_path, local_path)
    forms.alert(
        "The local 'Bored Pier' form has been updated automatically to the latest version.\n\n"
        "No further action is required. Please run the command again to load the family.",
        title="Form Updated Successfully"
    )

#------------------------------------------------------------------------------------
#----------- PRE-FORM CHECK AND LOAD ------------------------------------------------
# region ----------------------------------------------------------------------------
stage = "Preliminar Checks"

check_all_good = [os.path.exists(Lib_Path), os.path.exists(functions_path)]
if not all (check_all_good):
    forms.alert("Internal error [E00]. Please report it to STP Tools developer", "Error")
    sys.exit()

# Get Usage and Category List for Form
local_report, usage_List, categ_List, index_List, type_List = usage_categ_famtype_list(Lib_Path, family_types, stage)
final_report += local_report

# endregion

#-----------------------------------------------------------------------------------
#----------- GET EXISTING MEMBERS AND TYPE MARKS -----------------------------------
# region ---------------------------------------------------------------------------
stage = "Get Existing Type Mark List: "

collector = DB.FilteredElementCollector(doc)
instance_types = collector.OfClass(DB.FamilySymbol)\
                        .OfCategory(DB.BuiltInCategory.OST_StructuralFoundation)\
                        .ToElements() #                ^^^^^^--CHANGE--^^^^^^

try:
    local_report, type_Marks_List, type_Marks_Grey = create_Type_Mark_List(instance_types, stage)
    final_report += local_report
except Exception as e:
    final_report += u"\u274C Stage: " + stage + " Fail.\n" + str(e)


# endregion

#-----------------------------------------------------------------------------------
#-------------------------- MAIN WINDOW FORM ---------------------------------------
#-----------------------------------------------------------------------------------
class BoredPierForm(forms.WPFWindow):
    def __init__(self, xaml_file_path):
        forms.WPFWindow.__init__(self, xaml_file_path)
        self.initialize_ui()
        try:
            version = float(self.lblVersion.Content)
        except:
            update_this_form(script_path)
            sys.exit()
            
        current_version = 2.10
        if version < current_version:
            update_this_form(script_path)
            sys.exit()

        self.next_type_mark = ""
        self.usage_type = ""
        self.usage_sufix = ""
        self.path_txt_file = ""
        self.path_rfa_file = ""
        self.check_string = ""
        self.go_for_load = False
        global Load_List
 
        # Hook up buttons
        #--------------------- General ----------------------------
        self.cmbUsage.SelectionChanged += self.on_usage_changed
        self.txbComments.GotFocus += self.on_text_box_focus
        self.txbComments.TextChanged += self.on_comment_changed
        self.txbCategory.GotFocus += self.on_text_box_focus
        #-------------------- Geometry ----------------------------
        self.txbDiameter.GotFocus += self.on_text_box_focus
        self.txbDiameter.LostFocus += self.on_text_box_leave
        self.txbDepth.GotFocus += self.on_text_box_focus
        self.txbDepth.LostFocus += self.on_text_box_leave
        self.txbCover.GotFocus += self.on_text_box_focus
        self.chbMassConc.Click += self.on_reo_conditions_changed
        self.chbVaries.Click += self.on_varies_changed
        #-------------------- Longitudinal ------------------------
        self.cmbReo.SelectionChanged += self.on_reo_type_changed
        self.spnReo1.Click += self.on_reo_type_changed
        self.spnReo2.Click += self.on_reo_type_changed
        #-------------------- Ligatures ---------------------------
        self.chbLigs.Click += self.on_reo_conditions_changed
        self.rdoLigR.Click += self.on_reo_type_changed
        self.rdoLigN.Click += self.on_reo_type_changed
        self.cmbLigSize.SelectionChanged += self.on_reo_type_changed
        self.txbLigSpacing.TextChanged += self.on_reo_type_changed
        #-------------------- Auto-Reinf --------------------------
        self.chbAutoReo.Click += self.on_auto_reinf_changed
        #-------------------- Buttons -----------------------------
        self.btnAdd.Click += self.on_add_item
        self.btnRemove.Click += self.remove_item
        self.btnLoad.Click += self.load_families
        self.btnCancel.Click += self.close_form


        # Populate dropdowns and listboxes
        self.cmbUsage.ItemsSource = usage_List
        self.cmbConc.ItemsSource = ["N20", "N25", "N32", "N40"]
        self.txbDiameter.Text = "450"
        self.txbDepth.Text = "1500"
        self.txbCover.Text = "50"
        
        self.cmbReo.ItemsSource = N_list
        self.txbReo.Text = "6"
        
        self.cmbLigSize.ItemsSource = R_list
        self.cmbLigSize.SelectedIndex = 0
        #self.on_reo_conditions_changed(self, None)

        # Activate Initial Conditions
        if res_type:
            self.cmbUsage.SelectedItem = "PIER"
        else:
            self.cmbUsage.SelectedItem = "BORED PIER"
        self.cmbReo.SelectedIndex = 2
        self.chbAutoReo.IsChecked = True
        self.cmbConc.SelectedIndex = 0
        self.rdoLigR.IsChecked = True
        self.chbLigs.IsChecked = True
        self.reinf_text(self, None)

    def initialize_ui(self):
        # Path to the image
        img_path = Path.Combine(script_path, "Bored Pier.png")

        # Load the image WITHOUT locking the file
        stream = FileStream(img_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
        bitmap = BitmapImage()
        bitmap.BeginInit()
        bitmap.CacheOption = BitmapCacheOption.OnLoad  # load into memory to release file lock
        bitmap.StreamSource = stream
        bitmap.EndInit()
        bitmap.Freeze()  # Makes it usable across threads (recommended)
        stream.Close()   # Close to release the file lock

        # Set image source (make sure x:Name="imgPier" in your XAML)
        self.imgPier.Source = bitmap

    def on_usage_changed(self, sender, args):
        if self.cmbUsage.SelectedIndex >= 0:
            self.txbCategory.Text = categ_List[self.cmbUsage.SelectedIndex]
            self.txbComments.Text = "ADD COMMENT HERE"
            
            self.usage_type = self.cmbUsage.SelectedItem
            if self.usage_type in exceptions:
                self.usage_sufix = fixed_code[exceptions.index(self.usage_type)]
            else:
                self.usage_sufix = ''.join([word[0] for word in self.usage_type.split()])
            
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks

    def on_text_box_focus(self, sender, args):
        def select_all_callback():
            sender.SelectAll()
        sender.Dispatcher.BeginInvoke(Action(select_all_callback), DispatcherPriority.Input)

    def on_text_box_leave(self, sender, args):
        if sender.Text == "":
            sender.Text = "100"

    def on_comment_changed(self, sender, args):
        if self.txbComments.Text == "ADD COMMENT HERE":
            self.txbComments.Foreground = Brushes.LightGray
        else:
            self.txbComments.Foreground = Brushes.Black

    def on_reo_conditions_changed(self, sender, args):
        if self.chbMassConc.IsChecked:
            self.longGruop.IsEnabled = self.ligsGroup.IsEnabled = False
            if self.chbAutoReo.IsChecked == True:
                self.txbReoSummary.Text = "MASS CONCRETE"
        else:
            self.longGruop.IsEnabled = self.ligsGroup.IsEnabled = True

            if self.chbLigs.IsChecked:
                self.groupLig1.IsEnabled = self.groupLig2.IsEnabled = True
            else:
                self.groupLig1.IsEnabled = self.groupLig2.IsEnabled = False
            
            self.reinf_text(self, None)

    def on_reo_type_changed(self, sender, args):
        if sender == self.spnReo1:
            val = int(self.txbReo.Text)
            self.txbReo.Text = str(val - 1) if val - 1 >= 0 else str(val)
        elif sender == self.spnReo2:
            self.txbReo.Text = str(int(self.txbReo.Text) + 1)

        if sender == self.rdoLigR:
            self.cmbLigSize.ItemsSource = R_list
            self.cmbLigSize.SelectedIndex = 0
        elif sender == self.rdoLigN:
            self.cmbLigSize.ItemsSource = N_list
            self.cmbLigSize.SelectedIndex = 0

        if self.chbAutoReo.IsChecked == True:
            self.reinf_text(self, None)
    
    def on_varies_changed(self, sender, args):
        self.txbDepth.IsEnabled = not(sender.IsChecked)

    def reinf_text(self, sender, args):
        Reinf = ""
        if self.txbReo.Text != "0":
            Reinf = self.txbReo.Text + "/" + self.cmbReo.SelectedItem
            if self.chbLigs.IsChecked and self.cmbLigSize.SelectedIndex >= 0:
                #print("here")
                Reinf += " VERT. " + self.cmbLigSize.SelectedItem + " LIGS @" + self.txbLigSpacing.Text + "CRS."
            else:
                Reinf += " VERTICAL."

        if self.chbAutoReo.IsChecked:
            self.txbReoSummary.Text = Reinf

    def on_auto_reinf_changed(self, sender, args):
        global aux_reo
        if self.chbAutoReo.IsChecked == False:
            self.txbReoSummary.Text = aux_reo
            self.txbReoSummary.IsEnabled = True
        else:
            aux_reo = self.txbReoSummary.Text
            self.reinf_text(self, None)

    def check_is_last_item(self):
        check = (
            self.cmbUsage.SelectedItem + self.cmbConc.SelectedItem + self.txbMark.Text + 
            self.txbCategory.Text + self.txbComments.Text + 
            self.txbDiameter.Text + self.txbDepth.Text + self.txbCover.Text +
            self.txbReo.Text + self.cmbReo.SelectedItem +   
            self.txbLigSpacing.Text + self.cmbLigSize.SelectedItem
            )
        check += ("y" if self.chbLigs.IsChecked else "n")
        return check

    def on_add_item(self, sender, args):
        global Load_List
        family_block = []
        general_block = []
        params_block = []

        if all([float(self.txbDiameter.Text) > 100, float(self.txbDepth.Text) > 100]):
            selected_size_gral = self.txbDiameter.Text + "dia x " + ("DEPTH VARIES" if self.chbVaries.IsChecked else self.txbDepth.Text + "d")
            selected_size_resd = u"\xd8" + self.txbDiameter.Text + " X " + ("DEPTH VARIES" if self.chbVaries.IsChecked else self.txbDepth.Text + " MIN. DEEP")
            selected_type_mark = self.txbMark.Text
            new_name = (selected_type_mark + " - " + selected_size_gral)
            if res_type:
                new_name = u"\xd8" + self.txbDiameter.Text + " BORED PIER (" + selected_type_mark + ")"
            self.lsbNewItems.Items.Add(new_name)
            
            new_line = []
            fam_path = os.path.join(Lib_Path.replace("STP Tools","STP Structural"), "Foundations", fam_name + ".rfa")

            family_block = [fam_name, new_name, fam_path, fam_type]
            new_line.append(family_block)

            stp_comment = ". " + self.txbComments.Text if self.txbComments.Text != "ADD COMMENT HERE" else ""
            par_schedule = (("STP Schedule", "G"))
            par_category = (("STP Category", self.txbCategory.Text))
            par_stp_size = (("STP_Size", selected_size_gral))
            
            par_stp_comm = (("STP_Comment", self.cmbUsage.SelectedItem + stp_comment))
            par_res_comm = (("Type Comments", "BORED PIER " + stp_comment))
            par_typ_mark = (("Type Mark",selected_type_mark))
            par_concrete = (("STP_Concrete Grade/Fill", self.cmbConc.SelectedItem))
            par_reinforc = (("STP_Reinforcement", self.txbReoSummary.Text))
            par_cover = (("STP_Cover", self.txbCover.Text))
            #u'"\xd8450 
            
            if res_type:
                par_stp_size = (("STP_Size", selected_size_resd))
                #par_cover = (("STP_Cover", self.txbCover.Text + "mm"))
            general_block = [par_schedule, par_category, par_stp_size, par_stp_comm, par_res_comm, par_typ_mark, par_concrete, par_reinforc, par_cover]
            new_line.append(general_block)

            #print(general_block)

            params_block = []
            par_w = (("Diameter", self.txbDiameter.Text))
            par_w2 = (("b", self.txbDiameter.Text))
            par_d = (("Length", self.txbDepth.Text))
            par_mcc = (("Mass Concrete", 1 if self.chbMassConc.IsChecked else 0))
            par_lbn = (("No Bars", int(self.txbReo.Text)))
            par_lbs = (("Bars Size", float(self.cmbReo.SelectedItem.replace("N",""))))
            par_lgs = (("Ligs Size", float(self.cmbLigSize.SelectedItem.replace("N","").replace("R",""))))
            par_lsp = (("Ligs Pitch", float(self.txbLigSpacing.Text)))
            #par_ = (("", ))

            params_block = [par_w, par_w2, par_d, par_mcc, par_lbn, par_lbs, par_lgs, par_lsp]
            new_line.append(params_block)
            
            Load_List.append(new_line)
         
            # Update Type Mark List Box
            type_mark_list_name = selected_type_mark + " - " + selected_size_gral
            type_Marks_List.append((selected_type_mark, type_mark_list_name))
            # add filtered type mark function
            filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
            self.txbMark.Text = self.next_type_mark
            self.lsbMarks.ItemsSource = filtered_type_marks
            self.check_string = self.check_is_last_item()
        else:
            forms.alert(
                "Error: Check Width and Depth Parameter.",
                title="Warning",
                warn_icon=True  # This shows the warning (exclamation) icon
            )

    def remove_item(self, sender, args):
        global Load_List
        selected_index = self.lsbNewItems.SelectedIndex
        if selected_index >= 0:
            self.lsbNewItems.Items.RemoveAt(selected_index)
            del Load_List[selected_index]
            del type_Marks_List[selected_index + len(type_Marks_Grey)]

        # Update Type Mark List Box
        filtered_type_marks, self.next_type_mark = filter_type_mark(self.usage_type, self.usage_sufix, type_Marks_List, type_Marks_Grey)
        self.txbMark.Text = self.next_type_mark
        self.lsbMarks.ItemsSource = filtered_type_marks

    def close_form(self, sender, args):
        self.Close()

    def load_families(self, sender, args):
        final_check = self.check_is_last_item()
        if final_check == self.check_string: # Check if there are modifications in elements before load
            self.go_for_load = True
            self.Close()
        else:
            result = forms.alert(
                "The last item hasn't been added to the list. Do you want to continue loading without it?",
                title="Confirm Add",
                yes=True,
                no=True
            )
            if result:
                go_for_load = True
                self.Close()

# Show the form
form = BoredPierForm(xaml_file_name)
form.ShowDialog()

#sys.exit()
#-----------------------------------------------------------------------------------
#-------------COPY FAMILY INSTANCE AND ADD PARAMETERS-------------------------------
# region ---------------------------------------------------------------------------
stage = "Load Family and Parameters"
if form.go_for_load and Load_List:
    try:
        local_state, local_report = load_families_and_parameters(doc, Load_List)
    except Exception as e:
        local_report = str(e)
    final_report += local_report
else:
    sys.exit()

# endregion

#--------------------------------------------------------------------
#----------- REPORT SAVING TIME TO DATA BASE ------------------------
# region ------------------------------------------------------------
stage = "Tracking Data"
file_path = os.path.join(Lib_Path, "STP Tracking", "Data.txt")
end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if os.path.exists(file_path):
    final_report += fill_tracking_data(file_path, p_Numb, user_name, "Load Bored Piers", "4", start_time, end_time, str(len(Load_List)), stage)

# endregion


#print(final_report)




