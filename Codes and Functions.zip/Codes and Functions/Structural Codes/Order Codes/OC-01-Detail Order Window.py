# Load the Python Standard and DesignScript Libraries
import sys
import clr

# Add references for Windows Forms
clr.AddReference('ProtoGeometry')
clr.AddReference('System.Windows.Forms')

from Autodesk.DesignScript.Geometry import *
from System.Windows.Forms import Form, Label, ComboBox, Button, DialogResult, Application, MessageBox, FormStartPosition

clr.AddReference("RevitServices")
clr.AddReference("RevitAPI")
from RevitServices.Persistence import DocumentManager
from Autodesk.Revit.DB import FilteredElementCollector, View, ViewType

doc = DocumentManager.Instance.CurrentDBDocument

# The inputs to this node will be stored as a list in the IN variables.
Views = []
Codes = []

collector = FilteredElementCollector(doc).OfClass(View)
for view in collector:
    # Exclude view templates and invalid views
    if not view.IsTemplate and view.ViewType != ViewType.Internal:
        Views.append(view)
# Extract codes
for view in Views:
    p = view.LookupParameter("Detail Code")
    if p and p.AsString() not in Codes:
        Codes.append(p.AsString())

Codes = Codes[1:]
# Function to show a dropdown dialog
def show_dropdown_dialog(codes):
    class DropdownForm(Form):
        def __init__(self):
            self.Text = "Select Details' Group"
            self.Width = 300
            self.Height = 150
            self.StartPosition = FormStartPosition.CenterScreen

            # Label
            self.label = Label()
            self.label.Text = "Select Details' Group"
            self.label.Top = 10
            self.label.Left = 10
            self.label.Width = 200
            self.Controls.Add(self.label)

            # ComboBox
            self.comboBox = ComboBox()
            self.comboBox.Top = 40
            self.comboBox.Left = 10
            self.comboBox.Width = 200
            for code in Codes:
                self.comboBox.Items.Add(code)  # Populate ComboBox
            self.comboBox.SelectedIndex = 0  # Set default selection
            self.Controls.Add(self.comboBox)

            # OK Button
            self.okButton = Button()
            self.okButton.Text = "OK"
            self.okButton.Top = 80
            self.okButton.Left = 50
            self.okButton.Width = 80
            self.okButton.DialogResult = DialogResult.OK
            self.Controls.Add(self.okButton)

            # Cancel Button
            self.cancelButton = Button()
            self.cancelButton.Text = "Cancel"
            self.cancelButton.Top = 80
            self.cancelButton.Left = 150
            self.cancelButton.Width = 80
            self.cancelButton.DialogResult = DialogResult.Cancel
            self.Controls.Add(self.cancelButton)

            # Set default accept/cancel buttons
            self.AcceptButton = self.okButton
            self.CancelButton = self.cancelButton

    # Display the form and return the selected item
    form = DropdownForm()
    result = form.ShowDialog()
    if result == DialogResult.OK:
        return form.comboBox.SelectedItem
    else:
        return None

# Main logic
if not Codes:
    # Show message if Codes is empty
    message = (
        "Before using this tool, select the details you want to order and add a group code "
        "in the 'Detail Code' Parameter.\n\n"
        "For more information watch the training video in:\n\n"
        "SharePoint / STP Drafting / Drafting Standards / Training Videos / Dynamo Video Tutorial"
    )
    MessageBox.Show(message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
    OUT = None
else:
    selected_code = show_dropdown_dialog(Codes)
    OUT = Views, selected_code
